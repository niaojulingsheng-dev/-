"""他人名義の支払いを、お金が動く前に断って名簿に載せる。

代行(にゃんこ)・ツムツム代行・自販機のどれも、最後は payments の
「送金リンクを受け取る」に集まる。その手前で1回だけ判定する。常に効く。

受け取ってから返すと、こちらの残高と履歴に一度入れて送り返すことになる。
受け取る前に断れば、リンクは送り主の手元に残るので返金が要らない。

断るのは次の3つだけ。どれも普通に買う人には起こらない。

  1. すでに名簿に載っている
  2. 1つの決済アカウントが、何人もの別々のDiscordに払っている
  3. 同じ支払いリンクを、別のDiscordが持ってきた

支払いのやり直し・作りたてのアカウント・金額の大きさ・請求より多い額は
見ない。手間取っているだけの人が当たるので、引数からも外してある。
IPも見ない(Discordからは取れないし、PayPay/Kyashも返さない)。

環境変数:
  RISK_SHARED_SENDER  何人に払ったら断るか(既定4)
  RISK_KEEP_DAYS      結び付きを覚えておく日数(既定180)
"""
import os
import threading
import time
from typing import NamedTuple

from datapath import data_path, read_json, write_json

BLOCK_FILE = data_path("risk_blocks.json")
LEDGER_FILE = data_path("risk_ledger.json")
EVENT_FILE = data_path("risk_events.json")

# 名簿・結び付き・記録はどれも「読んで・足して・書く」。受け取りのスレッドと
# 支払い画面(remember をスレッドに逃がす)が同時に書くと片方が消えるので、
# 書き込みはプロセス内で直列にする。判定(読むだけ)はロックを取らない。
_write_lock = threading.Lock()

ALLOW = "allow"
BLOCK = "block"

DISCORD = "discord"
PAYPAY = "paypay"
KYASH = "kyash"


def _env_int(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, str(default)))
    except ValueError:
        return default


# 3人だと「友達の分をまとめて払う人」が当たるので4から。
SHARED_SENDER_USERS = max(2, _env_int("RISK_SHARED_SENDER", 4))
KEEP_DAYS = _env_int("RISK_KEEP_DAYS", 180)
EVENT_KEEP = _env_int("RISK_EVENT_KEEP", 500)

# 断る理由。これ以外では断らない。
BLOCKED_USER = "blocked_user"
BLOCKED_SENDER = "blocked_sender"
SHARED_SENDER = "shared_sender"
LINK_REUSE = "link_reuse"

REASONS = {
    BLOCKED_USER: "このDiscordアカウントは利用を止めています",
    BLOCKED_SENDER: "この決済アカウントは利用を止めています",
    SHARED_SENDER: "1つの決済アカウントが、複数のDiscordアカウントに支払っています",
    LINK_REUSE: "同じ支払いリンクを、別のDiscordアカウントが持ってきています",
}


class Verdict(NamedTuple):
    """判定の結果。断るときだけ理由が入る。"""
    action: str
    code: str = ""
    detail: str = ""

    @property
    def blocked(self) -> bool:
        return self.action == BLOCK

    @property
    def reason(self) -> str:
        text = REASONS.get(self.code, "")
        return f"{text}（{self.detail}）" if text and self.detail else text


ALLOWED = Verdict(ALLOW)


def _deny(code: str, detail: str = "") -> Verdict:
    return Verdict(BLOCK, code, detail)


# ---- 名簿 ----

def _blocks() -> dict:
    data = read_json(BLOCK_FILE, {})
    for key in (DISCORD, PAYPAY, KYASH):
        data.setdefault(key, {})
    return data


def is_blocked(kind: str, ident) -> dict:
    """止めているなら記録を返す。止めていなければ None。"""
    if not ident:
        return None
    return _blocks().get(kind, {}).get(str(ident))


def block(kind: str, ident, *, reason: str, by: str = "auto",
          evidence: str = "") -> bool:
    """名簿に載せる。すでに載っていれば理由を上書きしない(最初の理由を残す)。"""
    if not ident:
        return False
    with _write_lock:
        data = _blocks()
        table = data.setdefault(kind, {})
        key = str(ident)
        if key in table:
            return False
        table[key] = {"ts": time.time(), "reason": (reason or "")[:300],
                      "by": by, "evidence": (evidence or "")[:500]}
        write_json(BLOCK_FILE, data)
    print(f"[RISK] 名簿に追加 {kind}={key} by={by} {reason}", flush=True)
    return True


def unblock(kind: str, ident, *, by: str = "admin", note: str = "") -> bool:
    """名簿から外す。誤検知だったときに、その場で戻せるようにしておく。"""
    if not ident:
        return False
    with _write_lock:
        data = _blocks()
        if data.get(kind, {}).pop(str(ident), None) is None:
            return False
        write_json(BLOCK_FILE, data)
    print(f"[RISK] 解除 {kind}={ident} by={by} {note}", flush=True)
    return True


def blocked_list(kind: str = None) -> list:
    """止めている一覧。新しい順。解除の画面で候補を出すのに使う。"""
    data = _blocks()
    kinds = [kind] if kind else (DISCORD, PAYPAY, KYASH)
    out = []
    for k in kinds:
        for ident, info in (data.get(k) or {}).items():
            out.append({"kind": k, "id": ident, **info})
    return sorted(out, key=lambda x: -(x.get("ts") or 0))


# ---- これまでの結び付き(誰がどの決済アカウントで払ったか) ----

def _ledger() -> dict:
    data = read_json(LEDGER_FILE, {})
    data.setdefault("senders", {})
    data.setdefault("links", {})
    return data


def _sender_key(method: str, sender_id) -> str:
    return f"{method}:{sender_id}" if sender_id else ""


def link_key(method: str, link: str) -> str:
    """リンクの鍵。末尾のコードだけ使うので、貼り方が違っても同じ鍵になる。"""
    code = (link or "").strip().rstrip("/").rsplit("/", 1)[-1]
    return f"{method}:{code}" if code else ""


def remember(user_id, *, method: str, sender_id: str = "", sender_name: str = "",
             link: str = "", amount: int = 0):
    """支払いが通ったことを覚える。判定はこの積み重ねで決まる。

    ここで失敗しても支払いは止めない。
    """
    try:
        with _write_lock:
            data = _ledger()
            now = time.time()
            skey = _sender_key(method, sender_id)
            if skey:
                sender = data["senders"].setdefault(
                    skey, {"first_seen": now, "name": "", "users": {}})
                sender["last_seen"] = now
                if sender_name:
                    sender["name"] = str(sender_name)[:60]
                seen = sender["users"].setdefault(str(user_id), {"count": 0, "first": now})
                seen["count"] += 1
                seen["last"] = now
            lkey = link_key(method, link)
            if lkey:
                data["links"][lkey] = {"ts": now, "user_id": str(user_id),
                                       "amount": max(0, int(amount or 0))}
            _purge(data)
            write_json(LEDGER_FILE, data)
    except Exception as e:
        print(f"[RISK REMEMBER ERROR] {e}", flush=True)


def _purge(data: dict):
    limit = time.time() - KEEP_DAYS * 86400
    data["links"] = {k: v for k, v in data["links"].items()
                     if float(v.get("ts") or 0) >= limit}
    for key, sender in list(data["senders"].items()):
        if float(sender.get("last_seen") or sender.get("first_seen") or 0) < limit:
            del data["senders"][key]


def sender_users(method: str, sender_id: str) -> dict:
    """その決済アカウントが払ってきたDiscordアカウント {id: {...}}。"""
    skey = _sender_key(method, sender_id)
    return (_ledger()["senders"].get(skey) or {}).get("users") or {}


def link_owner(method: str, link: str) -> dict:
    """そのリンクが前に誰の注文で使われたか。無ければ None。"""
    lkey = link_key(method, link)
    return _ledger()["links"].get(lkey) if lkey else None


# ---- 判定 ----

def screen_payment(user_id, *, method: str, sender_id: str = "",
                   sender_name: str = "", link: str = "") -> Verdict:
    """受け取ってよいか。お金を動かす直前に呼ぶ。"""
    if is_blocked(DISCORD, user_id):
        return _deny(BLOCKED_USER)
    if sender_id and is_blocked(method, sender_id):
        return _deny(BLOCKED_SENDER, sender_name or str(sender_id))

    # 名義の使い回し。自分の分を自分で払っている限り、人数は1のまま増えない。
    if sender_id:
        users = set(sender_users(method, sender_id)) | {str(user_id)}
        if len(users) >= SHARED_SENDER_USERS:
            return _deny(SHARED_SENDER, f"{len(users)}アカウント")

    # 同じ人が払い直すのは普通なので、別の人が持ってきたときだけ断る。
    seen = link_owner(method, link)
    if seen and seen.get("user_id") and seen["user_id"] != str(user_id):
        return _deny(LINK_REUSE)

    return ALLOWED


# 名簿に載せる相手は理由で変える。巻き添えを出さないため。
#   名義の使い回し … 送金元が証拠なので両方
#   リンクの持ち回し … 持ち込んだDiscordだけ(作った本人は普通の客でありうる)
#   すでに名簿 … 何も足さない(代わりに払った友達を巻き込まない)
_LIST_SENDER_TOO = (SHARED_SENDER,)
_LIST_NOTHING_NEW = (BLOCKED_USER, BLOCKED_SENDER)


def enforce(verdict: Verdict, user_id, *, method: str = "", sender_id: str = "",
            sender_name: str = "", amount: int = 0, kind: str = "",
            link: str = "") -> bool:
    """断ると決まったら名簿に載せる。戻り値は断ったかどうか。"""
    if not verdict.blocked:
        return False
    log_event(user_id, verdict, method=method, sender_id=sender_id,
              sender_name=sender_name, amount=amount, kind=kind, link=link)
    if verdict.code in _LIST_NOTHING_NEW:
        return True
    evidence = (f"{kind or '取引'} {int(amount or 0):,}円 / 送金元 "
                f"{sender_name or '不明'}({sender_id or '不明'})")
    block(DISCORD, user_id, reason=verdict.reason, evidence=evidence)
    if sender_id and method and verdict.code in _LIST_SENDER_TOO:
        block(method, sender_id, reason=verdict.reason, evidence=evidence)
    return True


# ---- 断った記録(あとから追えるように) ----

def log_event(user_id, verdict: Verdict, *, method: str = "", sender_id: str = "",
              sender_name: str = "", amount: int = 0, kind: str = "", link: str = ""):
    if not verdict.blocked:
        return
    try:
        with _write_lock:
            events = read_json(EVENT_FILE, [])
            events.append({
                "ts": time.time(), "user_id": str(user_id), "code": verdict.code,
                "reason": verdict.reason, "method": method, "sender_id": sender_id,
                "sender_name": sender_name, "amount": int(amount or 0), "kind": kind,
                "link": link_key(method, link),
            })
            write_json(EVENT_FILE, events[-EVENT_KEEP:])
    except Exception as e:
        print(f"[RISK LOG ERROR] {e}", flush=True)


def recent_events(limit: int = 20, user_id=None) -> list:
    events = read_json(EVENT_FILE, [])
    if user_id is not None:
        events = [e for e in events if e.get("user_id") == str(user_id)]
    return list(reversed(events))[:limit]


# ---- お客さんに出す文面 ----

def decline_notice() -> str:
    """断ったときの文面。理由は書かない(避けて通されるため)。"""
    return ("安全確認のため、この支払いはお受けできませんでした。\n"
            "**お代はいただいていません。**リンクはそのまま残っていますので、"
            "アプリから取り消してお手元に戻してください。\n\n"
            "お心当たりがない場合は、購入画面のスクリーンショットなど"
            "分かるものを添えて、サポートまでご連絡ください。確認のうえ"
            "解除します。")
