"""取引履歴を、決済アプリの履歴画面に近い形で並べる。

PayPay・Kyash・LTCで出したいものは同じ(いつ・誰と・いくら・何の取引か)なので、
並べ方はここに1つだけ置く。サービスごとに違うのはキー名と種別の呼び方だけで、
そこは呼び出し側から渡す。

読めなかった行は伏せずに出す。伏せると、キー名が変わって全件0円になっても
画面はきれいなままで、気付けない。
"""
from datetime import datetime, timedelta, timezone

import discord

JST = timezone(timedelta(hours=9))
WEEKDAYS = ("月", "火", "水", "木", "金", "土", "日")

IN, OUT, SELF, FAIL = "in", "out", "self", "fail"
_ICONS = {IN: "📥", OUT: "📤", SELF: "🎁", FAIL: "🚫"}


def by_amount_sign(entry: dict) -> str:
    """符号だけで入り・出を決める。種別が読めないときの既定。"""
    amount = entry.get("amount")
    if amount is None:
        return IN
    return OUT if amount < 0 else IN


def yen(amount) -> str:
    return f"{int(amount):,}円"


def render(entries: list, *, title: str, balance=None, direction=by_amount_sign,
           kind_label=None, money=yen, note: str = "",
           empty: str = "取引がありません。") -> discord.Embed:
    """履歴を1つのEmbedにまとめる。

    direction(entry)  "in" / "out" / "self"
    kind_label(entry) 「受け取り」「送金」などの見出し
    money(amount)     金額の書き方。符号は付けない(円以外の単位もここ)
    note              見出しの下に出す但し書き
    """
    embed = discord.Embed(title=title, color=discord.Color.blurple(),
                          timestamp=discord.utils.utcnow())
    head = f"**残高 {money(balance)}**" if balance is not None else ""
    if note:
        head = (head + "\n" + note).strip()

    if not entries:
        embed.description = (head + "\n" + empty).strip()
        return embed

    lines, current_day, unreadable = [], None, 0
    for entry in entries:
        ts = entry.get("ts") or 0
        when = datetime.fromtimestamp(ts, tz=JST) if ts else None
        day = when.strftime("%Y-%m-%d") if when else "不明"
        if day != current_day:
            current_day = day
            header = (f"{when.month}月{when.day}日 ({WEEKDAYS[when.weekday()]})"
                      if when else "日付不明")
            lines.append(f"\n**― {header} ―**")

        amount = entry.get("amount")
        if amount is None:
            # 伏せると「何も起きていない」ように見えるので、そのまま出す
            unreadable += 1
            lines.append(f"❔ `金額を読めません` · `{(entry.get('shape') or '')[:80]}`")
            continue

        way = direction(entry) or IN
        if way == FAIL:
            # 失敗・取り消しで終わった取引。残高は動いていないので、±を付けると
            # 出ていった(入ってきた)ように見えてしまう。印だけ変えて素で出す。
            parts = [f"{_ICONS[FAIL]} `{money(abs(amount))}`", "**取消・失敗**"]
        else:
            # 符号が付いていればそちらが正。種別(チャージ・失効など)は
            # 何の動きかを表すだけで、増減とは別物。
            sign = "-" if (way == OUT or amount < 0) else "+"
            parts = [f"{_ICONS.get(way, '📥')} `{sign}{money(abs(amount))}`"]
        label = kind_label(entry) if kind_label else None
        if label:
            parts.append(f"**{label}**")
        if entry.get("name"):
            parts.append(str(entry["name"])[:24])
        if when:
            parts.append(when.strftime("%H:%M"))
        lines.append(" · ".join(parts))

        desc = str(entry.get("desc") or "").strip()
        if desc and desc != entry.get("name"):
            lines.append(f"　　{desc[:60]}")

    embed.description = (head + "\n" + "\n".join(lines)).strip()[:4000]
    footer = f"直近{len(entries)}件"
    if unreadable:
        footer += f" / 読めなかった行 {unreadable}件（表示の不具合）"
    embed.set_footer(text=footer)
    return embed
