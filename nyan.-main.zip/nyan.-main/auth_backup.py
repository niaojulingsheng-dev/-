"""Discord OAuth2 による認証 & メンバーバックアップ機能のロジック。

参考: https://github.com/taka-4602/Discord-Backup-Bot

仕組み:
  1. ユーザーが認証パネルの「認証する」ボタン(Discordの認可URL)を押す
  2. `identify` と `guilds.join` のスコープを許可すると、当サーバーの `/callback` に
     認可コードが返る
  3. コードをアクセストークン(+リフレッシュトークン)に交換して保存する
  4. あとで `/auth restore` を実行すると、保存したトークンで全員をサーバーに
     再参加(guilds.join)させられる = メンバーバックアップ

必要な環境変数:
  - DISCORD_CLIENT_ID     … アプリのクライアントID
  - DISCORD_CLIENT_SECRET … OAuth2のクライアントシークレット
  - OAUTH_REDIRECT_URI    … 公開コールバックURL(例: https://<app>/callback)
  - DISCORD_TOKEN / TOKEN … Botトークン(既存)

トークン等の機密は環境変数から読み込み、コードには一切ハードコードしない。
"""
import os
import json
import time
import threading
from urllib.parse import urlencode

import requests

from datapath import data_path, read_json, write_json

API_BASE = "https://discord.com/api/v10"

# {user_id: {"access_token","refresh_token","expires_at","guild_id","username"}}
TOKENS_FILE = data_path("auth_tokens.json")
# {guild_id: {"role_id": int|None}}
AUTH_CONFIG_FILE = data_path("auth_config.json")

_lock = threading.Lock()


def client_id() -> str:
    return os.getenv("DISCORD_CLIENT_ID", "").strip()


def client_secret() -> str:
    return os.getenv("DISCORD_CLIENT_SECRET", "").strip()


def redirect_uri() -> str:
    return os.getenv("OAUTH_REDIRECT_URI", "").strip()


def bot_token() -> str:
    return (os.getenv("DISCORD_TOKEN") or os.getenv("TOKEN") or "").strip()


def is_configured() -> bool:
    """OAuth2認証に必要な設定が揃っているか。"""
    return bool(client_id() and client_secret() and redirect_uri())


# ---------- 永続データ ----------

def _load(path: str) -> dict:
    return read_json(path, {})


def _save(path: str, data: dict):
    write_json(path, data)


def load_tokens() -> dict:
    return _load(TOKENS_FILE)


def save_tokens(data: dict):
    _save(TOKENS_FILE, data)


def load_auth_config() -> dict:
    return _load(AUTH_CONFIG_FILE)


def save_auth_config(data: dict):
    _save(AUTH_CONFIG_FILE, data)


def get_role_id(guild_id) -> int | None:
    conf = load_auth_config().get(str(guild_id)) or {}
    rid = conf.get("role_id")
    return int(rid) if rid else None


def set_role_id(guild_id, role_id):
    conf = load_auth_config()
    entry = conf.setdefault(str(guild_id), {})
    entry["role_id"] = int(role_id) if role_id else None
    save_auth_config(conf)


def store_token(user_id, token: dict, guild_id=None, username=None):
    """トークン交換/更新の結果を保存する。"""
    with _lock:
        data = load_tokens()
        entry = data.get(str(user_id), {})
        entry["access_token"] = token["access_token"]
        if token.get("refresh_token"):
            entry["refresh_token"] = token["refresh_token"]
        if token.get("expires_in") is not None:
            entry["expires_at"] = time.time() + int(token["expires_in"])
        if guild_id is not None:
            entry["guild_id"] = str(guild_id)
        if username is not None:
            entry["username"] = username
        data[str(user_id)] = entry
        save_tokens(data)


def delete_token(user_id) -> bool:
    with _lock:
        data = load_tokens()
        if str(user_id) in data:
            del data[str(user_id)]
            save_tokens(data)
            return True
    return False


def count_tokens() -> int:
    return len(load_tokens())


# ---------- OAuth2 ----------

def authorize_url(guild_id) -> str:
    """認証パネルのボタンに載せる、Discordの認可URLを組み立てる。"""
    params = {
        "client_id": client_id(),
        "redirect_uri": redirect_uri(),
        "response_type": "code",
        "scope": "identify guilds.join",
        "state": str(guild_id),
        "prompt": "consent",
    }
    return "https://discord.com/oauth2/authorize?" + urlencode(params)


def exchange_code(code: str) -> dict:
    """認可コードをアクセストークンに交換する。"""
    data = {
        "client_id": client_id(),
        "client_secret": client_secret(),
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": redirect_uri(),
    }
    r = requests.post(f"{API_BASE}/oauth2/token", data=data,
                      headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
    r.raise_for_status()
    return r.json()


def refresh_access_token(refresh_token: str) -> dict:
    """リフレッシュトークンでアクセストークンを更新する。"""
    data = {
        "client_id": client_id(),
        "client_secret": client_secret(),
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    }
    r = requests.post(f"{API_BASE}/oauth2/token", data=data,
                      headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
    r.raise_for_status()
    return r.json()


def get_user(access_token: str) -> dict:
    """アクセストークンでユーザー情報(identify)を取得する。"""
    r = requests.get(f"{API_BASE}/users/@me",
                     headers={"Authorization": f"Bearer {access_token}"}, timeout=15)
    r.raise_for_status()
    return r.json()


def get_valid_access_token(user_id) -> str | None:
    """有効なアクセストークンを返す。期限切れ間近ならリフレッシュして保存する。
    リフレッシュに失敗(認証取り消し等)したらデータを削除して None。"""
    entry = load_tokens().get(str(user_id))
    if not entry:
        return None
    expires_at = float(entry.get("expires_at", 0) or 0)
    # 期限の60秒前までは現行トークンをそのまま使う
    if entry.get("access_token") and expires_at - 60 > time.time():
        return entry["access_token"]
    rt = entry.get("refresh_token")
    if not rt:
        return entry.get("access_token")  # リフレッシュ手段なし。ダメ元で現行を返す
    try:
        token = refresh_access_token(rt)
    except requests.HTTPError:
        # invalid_grant 等 = ユーザーが認証を取り消した → データ削除
        delete_token(user_id)
        return None
    except requests.RequestException:
        return entry.get("access_token")  # 一時的な通信失敗。現行トークンで試す
    store_token(user_id, token, guild_id=entry.get("guild_id"), username=entry.get("username"))
    return token["access_token"]


# ---------- Discord API (Botトークン) ----------

def _bot_headers() -> dict:
    return {"Authorization": f"Bot {bot_token()}", "Content-Type": "application/json"}


def add_role(guild_id, user_id, role_id) -> int:
    """既にサーバーにいるメンバーにロールを付与する。HTTPステータスを返す。"""
    r = requests.put(
        f"{API_BASE}/guilds/{guild_id}/members/{user_id}/roles/{role_id}",
        headers=_bot_headers(), timeout=15,
    )
    return r.status_code


def add_member(guild_id, user_id, access_token: str) -> int:
    """guilds.join でユーザーをサーバーに参加させる。HTTPステータスを返す。
    201=追加成功 / 204=既に参加済み / 403=トークン失効 / その他=失敗。"""
    body = {"access_token": access_token}
    role_id = get_role_id(guild_id)
    if role_id:
        body["roles"] = [str(role_id)]
    r = requests.put(
        f"{API_BASE}/guilds/{guild_id}/members/{user_id}",
        headers=_bot_headers(), data=json.dumps(body), timeout=15,
    )
    return r.status_code


def restore_all(guild_id, only_user_id=None) -> dict:
    """保存済みユーザーを guild_id のサーバーへ一括再参加させる。
    集計 {"added","already","failed","expired","total"} を返す。
    ブロッキング処理のため、呼び出し側は asyncio.to_thread 等で実行すること。"""
    tokens = load_tokens()
    if only_user_id is not None:
        uids = [str(only_user_id)] if str(only_user_id) in tokens else []
    else:
        uids = list(tokens.keys())

    result = {"added": 0, "already": 0, "failed": 0, "expired": 0, "total": len(uids)}
    for uid in uids:
        access = get_valid_access_token(uid)
        if not access:
            result["expired"] += 1
            continue
        try:
            status = add_member(guild_id, uid, access)
        except requests.RequestException:
            result["failed"] += 1
            continue

        if status == 201:
            result["added"] += 1
        elif status == 204:
            result["already"] += 1
        elif status in (401, 403):
            # トークン失効。1度だけリフレッシュして再試行
            delete_token(uid)
            result["expired"] += 1
        elif status == 429:
            # レート制限。少し待って同じユーザーを再試行
            time.sleep(2)
            try:
                if add_member(guild_id, uid, access) in (201, 204):
                    result["added"] += 1
                else:
                    result["failed"] += 1
            except requests.RequestException:
                result["failed"] += 1
        else:
            result["failed"] += 1
        time.sleep(0.3)  # レート制限緩和
    return result
