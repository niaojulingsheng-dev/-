"""設置したパネルの居場所を覚えておいて、その場で書き換えられるようにする。

パネルの内容(価格・在庫・商品)は運用中によく変わる。置き直すと古いパネルが
上に残って、お客さんが古いほうを押してしまうし、チャンネルも流れる。
置いた場所を覚えておけば、同じメッセージを書き換えるだけで済む。

記録が無いパネル(この仕組みより前に置いたもの)は、そのときだけチャンネルを
さかのぼって探し、見つけたら記録に取り込む。

押されたときに必ず返事を返す guard もここに置く。
"""
import functools
import traceback

import discord

from datapath import data_path, read_json, write_json

CONFIG_FILE = data_path("config.json")
_KEY = "panels"

# 記録が無いパネルを探すとき、どこまでさかのぼるか。
SEARCH_LIMIT = 50

# 置き場所の記録が無いパネルをサーバー全体から探すとき、見るチャンネルの数。
SEARCH_CHANNELS = 20


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


# ---- 押されたときに必ず返事をする ----

BUSY_NOTE = ("うまく開けませんでした。少し時間をおいて、もう一度押してみてください。\n"
             "何度やっても同じときは、お手数ですが管理者にお知らせください。")


async def apologize(interaction: discord.Interaction, note: str = BUSY_NOTE):
    """押した人に返事だけは返す。返事済みなら追い足しで送る。"""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(note, ephemeral=True)
        else:
            await interaction.response.send_message(note, ephemeral=True)
    except discord.HTTPException:
        pass          # 3秒を過ぎている等


def guard(handler):
    """常設パネルのボタン用。中で何が起きても押した人に返事を返す。

    例外が出ても discord.py はコンソールに書くだけで、押した人には
    「応答しませんでした」しか出ない。ここで受け止めてログに残す。
    ボタンの書き方は2通りあるので、引数から Interaction を探す。
    """
    @functools.wraps(handler)
    async def wrapped(*args, **kwargs):
        try:
            return await handler(*args, **kwargs)
        except Exception:
            interaction = next(
                (a for a in args if isinstance(a, discord.Interaction)), None)
            print(f"[PANEL ERROR] {getattr(handler, '__qualname__', handler)}\n"
                  f"{traceback.format_exc()}", flush=True)
            if interaction is not None:
                await apologize(interaction)
    return wrapped


def remember(key: str, message: discord.Message):
    """このパネルはここにある、と覚える。"""
    cfg = _config()
    cfg.setdefault(_KEY, {})[key] = {"channel_id": message.channel.id,
                                     "message_id": message.id}
    write_json(CONFIG_FILE, cfg)


def forget(key: str):
    cfg = _config()
    if (cfg.get(_KEY) or {}).pop(key, None) is not None:
        write_json(CONFIG_FILE, cfg)


def location(key: str):
    spot = (_config().get(_KEY) or {}).get(key) or {}
    if spot.get("channel_id") and spot.get("message_id"):
        return int(spot["channel_id"]), int(spot["message_id"])
    return None


async def _scan(bot, key: str, title: str, channel):
    """チャンネルをさかのぼって「Botが出した、その見出しのパネル」を探す。

    見つかったら記録に取り込むので、次からは探さずに済む。
    """
    if channel is None or not title:
        return None
    try:
        async for message in channel.history(limit=SEARCH_LIMIT):
            if message.author.id != bot.user.id or not message.embeds:
                continue
            if (message.embeds[0].title or "") == title:
                remember(key, message)
                return message
    except discord.HTTPException:
        pass
    return None


async def _placed(bot, key: str, title: str, guild=None):
    """すでに置いてあるパネルを探す。新しく置くことはしない。

    まず覚えている場所を見る。記録が古い(消された・置き直した)ときは、
    そのチャンネルの中を探す。記録そのものが無いときだけ、サーバーの中を
    見て回る。こうしておくと、パネルを置いたのとは別のチャンネルから
    更新コマンドを叩いても届く。
    """
    spot = location(key)
    if spot:
        channel = bot.get_channel(spot[0])
        if channel is not None:
            try:
                return await channel.fetch_message(spot[1])
            except discord.HTTPException:
                pass          # 消された・置き直した → 同じチャンネルを探す
            found = await _scan(bot, key, title, channel)
            if found is not None:
                return found

    if guild is None:
        return None
    for channel in list(guild.text_channels)[:SEARCH_CHANNELS]:
        found = await _scan(bot, key, title, channel)
        if found is not None:
            return found
    return None


async def _find_message(bot, key: str, title: str, channel):
    """覚えている場所のメッセージを取る。無ければそのチャンネルから探す。"""
    spot = location(key)
    if spot:
        found = bot.get_channel(spot[0])
        if found is not None:
            try:
                return await found.fetch_message(spot[1])
            except discord.HTTPException:
                pass          # 消された・別チャンネルへ移した → 探し直す
    return await _scan(bot, key, title, channel)


async def refresh(bot, key: str, embed: discord.Embed,
                  view: discord.ui.View = None, guild=None) -> str:
    """置いてあるパネルを、その場で最新の内容に書き換える。

    put と違って新しく置くことはしない。置いていないパネルまで並んでしまうと
    お客さんが混乱するので、更新コマンドはこちらを使う。

    戻り値 "updated"(書き換えた) / "missing"(置いていない) / "failed"
    """
    message = await _placed(bot, key, embed.title or "", guild)
    if message is None:
        return "missing"
    try:
        await message.edit(embed=embed, view=view)
    except discord.HTTPException:
        return "failed"
    remember(key, message)
    return "updated"


async def put(bot, key: str, channel, embed: discord.Embed,
              view: discord.ui.View = None) -> str:
    """パネルを出す。すでにあるなら、その場で書き換える。

    戻り値 "updated"(書き換えた) / "posted"(新しく置いた) / "failed"
    """
    message = await _find_message(bot, key, embed.title or "", channel)
    if message is not None:
        try:
            await message.edit(embed=embed, view=view)
            remember(key, message)
            return "updated"
        except discord.HTTPException:
            pass              # 権限が無い等 → 置き直しに降りる

    if channel is None:
        return "failed"
    try:
        sent = await channel.send(embed=embed, view=view)
    except discord.HTTPException:
        return "failed"
    remember(key, sent)
    return "posted"
