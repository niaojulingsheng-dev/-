"""ツムツム(LINE:ディズニー ツムツム)のゲームAPIクライアント。

配布された Tsum/api2.py をそのまま持ち込んだもの。通信・暗号・ガチャの手順は
ゲーム側の仕様に合わせてあるので、原則として書き換えない(書き換えるとその場で
代行が通らなくなる)。このリポジトリに合わせたのは次の2点だけ。

  - 保存先を DATA_DIR 配下に寄せた(datapath)。リポジトリ直下に書かない。
  - getMast の生応答は TSUM_MAST_DUMP=1 のときだけ残す(常時書くと重い)。

環境変数:
  TSUM_APP_VER / TSUM_RES_VER   ゲームのバージョン(更新に追従する)
  TSUM_DEBUG                    getInfo等の生応答をコンソールに出す
  TSUM_GACHA_DEBUG              ガチャ応答の詳細をコンソールに出す
  TSUM_GACHA_MAX_CALLS          回す回数が決まっていないときの呼び出し上限(既定500回)
  TSUM_GACHA_MAX_SECONDS        1回の完売にかけてよい時間(既定1800秒 / 0で無制限)
  TSUM_MAST_DUMP                getMastの生応答をファイルに残す
  TSUM_HTTP_REUSE               接続を張ったまま使い回す(既定1 / 0で毎回張り直す)
  TSUM_MAST_CACHE               getMastの応答を1接続のあいだ覚える(既定1 / 0で毎回取る)
  TSUM_MAST_SHARED_SECONDS      getMastの応答を接続をまたいで覚える時間(既定900秒 / 0で切る)
  TSUM_GACHA_CALL_GAP_MIN/MAX   完売でガチャを引き続けるときの間隔(秒。既定0.25〜0.6)
"""
import os
import json
import time
import hmac
import hashlib
import random
import base64
import datetime
import urllib.parse
import asyncio
import collections
import aiohttp
from curl_cffi.requests import AsyncSession as CurlSession
import msgpack
from Crypto.Cipher import AES
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP
from Crypto.Hash import SHA256
from Crypto.Cipher import PKCS1_v1_5
import re
import uuid
import string
import secrets
import html
from bs4 import BeautifulSoup

from dataclasses import dataclass, field
from typing import Optional

from datapath import data_path, read_json, write_json


# --- アカウントごとの永続ブラウザ指紋 ---------------------------------------
# LINEは「いつもの端末(同じCookie一式)」から同じアカウントに入るぶんは信頼して
# 追加認証を出しにくい。逆に毎回違う端末に見えると新端末確認が出やすい。そこで
# アカウント(メール)ごとに固定のトラッキングCookieを持たせ、そのアカウントは常に
# 同じブラウザから入るように見せる。アカウントごとに別の指紋なので「1つのブラウザで
# 大量の垢に入っている」ようにも見えない。保存先は DATA_DIR(永続ボリューム可)。
_LINE_FP_FILE = "line_fingerprints.json"


def _new_line_cookies() -> dict:
    """新規のトラッキング/ブラウザ識別Cookie一式(実ブラウザの形に合わせる)。"""
    return {
        "_trmccid": secrets.token_hex(8),                # 16 hex
        "_trmcuser": '{"id":""}',
        "_ldbrbid": "lo__" + secrets.token_urlsafe(33),  # lo__ + ~44 chars
        "LC": secrets.token_hex(32),                     # 64 hex
    }


def line_account_cookies(email: str) -> dict:
    """アカウントごとに固定のトラッキングCookieを返す(無ければ作って保存)。

    同じ email なら常に同じCookie=同じ端末に見せる。email が空なら毎回新規。
    保存に失敗しても新規Cookieで続行する(ログインは止めない)。
    """
    if not email:
        return _new_line_cookies()
    key = hashlib.sha256(email.strip().lower().encode()).hexdigest()
    path = data_path(_LINE_FP_FILE)
    store = read_json(path, {})
    if not isinstance(store, dict):
        store = {}
    rec = store.get(key)
    now = int(time.time())
    if not (isinstance(rec, dict) and isinstance(rec.get("cookies"), dict)
            and rec["cookies"].get("LC")):
        rec = {"cookies": _new_line_cookies(), "created": now}
        store[key] = rec
    rec["last"] = now
    try:
        write_json(path, store)
    except Exception as e:
        print(f"[OAuth] 指紋の保存に失敗(継続): {type(e).__name__}: {e}", flush=True)
    return dict(rec["cookies"])

# getMast の生応答を残す先。ガチャの当たり判定を調べるとき以外は要らない。
RESULT_FILE = data_path("tsum_getmast.json")
TSUM_DEBUG = os.getenv("TSUM_DEBUG", "0") == "1"
TSUM_GACHA_DEBUG = os.getenv("TSUM_GACHA_DEBUG", "0") == "1"
# ガチャ応答を必ず出す(調査用)。既定は切っておく。1回の完売で数百回叩くので、
# 付けっぱなしだとログがガチャ応答で埋まって他の事故が見えなくなる。
GACHA_DIAGNOSTIC_FORCE = os.getenv("TSUM_GACHA_DIAG", "0") == "1"
TSUM_MAST_DUMP = os.getenv("TSUM_MAST_DUMP", "0") == "1"
TSUM_GACHA_MAX_CALLS = max(1, int(os.getenv("TSUM_GACHA_MAX_CALLS", "500") or "500"))
# 1回の完売にかけてよい時間。回数の上限だけだと、1回ずつしか引けないボックス
# (ハピネス)で万回のリクエストになり、その間ずっとその人の代行を止めたまま
# 待たせることになる。中身の数はこちらから知りようがないので、回数ではなく
# 時間で頭を押さえる。0で無制限。
TSUM_GACHA_MAX_SECONDS = max(0, int(os.getenv("TSUM_GACHA_MAX_SECONDS", "1800") or "0"))
# 完売でガチャを引き続けるときの、呼び出しどうしの間隔(秒)。数百回を無間隔で
# 連打すると、演出を見ながら引いている端末には出せない足取りになる(BAN対策)。
# 1回の呼び出し自体に往復ぶん(0.3〜0.5秒)がかかるので、間隔はそれに足す
# 揺らぎでよい。プレミアム完売(約4,900回=10連490回)で、以前の 0.4〜1.1 は
# 間隔だけで6分待っていた。足取りを緩めたければ環境変数で戻せる。
TSUM_GACHA_CALL_GAP_MIN = float(os.getenv("TSUM_GACHA_CALL_GAP_MIN", "0.25"))
TSUM_GACHA_CALL_GAP_MAX = float(os.getenv("TSUM_GACHA_CALL_GAP_MAX", "0.6"))
TSUM_APP_VER = os.getenv("TSUM_APP_VER", "12.8.1").strip() or "12.8.1"
TSUM_RES_VER = os.getenv("TSUM_RES_VER", "12.8.0").strip() or "12.8.0"
# 1回の代行のあいだ、ゲームAPIへの接続を張ったまま使い回すかどうか。
# 完売は同じ相手へ数百〜数千回続けて投げる。1回ごとに接続を張り直すと、
# そのたびにDNS・TCP・TLSの往復(3〜4往復ぶん)が丸ごと乗り、実際の
# やりとりより待ち時間のほうが長くなる。送る中身は変えないので、ゲーム側から
# 見た要求は同じまま。困ったら0で戻せる。
TSUM_HTTP_REUSE = os.getenv("TSUM_HTTP_REUSE", "1") != "0"
# getMast(数MB)の応答を1接続のあいだ覚えるかどうか。マスタはガチャの
# 開催日程・価格・中身の数といった動かない側の表で、1回の代行(数分)の
# あいだに書き換わるものではない。完売しているかどうかは getInfo 側の
# gachainfo で毎回見ているので、覚えても「完売済みを掴む」ことはない。
TSUM_MAST_CACHE = os.getenv("TSUM_MAST_CACHE", "1") != "0"
# getMast を接続をまたいで覚えておく時間(秒)。マスタはアカウントによらず
# 同じ表(ガチャの日程・価格・中身の数、イベントの期間)で、注文ごとに数MBを
# 引き直すぶんだけログイン直後の待ちが延びていた。日程が切り替わる境目で
# 古い表を掴んでも、gameStart が断られたときは捨てて引き直す(_forget_mast)
# ので、注文が丸ごと落ちることはない。0で切る(接続内のぶんは残る)。
TSUM_MAST_SHARED_SECONDS = max(0, int(os.getenv("TSUM_MAST_SHARED_SECONDS", "900") or "0"))
# {(appver, resver, 種類のtuple): (取得時刻, 応答)}
_MAST_SHARED: dict = {}
# 起動時の既定。set_versions() は上の TSUM_APP_VER を書き換えるので、
# 「設定を消したときに戻る先」はこちらに取っておく。
DEFAULT_APP_VER = TSUM_APP_VER
DEFAULT_RES_VER = TSUM_RES_VER


async def _mark_reused_connection(session, ctx, params):
    """使い回した接続に印を付ける(投げ直してよいのはこれだけ)。"""
    holder = getattr(ctx, "trace_request_ctx", None)
    if isinstance(holder, dict):
        holder["reused"] = True


def _reuse_trace() -> "aiohttp.TraceConfig":
    trace = aiohttp.TraceConfig()
    trace.on_connection_reuseconn.append(_mark_reused_connection)
    return trace


def _user_agent(app_ver: str) -> str:
    """ゲームアプリを名乗るUser-Agent。バージョンだけが変わる。"""
    return (f"com.linecorp.LGTMTM/{app_ver} ChannelSDK/5.11.1 "
            "(Linux; U; Android 11; ja-JP; Pixel 4a (5G) Build/RQ3A.211001.001)")


def _return_to_title(res) -> bool:
    """ゲーム側が「一度タイトルに戻れ」と言ってきたか(gameStart / gameEnd 共通)。

    retcode=92/retsubcode=2「プレイデータを受け取りました。プレイデータ反映の
    ため一度タイトルに戻ります。」と、gameStart の retcode=8「入力パラメータで
    エラーが発生しました。一度タイトルに戻ります。」がこれ。どちらもプレイは
    反映されていない(残高は動いていない) soft な合図で、getInfo を投げ直して
    入り直せば通る。番号が変わっても拾えるよう、メッセージでも見る。
    """
    if not isinstance(res, dict):
        return False
    if res.get("retcode") in (8, 92):
        return True
    msg = res.get("retmsg")
    return isinstance(msg, str) and "タイトルに戻" in msg


class GetInfoError(Exception):
    """getInfo 系の応答が userinfo を持たない(=エラー応答)ときに上げる。

    マイツムの一時替え(getInfo に mytsumid を載せる)などが弾かれると、
    サーバは userinfo の無いエラー応答を返す。そのまま from_dict に渡すと
    素の KeyError: 'userinfo' になり、ログから原因(retcode/retmsg)が分からず、
    代行が途中で止まる。ここで retcode/retmsg を抱えた分かる例外にしておく。
    """
    def __init__(self, resp):
        d = resp if isinstance(resp, dict) else {}
        self.retcode = d.get("retcode")
        self.retsubcode = d.get("retsubcode")
        self.retmsg = d.get("retmsg")
        keys = sorted(d.keys()) if isinstance(resp, dict) else type(resp).__name__
        super().__init__(
            f"getInfo が userinfo を返しませんでした "
            f"(retcode={self.retcode} retsubcode={self.retsubcode} "
            f"retmsg={self.retmsg!r} keys={keys})"
        )


def is_getinfo_payload(resp) -> bool:
    """getInfo として読める応答か。userinfo と mydatainfo が揃っていればOK。

    エラー応答(userinfo 無し)を from_dict に渡す前に、ここで弾くために使う。
    """
    return (isinstance(resp, dict)
            and isinstance(resp.get("userinfo"), dict)
            and isinstance(resp.get("mydatainfo"), dict))


@dataclass
class TsumInfo:
    tsumid: int; lv: int; exp: int; skilllv: int; vanishcnt: int
    tsumcnt: int; lbcoin: int; limitlv: int; nextlimitlv: int
    nextlbcoin: int; skinbit: int; setflg: int; fav: str
    regdt: int; discountflg: int; wappen: Optional[list[int]] = None

    @property
    def is_mytsum(self) -> bool: return self.setflg == 1
    @property
    def has_skin(self) -> bool: return self.skinbit != 0

    @classmethod
    def from_dict(cls, d: dict) -> "TsumInfo":
        return cls(
            tsumid=d["tsumid"], lv=d["lv"], exp=d["exp"],
            skilllv=d["skilllv"], vanishcnt=d["vanishcnt"],
            tsumcnt=d["tsumcnt"], lbcoin=d["lbcoin"],
            limitlv=d["limitlv"], nextlimitlv=d["nextlimitlv"],
            nextlbcoin=d["nextlbcoin"] or 0,
            skinbit=d["skinbit"], setflg=d["setflg"],
            fav=d["fav"], regdt=int(d["regdt"]),
            discountflg=d["discountflg"], wappen=d.get("wappen"),
        )

@dataclass
class GachaInfo:
    gachaid: int; multiflg: int; compflg: int

    @property
    def can_multi(self) -> bool: return self.multiflg == 1
    @property
    def is_completed(self) -> bool: return self.compflg == 1

    @classmethod
    def from_dict(cls, d: dict) -> "GachaInfo":
        return cls(gachaid=d["gachaid"], multiflg=d["multiflg"], compflg=d["compflg"])

@dataclass
class UserInfo:
    name: str; lv: int; score: int; bcoin: int; bmedal: int
    bruby: int; bheart: int; maxcoin: int; maxcombo: int
    maxchain: int; playcnt: int; range: str; expper: int; regdt: int
    pcoin: int = 0; pmedal: int = 0; pruby: int = 0; pheart: int = 0

    @property
    def coin_total(self) -> int:
        return max(0, self.bcoin + self.pcoin)

    @property
    def medal_total(self) -> int:
        return max(0, self.bmedal + self.pmedal)

    @property
    def ruby_total(self) -> int:
        return max(0, self.bruby + self.pruby)

    @classmethod
    def from_dict(cls, d: dict) -> "UserInfo":
        return cls(
            name=d["name"], lv=d["lv"], score=d["score"],
            bcoin=d.get("bcoin", 0), bmedal=d.get("bmedal", 0), bruby=d.get("bruby", 0),
            bheart=d.get("bheart", 0), maxcoin=d.get("maxcoin", 0),
            maxcombo=d.get("maxcombo", 0), maxchain=d.get("maxchain", 0),
            playcnt=d.get("playcnt", 0), range=d.get("range", ""),
            expper=d.get("expper", 0), regdt=int(d.get("regdt", 0)),
            pcoin=d.get("pcoin", 0), pmedal=d.get("pmedal", 0),
            pruby=d.get("pruby", 0), pheart=d.get("pheart", 0),
        )

@dataclass
class StatEntry:
    type: int; value: int; tsumid: int

@dataclass
class TsumScore:
    tsumid: int; score: int

@dataclass
class MyDataInfo:
    totalexp: int; totalplaycnt: int; totalskillcnt: int
    logincnt: int; currentlogincnt: int; maxlogincnt: int
    hometsum: int; homebgid: int
    statslist: list[StatEntry] = field(default_factory=list)
    tsumscorelist: list[TsumScore] = field(default_factory=list)

    @property
    def mytsum_id(self) -> int:
        for s in self.statslist:
            if s.type == 9: return s.tsumid
        return 0

    @classmethod
    def from_dict(cls, d: dict) -> "MyDataInfo":
        return cls(
            totalexp=d["totalexp"], totalplaycnt=d["totalplaycnt"],
            totalskillcnt=d["totalskillcnt"], logincnt=d["logincnt"],
            currentlogincnt=d["currentlogincnt"], maxlogincnt=d["maxlogincnt"],
            hometsum=d["hometsum"], homebgid=d["homebgid"],
            statslist=[StatEntry(s["type"], s["value"], s["tsumid"]) for s in d.get("statslist", [])],
            tsumscorelist=[TsumScore(t["tsum"], t["score"]) for t in d.get("tsumscorelist", [])],
        )

@dataclass
class ItemInfo:
    id: int; type: int; cnt: int

    @classmethod
    def from_dict(cls, d: dict) -> "ItemInfo":
        return cls(id=d["id"], type=d["type"], cnt=d["cnt"])

@dataclass
class GetInfoResponse:
    userinfo: UserInfo; mydatainfo: MyDataInfo
    tsuminfo: list[TsumInfo] = field(default_factory=list)
    iteminfo: list[ItemInfo] = field(default_factory=list)
    gachainfo: list[GachaInfo] = field(default_factory=list)
    retcode: int = 0; retmsg: str = ""; retsubcode: int = 0

    @property
    def mytsum(self) -> Optional[TsumInfo]:
       
        t = next((t for t in self.tsuminfo if t.is_mytsum), None)
        if t:
            return t

        t = self.get_tsum(self.mydatainfo.hometsum)
        if t:
            return t

        return self.get_tsum(1)

    def get_tsum(self, tsumid: int) -> Optional[TsumInfo]:
        return next((t for t in self.tsuminfo if t.tsumid == tsumid), None)

    def get_item(self, item_id: int, item_type: int) -> int:
        return next((i.cnt for i in self.iteminfo if i.id == item_id and i.type == item_type), 0)

    @property
    def available_gachas(self) -> list[GachaInfo]:
        return [g for g in self.gachainfo]

    @property
    def play_items(self) -> dict[str, int]:
        NAME = {1: "5to4", 2: "4to3", 3: "time+5", 4: "score+2", 5: "coin+2", 7: "other"}
        return {NAME.get(i.id, str(i.id)): i.cnt for i in self.iteminfo if i.type == 4}

    @classmethod
    def from_dict(cls, d: dict) -> "GetInfoResponse":
        # エラー応答(userinfo 無し)は素の KeyError にせず、retcode/retmsg の
        # 分かる GetInfoError にする。呼び出し側はこれを捕まえて後始末できる。
        if not is_getinfo_payload(d):
            raise GetInfoError(d)
        return cls(
            userinfo=UserInfo.from_dict(d["userinfo"]),
            mydatainfo=MyDataInfo.from_dict(d["mydatainfo"]),
            tsuminfo=[TsumInfo.from_dict(t) for t in d.get("tsuminfo", [])],
            iteminfo=[ItemInfo.from_dict(i) for i in d.get("iteminfo", [])],
            gachainfo=[GachaInfo.from_dict(g) for g in d.get("gachainfo", [])],
            retcode=d.get("retcode", 0),
            retmsg=d.get("retmsg", ""),
            retsubcode=d.get("retsubcode", 0),
        )

class SecureSessionCrypto:
    @staticmethod
    def generate_secure_random(length: int) -> bytes:
        return os.urandom(length)

    @staticmethod
    def rsa_encrypt_oaep(data: bytes, public_key_b64: str) -> str:
        pub_key_der = base64.b64decode(public_key_b64)
        pub_key     = RSA.import_key(pub_key_der)
        cipher      = PKCS1_OAEP.new(pub_key, hashAlgo=SHA256)
        return base64.b64encode(cipher.encrypt(data)).decode()

    @staticmethod
    def aes_gcm_encrypt(plaintext_str: str, key: bytes) -> bytes:
        iv              = SecureSessionCrypto.generate_secure_random(12)
        cipher          = AES.new(key, AES.MODE_GCM, nonce=iv, mac_len=16)
        ciphertext, tag = cipher.encrypt_and_digest(plaintext_str.encode("utf-8"))
        return iv + ciphertext + tag

    @staticmethod
    def aes_gcm_decrypt(data: bytes, key: bytes) -> str:
        iv         = data[:12]
        ciphertext = data[12:-16]
        tag        = data[-16:]
        cipher     = AES.new(key, AES.MODE_GCM, nonce=iv, mac_len=16)
        return cipher.decrypt_and_verify(ciphertext, tag).decode("utf-8")

class LineLoginError(Exception):
    """LINEのログインに進めなかった。理由は種類で分ける。

    ここを1つにまとめて「メアパスが間違っています」と言ってしまうと、
    実際には合っているのに疑わせることになる（PINコード認証に進んだ場合が
    まさにそれで、LINE側は認証を受け付けているのにこちらが失敗と決めつけていた）。
    """


class LineCredentialError(LineLoginError):
    """LINEがメールアドレス／パスワードを拒否した（LINE自身がそう答えた場合だけ）。"""


class LineVerificationRequired(LineLoginError):
    """PINコード認証（本人確認）が終わらないまま時間切れになった。

    メールアドレスとパスワードは通っている。LINEアプリ側で承認されるまで
    先へ進めないだけなので、案内の文面もそう書くこと。
    """

    def __init__(self, message: str, pin: str = None):
        super().__init__(message)
        self.pin = pin


class LineOAuthLogin:
    BASE_URL     = "https://access.line.me"
    TOKEN_URL    = "https://api.line.me/oauth2/v2.1/token"
    CLIENT_ID    = "1381161556"
    REDIRECT_URI = "intent://result#Intent;package=com.linecorp.LGTMTM;scheme=lineauth;end"
    UA_BROWSER   = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36"
    UA_APP       = _user_agent(TSUM_APP_VER)
    # UA_BROWSER の Chrome バージョンに合わせた Client Hints。実ブラウザは sec-ch-ua /
    # sec-fetch-* を必ず送る。これが無いと「素のbot」と判別されて追加認証(challenge)を
    # 誘発しやすい。UAと矛盾しないようバージョンを揃える。
    _CH_VER = "147"
    CH_HEADERS = {
        "sec-ch-ua": f'"Chromium";v="{_CH_VER}", "Google Chrome";v="{_CH_VER}", "Not?A_Brand";v="24"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
    }

    # PINコード認証を待つ時間と、承認されたかを見に行く間隔（秒）。
    # LINEアプリを開いて数字を確かめて押すまでの時間を見込む。お客さんが
    # アプリを開くのに手間取ることがあるので、既定を長めにして環境変数で変えられる。
    PIN_WAIT_SECONDS  = int(os.getenv("TSUM_LINE_PIN_WAIT", "300"))
    PIN_POLL_SECONDS  = int(os.getenv("TSUM_LINE_PIN_POLL", "4"))
    # PINの承認待ち専用エンドポイント(pin/wait)のロングポーリング1回の待ち上限(秒)。
    PIN_LONGPOLL_TIMEOUT = int(os.getenv("TSUM_LINE_PIN_LONGPOLL", "30"))
    # 見つからなかったとき用の既定パス(app-dataから取れればそちらを優先)。
    PIN_WAIT_PATH_DEFAULT = "/qrlogin/oauth2/v2.1/authn/pin/wait"
    # PINの承認待ちのやり取りをログに出す(なぜ承認を拾えないかの調査用)。
    PIN_DEBUG         = os.getenv("TSUM_LINE_PIN_DEBUG", "1") not in ("0", "", "false")
    # curl_cffi でなりすます本物ブラウザのTLS/HTTP2指紋。UA/sec-ch-ua もこれに揃う。
    IMPERSONATE       = os.getenv("TSUM_LINE_IMPERSONATE", "chrome")

    def __init__(self, line_id: str, password: str, captcha_callback=None,
                 pin_callback=None):
        self.line_id  = line_id
        self.password = password
        self.captcha_callback = captcha_callback
        # pin_callback(pin) … PINコードをお客さんに見せるための入口。
        # 見せないと、LINEアプリに出た数字のどれを押せばいいのか分からない。
        self.pin_callback = pin_callback
        # pin/wait の通った送り方を覚えておく(最初の周回で当てて、以後は使い回す)。
        self._pin_wait_variant = None
        # 弾かれた送り方。あとの周回で試し直さない(待ち時間を探りに使い切らないため)。
        self._pin_wait_dead = set()

    # curl_cffi の impersonate が User-Agent / sec-ch-ua / Accept-Encoding を、TLS指紋と
    # 矛盾しない本物のChromeの値で入れてくれる。だからここでは"リクエスト種別ごとに変わる"
    # ヘッダ(Accept / sec-fetch-* / Referer / Priority 等)だけを足す。UAやsec-ch-uaは
    # ここで上書きしない(上書きするとTLSと食い違ってかえって怪しくなる)。
    def _nav_headers(self, referer: str = None, first: bool = False) -> dict:
        """ページ遷移(HTML)用の追加ヘッダ。"""
        h = {
            "Accept": ("text/html,application/xhtml+xml,application/xml;q=0.9,"
                       "image/avif,image/webp,image/apng,*/*;q=0.8"),
            "Accept-Language": "ja-JP,ja;q=0.9",
            "Sec-Fetch-Site": "none" if first else "same-origin",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "Priority": "u=0, i",
        }
        if referer:
            h["Referer"] = referer
        return h

    def _xhr_headers(self, referer: str = None) -> dict:
        """XHR(fetch)用の追加ヘッダ。"""
        h = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "ja-JP,ja;q=0.9",
            "X-Requested-With": "XMLHttpRequest",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "cors",
            "Sec-Fetch-Dest": "empty",
            "Priority": "u=1, i",
        }
        if referer:
            h["Referer"] = referer
        return h

    def _form_post_headers(self, referer: str) -> dict:
        """フォーム送信(POSTしてページ遷移)用の追加ヘッダ。"""
        h = {
            "Origin": self.BASE_URL,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": ("text/html,application/xhtml+xml,application/xml;q=0.9,"
                       "image/avif,image/webp,image/apng,*/*;q=0.8"),
            "Accept-Language": "ja-JP,ja;q=0.9",
            "Sec-Fetch-Site": "same-origin",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-User": "?1",
            "Upgrade-Insecure-Requests": "1",
            "Priority": "u=0, i",
            "Referer": referer,
        }
        return h

    @staticmethod
    def _pkce() -> tuple[str, str]:
        verifier  = secrets.token_urlsafe(64)[:87]
        challenge = base64.urlsafe_b64encode(
            hashlib.sha256(verifier.encode()).digest()
        ).rstrip(b"=").decode()
        return verifier, challenge

    @staticmethod
    def _encrypt_password(line_id: str, password: str, rsa_key_str: str, session_key: str) -> tuple[str, str, str]:
        def build_message(sk, lid, pw) -> bytes:
            def lc(s): return bytes([len(s)])
            return lc(sk) + sk.encode() + lc(lid) + lid.encode() + lc(pw) + pw.encode()

        key_id, n_hex, e_hex = rsa_key_str.split(",")
        message = build_message(session_key, line_id, password)
        n, e    = int(n_hex, 16), int(e_hex, 16)
        pub_key = RSA.construct((n, e))
        cipher  = PKCS1_v1_5.new(pub_key)
        encrypted = cipher.encrypt(message)
        user_id   = hashlib.md5(line_id.encode()).hexdigest()
        return key_id, encrypted.hex(), user_id

    @staticmethod
    def _app_data(html_text: str) -> dict:
        """ページに埋まっている app-data を辞書で返す。読めなければ空。"""
        try:
            soup    = BeautifulSoup(html_text, "html.parser")
            app_tag = soup.find("app")
            if not app_tag:
                return {}
            return json.loads(app_tag.get("app-data", "{}")) or {}
        except (ValueError, TypeError):
            return {}

    @staticmethod
    def _deep_find(node, match, depth: int = 0):
        """入れ子のどこかにある値を、キー名の条件で拾う。

        LINEは項目の位置も名前もよく変えるので、決め打ちの経路では追えない。
        """
        if depth > 8:
            return None
        if isinstance(node, dict):
            for key, value in node.items():
                if match(str(key), value):
                    return value
                found = LineOAuthLogin._deep_find(value, match, depth + 1)
                if found is not None:
                    return found
        elif isinstance(node, (list, tuple)):
            for item in node:
                found = LineOAuthLogin._deep_find(item, match, depth + 1)
                if found is not None:
                    return found
        return None

    @classmethod
    def _find_pin(cls, data: dict):
        """PINコード認証のページなら、その数字を返す。違えば None。"""
        def is_pin(key, value):
            return ("pin" in key.lower()
                    and isinstance(value, (str, int))
                    and str(value).strip().isdigit()
                    and 3 <= len(str(value).strip()) <= 8)
        found = cls._deep_find(data, is_pin)
        return str(found).strip() if found is not None else None

    @classmethod
    def _find_error(cls, data: dict):
        """LINEが返したエラー文言。無ければ None。"""
        def is_error(key, value):
            return (key.lower() in ("error", "errormessage", "error-message",
                                    "message", "errordescription")
                    and isinstance(value, str) and value.strip())
        found = cls._deep_find(data, is_error)
        return found.strip() if isinstance(found, str) else None

    @staticmethod
    def detect_captcha(html_text: str) -> dict:
        soup    = BeautifulSoup(html_text, "html.parser")
        app_tag = soup.find("app")
        if not app_tag:
            return {"has_captcha": False}
        raw  = app_tag.get("app-data", "{}")
        data = json.loads(raw).get("props", {})
        return {
            "has_captcha":   data.get("is-captcha", False),
            "is_recaptcha":  data.get("is-recaptcha", False),
            "captcha_url":   data.get("captcha-url"),
            "recaptcha_key": data.get("recaptcha-key"),
        }

    @staticmethod
    def _code_from(url_or_loc: str):
        """URL/Location から認可コードを取り出す。無ければ None。"""
        if not url_or_loc:
            return None
        return urllib.parse.parse_qs(
            urllib.parse.urlparse(url_or_loc).query).get("code", [None])[0]

    def _current_csrf(self, session):
        """セッションの今の csrf クッキー。承認後は入れ替わっていることがある。"""
        try:
            return session.cookies.get("X-SCGW-CSRF-Token") or ""
        except Exception:
            return ""

    async def _post_consent_once(self, session, csrf_token: str, referer: str):
        """同意を1回だけ投げて、認可コードがあれば返す。無ければ None。"""
        # allPermission/approvedPermission は同じキーが複数回出るので、手で
        # urlencode して繰り返しキーを保つ(dictだと潰れる)。
        body = urllib.parse.urlencode([
            ("addFriend", "true"), ("allPermission", "P"), ("approvedPermission", "P"),
            ("allPermission", "F"), ("approvedPermission", "F"),
            ("allPermission", "M"), ("approvedPermission", "M"),
            ("allPermission", "TUK"), ("approvedPermission", "TUK"),
            ("channelId", self.CLIENT_ID), ("addFriendMode", "ALREADY_FRIENDED_MODE"),
            ("__csrf", csrf_token), ("lang", "ja"), ("allow", "true"),
        ])
        resp = await session.post(
            f"{self.BASE_URL}/oauth2/v2.1/authorize/consent",
            data=body,
            headers=self._form_post_headers(referer),
            allow_redirects=False,
        )
        location = resp.headers.get("Location", "") or ""
        return self._code_from(location), resp.status_code, location

    # pin/wait が承認待ちのセッションを見分けるための印を載せるヘッダ名。
    # /qrlogin/v1/ の API はクエリではなくここでトークンを受け取る。
    def _pin_wait_variants(self, urls: list, session_id: str, verifier: str):
        """pin/wait の正解の叩き方。実機キャプチャ(HAR)で確定。

        GET {url}?_=<ミリ秒> で、verifier は **X-Line-Login-Verifier ヘッダ** に入れる。
        クエリの ?verifier= では 400 になる(ヘッダが必須だった)。承認されると応答本文は
        {"result":true}。サーバはロングポーリングで、承認されるまで接続を保持する。
        本線は api-url(/qrlogin/oauth2/v2.1/authn/pin/wait)。complete-url も一応残す。
        """
        variants = []
        hdrs = {"X-Line-Login-Verifier": verifier} if verifier else {}
        for url in urls:
            variants.append((f"GET pin/wait …{url[-20:]}", url, {
                "method": "GET", "cache_buster": True, "headers": hdrs,
            }))
        return variants

    async def _pin_wait_send(self, session, url, headers, spec, timeout):
        """spec の通りに1回叩いて (status, body) を返す。pin/wait は GET のみ。"""
        hdrs = dict(headers)
        hdrs.update(spec.get("headers") or {})
        # 実機に合わせてキャッシュ無効化ヘッダを付ける。
        hdrs.setdefault("Pragma", "no-cache")
        hdrs.setdefault("Cache-Control", "no-cache")
        hdrs.setdefault("If-Modified-Since", "Thu, 01 Jan 1970 00:00:00 GMT")
        params = dict(spec.get("params") or {})
        if spec.get("cache_buster"):
            params["_"] = int(time.time() * 1000)
        r = await session.get(
            url, params=params, allow_redirects=False, headers=hdrs, timeout=timeout)
        return r.status_code, (r.text or "")[:4000]

    async def _poll_pin_wait(self, session, pin_wait_urls, session_id: str,
                             referer: str, attempt: int, verifier: str = None):
        """PIN承認待ちエンドポイント(pin/wait)を叩く。

        LINEはスマホでPINを承認しても、それだけではこのWebセッションは「承認済み」に
        ならない。ブラウザがこの pin/wait をロング・ポーリングして初めて、サーバ側で
        セッションが承認済みに切り替わる。だから承認を拾うには必ずここを正しく叩く。
        叩き方は実機キャプチャで確定済み(X-Line-Login-Verifier ヘッダ + GET)。承認されると
        {"result":true} が返る。戻り値 (status, body)。呼べなくても致命ではないので握りつぶす。
        """
        urls = [u for u in (pin_wait_urls or []) if u]
        if not urls:
            return None, ""
        csrf = self._current_csrf(session)
        headers = self._xhr_headers(referer)
        if csrf:
            headers["X-SCGW-CSRF-Token"] = csrf
        # 叩き方は確定済みなので、最初からロングポーリングの待ち上限で待つ
        # (誤りの送り方なら400等が即返るだけなので長めでも損はない)。
        if self._pin_wait_variant is not None:
            variants = [self._pin_wait_variant]
        else:
            variants = [v for v in self._pin_wait_variants(urls, session_id, verifier)
                        if v[0] not in self._pin_wait_dead]
            if not variants:
                # 全部の送り方が弾かれた。以後は authorize/consent の取り直しだけで待つ。
                if self.PIN_DEBUG and attempt == 1:
                    print("[OAuth] PIN待ち: pin/wait はどの送り方も通らず。"
                          "authorize/consent の取り直しのみで待ちます。")
                return None, ""
        probe_timeout = self.PIN_LONGPOLL_TIMEOUT
        for v in variants:
            label, url, spec = v
            try:
                status, body = await self._pin_wait_send(
                    session, url, headers, spec, probe_timeout)
            except Exception as e:
                # ロングポーリングのタイムアウトは「サーバが接続を保持して承認を待って
                # いる＝効いている」サイン。curl_cffi は asyncio.TimeoutError ではなく
                # 独自の例外(curl 28: Operation timed out)で飛ぶので、両方を拾う。
                msg = str(e)
                is_timeout = (isinstance(e, asyncio.TimeoutError)
                              or "timed out" in msg.lower() or "(28)" in msg)
                if is_timeout:
                    self._pin_wait_variant = v
                    if self.PIN_DEBUG:
                        print(f"[OAuth] PIN待ち #{attempt}: pin/wait[{label}] "
                              "待機中(ロングポーリング継続・承認待ち)")
                    return None, "(timeout)"
                if self.PIN_DEBUG:
                    print(f"[OAuth] PIN待ち #{attempt}: pin/wait[{label}] 失敗 "
                          f"{type(e).__name__}: {e}")
                continue
            if self.PIN_DEBUG:
                print(f"[OAuth] PIN待ち #{attempt}: pin/wait[{label}] {status} {body!r}")
            # 当て方が違うもの: 400(パラメータ)・401/403(印が違う)・404/405(URL/メソッド)。
            # 3xx はログイン画面へ戻されているので、これも受け付けられていない。
            if status in (400, 401, 403, 404, 405) or 300 <= status < 400:
                self._pin_wait_dead.add(label)
                continue
            self._pin_wait_variant = v
            return status, body
        return None, ""

    async def _consent_for_code(self, session, csrf_token: str, referer: str,
                                wait_seconds: int = 0, authorize_url: str = None,
                                pin_wait_urls=None, session_id: str = None,
                                verifier: str = None, pin_referer: str = None):
        """同意を投げて認可コードを取る。取れなければ None。

        wait_seconds を渡すと、その時間まで待ちながら取りにいく（PINコード認証の待ち）。
        PIN認証のあいだ、各周回で:
          1) pin/wait を叩く。スマホでの承認をサーバに拾わせ、セッションを承認済みへ
             切り替えさせる（これを叩かないと、いくら consent を投げても永久に通らない）。
          2) 認可ページ(authorize_url)を取り直す。承認済みならここで code つきに
             リダイレクトされる。ついでに今の csrf を取り込む。
          3) 取り直した csrf で同意を投げる。
        これで「アプリで承認 → こちらが検知して先へ進む」がつながる。
        """
        # 待ちなし（PIN無し）は今まで通り、1回だけ同意を投げる。
        if wait_seconds <= 0:
            code, _, _ = await self._post_consent_once(session, csrf_token, referer)
            return code

        deadline = time.time() + wait_seconds
        attempt  = 0
        # 待ちに入る前に、ブラウザと同じく PINページ(/pincode)を一度開く。
        # authenticate 直後にいきなり pin/wait を叩くと、サーバ側がまだ「PIN待ち」状態に
        # なっておらず、pin/wait が素の400・authorize も login へ戻される(実機ログで確認)。
        # /pincode に着地させてから待つ。
        if pin_referer:
            try:
                pr = await session.get(pin_referer, allow_redirects=False,
                                       headers=self._nav_headers(referer))
                if self.PIN_DEBUG:
                    print(f"[OAuth] PINページを開く: {pr.status_code} {pin_referer}")
            except Exception as e:
                if self.PIN_DEBUG:
                    print(f"[OAuth] PINページを開けず(継続): {type(e).__name__}: {e}")
        while True:
            attempt += 1
            # 1) pin/wait を叩いて、スマホでの承認をサーバに拾わせる（最重要）。
            #    ロングポーリングの Referer は PINページ(/pincode)にする。
            await self._poll_pin_wait(session, pin_wait_urls, session_id,
                                      pin_referer or referer,
                                      attempt, verifier=verifier)
            # 2) 認可ページを取り直す（承認済みならcodeへ、csrfも更新される）。
            if authorize_url:
                try:
                    gr = await session.get(
                        authorize_url, allow_redirects=False,
                        headers=self._nav_headers(referer),
                    )
                    gloc = gr.headers.get("Location", "") or ""
                    gstatus = gr.status_code
                    gcode = self._code_from(gloc)
                    if self.PIN_DEBUG:
                        print(f"[OAuth] PIN待ち #{attempt}: authorize {gstatus} "
                              f"loc={gloc[:80]!r}")
                    if gcode:
                        return gcode
                except Exception as e:
                    if self.PIN_DEBUG:
                        print(f"[OAuth] PIN待ち authorize 取得失敗: {type(e).__name__}: {e}")
            # 3) 最新の csrf で同意を投げる。
            fresh = self._current_csrf(session)
            if fresh:
                csrf_token = fresh
            code, cstatus, cloc = await self._post_consent_once(
                session, csrf_token, referer)
            if self.PIN_DEBUG:
                print(f"[OAuth] PIN待ち #{attempt}: consent {cstatus} loc={cloc[:80]!r}")
            if code:
                return code
            if time.time() >= deadline:
                return None
            if attempt == 1:
                print("[OAuth] PINの承認待ち。承認され次第そのまま進みます。")
            await asyncio.sleep(min(self.PIN_POLL_SECONDS,
                                    max(1.0, deadline - time.time())))

    async def login(self) -> tuple[str, str]:
        state            = secrets.token_urlsafe(12)
        verifier, challenge = self._pkce()
        redirect_encoded = urllib.parse.quote(self.REDIRECT_URI, safe="")
        consent_params   = (
            f"response_type=code&client_id={self.CLIENT_ID}&state={state}"
            f"&code_challenge={challenge}&code_challenge_method=S256"
            f"&redirect_uri={redirect_encoded}&sdk_ver=5.11.1"
            f"&scope=friends%20message.write%20profile%20trident.user.key&bot_prompt=normal"
        )
        return_uri         = "/oauth2/v2.1/authorize/consent?" + consent_params
        return_uri_encoded = urllib.parse.quote(return_uri, safe="")
        login_url = (
            f"{self.BASE_URL}/oauth2/v2.1/login"
            f"?returnUri={return_uri_encoded}&loginChannelId={self.CLIENT_ID}&ui_locales=ja"
        )

        # トラッキング/ブラウザ識別のCookieは「アカウントごとに固定」にする。
        # 同じ垢は常に同じ端末から入るように見せ(=LINEに信頼された端末と認識させ)、
        # かつ垢ごとに別の指紋にして「1台で大量の垢」に見えないようにする。両取り。
        initial_cookies = line_account_cookies(self.line_id)

        # curl_cffi で本物のChromeになりすます(TLS/JA3・HTTP2・ヘッダ順・UA・sec-ch-ua)。
        # 生HTTP(aiohttp)だとTLS指紋がPythonのままで「bot」と判別されやすいので、ここを
        # Chromeに寄せるのが最大の対策。impersonate が UA/sec-ch-ua も揃えてくれる。
        async with CurlSession(impersonate=self.IMPERSONATE,
                               cookies=initial_cookies) as session:

            print("[OAuth] Step 1: session init")
            resp = await session.get(login_url, headers=self._nav_headers(first=True))
            html_text = resp.text

            captcha_info = self.detect_captcha(html_text)
            captcha      = None
            if captcha_info["has_captcha"]:
                print(f"[OAuth] キャプチャあり: {captcha_info['captcha_url']}")
                img_resp = await session.get(
                    self.BASE_URL + captcha_info["captcha_url"],
                    headers={"Referer": login_url})
                img_data = img_resp.content

                if self.captcha_callback:
                    captcha = await self.captcha_callback(img_data)
                else:
                    with open("captcha.png", "wb") as f:
                        f.write(img_data)
                    captcha = input("CaptchaCode: ")

            m = re.search(r'app-data="(.+?)"', html_text)
            if not m:
                raise Exception("app-data not found")
            data        = json.loads(html.unescape(m.group(1)))
            captcha_url = data["props"]["captcha-url"]
            captcha_key = next(
                (f["value"] for f in data["slots"]["serverside_field"] if f.get("name") == "captchaKey"),
                None,
            )

            ts = int(time.time() * 1000)
            resp = await session.get(
                f"{self.BASE_URL}/oauth2/v2.1/authn/session?_={ts}",
                headers=self._xhr_headers(login_url))
            session_id = resp.json()["result"]
            print(f"[OAuth] sessionId: {session_id[:20]}...")

            ts = int(time.time() * 1000)
            resp = await session.get(
                f"{self.BASE_URL}/oauth2/v2.1/authn/keys/line?sessionId={session_id}&_={ts}",
                headers=self._xhr_headers(login_url))
            key_data    = resp.json()
            session_key = key_data["session_key"]
            rsa_key     = key_data["rsa_key"]

            key_id, encrypted_pw, user_id = self._encrypt_password(self.line_id, self.password, rsa_key, session_key)
            csrf_token = self._current_csrf(session)

            # 人はメアド・パスを一瞬では打てない。即 authenticate すると「速すぎる=bot」に
            # 見えて追加認証を誘発しやすいので、入力時間ぶんだけ間を空ける(毎回ゆらす)。
            await asyncio.sleep(random.uniform(
                float(os.getenv("TSUM_LINE_TYPE_DELAY_MIN", "2.5")),
                float(os.getenv("TSUM_LINE_TYPE_DELAY_MAX", "6.0"))))

            print("[OAuth] Step 4: authenticate")
            post_data = {
                "userId": user_id, "encUserId": "", "id": key_id,
                "password": encrypted_pw, "idProvider": "1",
                "sessionId": session_id, "encKeyId": key_id,
                "loginChannelId": self.CLIENT_ID, "returnUri": return_uri,
                "displayType": "M", "captchaKey": captcha_key,
                "__csrf": csrf_token, "lang": "ja",
                **( {"captcha": captcha} if captcha is not None else {} ),
            }
            resp = await session.post(
                f"{self.BASE_URL}/oauth2/v2.1/authenticate",
                data=post_data,
                headers=self._form_post_headers(login_url),
                allow_redirects=True,
            )
            last_url  = str(resp.url)
            auth_html = resp.text

            # authenticate の着地点を確定させる。承認待ちの /pincode に着いているのか、
            # それともエラー/再試行(noauto-login)へ弾かれているのかで打つ手が変わる。
            if self.PIN_DEBUG:
                try:
                    hops = " -> ".join(
                        f"{h.status_code}:{str(h.url)[:70]}"
                        for h in (getattr(resp, "history", None) or []))
                    print(f"[OAuth] authenticate 経路: [{hops}] => "
                          f"{resp.status_code}:{last_url[:100]}")
                    pick = ("location", "x-line", "x-scgw", "x-lal", "x-ls")
                    rh = {k: (v if not k.lower().startswith("set-cookie") else "(省略)")
                          for k, v in resp.headers.items()
                          if k.lower().startswith(pick)}
                    ck = [c.split("=", 1)[0] for c in resp.headers.get_list("set-cookie")] \
                        if hasattr(resp.headers, "get_list") else []
                    print(f"[OAuth] authenticate 応答ヘッダ(抜粋): {rh} / Set-Cookie名: {ck}")
                except Exception as e:
                    print(f"[OAuth] authenticate 経路ログ失敗: {type(e).__name__}: {e}")

            # ここで応答を読む。読まずに consent へ進むと、PINコード認証に
            # 進んだ場合も「メアパスが間違っています」で終わってしまう
            # （LINEは受け付けていて、承認を待っているだけなのに）。
            auth_data = self._app_data(auth_html)
            pin       = self._find_pin(auth_data)
            props     = auth_data.get("props", {}) if isinstance(auth_data, dict) else {}
            print(f"[OAuth] Step 4 done: {last_url}")

            # 追加認証(reCAPTCHA付きchallenge)が出たら、こちらでは解けない。5分待たせず、
            # PINも見せず、すぐ正直に案内する(時間をおくと出ないことが多い/ゲスト誘導)。
            if bool(props.get("is-recaptcha")) and bool(props.get("is-error")):
                print("[OAuth] reCAPTCHA付きの追加認証を検知 → 即中止して案内")
                raise LineVerificationRequired(
                    "LINE側で追加の本人確認（ロボット確認）が入りました。少し時間をおいて"
                    "もう一度ログインするか、「ゲストログイン」でお進みください。", pin=None)

            if pin:
                print(f"[OAuth] PINコード認証: {pin}")
                if self.PIN_DEBUG:
                    # PINページの中身(キー構成)を出す。専用の承認確認URLが要るなら
                    # ここに手掛かりがあるはず(verifyUrl / certificate など)。
                    try:
                        print(f"[OAuth] PINページ app-data: "
                              f"{json.dumps(auth_data, ensure_ascii=False)[:8000]}")
                    except Exception:
                        pass
                if self.pin_callback:
                    try:
                        await self.pin_callback(pin)
                    except Exception as e:
                        print(f"[OAuth] PINの通知に失敗: {type(e).__name__}: {e}")

            print("[OAuth] Step 5: consent")
            # PIN承認待ち専用のエンドポイント(pin/wait)。app-dataに載っていれば
            # それを使う(LINEはパスをよく変えるので決め打ちにしない)。
            # LINEが載せてくる承認待ちURLは2種類ある(api-url と complete-url)。両方試す。
            pin_paths = [props.get("wait-pin-code-verification-api-url"),
                         props.get("wait-pin-code-verification-complete-url")]
            pin_paths = [p for p in pin_paths if p] or [self.PIN_WAIT_PATH_DEFAULT]
            pin_wait_urls = [f"{self.BASE_URL}{p}" for p in pin_paths] if pin else None
            # 注意: これは pin/wait 用の app-data の verifier。PKCEの code_verifier
            # (関数冒頭の verifier)とは別物なので、名前を分けて上書きしない。
            pin_verifier = props.get("verifier")
            # pin/wait の Referer は、実機では再試行ページ(noauto-login=last_url)だった。
            # /pincode を直接開く必要はない(むしろ直GETは403)。pin_referer=None にして、
            # pin/wait の Referer は last_url をそのまま使わせる。
            pin_referer = None
            if pin and self.PIN_DEBUG:
                print(f"[OAuth] PIN待ちURL: {pin_wait_urls} / verifier={pin_verifier!r} "
                      f"/ referer={last_url[:90]}")

            code = await self._consent_for_code(
                session, csrf_token, last_url,
                # PINが出ているなら、承認されるまで待つ。待ちのあいだは pin/wait を叩いて
                # スマホでの承認をサーバに拾わせ、認可ページを取り直して同意を投げ直す。
                wait_seconds=self.PIN_WAIT_SECONDS if pin else 0,
                authorize_url=f"{self.BASE_URL}{return_uri}",
                pin_wait_urls=pin_wait_urls, session_id=session_id,
                verifier=pin_verifier, pin_referer=pin_referer)

            if not code:
                if pin and self._pin_wait_variant is None:
                    # 承認待ちを拾う口に一度も通らなかった。承認したかどうかに関わらず
                    # こちらが受け取れていないので、お客さんのせいにしない。
                    print("[OAuth] pin/wait に通らないまま時間切れ")
                    raise LineVerificationRequired(
                        "LINEの本人確認の結果をこちらで受け取れませんでした。"
                        "お手数ですが、もう一度ログインするか「ゲストログイン」で"
                        "お進みください。", pin=pin)
                if pin:
                    raise LineVerificationRequired(
                        "LINEのPINコード認証が承認されませんでした。"
                        f"LINEアプリに出た「{pin}」を選んで承認してから、"
                        "もう一度お試しください。", pin=pin)
                message = self._find_error(auth_data)
                if message:
                    raise LineCredentialError(f"LINEからの応答: {message}")
                raise LineLoginError(
                    "LINEのログインを完了できませんでした。"
                    f"（最後に開いた画面: {last_url[:200]}）")
            print(f"[OAuth] code: {code}")

            print("[OAuth] Step 6: token")
            async with aiohttp.ClientSession() as token_session:
                async with token_session.post(
                    self.TOKEN_URL,
                    data={
                        "grant_type": "authorization_code", "code": code,
                        "redirect_uri": self.REDIRECT_URI, "client_id": self.CLIENT_ID,
                        "code_verifier": verifier, "id_token_key_type": "JWK",
                        "client_version": "LINE SDK Android v5.11.1",
                    },
                    headers={
                        "User-Agent": self.UA_APP,
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                ) as resp:
                    token_data = await resp.json()

        print("[OAuth] token取得 OK")
        return token_data["access_token"], token_data["refresh_token"]

class LineTokenManager:
    TOKEN_URL  = "https://api.line.me/oauth2/v2.1/token"
    CLIENT_ID  = "1381161556"
    USER_AGENT = _user_agent(TSUM_APP_VER)

    def __init__(self, refresh_token: str):
        self.refresh_token = refresh_token
        self.access_token  = None
        self.expires_at    = 0

    async def refresh(self) -> str:
        print("[LINE] access_token 更新中...")
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.TOKEN_URL,
                data={
                    "grant_type":    "refresh_token",
                    "refresh_token": self.refresh_token,
                    "client_id":     self.CLIENT_ID,
                },
                headers={"User-Agent": self.USER_AGENT, "Content-Type": "application/x-www-form-urlencoded"},
            ) as resp:
                
                resp.raise_for_status()
                data = await resp.json()

        self.access_token  = data["access_token"]
        self.refresh_token = data.get("refresh_token", self.refresh_token)
        self.expires_at    = time.time() + data["expires_in"]
        print("[LINE] access_token更新 OK")
        return self.access_token

    async def get_token(self) -> str:
        if not self.access_token or time.time() > self.expires_at - 60:
            await self.refresh()
        return self.access_token

class LineGameAuth:
    AUTH_URL    = "https://game-api.line.me/auth/v3.8/refresh"
    APP_ID      = "LGTMTM"
    DEVICE_ID   = "ebf92ff8f267402fa5600f1a025242d9"
    SDK_VER     = "3.12.1.422"
    USER_AGENT  = "android;11;RQ3A_211001_001;GOOGLEPLAY;ja"

    def __init__(self, refresh_user_token: str = None):
        self.refresh_user_token = refresh_user_token
        self.user_token         = None
        self.user_key           = None
        self.expires_at         = 0

    async def refresh(self, access_token: str) -> dict:
        print("[GameSDK] userToken 更新中...")
        timestamp_ms = int(time.time() * 1000)
        ts_str = datetime.datetime.fromtimestamp(
            timestamp_ms / 1000,
            tz=datetime.timezone(datetime.timedelta(hours=9))
        ).strftime("%Y-%m-%dT%H:%M:%S.000+0900")

        body = msgpack.packb(
            {"providerId": "LINE", "accessToken": access_token, "country": "JP"},
            use_bin_type=True,
        )

        async with aiohttp.ClientSession(headers={}) as session:
            async with session.post(
                self.AUTH_URL,
                data=body,
                headers={
                    "Accept-Encoding":          "identity",
                    "X-Linegame-DeviceId":      self.DEVICE_ID,
                    "X-Linegame-AppId":         self.APP_ID,
                    "Content-Type":             "application/x-msgpack",
                    "X-Linegame-Authorization": f'ts="{timestamp_ms}", si=""',
                    "User-Agent":               self.USER_AGENT,
                    "X-Linegame-Timestamp":     ts_str,
                    "X-Linegame-SdkVersion":    self.SDK_VER,
                    "X-Linegame-MCC":           "",
                    "X-Linegame-MNC":           "",
                },
            ) as resp:
                print(f"[GameSDK] status: {resp.status}")
                resp.raise_for_status()
                data = await resp.json()

        self.user_key           = data["userKey"]
        self.user_token         = data["userToken"]
        self.refresh_user_token = data["refreshUserToken"]
        self.expires_at         = data["userTokenExpireTime"] / 1000
        print("[GameSDK] userToken取得 OK")
        return data

    async def get_user_token(self, access_token: str) -> str:
        if not self.user_token or time.time() > self.expires_at - 60:
            await self.refresh(access_token)
        return self.user_token


class TsumMigrationError(Exception):
    """引き継ぎ番号・パスワードでの認証に失敗した。

    番号かパスワードが違う／期限切れのときにここへ来る。やり直しても
    同じなので、呼び出し側はお客さんに番号を確かめてもらう。
    """


# 引き継ぎ(ゲスト)認証の宛先。ゲームAPI本体(lgtmtm-game)とは別のホスト。
GUEST_AUTH_HOST  = "https://game-api.line.me"
GUEST_TERMS_HOST = "https://game-terms.line.me"
# 引き継ぎ番号に使える文字。英小文字＋数字で、最後の1文字は必ず英字にする
# (数字だけの番号はサーバーが「形式が違う」で弾く)。
_MIGID_CHARS = string.ascii_lowercase + string.digits


class GuestAuth:
    """LINEを介さず、引き継ぎ番号(id)とパスワードでゲスト垢に入る。

    LINEログインが「LINE OAuth → access_token → userToken」なのに対し、
    ゲストはこちらで作った uuid で新しいゲスト垢を起こし、引き継ぎ番号で
    その垢をお客さんの垢に入れ替える。入れ替えたあとの代行の中身は、
    LINEで入ったときとまったく同じ経路(login.nhn 以降)を使う。

    手順はすべて実サーバーで確かめてある:
      1. 規約を取ってきて termsResult を作る(規約は改定されるので毎回取る)
      2. authentication/GUEST でゲスト垢を新規発行 → userToken
      3. migration に番号+パスワードを渡してお客さんの垢へ入れ替え
      4. refresh で入れ替え後の垢の userToken を取り直す(ここを飛ばすと
         login.nhn がセッションを返さない)
    代行が終わったら issue_code() で新しい番号を発行してお客さんに返す。この
    番号は防犯ロックのため、発行から数時間〜24時間ほど経たないと使えない
    (移した直後は「最近移動したばかり」で弾かれる)。すぐ使えないのは仕様。
    """
    APP_ID    = "LGTMTM"
    DEVICE_ID = LineGameAuth.DEVICE_ID
    SDK_VER   = LineGameAuth.SDK_VER
    COUNTRY   = "JP"
    LANGUAGE  = "ja"

    def __init__(self):
        self.uuid = str(uuid.uuid4())
        self.user_token = None
        self.refresh_user_token = None
        self.user_key = None

    def _headers(self, user_token: str = None, msgpack_body: bool = True) -> dict:
        ts = int(time.time() * 1000)
        tss = datetime.datetime.fromtimestamp(
            ts / 1000, tz=datetime.timezone(datetime.timedelta(hours=9))
        ).strftime("%Y-%m-%dT%H:%M:%S.000+0900")
        h = {
            "X-Linegame-DeviceId":      self.DEVICE_ID,
            "X-Linegame-AppId":         self.APP_ID,
            "X-Linegame-SdkVersion":    self.SDK_VER,
            "X-Linegame-AppVersion":    TSUM_APP_VER,
            "X-Linegame-Region":        self.COUNTRY,
            "X-Linegame-Timestamp":     tss,
            # si(署名)はサーバーが見ていない。LINEログインも空で通っている。
            "X-Linegame-Authorization": f'ts="{ts}", si=""',
            "X-Linegame-MCC":           "",
            "X-Linegame-MNC":           "",
            "Accept-Encoding":          "identity",
            "User-Agent":               "android;11;RQ3A_211001_001;GOOGLEPLAY;ja",
        }
        if msgpack_body:
            h["Content-Type"] = "application/x-msgpack"
        if user_token:
            h["X-Linegame-UserToken"] = user_token
        return h

    @staticmethod
    def _parse(raw: bytes) -> dict:
        # 認証系の応答はJSON。念のためmsgpackも受ける。
        try:
            return json.loads(raw)
        except Exception:
            try:
                return msgpack.unpackb(raw, raw=False)
            except Exception:
                return {}

    async def _post(self, session, path: str, payload: dict,
                    user_token: str = None) -> dict:
        async with session.post(
                GUEST_AUTH_HOST + path,
                data=msgpack.packb(payload, use_bin_type=True),
                headers=self._headers(user_token)) as resp:
            return resp.status, self._parse(await resp.read())

    async def _terms_result(self, session) -> str:
        """いま必須の規約を全部「同意した」形にした文字列を作る。

        規約(termsId・改定日)はサーバーが持っていて、改定されると変わる。
        決め打ちすると改定のたびに代行が止まるので、毎回取ってくる。
        """
        url = f"{GUEST_TERMS_HOST}/terms/v2.0/group/{self.APP_ID}/{self.COUNTRY}"
        async with session.get(url, headers=self._headers(msgpack_body=False)) as resp:
            terms = self._parse(await resp.read())
        if not isinstance(terms, list) or not terms:
            raise TsumMigrationError("規約情報を取得できませんでした")
        agreements = []
        for t in terms:
            revs = t.get("revisions") or []
            if not revs:
                continue
            latest = max(revs, key=lambda r: r.get("date", ""))
            agreements.append({
                "termsId":      t["termsId"],
                "country":      self.COUNTRY,
                "language":     self.LANGUAGE,
                "revisionDate": latest["date"],
                "agree":        True,
            })
        return json.dumps({"agreements": agreements}, separators=(",", ":"))

    async def _refresh(self, session):
        """入れ替え後・期限切れ後の userToken を取り直す。"""
        st, res = await self._post(session, "/auth/v3.8/refresh", {
            "providerId":       "GUEST",
            "uuid":             self.uuid,
            "refreshUserToken": self.refresh_user_token,
            "country":          self.COUNTRY,
        })
        if not res.get("userToken"):
            raise TsumMigrationError("ゲストセッションの更新に失敗しました")
        self.user_token = res["userToken"]
        self.refresh_user_token = res.get("refreshUserToken", self.refresh_user_token)
        self.user_key = res.get("userKey", self.user_key)

    async def open(self, session, migration_id: str, password: str) -> str:
        """新規ゲスト作成 → 引き継ぎ → 更新まで。login.nhn 用の userToken を返す。"""
        # 1) 規約に同意して新しいゲスト垢を作る
        tr = await self._terms_result(session)
        st, res = await self._post(session, "/auth/v3.8/authentication/GUEST", {
            "uuid":           self.uuid,
            "country":        self.COUNTRY,
            "transferOption": "useCurrent",
            "resetLimit":     24,
            "termsResult":    tr,
            "accessToken":    "",
            "providerKey":    "",
        })
        if not res.get("userToken"):
            raise TsumMigrationError(f"ゲスト垢の作成に失敗しました: {_auth_err(res)}")
        self.user_token = res["userToken"]
        self.refresh_user_token = res.get("refreshUserToken")
        self.user_key = res.get("userKey")

        # 2) 引き継ぎ番号でお客さんの垢へ入れ替え
        st, res = await self._post(session, "/auth/v3.0/user/migration?dryRun=false",
                                   {"id": migration_id, "password": password},
                                   user_token=self.user_token)
        if not res.get("userKey"):
            raise TsumMigrationError(
                f"引き継ぎに失敗しました（番号かパスワードが違います）: {_auth_err(res)}")
        self.user_key = res["userKey"]

        # 3) 入れ替え後の垢の userToken を取り直す(飛ばすと login.nhn が通らない)
        await self._refresh(session)
        return self.user_token

    async def validate(self, session, migration_id: str, password: str):
        """番号とパスワードが正しいかだけ確かめる(垢は動かさない)。

        migration の dryRun=true は、番号を消費せずに当たり判定だけ返す。
        支払いの前にこれで確かめておけば、間違った番号のまま課金させずに済む。
        確認用に起こしたゲスト垢は捨てる。
        """
        tr = await self._terms_result(session)
        st, res = await self._post(session, "/auth/v3.8/authentication/GUEST", {
            "uuid": self.uuid, "country": self.COUNTRY, "transferOption": "useCurrent",
            "resetLimit": 24, "termsResult": tr, "accessToken": "", "providerKey": "",
        })
        if not res.get("userToken"):
            raise TsumMigrationError(f"確認用のゲスト垢を作れませんでした: {_auth_err(res)}")
        st, res = await self._post(session, "/auth/v3.0/user/migration?dryRun=true",
                                   {"id": migration_id, "password": password},
                                   user_token=res["userToken"])
        if not res.get("userKey"):
            raise TsumMigrationError("引き継ぎ番号かパスワードが違います")

    async def issue_code(self, session) -> tuple:
        """新しい引き継ぎ番号を発行して (番号, パスワード) を返す。

        代行が終わったあと、お客さんに垢を返すために使う。番号はこちらで作り、
        パスワードはサーバーが決めて返す。発行自体はすぐ通るが、防犯ロックで
        実際に使えるのは数時間〜24時間ほど後(それまでは 2010 で弾かれる)。
        """
        await self._refresh(session)          # 長い代行で切れていることがある
        for _ in range(5):
            mid = ("".join(secrets.choice(_MIGID_CHARS) for _ in range(7))
                   + secrets.choice(string.ascii_lowercase))
            st, res = await self._post(session, "/auth/v3.0/user/migration-id",
                                       {"id": mid}, user_token=self.user_token)
            if res.get("password"):
                return mid, res["password"]
            # 万一ぶつかった(既に使われている番号)だけやり直す
            if (res.get("error") or {}).get("code") not in ("AUTH_400_0009",):
                break
        raise TsumMigrationError(f"引き継ぎ番号の発行に失敗しました: {_auth_err(res)}")


def _auth_err(res: dict) -> str:
    err = (res or {}).get("error") or {}
    return err.get("message") or err.get("code") or "unknown"


async def validate_guest_code(migration_id: str, password: str):
    """引き継ぎ番号・パスワードが正しいか確かめる(垢は動かさない)。

    支払いの前に呼ぶ。違っていれば TsumMigrationError。
    """
    guest = GuestAuth()
    async with aiohttp.ClientSession() as session:
        await guest.validate(session, migration_id, password)


class LGTMTMClient:
    BASE_URL    = "https://lgtmtm-game.linegame.jp"
    APP_VER     = TSUM_APP_VER
    RES_VER     = TSUM_RES_VER
    MST_VER     = "1.0.0"
    HASH        = "4c7ad3ad6b44d908964a95f44fbcdb35cdf2354ad768888e155aa5ad10496157"
    TERMINAL_ID = "ebf92ff8f267402fa5600f1a025242d9"
    DEVICE_NAME = "Pixel 4a (5G)"

    def __init__(self, refresh_token: str = None, refresh_user_token: str = None):
        # refresh_token はLINEログイン用。ゲスト(引き継ぎ番号)で入るときは
        # login_guest() を使うので None のままでよい。
        self.token_manager = LineTokenManager(refresh_token)
        self.game_auth     = LineGameAuth(refresh_user_token)
        # ゲストで入ったときの認証状態。代行後に番号を返すのに使う。
        self.guest         = None
        self.user_id       = ""
        self.checkval      = ""
        self.session_id    = ""
        self.enc_key       = None
        # gameStart に載せるイベントID。1接続のあいだは変わらない。
        self._event_id     = None
        # game_play(event_id=…) で、そのプレイだけイベントIDを決め打ちしている最中か。
        self._pin_event    = False
        # 直近の gameStart が渡してきた、そのプレイのミッション(playmissioninfo)。
        # イベントに参加している口だけ付いてくる。gameEnd でイベントの結果
        # (eventpt)を返すのに要る(_event_result を参照)。
        self._last_play_mission = None
        # eventpt の書式。この接続で通ったものを覚える(_probe_end を参照)。
        # confirmed は実際に通った印。
        self._eventpt_style = None
        self._eventpt_confirmed = False
        # getEvent の応答 {eventid: 応答}。マスごとのミッションの文言を読むのに使う。
        self._event_cache = {}
        # 直近の gameStart が渡してきた、そのプレイのイベント設定(eventinfo)。
        # エネルギーの箱(boxlist)が付くプレイでは、gameEnd の boxcnt に箱ごとの
        # 数を並べる必要がある(_boxcnt_candidates を参照)。
        self._last_play_event = None
        # boxcnt の書き方。この接続で通ったもの(_probe_end を参照)。
        self._boxcnt_scheme = None
        # 直近の gameEnd で使った boxcnt の書き方(通ったら覚える)。
        self._last_boxcnt_scheme = None
        # イベント付きのプレイが、書式・達成・箱の組み合わせを全部試しても
        # 通らなかった印。立ったら以降のプレイは投げない(ハートを捨てない)。
        self._event_broken = False
        # 1プレイぶんの探りで試した (eventpt, boxcnt) の組。入り直しても
        # 同じものを二度投げない。
        self._tried_ends = set()
        # 探りの途中でプレイが閉じられた(retcode=92)印。
        self._play_closed = False
        # メダルを申告するプレイの gameEnd を、9/22(イベント参加中でもメダルが
        # 入っていた頃)と同じ形で投げるか(game_end の LEGACY_END を参照)。
        # tsum_daiko の _medal_with_legacy_end が立てる。
        self._legacy_end = False
        # ゲームAPIへの接続。使い回すぶんだけ待ち時間が減る(close で手放す)。
        self._session      = None
        # getMast の応答。{種類のtuple: 応答}。マスタは走っているあいだ動かない。
        self._mast_cache   = {}
        # このうち、前の接続が取ったもの(_MAST_SHARED)を借りている種類。
        # gameStart が断られたときに捨てて引き直すのはこれだけ(この接続で
        # 引いたばかりのものを捨てても、同じ表が返ってくるだけ)。
        self._mast_borrowed = set()

    # ---- HTTP ----

    def _http(self) -> aiohttp.ClientSession:
        """ゲームAPIへ出るときのセッション。閉じていたら張り直す。

        cookie は持たない(DummyCookieJar)。1回ごとにセッションを作っていた
        ころは cookie が残りようがなかったので、使い回しても送る中身が
        変わらないようにする。
        """
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                # DNSは既定の10秒だと張り直しのたびに引き直しになる。
                # 相手は1つなので長めに覚えてよい。
                connector=aiohttp.TCPConnector(ttl_dns_cache=300),
                cookie_jar=aiohttp.DummyCookieJar(),
                trace_configs=[_reuse_trace()],
            )
        return self._session

    async def close(self):
        """張っている接続を手放す。代行が終わったら呼ぶ。"""
        session, self._session = self._session, None
        if session is not None and not session.closed:
            try:
                await session.close()
            except Exception as e:      # 後始末で代行の結果を変えない
                print(f"[TSUM] 接続の後始末に失敗: {type(e).__name__}: {e}",
                      flush=True)

    async def _send(self, url: str, data, headers: dict, handler):
        """POSTして handler(応答) の戻り値を返す。

        使い回した接続は、相手が黙って閉じていることがある。そのときは
        応答が1バイトも来ないまま ServerDisconnectedError になる
        (=ゲーム側はこの要求を受け取っていない)。この場合にかぎり、
        新しい接続で1度だけ投げ直す。投げ直さないと、完売の途中で
        「未完売」のまま終わってお客さんのコインだけが減る。

        新しく張った接続で切られたときは投げ直さない。そちらは要求が
        通ったあとに切れた可能性があり、投げ直すと同じガチャを2回引く。
        本文の読み取り中に切れた場合も handler の中なので投げ直さない。
        """
        if not TSUM_HTTP_REUSE:
            async with aiohttp.ClientSession(
                    cookie_jar=aiohttp.DummyCookieJar()) as session:
                async with session.post(url, data=data, headers=headers) as resp:
                    return await handler(resp)

        session = self._http()
        for attempt in (0, 1):
            reuse = {}
            try:
                resp = await session.post(url, data=data, headers=headers,
                                          trace_request_ctx=reuse)
            except aiohttp.ServerDisconnectedError:
                if attempt or not reuse.get("reused"):
                    raise
                print("[TSUM] 使い回した接続が閉じていました。張り直します",
                      flush=True)
                continue
            try:
                return await handler(resp)
            finally:
                resp.release()
        raise RuntimeError("unreachable")     # 上の for で必ず返るか投げる

    def _generate_request_id(self) -> str:
        """requestid(上位4ビットが乱数・下位が時刻の秒)。同じ接続で同じ番号を2度使わない。

        同じ秒のうちに投げると、16通りしかない上位ビットが前の要求と重なることがある。
        ゲーム側は同じ requestid の要求を再送とみなして前の応答を返すらしく、
        gameStart と gameEnd に getEvent の応答がそのまま返ってきたことがある
        (プレイにならず、メダルが「通ったのに0枚」に見えた)。直近に使った番号と
        重なったら引き直す。
        """
        used = self.__dict__.get("_used_request_ids")
        if used is None:
            used = self.__dict__["_used_request_ids"] = collections.deque(maxlen=256)
        rid = "1"
        for _ in range(64):
            rand_part = random.randint(0, 0xF) << 28
            time_part = int(time.time()) & 0x0FFFFFFF
            rid = str((rand_part | time_part) or 1)
            if rid not in used:
                break
        used.append(rid)
        return rid

    def _growthyinfo(self) -> str:
        info = {
            "sdkVersion": "3.0", "osVer": "11",
            "terminalId": self.TERMINAL_ID, "deviceName": self.DEVICE_NAME,
            "country": "JP", "language": "ja", "networkType": 2,
            "carrier": "/", "clientTimestamp": datetime.datetime.now().strftime("%Y%m%d %H%M%S"),
        }
        return urllib.parse.quote(json.dumps(info, separators=(",", ":")))

    def _build_query(self, params: dict) -> str:
        return "&".join(f"{k}={v}" for k, v in params.items()) + f"&growthyinfo={self._growthyinfo()}"

    def _encrypt(self, plaintext: str) -> bytes:
        if not self.enc_key or len(self.enc_key) != 32:
            raise RuntimeError("SecureSessionが未確立です (AES key unavailable)")
        return SecureSessionCrypto.aes_gcm_encrypt(plaintext, self.enc_key)

    def _decrypt(self, data: bytes) -> dict:
        if not self.enc_key or len(self.enc_key) != 32:
            raise RuntimeError("SecureSessionが未確立です (AES key unavailable)")
        raw = SecureSessionCrypto.aes_gcm_decrypt(data, self.enc_key)

        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            return dict(urllib.parse.parse_qsl(raw))

    def _update_session(self, resp: dict):
        if "hash" in resp and resp["hash"]:
            self.HASH = resp["hash"]

        userinfo = resp.get("userinfo", resp)

        checkval = userinfo.get("checkval")
        if checkval:
            self.checkval = checkval
            if TSUM_DEBUG:
                print("[*] checkval updated")

        session_id = (
            userinfo.get("session_id")
            or userinfo.get("sessionid")
            or userinfo.get("sessionId")
        )
        if session_id:
            # 変わったときだけ出す。応答ごとに同じ値が入っているので、
            # そのまま出すと完売1回で数千行がこれで埋まり、他が見えなくなる。
            if session_id != self.session_id:
                print("[*] session_id updated")
            self.session_id = session_id

        user_id = userinfo.get("userid") or userinfo.get("userId")
        if user_id:
            self.user_id = user_id
            if TSUM_DEBUG:
                print("[*] userid updated")

    def _base_headers(self, extra: dict = None) -> dict:
        h = {"Accept": "*/*", "Content-Type": "application/tsum"}
        if self.session_id:
            h["X-Session-Id"] = self.session_id
        if extra:
            h.update(extra)
        return h

    def _base_params(self) -> dict:
        return {
            "requestid":   self._generate_request_id(),
            "userid":      self.user_id,
            "appver":      self.APP_VER,
            "resver":      self.RES_VER,
            "mstver":      self.MST_VER,
            "hash":        self.HASH,
            "os":          "2",
            "lang":        "ja",
            "checkval":    self.checkval,
            "countrycode": "JP",
        }

    async def _post_plain(self, endpoint: str, params: dict, extra_headers: dict = None) -> dict:
        plaintext = self._build_query(params)
        print(f"[>] POST {endpoint} (平文)")

        async def read_text(resp):
            resp.raise_for_status()
            return await resp.text()

        text = await self._send(self.BASE_URL + endpoint, plaintext,
                                self._base_headers(extra_headers), read_text)
        #print(f"[<] {text[:200]}")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return dict(urllib.parse.parse_qsl(text))

    async def _post(self, endpoint: str, params: dict) -> dict:
        plaintext = self._build_query(params)
        encrypted = self._encrypt(plaintext)
        print(f"[>] POST {endpoint}")

        is_gacha = endpoint in {
            "/gachaResult.nhn",
            "/gachaResultMulti.nhn",
            "/pickUpResult.nhn",
        }
        gacha_diag = is_gacha and (TSUM_GACHA_DEBUG or GACHA_DIAGNOSTIC_FORCE)

        async def read_body(resp):
            body = await resp.read()
            if gacha_diag:
                print(
                    f"[GACHA-HTTP] endpoint={endpoint} "
                    f"status={resp.status} bytes={len(body)}"
                )
            if resp.status >= 400:
                if gacha_diag:
                    print(f"[GACHA-HTTP-ERROR] status={resp.status} reason={resp.reason}")
                resp.raise_for_status()
            return body

        content = await self._send(self.BASE_URL + endpoint, encrypted,
                                   self._base_headers(), read_body)

        try:
            result = self._decrypt(content)
        except Exception as e:
            if gacha_diag:
                print(f"[GACHA-DECRYPT-ERROR] {type(e).__name__}: {e}")
            raise

        if gacha_diag:
            user = result.get("userinfo") or {}
            print(
                "[GACHA] "
                f"endpoint={endpoint} "
                f"request_gachaid={params.get('gachaid')} "
                f"retcode={result.get('retcode')} "
                f"retsubcode={result.get('retsubcode')} "
                f"bcoin={user.get('bcoin')}"
            )

            gacha_keys = [k for k in result.keys() if "gacha" in str(k).lower()]
            print(f"[GACHA] response_gacha_keys={gacha_keys}")
            for key in gacha_keys:
                try:
                    rendered = json.dumps(result.get(key), ensure_ascii=False, separators=(",", ":"))
                except Exception:
                    rendered = repr(result.get(key))
                if len(rendered) > 1800:
                    rendered = rendered[:1800] + "...<truncated>"
                print(f"[GACHA] {key}={rendered}")

        if endpoint == "/getMast.nhn" and TSUM_MAST_DUMP:
            # ガチャIDや価格を手で確かめたいときだけ残す。毎回書くと数MBの
            # ファイルを代行のたびに上書きすることになる。
            try:
                with open(RESULT_FILE, "w", encoding="utf-8") as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
            except OSError as e:
                print(f"[TSUM] getMastの保存に失敗: {e}", flush=True)
        if TSUM_DEBUG and endpoint in {"/gameStart.nhn", "/gameEnd.nhn", "/getInfo.nhn"}:
            print(f"[<]\n{json.dumps(result, ensure_ascii=False)}")
        self._update_session(result)
        return result
    
    async def _get_public_key(self) -> tuple[str, str]:
        key_resp = await self._post_plain(
            f"/api/getPublicKey.nhn?appver={self.APP_VER}",
            {
                "requestid": self._generate_request_id(),
                "userid": "",
                "appver": self.APP_VER,
                "resver": self.RES_VER,
                "mstver": self.MST_VER,
                "hash": self.HASH,
                "os": "2",
                "lang": "ja",
                "checkval": "",
                "countrycode": "JP",
            },
        )

        public_key_b64 = (
            key_resp.get("public_key")
            or key_resp.get("publickey")
            or key_resp.get("key")
        )
        key_id = key_resp.get("kid")

        if not public_key_b64:
            raise RuntimeError("getPublicKey: public_key がありません")
        if not key_id:
            raise RuntimeError("getPublicKey: kid がありません")

        print("[3] getPublicKey OK")
        print(f"    kid: {key_id}")
        return public_key_b64, key_id

    def _establish_secure_session(self, public_key_b64: str) -> str:
        session_key = SecureSessionCrypto.generate_secure_random(32)
        if len(session_key) != 32:
            raise RuntimeError("SecureSession: 32byte key generation failed")

        encrypted_session_key = SecureSessionCrypto.rsa_encrypt_oaep(
            session_key,
            public_key_b64,
        )

        self.enc_key = session_key
        print("[4] SecureSession key + RSA-OAEP OK")
        if TSUM_DEBUG:
            print(f"    AES key length: {len(self.enc_key)} bytes")
        return encrypted_session_key

    async def _game_login(
        self,
        user_token: str,
        key_id: str,
        encrypted_session_key: str,
    ) -> dict:
        login_params = {
            "rankdt": "0",
            "accesstoken": urllib.parse.quote(user_token, safe=""),
            "trigger": "0",
            "userid": "",
            "appver": self.APP_VER,
            "resver": self.RES_VER,
            "mstver": self.MST_VER,
            "hash": self.HASH,
            "os": "2",
            "lang": "ja",
            "checkval": "",
            "countrycode": "JP",
        }

        plaintext = self._build_query(login_params)
        encrypted = self._encrypt(plaintext)

        print("[5] login.nhn request")

        async def read_body(resp):
            print(f"[6] login.nhn status: {resp.status}")
            resp.raise_for_status()
            return await resp.read()

        content = await self._send(
            self.BASE_URL + "/login.nhn",
            encrypted,
            {
                "Accept": "*/*",
                "Content-Type": "application/tsum",
                "X-Encrypted-Session-Key": encrypted_session_key,
                "X-Key-Id": key_id,
            },
            read_body,
        )

        try:
            result = self._decrypt(content)
        except Exception as e:
            raise RuntimeError(f"login response decrypt failed: {type(e).__name__}") from e

        print("[7] login response decrypt OK")
        self._update_session(result)

        if self.session_id:
            print("[8] SecureSession established: session_id OK")
        else:
            print("[8] WARNING: login応答からsession_idを確認できません")

        return result

    async def login(self) -> dict:
        print("=" * 50)
        print(f"[*] client appver={self.APP_VER} resver={self.RES_VER}")

        print("[1] LINE access_token")
        access_token = await self.token_manager.get_token()
        if not access_token:
            raise RuntimeError("LINE access_token が取得できません")
        print("[1] LINE access_token OK")

        print("[2] game-api userToken")
        game_data = await self.game_auth.refresh(access_token)
        user_token = game_data.get("userToken")
        if not user_token:
            raise RuntimeError("GameSDK userToken が取得できません")
        print("[2] game-api userToken OK")

        public_key_b64, key_id = await self._get_public_key()
        encrypted_session_key = self._establish_secure_session(public_key_b64)
        return await self._game_login(user_token, key_id, encrypted_session_key)

    async def login_guest(self, migration_id: str, password: str) -> dict:
        """引き継ぎ番号でお客さんのゲスト垢に入る。LINEの login() と同じ位置。

        LINE OAuth の代わりに、新規ゲストを起こして番号で入れ替える。その先
        (getPublicKey → SecureSession → login.nhn)は LINE と共通。self.guest に
        残しておくので、代行が終わったら issue_guest_code() で番号を返せる。
        """
        print("=" * 50)
        print(f"[*] guest client appver={self.APP_VER} resver={self.RES_VER}")
        self.guest = GuestAuth()
        async with aiohttp.ClientSession() as session:
            user_token = await self.guest.open(session, migration_id, password)
        print("[2] guest userToken OK")

        public_key_b64, key_id = await self._get_public_key()
        encrypted_session_key = self._establish_secure_session(public_key_b64)
        return await self._game_login(user_token, key_id, encrypted_session_key)

    async def issue_guest_code(self) -> tuple:
        """代行後、入っているゲスト垢の新しい引き継ぎ番号を発行して返す。

        戻り値 (番号, パスワード)。ゲストで入っていないときは呼ばない。
        """
        if not getattr(self, "guest", None):
            raise TsumMigrationError("ゲストで入っていません")
        async with aiohttp.ClientSession() as session:
            return await self.guest.issue_code(session)

    async def get_item_store(self) -> dict:
        params = self._base_params()
        return await self._post("/getItemStore.nhn", {"requestid": params.pop("requestid"), **params})

    async def get_plaza(self) -> dict:
        params = self._base_params()
        return await self._post("/getPlaza.nhn", {"requestid": params.pop("requestid"), **params})

    async def get_information(self) -> dict:
        params = self._base_params()
        return await self._post("/getInformation.nhn", {"requestid": params.pop("requestid"), **params})

    async def get_mast(self, kind: list[int] | None = None) -> dict:
        """マスタ(ガチャの日程・価格・中身の数など)を取る。数MB。

        同じ種類は1接続のあいだ覚えておく。1回の代行で、イベントIDの確認
        (get_event_id)と開催中ガチャの特定(resolve_active_gacha_targets)が
        同じ 3|7|11|14 を引き、セット商品なら完売の数だけさらに引き直す。
        中身は毎回同じなので、そのぶんの数MBの往復がまるごと無駄になる。
        完売したかどうかは getInfo の gachainfo で毎回見ているので、
        ここを覚えても古い完売状況を掴むことはない。
        """
        if kind is None: kind = [0]
        key = tuple(kind)
        if TSUM_MAST_CACHE:
            cached = self._mast_cache.get(key)
            if cached is not None:
                print(f"[>] getMast {key} は取得済みのものを使う")
                return cached
            shared = self._shared_mast(key)
            if shared is not None:
                print(f"[>] getMast {key} は前の接続で取ったものを使う")
                self._mast_cache[key] = shared
                self._mast_borrowed.add(key)
                return shared
        params = self._base_params()
        res = await self._post("/getMast.nhn", {
            "requestid": params.pop("requestid"),
            "kind": "|".join(map(str, kind)) + "|",
            **params,
        })
        # 通った応答だけ覚える。エラーを覚えると、そのあと何度呼んでも
        # 同じエラーが返り続けることになる。種類の数はたかが知れているが、
        # 数MBを抱えるので念のため頭を押さえる。
        if (TSUM_MAST_CACHE and isinstance(res, dict)
                and res.get("retcode") == 0 and len(self._mast_cache) < 4):
            self._mast_cache[key] = res
            self._mast_borrowed.discard(key)
            self._remember_shared_mast(key, res)
        return res

    def _shared_key(self, key: tuple) -> tuple:
        # 名乗るバージョンが変わればマスタも変わり得るので、鍵に含める。
        return (str(self.APP_VER), str(self.RES_VER), key)

    def _shared_mast(self, key: tuple):
        """前の接続が取った getMast のうち、まだ新しいもの。無ければ None。"""
        if TSUM_MAST_SHARED_SECONDS <= 0:
            return None
        entry = _MAST_SHARED.get(self._shared_key(key))
        if entry is None:
            return None
        fetched_at, res = entry
        if time.monotonic() - fetched_at > TSUM_MAST_SHARED_SECONDS:
            _MAST_SHARED.pop(self._shared_key(key), None)
            return None
        return res

    def _remember_shared_mast(self, key: tuple, res: dict):
        if TSUM_MAST_SHARED_SECONDS <= 0:
            return
        # 種類の組み合わせはたかが知れているが、数MBずつ抱えるので頭を押さえる。
        if len(_MAST_SHARED) >= 4:
            oldest = min(_MAST_SHARED, key=lambda k: _MAST_SHARED[k][0])
            _MAST_SHARED.pop(oldest, None)
        _MAST_SHARED[self._shared_key(key)] = (time.monotonic(), res)

    def _forget_mast(self) -> bool:
        """前の接続から借りている getMast を捨てる(次は必ず引き直す)。

        開催の境目(イベントやガチャが始まった/終わった直後)に古い表を
        掴んでいると、開催中のイベントを取りこぼして gameStart が断られたり、
        始まったばかりのガチャが「開催していない」に見えたりする。そのとき
        呼んで、開催中の一覧を新しい表から引き直す。この接続で引いたばかりの
        ものは捨てない(引き直しても同じ表が返るだけで、断られるたびに数MBを
        引き直すことになる)。戻り値は捨てたものがあったか(=引き直す意味が
        あるか)。
        """
        if not self._mast_borrowed:
            return False
        for key in list(self._mast_borrowed):
            self._mast_cache.pop(key, None)
            _MAST_SHARED.pop(self._shared_key(key), None)
        self._mast_borrowed.clear()
        return True
    
    async def running_event_ids(self) -> list:
        """いま開催中のイベントIDを、マスタに並んでいる順で返す。

        種別の番号は決め打ちにしない。マスタに並ぶ番号はイベントの形式が
        変わるたびに入れ替わる(いま見えるのは 137 / 39 / 127)。外すと空が
        返り、gameStart にイベントIDが載らない。イベントに参加していない
        アカウントはそれでも通るが、参加しているアカウントは
        「入力パラメータでエラーが発生しました」で断られる。

        開催中のものを全部拾い、どれを使うかは呼び出し側に決めさせる。
        """
        now = int(time.time())
        data = await self.get_mast([3, 7, 11, 14])
        out = []
        for e in data.get("eventmst", []):
            try:
                if int(e["startdt"]) <= now <= int(e["enddt"]):
                    out.append(int(e["eventid"]))
            except (KeyError, TypeError, ValueError):
                continue
        return out

    async def joined_event_ids(self) -> list:
        """開催中のうち、このアカウントが参加している(card>0)ものだけ。"""
        out = []
        for event_id in await self.running_event_ids():
            try:
                if await self.is_event_joined(await self.get_event(event_id)):
                    out.append(event_id)
            except Exception as e:
                print(f"[TSUM] イベント{event_id}を確認できません: "
                      f"{type(e).__name__}: {e}", flush=True)
        return out

    async def get_event_id(self):
        """gameStart に載せる既定のイベントID。参加していなければ 0。"""
        joined = await self.joined_event_ids()
        return joined[0] if joined else 0

    async def get_info(self, kind: int = -1, limitedruby: int = 0, mytsumid: int | None = None) -> dict:
        """アカウントの現状を取る。mytsumid を渡すとマイツムを替える。

        ゲームは「いまのマイツム」でしかプレイできない。こちらが知らない
        (名乗っているバージョンに存在しない)ツムをマイツムにしていると、
        そのIDでは gameStart が通らず、かといって別のツムを指定しても
        「マイツムではない」ので通らない。どちらもふさがるので、先にここで
        マイツムを替える必要がある。
        """
        params = self._base_params()
        ordered = {"requestid": params.pop("requestid")}
        if mytsumid is not None:
            ordered["mytsumid"] = int(mytsumid)
        ordered.update(params)
        return await self._post("/getInfo.nhn", ordered)

    async def ads(self, cmd: int = 0) -> dict:
        params = self._base_params()
        return await self._post("/ads.nhn", {"requestid": params.pop("requestid"), "cmd": cmd, **params})

    async def pickup_result(self, gacha_id: int) -> dict:
        """現行SceneStoreのtype=21/31経路。通常購入ではtargetmidを送らない。"""
        params = self._base_params()
        return await self._post("/pickUpResult.nhn", {
            "requestid": params.pop("requestid"), "gachaid": gacha_id, **params,
        })

    async def gacha_result_multi(
        self, gacha_id: int, bonus_id: int = 0, pay_type: int = 1
    ) -> dict:
        params = self._base_params()
        payload = {
            "requestid": params.pop("requestid"),
            "gachaid": gacha_id,
            "paytype": str(int(pay_type)),
            **params,
        }
        if bonus_id >= 1:
            payload["gachabonusid"] = int(bonus_id)
        return await self._post("/gachaResultMulti.nhn", payload)

    async def gacha_result(
        self, gacha_id: int, bonus_id: int = 0, pay_type: int = 1
    ) -> dict:
        params = self._base_params()
        payload = {
            "requestid": params.pop("requestid"),
            "gachaid": gacha_id,
            "paytype": str(int(pay_type)),
            **params,
        }
        if bonus_id >= 1:
            payload["gachabonusid"] = int(bonus_id)
        return await self._post("/gachaResult.nhn", payload)
    async def is_event_joined(self,event):
        eventinfo = event.get("eventinfo") if isinstance(event, dict) else None
        if not isinstance(eventinfo, dict):
            # 開催が無いときの getEvent は eventinfo を返さない。素直に
            # .get を重ねると None を触って落ち、プレイ自体が失敗になる。
            return False
        # card はカード形式(type=138 など)の進み、challenge は「チャレンジ中!」の
        # 印(実物: eventinfo.challenge=1)。形式によってどちらかしか無いことが
        # あるので両方見る。どちらも無い形式は、gameStart 側が開催中のIDを順に
        # 試して拾う(game_play を参照)。
        return (int(eventinfo.get("card") or 0) > 0
                or int(eventinfo.get("challenge") or 0) > 0)

    async def _resolve_event_id(self) -> int:
        """gameStart に載せるイベントID。1接続のあいだは覚えておく。

        毎回引き直すと、プレイ1回ごとに getMast(数MB)と getEvent の重い
        往復が2回増える。ツムレベル上げのように何度もプレイする処理では、
        そのぶんだけ失敗する機会が増えるだけで、得るものが無い。
        """
        if self._event_id is not None:
            return self._event_id
        event_id = 0
        try:
            event_id = await self.get_event_id()
        except Exception as e:
            print(f"[TSUM] イベントIDを確認できません: {type(e).__name__}: {e}",
                  flush=True)
        self._event_id = event_id
        return event_id

    async def game_start(self, tsum_id: int, event_id: int = None) -> dict:
        # event_id を渡すと、覚えているイベントIDの代わりにそれを使う。
        # イベントIDを外してやり直すために要る（game_play を参照）。
        if event_id is None:
            event_id = await self._resolve_event_id()
        # パラメータは投げる直前に作る。checkval は応答ごとに変わるので、
        # 先に作ってから別のリクエストを挟むと、古い値のまま投げてしまう。
        params = self._base_params()
        data = await self._post("/gameStart.nhn", {
            "requestid": params.pop("requestid"),
            "tsumid": tsum_id, "eventid": event_id, "plazaeventid": 0,
            "hearttype": 0, "probmstver": 2, "bonusflg": 0,
            **params,
        })
        # このプレイに載っているミッションを控える。通った開始ごとに取り直す
        # (入り直して始め直すと、別のミッションが付いてくることがある)。
        # 通らなかった開始のものを残すと、次の gameEnd が古いミッションで
        # 計算される。
        if isinstance(data, dict) and data.get("retcode", -1) == 0:
            info = data.get("playmissioninfo")
            self._last_play_mission = info if isinstance(info, dict) else None
            event = data.get("eventinfo")
            self._last_play_event = event if isinstance(event, dict) else None
        return data

    # ミッションの文言(getEvent の desc)から、gameEnd のどの申告値で測られるかを
    # 読む。(文言に含まれる語, 申告値の名前)。上から順に見て最初に当たったもの。
    # 実物で確かめられているのは「1プレイでコインを 120枚稼ごう」= theme 5 = coin
    # だけだが、次のマスはスコア・チェーン・回数など別の種類になる。サーバは
    # こちらの申告から達成を自分でも計算するので、こちらの読みが違うと
    # (達成なのに 0、未達成なのに 1)食い違って retcode=1/2 になる。
    _MISSION_KEYWORDS = (
        ("コイン", "coin"),
        ("スコア", "score"),
        ("点稼", "score"),        # 「1プレイで 500,000点稼ごう」(スコアと書かない)
        ("万点", "score"),
        ("点", "score"),
        ("コンボ", "combo"),
        ("チェーン", "chain"),
        ("スキル", "skillcnt"),
        ("ボム", "bomb"),
        ("フィーバー", "fever"),
        ("経験値", "exp"),
        ("EXP", "exp"),
        ("Exp", "exp"),
        ("大きなツム", "big"),
        ("大ツム", "big"),
        ("回プレイ", "play"),     # 「N回プレイしよう」= 1プレイで1
        ("プレイしよう", "play"),
        ("消そう", "vanish"),     # 「〇〇のツムを N個消そう」
        ("消して", "vanish"),
    )
    # desc が読めなかった theme の既定。theme 5 = コイン は実物で確認済み。
    _MISSION_THEME_FIELD = {5: "coin"}

    def _kind_from_desc(self, desc: str):
        """ミッションの文言から (申告値の名前, 合計型か)。読めなければ None。"""
        desc = str(desc or "")
        field = next((f for word, f in self._MISSION_KEYWORDS if word in desc), None)
        if field is None:
            return None
        return field, (("合計" in desc) or (field == "play"))

    def _mission_kinds(self) -> dict:
        """theme -> (申告値の名前, 合計型か) を、参加中イベントの全マスの文言から作る。

        playmissioninfo(gameStart)の theme は getEvent の missionlist の subtype と
        同じ番号で、desc(文言)は getEvent 側にしか無い。番号の対応はイベント内で
        変わらないので、現在のマスに限らず全マスから拾っておく。
        合計型(「合計で」「N回プレイ」)は nowvalue(これまでの進み)を足して達成を
        見る。「1プレイで」型は、その1回の値だけで見る(nowvalue は前回の結果
        なので足してはいけない)。
        """
        kinds = dict((t, (f, False)) for t, f in self._MISSION_THEME_FIELD.items())
        event = self._event_cache.get(int(self._event_id or 0))
        info = (event or {}).get("eventinfo") if isinstance(event, dict) else None
        for cell in (info or {}).get("celllist") or []:
            for mission in (cell or {}).get("missionlist") or []:
                if not isinstance(mission, dict):
                    continue
                theme = mission.get("subtype")
                kind = self._kind_from_desc(mission.get("desc"))
                if theme is None or kind is None:
                    continue
                kinds[theme] = kind
        return kinds

    def _current_cell_descs(self) -> list:
        """いま進めているマスのミッションの文言を、並び順のまま返す。

        playmissioninfo の theme は、subtype と同じ番号とは限らない(実物:
        「ボムやスキルを当ててエネルギーを合計3コ集めよう」は subtype=1 なのに
        theme=36)。番号で引けないときは、位置で引く。gameStart に載るミッションは
        「いま進めているマス」(missionlist を持ち、nowpt < maxpt の最初のマス)
        のものが、同じ並びで来る。
        """
        event = self._event_cache.get(int(self._event_id or 0))
        info = (event or {}).get("eventinfo") if isinstance(event, dict) else None
        for cell in (info or {}).get("celllist") or []:
            missions = (cell or {}).get("missionlist") if isinstance(cell, dict) else None
            if not missions:
                continue
            try:
                done = int(cell.get("nowpt") or 0) >= int(cell.get("maxpt") or 0) > 0
            except (TypeError, ValueError):
                done = False
            if done:
                continue
            return [str(m.get("desc") or "") for m in missions if isinstance(m, dict)]
        return []

    def _mission_entries(self) -> list:
        """直近の gameStart に載っていたミッション(無ければ空)。"""
        mission = self._last_play_mission
        if not isinstance(mission, dict):
            return []
        missions = mission.get("missionlist")
        if not isinstance(missions, list):
            return []
        return [e for e in missions if isinstance(e, dict)]

    # gameEnd の eventpt の書き方の候補。
    #
    # 実測(イベント156・参加中の口・フォーム文字列で送信):
    #   eventpt=""  → 通る(retcode=0)。ただし達成したはずのコインでは retcode=1/2
    #   eventpt="1" → retcode=8「入力パラメータでエラー」
    #   eventpt="0" → retcode=8「入力パラメータでエラー」
    # 素の数字は書式として受け付けられない。同じリクエストの他の集計欄は全部
    #   vanishcnt "860,14|1,0|…"  bombcnt "0,0|1,0|…"  sizecnt "0,6|1,0|…"
    # の「id,値|」の並びなので、その形を候補にする。どれが正しいかは実機の
    # 送信を取らないと決まらないため、同じプレイ(同じ playcode)に順に投げ直し、
    # 通ったものを覚える。gameStart を挟まないのでハートは減らない。
    #   idx0  … 「ミッションの番号(0始まり),点|」を並べる
    #   idx1  … 同じく 1 始まり
    #   total … 「合計点|」
    #   theme … 「theme,点|」を並べる
    EVENTPT_STYLES = ("idx0", "idx1", "total", "theme")
    EVENT_FORMAT_FILE = data_path("tsum_event_format.json")
    # 全部駄目だったとき、次に候補を試すまで空ける時間。毎注文で同じ空振りを
    # 繰り返さないため(イベントが替われば書式が違う可能性もあるので永久ではない)。
    EVENT_FORMAT_RETRY_SECONDS = 24 * 3600

    def _event_points(self, values: dict):
        """このプレイのミッションの達成を、申告値から決める。

        戻り値は (ミッションごとの [(theme, 点)], 合計点)。ミッションが付いて
        いないプレイ(参加していない口)は None。

        実物(イベント156 / type=138 のカードイベント):
            playmissioninfo: {"playtype": 1, "maxpt": 1, "missiontype": 1,
                              "missionlist": [{"theme": 5, "maxvalue": 120,
                                               "nowvalue": 0, "eventpt": 1}]}
        = 「このプレイでコインを120枚稼げば1ポイント」。サーバはこちらの申告
        (coin など)から達成を自分でも計算するので、送る点はそれと一致して
        いなければならない(空で送ると、達成したはずのコインでは retcode=1/2)。
        """
        mission = self._last_play_mission
        if not isinstance(mission, dict):
            return None
        missions = mission.get("missionlist")
        if not isinstance(missions, list):
            return None
        kinds = self._mission_kinds()
        descs = self._current_cell_descs()
        per_mission = []
        for index, entry in enumerate(missions):
            if not isinstance(entry, dict):
                continue
            theme = entry.get("theme")
            kind = kinds.get(theme)
            if kind is None and index < len(descs):
                # 番号(theme)で引けない。いま進めているマスの同じ位置の文言で読む。
                kind = self._kind_from_desc(descs[index])
                if kind is not None:
                    print(f"[PLAY] theme={theme!r} は「{descs[index]}」(位置で照合) "
                          f"→ {kind[0]}", flush=True)
            points = 0
            if kind is None:
                # 何だったかを残す。次の1回で文言と申告値の対応を足せる。
                # 達成扱いにはしない(こちらの申告は 0 の欄が多いので、たいてい
                # 未達成で合っている。外れたときは投げ直しで入れ替える)。
                print(f"[PLAY] 知らないミッション theme={theme!r}: {entry} "
                      f"文言={descs[index] if index < len(descs) else '?'}", flush=True)
            else:
                field, cumulative = kind
                need = int(entry.get("maxvalue") or 0)
                have = int(values.get(field) or 0)
                if cumulative:
                    have += int(entry.get("nowvalue") or 0)
                if need > 0 and have >= need:
                    points = int(entry.get("eventpt") or 0)
            per_mission.append((theme, points))
        total = sum(p for _, p in per_mission)
        cap = int(mission.get("maxpt") or 0)
        if cap > 0:
            total = min(total, cap)
        return per_mission, total

    @staticmethod
    def _mission_values(score, coin, medal, exp, combo, chain, vanish) -> dict:
        """ミッションの達成判定に使う、このプレイの申告値。

        gameEnd で固定で 0 にしている欄(スキル・ボム・フィーバー・大きなツム)も
        名前を揃えて入れておく。「スキルを3回」のようなミッションが来たとき、
        0 なので未達成、と正しく読めるようにするため。プレイ回数は1回で1。
        """
        return {
            "score": int(score or 0), "coin": int(coin or 0),
            "medal": int(medal or 0), "exp": int(exp or 0),
            "combo": int(combo or 0), "chain": int(chain or 0),
            "vanish": int(vanish or 0),
            "skillcnt": 0, "bomb": 0, "fever": 0, "big": 0, "play": 1,
        }

    @staticmethod
    def _format_eventpt(style: str, per_mission: list, total: int) -> str:
        if style == "idx0":
            return "".join(f"{i},{p}|" for i, (_, p) in enumerate(per_mission))
        if style == "idx1":
            return "".join(f"{i + 1},{p}|" for i, (_, p) in enumerate(per_mission))
        if style == "total":
            return f"{total}|"
        if style == "theme":
            return "".join(f"{t},{p}|" for t, p in per_mission)
        return str(total)

    def _load_event_format(self) -> dict:
        """覚えている書式。{"styles": {イベントID: 書式}, "last": 書式,
        "failed": {イベントID: {"at": 時刻, "tried": [...]}}}。

        イベントごとに覚える。書式はイベントの形式(種別)ごとに違いうるので、
        全体で1つにすると、別のイベントで通った書式に上書きされて、戻った
        ときにまた探ることになる。古い形({"style": …})も読める。
        """
        data = read_json(self.EVENT_FORMAT_FILE, None)
        if not isinstance(data, dict):
            return {"styles": {}, "last": None, "failed": {}, "boxcnt": {}, "medal": {}}
        if "styles" not in data:
            style = data.get("style")
            data = {"styles": ({str(data.get("event_id")): style}
                               if style and data.get("event_id") else {}),
                    "last": style,
                    "failed": ({str(data.get("event_id")): {"at": data.get("at"),
                                                            "tried": data.get("tried")}}
                               if not style and data.get("event_id") else {})}
        data.setdefault("styles", {})
        data.setdefault("failed", {})
        data.setdefault("boxcnt", {})
        data.setdefault("medal", {})
        return data

    # ---- イベント参加中の口でメダルが入る送り方(イベントごとに覚える) ----
    #
    # 参加中の口は、普段のツムでプレイすると、プレイが通っても(retcode=0)メダルが
    # +0 で返る(応答の userinfo は bmedal=-1)。10/7 の実測で、プラスツムをマイツムに
    # してプレイすれば申告どおり入ると分かった(tsum_daiko の _event_medal_mode が
    # 既定の送り方にしている)。ここには、イベントごとに分かったことを残す:
    #   mode:     "plus"(既定) / "limit" / "tiny"(探索を有効にした動作確認で見つけたもの)
    #   tsum:     プレイに使ったプラスツムの ID
    #   cap:      1プレイの上限(申告より少なく入った実測。partial=True のときだけ上限。
    #             limit / tiny では常に上限)
    #   verified: 丸ごと入ると確かめた最大の枚数(本番はまずご注文の残りを申告し、
    #             +0 ならこの枚数で投げ直す)
    #   tried / failed_at: 探索で全部 +0 だったときの記録(24時間は同じ送り方を試さない)
    MEDAL_TRIAL_RETRY_SECONDS = 24 * 3600

    def medal_mode_for(self, event_id) -> dict:
        """このイベントで入ると分かっている送り方。無ければ None。"""
        if not event_id:
            return None
        known = self._load_event_format()["medal"].get(str(event_id))
        if isinstance(known, dict) and known.get("mode"):
            return dict(known)
        return None

    def medal_failed_modes(self, event_id) -> set:
        """このイベントで、最近(24時間以内)試して +0 だった送り方の集まり。

        空なら何も試していない(または試してから時間が経った)。試していない
        送り方だけを次の動作確認で試す(同じものを繰り返してハートを捨てない)。
        """
        if not event_id:
            return set()
        known = self._load_event_format()["medal"].get(str(event_id))
        if not isinstance(known, dict) or known.get("mode"):
            return set()
        try:
            recent = time.time() - float(known.get("failed_at") or 0) < self.MEDAL_TRIAL_RETRY_SECONDS
        except (TypeError, ValueError):
            recent = False
        if not recent:
            return set()
        return {str(m) for m in (known.get("tried") or [])}

    def medal_trial_recently_failed(self, event_id) -> bool:
        """このイベントで、送り方を試して駄目だったばかりか(互換用)。"""
        return bool(self.medal_failed_modes(event_id))

    def remember_medal_mode(self, event_id, mode: str, **detail):
        """入った送り方を残す。接続をまたいで、ほかの口の注文でも使う。"""
        if not event_id or not mode:
            return
        known = self._load_event_format()
        known["medal"][str(event_id)] = {"mode": mode, "at": time.time(), **detail}
        try:
            write_json(self.EVENT_FORMAT_FILE, known)
        except Exception as e:
            print(f"[PLAY] メダルの送り方を保存できませんでした: {e}", flush=True)

    def remember_medal_failed(self, event_id, tried: list):
        """全部駄目だったことを残す(しばらくは同じ試しを繰り返さない)。"""
        if not event_id:
            return
        known = self._load_event_format()
        current = known["medal"].get(str(event_id))
        if isinstance(current, dict) and current.get("mode"):
            return          # 入る送り方が分かっているものは消さない
        # 前に試した送り方も足し合わせて残す(次は残りだけを試す)。
        before = set(str(m) for m in ((current or {}).get("tried") or [])) \
            if isinstance(current, dict) else set()
        known["medal"][str(event_id)] = {"mode": None, "failed_at": time.time(),
                                         "tried": sorted(before | {str(m) for m in tried})}
        try:
            write_json(self.EVENT_FORMAT_FILE, known)
        except Exception as e:
            print(f"[PLAY] メダルの試しの記録を保存できませんでした: {e}", flush=True)

    @staticmethod
    def start_medal_limit(start_response) -> int:
        """gameStart の応答にある medallimit。無ければ 0。-1 はそのまま返す。"""
        if not isinstance(start_response, dict):
            return 0
        try:
            return int(start_response.get("medallimit"))
        except (TypeError, ValueError):
            return 0

    def _known_event_style(self):
        """このイベントで通った書式。無ければ最後にどこかで通った書式。"""
        known = self._load_event_format()
        return known["styles"].get(str(self._event_id)) or known.get("last")

    def _remember_event_format(self, style, tried: list):
        """通った書式(style)、または全部駄目だったこと(None)を、イベントごとに残す。

        1つの口で分かれば全部の口で使える話なので、接続をまたいで覚える。
        """
        known = self._load_event_format()
        key = str(self._event_id)
        if style:
            known["styles"][key] = style
            known["last"] = style
            known["failed"].pop(key, None)
        else:
            known["failed"][key] = {"at": time.time(), "tried": list(tried)}
        try:
            write_json(self.EVENT_FORMAT_FILE, known)
        except Exception as e:
            print(f"[PLAY] eventpt の書式を保存できませんでした: {e}", flush=True)

    def _eventpt_candidates(self) -> list:
        """この接続で試す書式の順。覚えているものがあればそれを先頭に。"""
        styles = list(self.EVENTPT_STYLES)
        known = self._load_event_format()
        key = str(self._event_id)
        style = known["styles"].get(key) or known.get("last")
        if style in styles:
            styles.remove(style)
            styles.insert(0, style)
        failed = known["failed"].get(key)
        if not known["styles"].get(key) and isinstance(failed, dict):
            # このイベントでは前回全部駄目だった。しばらくは最初の1つだけ試す。
            if time.time() - float(failed.get("at") or 0) < self.EVENT_FORMAT_RETRY_SECONDS:
                return styles[:1]
        return styles

    def _event_result(self, values: dict) -> str:
        """gameEnd に載せる eventpt。

        ミッションが無ければ ""(参加していない口はこれまでどおり)。ミッションが
        あれば、0 点でも書式どおりに並べて送る(「0,0|」)。空で送ると、
        エネルギーの箱が付くマス(実物: theme=36「ボムやスキルを当てて
        エネルギーを合計3コ集めよう」)では retcode=1/2 で丸ごと弾かれ、
        コイン付与もメダル付与も全部落ちた。「0,0|」はイベント156で通ることを
        確かめてある。それでも弾かれたら、同じプレイに他の組み合わせを
        投げ直す(_probe_end)。
        """
        got = self._event_points(values)
        if got is None:
            return ""
        per_mission, total = got
        style = self._eventpt_style or self._eventpt_candidates()[0]
        self._eventpt_style = style
        return self._format_eventpt(style, per_mission, total)

    # gameEnd の boxcnt の書き方。エネルギーの箱(gameStart の eventinfo.boxlist)が
    # 付くプレイでは、箱ごとに「id,壊した数|」を並べる必要があるとみられる
    # (bombcnt「0,0|1,0|…」/ sizecnt「0,6|1,0|2,0|」と同じ作り)。id が箱の並び
    # (0始まり)なのか type(実物: 100)なのかは実機の送信を取らないと決まらない
    # ので、順に試して通ったものを覚える。箱が無いプレイは従来どおり空。
    #   index … 「並びの番号,0|」   type … 「type,0|」   empty … ""
    BOXCNT_SCHEMES = ("index", "type", "empty")

    def _box_list(self) -> list:
        event = self._last_play_event
        boxes = (event or {}).get("boxlist") if isinstance(event, dict) else None
        return [b for b in boxes if isinstance(b, dict)] if isinstance(boxes, list) else []

    def _format_boxcnt(self, scheme: str) -> str:
        boxes = self._box_list()
        if scheme == "index":
            return "".join(f"{i},0|" for i in range(len(boxes)))
        if scheme == "type":
            return "".join(f"{b.get('type', i)},0|" for i, b in enumerate(boxes))
        return ""

    def _known_boxcnt_scheme(self):
        known = self._load_event_format()
        return known["boxcnt"].get(str(self._event_id))

    def _remember_boxcnt_scheme(self, scheme: str):
        if not scheme:
            return
        known = self._load_event_format()
        if known["boxcnt"].get(str(self._event_id)) == scheme:
            return
        known["boxcnt"][str(self._event_id)] = scheme
        try:
            write_json(self.EVENT_FORMAT_FILE, known)
        except Exception as e:
            print(f"[PLAY] boxcnt の書式を保存できませんでした: {e}", flush=True)

    def _boxcnt_candidates(self) -> list:
        """この接続で試す boxcnt の書き方の順。箱が無ければ空だけ。"""
        if not self._box_list():
            return ["empty"]
        schemes = list(self.BOXCNT_SCHEMES)
        known = self._boxcnt_scheme or self._known_boxcnt_scheme()
        if known in schemes:
            schemes.remove(known)
            schemes.insert(0, known)
        return schemes

    def _box_default(self) -> str:
        """いまのプレイで最初に送る boxcnt(通ったら覚える)。"""
        scheme = self._boxcnt_candidates()[0]
        self._last_boxcnt_scheme = scheme
        return self._format_boxcnt(scheme)

    def _zeroed_body(self, body: dict) -> dict:
        """申告を全部 0 にした gameEnd の中身(枚数が原因かを切り分けるのに使う)。

        eventpt / boxcnt は「いちばん通りそうな形」(覚えている書式、無ければ
        先頭の候補)に戻して、0 の申告で読み直す。探りの最後に投げた形のまま
        だと、書式が外れているせいで枚数の話が見えなくなる。
        """
        out = dict(body)
        out.update({"score": 0, "coin": 0, "medal": 0, "exp": 0,
                    "basemedal": 0, "maxmedal": 0})
        vanish = str(out.get("vanishcnt") or "")
        out["vanishcnt"] = "".join(f"{pair.split(',')[0]},0|"
                                   for pair in vanish.split("|") if "," in pair)
        out["otherresult"] = self._other_result(0)
        self._eventpt_style = self._eventpt_candidates()[0]
        out["eventpt"] = self._event_result(self._mission_values(
            0, 0, 0, 0, out.get("combo"), out.get("chain"), 0))
        out["boxcnt"] = self._box_default()
        return out

    async def _resubmit_end(self, eventpt: str, boxcnt: str = None,
                            play_code: str = None, zero: bool = False) -> dict:
        """直前の gameEnd を、eventpt(と boxcnt)だけ替えて同じ playcode に投げ直す。

        揺らした playtime / combo / chain はそのまま。書式を探るのに
        毎回別のプレイに見せる必要はないし、変えると比較が汚れる。
        play_code を渡すと、入り直した新しいプレイに同じ中身を投げる。
        zero=True は申告を全部 0 にする(枚数が原因かどうかの切り分け用。
        通ればそのプレイは 0 枚で終わる)。
        """
        body = dict(self._last_end_body or {})
        body["eventpt"] = eventpt
        if boxcnt is not None:
            body["boxcnt"] = boxcnt
        if play_code:
            body["playcode"] = play_code
        if zero:
            body = self._zeroed_body(body)
        self._last_end_body = dict(body)
        params = self._base_params()
        return await self._post("/gameEnd.nhn", {
            "requestid": params.pop("requestid"),
            **body,
            **params,
        })

    # 達成の読み違いを疑って試し直す数の上限。ミッションが1つのマスなら
    # 1つで済む(達成⇔未達成を入れ替えるだけ)。
    MISSION_FLIP_LIMIT = 4

    def _end_variants(self, per_mission: list, total: int) -> list:
        """イベント付きのプレイで gameEnd が弾かれたとき、同じプレイに順に投げ直す
        (印, eventpt, boxcnt, eventpt の書式, boxcnt の書式) の並び。

        当たりやすい順に並べる。
          1. 読んだ達成のまま、boxcnt の書き方を替える(箱が原因のとき)
          2. eventpt を空にする(0 点しか通らない形式のとき)
          3. ミッションごとに達成⇔未達成を入れ替える(読み違いのとき)
          4. eventpt の書式そのものを替える(idx1 / total / theme)
        gameStart を挟まないのでハートは減らない。
        """
        styles = self._eventpt_candidates()
        schemes = self._boxcnt_candidates()
        first = styles[0]
        out = []

        def add(label, style, points, scheme):
            eventpt = "" if style == "" else self._format_eventpt(
                style, points, min(sum(p for _, p in points), total_cap))
            out.append((label, eventpt, self._format_boxcnt(scheme),
                        style or None, scheme))

        mission = self._last_play_mission or {}
        total_cap = int(mission.get("maxpt") or 0) or 10 ** 9
        for scheme in schemes:
            add(f"{first}/{scheme}", first, per_mission, scheme)
        for scheme in schemes:
            add(f"空/{scheme}", "", per_mission, scheme)
        entries = self._mission_entries()
        for i, (theme, pts) in enumerate(per_mission[:self.MISSION_FLIP_LIMIT]):
            entry = entries[i] if i < len(entries) else {}
            flipped = list(per_mission)
            flipped[i] = (theme, 0 if pts else int(entry.get("eventpt") or 1))
            for scheme in schemes:
                add(f"達成入替{i}/{scheme}", first, flipped, scheme)
        for style in styles[1:]:
            add(f"{style}/{schemes[0]}", style, per_mission, schemes[0])
        return out

    async def _probe_end(self, values: dict, note, end_label) -> dict:
        """イベント付きのプレイで gameEnd が弾かれた(retcode=1 または 8)。

        eventpt と boxcnt の組み合わせを、同じプレイ(同じ playcode)に順に
        投げ直し、通ったものを覚える。何を投げても同じなら、それはこの
        プレイの中身(枚数)の話ではなくイベントの話なので、呼び出し側は
        枚数を半分にして繰り返してはいけない(ハートを捨てるだけ)。
        戻り値は最後の応答(何も投げていなければ空)。プレイが閉じられたら
        (retcode=92)_play_closed を立てて打ち切る。試した組は _tried_ends に
        残し、入り直したあとの続きで同じものを投げない。
        """
        got = self._event_points(values)
        if got is None:
            return {}
        per_mission, total = got
        last = {}
        for label, eventpt, boxcnt, style, scheme in self._end_variants(per_mission, total):
            if (eventpt, boxcnt) in self._tried_ends:
                continue
            print(f"[PLAY] gameEnd を {label}(eventpt={eventpt!r} boxcnt={boxcnt!r})で"
                  "投げ直します", flush=True)
            try:
                last = await self._resubmit_end(eventpt, boxcnt)
            except Exception as e:
                last = {"retmsg": f"{type(e).__name__}: {e}"}
            note(end_label(f"gameEnd({label})"), last)
            if isinstance(last, dict) and last.get("retcode", -1) == 0:
                if style:
                    self._eventpt_style = style
                    self._eventpt_confirmed = True
                    self._remember_event_format(style, [style])
                self._boxcnt_scheme = scheme
                self._remember_boxcnt_scheme(scheme)
                print(f"[PLAY] gameEnd は {label} で通りました", flush=True)
                return last
            if isinstance(last, dict) and last.get("retcode") == 92:
                # プレイが閉じられた。この組はまだ答えが出ていない(入り直して
                # から同じ組を投げる)ので、試した印は付けない。
                self._play_closed = True
                break
            self._tried_ends.add((eventpt, boxcnt))
        return last

    def _end_exhausted(self, per_mission: list, total: int) -> bool:
        """投げ直せる組み合わせを全部試したか。"""
        return all((eventpt, boxcnt) in self._tried_ends
                   for _, eventpt, boxcnt, _, _ in self._end_variants(per_mission, total))

    @staticmethod
    def _build_vanish_cnt(tsum_id: int, vanish: int) -> str:
        """このプレイで消したツムの申告。「ツムID,個数|」を並べた形。

        対象のツムを2度書いてはいけない。持ち込んだコードは常に
        「1,0|2,0|3,0|4,0|」を足していたので、対象がミッキー〜デイジー
        (ID 1〜4)のときだけ同じIDが2回並び、後ろの 0 が効いて消去数が
        入らなかった(=何回プレイしてもレベルが上がらない)。
        """
        tsum_id = int(tsum_id)
        pairs = [(tsum_id, max(0, int(vanish)))]
        # 埋めの数は元のまま4つ。対象と重なるIDは使わない。
        pairs += [(i, 0) for i in (1, 2, 3, 4, 5) if i != tsum_id][:4]
        return "".join(f"{tid},{cnt}|" for tid, cnt in pairs)

    @staticmethod
    def _other_result(coin: int) -> str:
        # メダルの記録(playlog の "medal")を足しても、イベント参加中の口の
        # メダルは +0 のままだった(10/1 実測)。コインだけの元の形に戻してある。
        obj = {"playlog": {"coin": {
            "inval": [], "cnt": {"1": coin}, "key": [1], "sum": str(coin), "req": "ne",
        }}}
        return urllib.parse.quote(json.dumps(obj, separators=(",", ":")), safe="")

    # 9/22 の gameEnd の数字。イベント参加中の口でもメダルが入っていた頃の送り方。
    # 翌朝(9/23 4:41)から playtime / combo / chain / 消去数を毎回揺らすようにし、
    # その後で eventpt をミッションから決めるようにした。参加中の口のメダルが
    # +0 になったのはその頃から(参加していない口は揺らしたままでも入る)。
    # eventpt は 9/22 と同じく空で送る(未達成のミッションなら通る。達成扱いの
    # マスで弾かれたら、同じプレイに計算した eventpt を投げ直す=_probe_end)。
    LEGACY_END = {"playtime": 60, "combo": 1, "chain": 6, "vanish": 10, "eventpt": ""}

    async def game_end(self,tsum_id:int, score: int = 0, coin: int = 0, exp: int = 0,
                       medal: int = 0, play_code: str = None, vanish: int = 10,
                       eventpt: str = None, boxcnt: str = None) -> dict:
        # vanish はこのプレイで消したツムの数。ツムのレベルはこの数で上がるので、
        # レベル上げのときは大きめの値を渡す(既定の10は元のまま)。
        #
        # eventpt はこのプレイで得たイベントポイント。省略すると、直近の gameStart
        # が渡してきたミッションと申告値から決める(_event_result)。イベントに
        # 参加していない口では従来どおり ""。明示して渡すのは、閉じ忘れたプレイを
        # 0 で片付けるときなど、計算させたくない場合だけ。
        # boxcnt はエネルギーの箱を壊した数。省略すると、箱が付くプレイなら
        # 箱ごとに 0 を並べ、無ければ ""(_box_default)。

        # 毎回まったく同じ数字を並べると、サーバ側から見て「同一のプレイ」が
        # 何百回も届くことになり、機械の署名になる(BAN対策)。値そのものは
        # 通っている実測の近くで小さく揺らすだけにして、検証に当たる危険を
        # 増やさない。playtime は 1プレイの標準(60秒)の前後。
        playtime = random.randint(54, 78)
        combo = random.randint(1, 4)
        chain = random.randint(4, 9)
        if self._legacy_end and medal > 0:
            # メダルを申告するプレイだけ 9/22 の形で投げる(LEGACY_END を参照)。
            # コインやレベル上げのプレイは今まで通り揺らす。
            legacy = self.LEGACY_END
            playtime, combo, chain = legacy["playtime"], legacy["combo"], legacy["chain"]
            vanish = legacy["vanish"]
            if eventpt is None:
                eventpt = legacy["eventpt"]
        if eventpt is None:
            # ミッションの達成は、これから申告するのと同じ値で判定する
            # (揺らした combo / chain も含めて)。
            eventpt = self._event_result(self._mission_values(
                score, coin, medal, exp, combo, chain, vanish))
        if boxcnt is None:
            boxcnt = self._box_default()
        body = {
            "score": score, "coin": coin, "medal": medal, "exp": exp,
            "combo": combo, "chain": chain, "treasurecnt": 0, "fever": 0,
            "skillcnt": 0, "extendflg": 0, "basescore": 2580, "basecoin": 5,
            "basemedal": medal, "maxmedal": medal, "baseexp": 100,
            "playtime": playtime,
            "vanishcnt": self._build_vanish_cnt(tsum_id, vanish),
            "playcode": play_code,
            "bombcnt": "0,0|1,0|2,0|3,0|4,0|5,0|6,0|", "cheat": 0,
            "sizecnt": "0,6|1,0|2,0|", "eventpt": eventpt, "boxcnt": boxcnt,
            "genericval": "", "otherresult": self._other_result(coin),
        }
        # 送ったプレイの中身(認証まわりの共通パラメータは含めない)。弾かれた
        # ときに、実機のプレイと見比べられるよう非公開ログへ添付する。
        self._last_end_body = dict(body)
        params = self._base_params()
        return await self._post("/gameEnd.nhn", {
            "requestid": params.pop("requestid"),
            **body,
            **params,
        })
    
    


    async def game_play(self, info: GetInfoResponse = None, tsum_id: int = 1, score: int = 0,
                        coin: int = 0, exp: int = 0, medal: int = 0, vanish: int = 10,
                        event_id: int = None, medal_hook=None) -> dict:
        """1プレイ分を投げる(中身は _game_play)。

        event_id を渡すと、そのイベントID(0 ならイベント無し)だけで始める。開始が
        断られても、ほかの開催中のイベントIDには回らない(イベントを外して試すための
        もの。参加中の口は外して始められないことがあり、そのときは開始で断られて
        ハートは減らない)。そのプレイが終わったら、覚えているイベントIDは元に戻す。

        medal_hook(gameStart の応答) -> 申告するメダルの枚数。渡すと、通った
        gameStart の応答(medallimit など)を見てから gameEnd の申告を決められる。
        """
        if event_id is None:
            return await self._game_play(info=info, tsum_id=tsum_id, score=score, coin=coin,
                                         exp=exp, medal=medal, vanish=vanish,
                                         medal_hook=medal_hook)
        saved = self._event_id
        self._event_id = int(event_id)
        self._pin_event = True
        try:
            return await self._game_play(info=info, tsum_id=tsum_id, score=score, coin=coin,
                                         exp=exp, medal=medal, vanish=vanish,
                                         medal_hook=medal_hook)
        finally:
            self._event_id = saved
            self._pin_event = False

    async def _game_play(self,info: GetInfoResponse = None,tsum_id: int=1,score:int=0,coin:int=0,exp:int=0,medal:int=0,vanish:int=10, medal_hook=None) -> dict:
        """1プレイ分(gameStart → gameEnd)を投げる。

        戻り値は必ず dict。通れば gameEnd の応答、通らなければ「どちらで
        弾かれたか」(_stage) と、ゲーム側が返した理由(retcode/retsubcode)を
        _failed 付きで返す。ここを 0 に潰してしまうと、呼び出し側には
        「失敗しました」しか残らず、後から理由を追えない。
        """
        def claim(start_data):
            """このプレイで申告するメダル。medal_hook があれば、通った gameStart の
            応答を見せて決めてもらう(medallimit に合わせて抑えるなど)。"""
            nonlocal medal
            if medal_hook is None:
                return
            try:
                decided = medal_hook(start_data)
            except Exception as e:
                print(f"[PLAY] medal_hook でエラー: {type(e).__name__}: {e}", flush=True)
                return
            if decided is not None:
                medal = max(0, int(decided))
        # 何をどう試したかを残す。gameStart が弾かれたとき、こちらに届くのは
        # retcode だけで、どのパラメータが悪いのかは分からない。試した中身を
        # 非公開ログに出しておけば、次の1回で切り分けられる。
        trail = []
        # 応答そのもの(gameStart も gameEnd も)。retcode だけでは、イベントとして
        # 始めたプレイにサーバが何を渡してきて、何を返してほしいのかが分からない。
        # 弾かれたときに丸ごと非公開ログへ添付するために持っておく。
        raw_trail = []

        def note(label: str, res):
            res = res if isinstance(res, dict) else {}
            trail.append(f"{label}→retcode={res.get('retcode')}"
                         f"/{res.get('retsubcode')}")
            # 写しを取る(あとで _attempts などを足しても自分自身を抱えないように)。
            raw_trail.append({"step": label, "response": dict(res)})

        def failed(stage: str, res, reason: str = None) -> dict:
            out = dict(res) if isinstance(res, dict) else {}
            out["_failed"] = True
            out["_stage"] = stage
            out["_attempts"] = list(trail)
            out["_raw_trail"] = list(raw_trail)
            if reason:
                # "amount" = 申告が大きすぎる(半分に落とせば通る見込み)
                # "event"  = イベントの中身がどう投げても通らない(枚数の話ではない。
                #            繰り返してもハートを捨てるだけ)
                out["_reason"] = reason
            print(f"[PLAY ERROR] {stage} retcode={out.get('retcode')} "
                  f"retsubcode={out.get('retsubcode')} retmsg={out.get('retmsg')} "
                  f"reason={reason} 試行={trail}", flush=True)
            return out

        def rejected(res) -> bool:
            return not isinstance(res, dict) or res.get("retcode", -1) != 0

        try:
            event_id = await self._resolve_event_id()
            data = await self.game_start(tsum_id, event_id=event_id)
        except Exception as e:
            note("tsumid=%s eventid=?" % tsum_id, None)
            return failed("start", {"retmsg": f"{type(e).__name__}: {e}"})
        note(f"tsumid={tsum_id} eventid={event_id}", data)

        # gameStart が弾かれても、ハートはまだ減っていない。やり直しは
        # お客さんの持ち物を減らさないので、心当たりのある順に試す。
        # イベントIDを指定された(game_play の event_id)ときは、ほかのIDには回らない。
        if rejected(data) and not getattr(self, "_pin_event", False):
            # 1) イベントID。gameStart に載せるうち、アカウントによって変わる
            #    のは実質これだけ。イベントに参加している口では、参加している
            #    イベントのIDを載せないと断られる(0 のままだと通らない)。
            #    逆に参加していない口では 0 でなければ通らない。どちらが要る
            #    かは種別の番号からは決められない(形式が変わるたびに変わる)
            #    ので、開催中で参加しているものを順に試して、通ったものを
            #    この接続の答えとして覚える。
            tried = {event_id}
            candidates = []
            try:
                candidates = [i for i in await self.joined_event_ids()
                              if i not in tried]
                if not candidates and self._forget_mast():
                    # 前の接続から借りたマスタが開催の境目で古く、参加中の
                    # イベントが載っていない可能性がある。引き直して見直す
                    # (候補が見つかっているときは引き直さない。数MBある)。
                    candidates = [i for i in await self.joined_event_ids()
                                  if i not in tried]
                if not candidates:
                    # 参加の判定(card / challenge)は、カード形式以外のイベントでは
                    # 当てにならない。gameStart が断られても、断られた開始で
                    # ハートは減らないので、開催中のものを全部順に試す。
                    candidates = [i for i in await self.running_event_ids()
                                  if i not in tried]
            except Exception as e:
                print(f"[PLAY] 参加中のイベントを調べられません: "
                      f"{type(e).__name__}: {e}", flush=True)
            if event_id:
                candidates.append(0)        # 外して試すのも最後に残す
            for candidate in candidates:
                print(f"[PLAY] eventid={candidate} でやり直します", flush=True)
                try:
                    data = await self.game_start(tsum_id, event_id=candidate)
                except Exception as e:
                    return failed("start", {"retmsg": f"{type(e).__name__}: {e}"})
                note(f"tsumid={tsum_id} eventid={candidate}", data)
                if not rejected(data):
                    # 通った。以降のプレイも同じIDで投げる
                    self._event_id = candidate
                    print(f"[PLAY] eventid={candidate} で通りました", flush=True)
                    break

        if rejected(data):
            # 2) 「一度タイトルに戻ります」と言われている。ゲーム側から見て
            #    こちらの状態が食い違っているので、getInfo を投げ直して
            #    入り直したことにしてから、もう一度だけ試す。checkval も
            #    ここで引き直される。
            print("[PLAY] getInfo を投げ直してから、もう一度だけ試します",
                  flush=True)
            try:
                await self.get_info()
                data = await self.game_start(tsum_id, event_id=0)
            except Exception as e:
                return failed("start", {"retmsg": f"{type(e).__name__}: {e}"})
            note(f"getInfo後 tsumid={tsum_id} eventid=0", data)

        if rejected(data):
            return failed("start", data)

        user_info = data.get("userinfo", {}) or {}
        playcode  = user_info.get("playcode")
        if not playcode:
            # 開始は通った形(retcode=0)なのに、プレイの番号(playcode)が無い。実測では
            # gameStart にゲーム開始ではなく getEvent(イベント9999)の応答がそのまま
            # 返ってきて、続く gameEnd も同じ応答だった(プレイにはなっておらず、
            # ハートも減っていない)。そのまま gameEnd を投げると「通ったのに0枚」に
            # 見えて、メダルなどの判断を誤る。少し空けて(requestid の秒も変わる)
            # 1回だけ始め直し、それでも番号が無ければ開始の失敗として返す。
            print("[PLAY] gameStart の応答にプレイの番号がありません。始め直します",
                  flush=True)
            retry_event = self._event_id if self._event_id is not None else event_id
            await asyncio.sleep(1.1)
            try:
                data = await self.game_start(tsum_id, event_id=retry_event)
            except Exception as e:
                return failed("start", {"retmsg": f"{type(e).__name__}: {e}"})
            note(f"番号無しのため再開始 tsumid={tsum_id} eventid={retry_event}", data)
            if rejected(data):
                return failed("start", data)
            user_info = data.get("userinfo", {}) or {}
            playcode  = user_info.get("playcode")
            if not playcode:
                return failed("start", {**data, "retcode": -1,
                                        "retmsg": "ゲーム開始の応答にプレイの番号がありません"})
        print(f"PlayCode={playcode}, Coin={user_info.get('bcoin')}, Heart={user_info.get('bheart')}")
        # 通った gameStart の応答を見て、申告するメダルを決める(以降の始め直しでも、
        # そのたびに新しい応答で決め直す)。
        claim(data)

        async def submit_end(code):
            return await self.game_end(tsum_id=tsum_id, score=score, coin=coin,
                                       exp=exp, medal=medal, play_code=code,
                                       vanish=vanish)

        def end_label(prefix: str) -> str:
            # 何を eventpt / boxcnt に入れて投げたかを足取りに残す。弾かれたとき、
            # ミッションの読みが合っていたのかをここで切り分ける。
            body = getattr(self, "_last_end_body", None) or {}
            text = f"{prefix} eventpt={body.get('eventpt')!r}"
            if body.get("boxcnt"):
                text += f" boxcnt={body.get('boxcnt')!r}"
            return text

        def values_now() -> dict:
            body = self._last_end_body or {}
            return self._mission_values(score, coin, medal, exp,
                                        body.get("combo"), body.get("chain"), vanish)

        self._tried_ends = set()
        self._play_closed = False
        try:
            res_end = await submit_end(playcode)
        except Exception as e:
            return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
        note(end_label("gameEnd"), res_end)

        mission_play = bool(self._mission_entries())
        reason = None
        if rejected(res_end) and mission_play:
            # イベント付きのプレイ。弾かれた理由は retcode からは分からない
            # (1/2「ゲームサーバでエラー」は、枚数が大きすぎるときも、ミッションや
            # 箱の中身が合わないときも同じ)。同じプレイ(同じ playcode)に
            # eventpt / boxcnt の組み合わせを順に投げ直す。ハートは減らない。
            if res_end.get("retcode") in (1, 8):
                body = self._last_end_body or {}
                self._tried_ends.add((body.get("eventpt"), body.get("boxcnt")))
                probed = await self._probe_end(values_now(), note, end_label)
                if probed:
                    res_end = probed
            elif res_end.get("retcode") == 92:
                # 最初の gameEnd でプレイが閉じられた。既定の組はまだ答えが
                # 出ていないので、入り直してから同じ組から投げる。
                self._play_closed = True

            if rejected(res_end) and self._play_closed:
                # 探りの途中でプレイが閉じられた。入り直して(ハート1つ)、
                # まだ試していない組み合わせを続ける。入り直しは1回だけ。
                print("[PLAY] プレイが閉じられたので、入り直して残りの組み合わせを"
                      "試します", flush=True)
                event_for_retry = self._event_id if self._event_id is not None else event_id
                try:
                    await self.get_info()
                    data = await self.game_start(tsum_id, event_id=event_for_retry)
                except Exception as e:
                    return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
                note(f"getInfo後 再開始 tsumid={tsum_id} eventid={event_for_retry}", data)
                if rejected(data):
                    return failed("start", data)
                playcode = (data.get("userinfo", {}) or {}).get("playcode")
                claim(data)
                self._play_closed = False
                got = self._event_points(values_now())
                if got is not None and not self._end_exhausted(*got):
                    # 新しい playcode に、まだ試していないものから投げる。
                    self._last_end_body["playcode"] = playcode
                    probed = await self._probe_end(values_now(), note, end_label)
                    if probed:
                        res_end = probed
                else:
                    try:
                        res_end = await submit_end(playcode)
                    except Exception as e:
                        return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
                    note(end_label("再gameEnd"), res_end)

            if (rejected(res_end) and not self._play_closed
                    and res_end.get("retcode") in (1, 8)):
                # どの組み合わせでも通らない。枚数が原因なら、申告を全部 0 に
                # した同じプレイは通る(そのプレイは 0 枚で終わる)。それも
                # 通らなければイベントの話で、枚数を落としても同じ。
                # 1/8 以外(閉じられ続ける・想定外の番号)は、この切り分けの
                # 対象にしない(一時的な不調でイベント全体を止めない)。
                print("[PLAY] 申告を 0 にして、枚数が原因かを確かめます", flush=True)
                try:
                    zero = await self._resubmit_end("", "", zero=True)
                except Exception as e:
                    zero = {"retmsg": f"{type(e).__name__}: {e}"}
                note(end_label("gameEnd(申告0)"), zero)
                if not rejected(zero):
                    reason = "amount"
                    print("[PLAY] 申告 0 なら通った。枚数が大きすぎる", flush=True)
                else:
                    reason = "event"
                    self._event_broken = True
                    print("[PLAY] 申告 0 でも通らない。このイベントのプレイは"
                          "投げても通らないので、以降は投げない", flush=True)

        elif _return_to_title(res_end):
            # gameEnd も「一度タイトルに戻ります」で弾かれることがある(retcode=92
            # retsubcode=2「プレイデータを受け取りました。プレイデータ反映のため
            # 一度タイトルに戻ります。」)。gameStart の retcode=8 と同じ soft な
            # 合図で、プレイは反映されていない = 残高は動いていない。ここを即失敗に
            # していたので、お客さんの注文がこれで [失敗] になり、同じ口・同じ枚数を
            # 後から管理者テストで流したらそのまま通っていた(その頃には状態が
            # 解けていた)。gameStart と同じく、getInfo を投げ直して入り直し、開始
            # から一度だけやり直す。checkval もここで引き直される。反映されていない
            # 合図なので投げ直しても二重には付かない(呼び出し側も実測で確かめる)。
            print("[PLAY] gameEnd で「一度タイトルに戻ります」。入り直して"
                  "もう一度だけ試します", flush=True)
            event_for_retry = self._event_id if self._event_id is not None else event_id
            try:
                await self.get_info()
                data = await self.game_start(tsum_id, event_id=event_for_retry)
            except Exception as e:
                return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
            note(f"getInfo後 再開始 tsumid={tsum_id} eventid={event_for_retry}", data)
            if rejected(data):
                return failed("start", data)
            playcode = (data.get("userinfo", {}) or {}).get("playcode")
            claim(data)
            try:
                res_end = await submit_end(playcode)
            except Exception as e:
                return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
            note(end_label("再gameEnd"), res_end)

        # それでも通らないとき、イベント付きで始めたプレイ(eventid≠0)なら、
        # 最後にイベントを外してもう一度だけ試す。参加中の口はイベントを外して
        # 始められない(eventid=0 は retcode=8)ことがあるので、これは最後の
        # 逃げ道であって本筋ではない。断られた開始でハートは減らない。
        used_event = self._event_id if self._event_id is not None else event_id
        if rejected(res_end) and used_event and reason != "amount":
            print(f"[PLAY] gameEnd が通らないので、イベント{used_event}を外して"
                  "もう一度だけ試します", flush=True)
            data = None
            try:
                await self.get_info()
                data = await self.game_start(tsum_id, event_id=0)
            except Exception as e:
                print(f"[PLAY] イベント無しの開始に失敗: {type(e).__name__}: {e}",
                      flush=True)
            note(f"イベント無し tsumid={tsum_id} eventid=0", data)
            if not rejected(data):
                playcode = (data.get("userinfo", {}) or {}).get("playcode")
                claim(data)
                try:
                    retry_end = await submit_end(playcode)
                except Exception as e:
                    return failed("end", {"retmsg": f"{type(e).__name__}: {e}"})
                note(end_label("イベント無しgameEnd"), retry_end)
                if not rejected(retry_end):
                    # イベントが原因だった。この接続の以降のプレイも外して投げる
                    # (毎プレイこの回り道をしないため)。
                    self._event_id = 0
                    self._event_broken = False
                    reason = None
                    print("[PLAY] イベントを外したら通りました。以降のプレイも"
                          "イベント無しで投げます", flush=True)
                res_end = retry_end
            # イベント無しの開始が弾かれた(参加中の口では外せないことがある)
            # ときは、元の失敗をそのまま返す。試したことは trail に残っている。

        if not isinstance(res_end, dict) or res_end.get("retcode", -1) != 0:
            return failed("end", res_end, reason)
        print("[SUCCESS] game_end成功")
        if mission_play:
            # 一発で通った書き方も覚える(探りで見つけたものだけ覚えていたので、
            # 一発で通り続けている間は何も残らず、別の口の 0 点のプレイで
            # 振り出しに戻っていた)。
            if self._eventpt_style and not self._eventpt_confirmed:
                self._eventpt_confirmed = True
                self._remember_event_format(self._eventpt_style, [self._eventpt_style])
            if self._last_boxcnt_scheme and not self._boxcnt_scheme:
                self._boxcnt_scheme = self._last_boxcnt_scheme
                self._remember_boxcnt_scheme(self._last_boxcnt_scheme)
        # 通ったときも、何を投げてどれが通ったかを返す。応答が通っても付与が
        # 0 のことがあり、そのとき「一発で通ったのか、入り直してから通ったのか」
        # が分からないと切り分けられない(ハートは通った開始の数だけ減る)。
        res_end["_attempts"] = list(trail)
        res_end["_raw_trail"] = list(raw_trail)
        return res_end
    async def release_tsum_lv(self, tsumid: int) -> dict:
        """POST /releaseTsumLv.nhn"""
        params = self._base_params()
        ordered = {
            "requestid": params.pop("requestid"),
            "tsumid":    tsumid,
            **params,
        }
        return await self._post("/releaseTsumLv.nhn", ordered)
    

    async def gacha_comp(
        self,
        gacha_id: int,
        pickup: bool = False,
        multi_allowed: bool | None = None,
        bonus_id: int = 0,
    ):
        """ガチャを完売方向へ進める。

        現行getInfoの multiflg を呼び出し側から渡し、
        multiflg=0 のガチャに gachaResultMulti を送らない。
        """
        print(
            f"[GACHA-COMP] gachaid={gacha_id} pickup={pickup} "
            f"multi_allowed={multi_allowed} bonus_id={bonus_id}"
        )

        async def wait_loop(func, end_codes, max_loop=500):
            for loop_no in range(1, max_loop + 1):
                try:
                    # pickupResult は bonus_id を受けないので分岐する。
                    func_name = getattr(func, "__name__", "")
                    if func_name == "pickup_result":
                        res = await func(gacha_id=gacha_id)
                    else:
                        res = await func(gacha_id=gacha_id, bonus_id=bonus_id)
                except Exception as e:
                    print(
                        f"[GACHA-CALL-ERROR] loop={loop_no} "
                        f"func={getattr(func, '__name__', str(func))} "
                        f"{type(e).__name__}: {e}"
                    )
                    return {
                        "retcode": -998,
                        "retmsg": f"{type(e).__name__}: {e}",
                    }

                if not isinstance(res, dict):
                    print(f"[GACHA-RESULT-ERROR] loop={loop_no} non-dict response: {type(res).__name__}")
                    return {"retcode": -997, "retmsg": "non-dict response"}

                retcode = res.get("retcode")
                if retcode is None:
                    print(f"[GACHA-RESULT-ERROR] loop={loop_no} retcode missing keys={list(res.keys())}")
                    return {"retcode": -996, "retmsg": "retcode missing"}

                print(
                    f"[GACHA-LOOP] loop={loop_no} "
                    f"func={getattr(func, '__name__', str(func))} retcode={retcode}"
                )

                coin = res.get("userinfo", {}).get("bcoin")
                if coin is not None and coin < 300_000:
                    return {
                        "retcode": -1,
                        "retmsg": f"コイン不足で停止 ({coin:,})"
                    }

                if retcode in end_codes:
                    return res

                if retcode != 0:
                    return res

            return {"retcode": -1, "retmsg": "timeout"}

        if pickup:
            return await wait_loop(self.pickup_result, (31, 34, 35))

        if multi_allowed is False:
            return await wait_loop(self.gacha_result, (31, 34, 35))

        res = await wait_loop(self.gacha_result_multi, (34, 35))

        if res.get("retcode") == 35:
            res = await wait_loop(self.gacha_result, (31, 34, 35))

        return res
    @staticmethod
    def _gacha_completed_in_response(res: dict, gacha_id: int) -> bool:
        comp = res.get("gachacompinfo") if isinstance(res, dict) else None
        entries = comp if isinstance(comp, list) else [comp] if isinstance(comp, dict) else []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            if entry.get("gachaid") == gacha_id and entry.get("compflg") == 1:
                return True
        return False

    @staticmethod
    def _gacha_bonus_id_from_response(res: dict, current: int = 0) -> int:
        info = res.get("gachabonusinfo") if isinstance(res, dict) else None
        entries = info if isinstance(info, list) else [info] if isinstance(info, dict) else []
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            value = entry.get("id")
            if isinstance(value, int):
                return value
        return current

    @staticmethod
    def _gacha_ticket_count_from_response(
        res: dict, gacha_type: int, current: int
    ) -> tuple[int, bool]:
        """レスポンスにtype=7/id=gachaTypeのticket情報があれば更新する。"""
        if not isinstance(res, dict):
            return current, False
        found = False
        value = current
        for key in ("iteminfo", "ticketinfo"):
            raw = res.get(key)
            entries = raw if isinstance(raw, list) else [raw] if isinstance(raw, dict) else []
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                if entry.get("type") == 7 and entry.get("id") == gacha_type:
                    cnt = entry.get("cnt")
                    if isinstance(cnt, int):
                        value = max(0, cnt)
                        found = True
        return value, found

    @staticmethod
    def _gacha_currency(gacha_type: int) -> tuple[str, str]:
        """SceneStore::purchaseProcedureのuType % 10分岐を再現。"""
        mod = int(gacha_type) % 10
        if mod == 1:
            return "coin", "コイン"
        if mod == 2:
            return "ruby", "ルビー"
        if mod == 4:
            return "medal", "メダル"
        return "unknown", "不明通貨"

    @staticmethod
    def _gacha_balance_from_response(
        res: dict, currency: str, current: int
    ) -> tuple[int, bool]:
        ui = res.get("userinfo") if isinstance(res, dict) else None
        if not isinstance(ui, dict):
            return current, False
        key_map = {
            "coin": ("bcoin", "pcoin"),
            "ruby": ("bruby", "pruby"),
            "medal": ("bmedal", "pmedal"),
        }
        keys = key_map.get(currency)
        if not keys:
            return current, False
        if not any(k in ui for k in keys):
            return current, False
        total = 0
        for key in keys:
            value = ui.get(key, 0)
            if isinstance(value, int):
                total += value
        return max(0, total), True

    async def gacha_comp_store(
        self,
        gacha_id: int,
        gacha_type: int,
        multi_allowed: bool,
        curr_price: int,
        balance: int,
        ticket_count: int,
        bonus_id: int = 0,
        label: str = "STORE",
        max_calls: int | None = None,
        max_draws: int = 0,
    ) -> dict:
        """現行SceneStoreのtype=21/31経路
        """
        price = max(0, int(curr_price or 0))
        balance = max(0, int(balance or 0))
        ticket_count = max(0, int(ticket_count or 0))
        bonus_id = max(0, int(bonus_id or 0))
        max_draws = max(0, int(max_draws or 0))
        # HTTP呼び出しの安全上限。回す回数(max_draws)が決まっているなら、そこから
        # 決める。固定値にすると10連では回数の何分の1かで打ち切られ、完売の
        # 手前で止まる。呼び出しの上限で完売を取りこぼすくらいなら、回数の
        # 上限のほうで止めたい。
        max_calls = max_calls or (max_draws + 10 if max_draws > 0
                                  else TSUM_GACHA_MAX_CALLS)
        max_calls = max(1, int(max_calls))
        currency, currency_jp = self._gacha_currency(gacha_type)
        if currency == "unknown":
            return {
                "retcode": -990,
                "_status": "unsupported_currency",
                "retmsg": f"未対応のGachaType={gacha_type}",
            }

        draws = 0
        print(
            f"[{label}-NATIVE] gachaid={gacha_id} type={gacha_type} "
            f"currency={currency} price={price} balance={balance} "
            f"tickets={ticket_count} bonus_id={bonus_id} multi_allowed={multi_allowed} "
            f"max_calls={max_calls} max_draws={max_draws or 'unbounded'}"
        )

        last_res: dict = {"retcode": 0}
        deadline = (time.monotonic() + TSUM_GACHA_MAX_SECONDS
                    if TSUM_GACHA_MAX_SECONDS else 0)
        for call_no in range(1, max_calls + 1):
            if deadline and time.monotonic() >= deadline:
                # 回した分の中身は付いている。打ち切りとして返して、どこまで
                # 進んだかを呼び出し側から伝えられるようにする。
                print(f"[{label}-STOP] 時間の上限 {TSUM_GACHA_MAX_SECONDS}秒に到達 "
                      f"calls={call_no - 1} draws={draws}")
                last_res.update({
                    "retcode": -1,
                    "_status": "time_limit",
                    "_calls": call_no - 1,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "_bonus_id": bonus_id,
                    "retmsg": f"時間の安全上限 {TSUM_GACHA_MAX_SECONDS}秒に到達",
                })
                return last_res
            if call_no > 1:
                # 引き続けるときも機械の連打にしない(上の GAP の説明を参照)。
                await asyncio.sleep(random.uniform(TSUM_GACHA_CALL_GAP_MIN,
                                                   TSUM_GACHA_CALL_GAP_MAX))
            remaining = max_draws - draws if max_draws > 0 else None

            can_try_multi = bool(multi_allowed and (remaining is None or remaining >= 10))
            if can_try_multi and ticket_count >= 10:
                use_multi, units, pay_type = True, 10, 2
            elif can_try_multi and (price == 0 or balance >= price * 10):
                use_multi, units, pay_type = True, 10, 1
            elif ticket_count >= 1:
                use_multi, units, pay_type = False, 1, 2
            elif price == 0 or balance >= price:
                use_multi, units, pay_type = False, 1, 1
            else:
                print(
                    f"[{label}-STOP] {currency_jp}不足: balance={balance} "
                    f"need={price} tickets={ticket_count}"
                )
                return {
                    "retcode": -2,
                    "_status": "insufficient_funds",
                    "_currency": currency,
                    "_currency_jp": currency_jp,
                    "_balance": balance,
                    "_need": price,
                    "_ticket_count": ticket_count,
                    "_calls": call_no - 1,
                    "_draws": draws,
                    "_bonus_id": bonus_id,
                    "retmsg": f"{currency_jp}不足 ({balance:,} / 必要 {price:,})",
                }

            cost = price * units if pay_type == 1 else 0
            mode = "MULTI" if use_multi else "SINGLE"
            print(
                f"[{label}-{mode}] call={call_no} draws={draws} "
                f"paytype={pay_type} units={units} cost={cost} "
                f"balance={balance} tickets={ticket_count} bonus_id={bonus_id}"
            )

            try:
                if use_multi:
                    res = await self.gacha_result_multi(
                        gacha_id=gacha_id,
                        bonus_id=bonus_id,
                        pay_type=pay_type,
                    )
                else:
                    res = await self.gacha_result(
                        gacha_id=gacha_id,
                        bonus_id=bonus_id,
                        pay_type=pay_type,
                    )
            except Exception as e:
                return {
                    "retcode": -998,
                    "_status": "exception",
                    "_calls": call_no,
                    "_draws": draws,
                    "retmsg": f"{type(e).__name__}: {e}",
                }

            if not isinstance(res, dict):
                return {
                    "retcode": -997,
                    "_status": "invalid_response",
                    "retmsg": "non-dict response",
                }
            last_res = dict(res)
            retcode = res.get("retcode")
            print(
                f"[{label}-RESULT] call={call_no} mode={mode} "
                f"retcode={retcode} retsubcode={res.get('retsubcode')}"
            )

            if retcode == 35 and use_multi:
                print(f"[{label}-FALLBACK] retcode=35 -> Singleへ切替")
                multi_allowed = False
                continue
            if retcode != 0:
                last_res.update({
                    "_status": "server_error",
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "_bonus_id": bonus_id,
                })
                return last_res

            draws += units
            bonus_id = self._gacha_bonus_id_from_response(res, bonus_id)

            new_balance, balance_found = self._gacha_balance_from_response(
                res, currency, balance
            )
            if balance_found:
                balance = new_balance
            elif pay_type == 1:
                balance = max(0, balance - cost)

            new_tickets, ticket_found = self._gacha_ticket_count_from_response(
                res, gacha_type, ticket_count
            )
            if ticket_found:
                ticket_count = new_tickets
            elif pay_type == 2:
                ticket_count = max(0, ticket_count - units)

            if self._gacha_completed_in_response(res, gacha_id):
                print(f"[{label}-COMPLETE] compflg=1 calls={call_no} draws={draws}")
                last_res.update({
                    "_status": "completed",
                    "_completed": True,
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "_bonus_id": bonus_id,
                })
                return last_res

            if max_draws > 0 and draws >= max_draws:
                last_res.update({
                    "_status": "max_draws_reached",
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "_bonus_id": bonus_id,
                })
                return last_res

        last_res.update({
            "retcode": -1,
            "_status": "loop_limit",
            "_calls": max_calls,
            "_draws": draws,
            "_balance": balance,
            "_ticket_count": ticket_count,
            "_bonus_id": bonus_id,
            "retmsg": f"安全上限 {max_calls} 回に到達",
        })
        return last_res

    async def gacha_comp_pickup(
        self,
        gacha_id: int,
        gacha_type: int,
        curr_price: int,
        balance: int,
        ticket_count: int,
        max_count: int = 0,
        label: str = "PICKUP",
        max_calls: int | None = None,
    ) -> dict:
        """type=21/31のSceneStore経路を再現。/pickUpResult.nhnを1回ずつ呼ぶ。"""
        # 1回の呼び出しで1回ぶんしか引けないので、中身の数が分かっているなら
        # そこから決める(呼び出しの上限で完売を取りこぼさないため)。
        # transient/no-op 応答用に少し余裕を持たせる。
        max_calls = max_calls or (max_count + 10 if max_count and max_count > 0
                                  else TSUM_GACHA_MAX_CALLS)
        max_calls = max(1, int(max_calls))
        price = max(0, int(curr_price or 0))
        balance = max(0, int(balance or 0))
        ticket_count = max(0, int(ticket_count or 0))
        currency, currency_jp = self._gacha_currency(gacha_type)
        if currency == "unknown":
            return {"retcode": -990, "_status": "unsupported_currency"}

        print(
            f"[{label}-NATIVE] gachaid={gacha_id} type={gacha_type} "
            f"endpoint=/pickUpResult.nhn price={price} {currency}={balance} "
            f"tickets={ticket_count} maxcnt={max_count} max_calls={max_calls}"
        )

        last_res: dict = {"retcode": 0}
        draws = 0
        no_progress_streak = 0
        deadline = (time.monotonic() + TSUM_GACHA_MAX_SECONDS
                    if TSUM_GACHA_MAX_SECONDS else 0)
        for call_no in range(1, max_calls + 1):
            if deadline and time.monotonic() >= deadline:
                print(f"[{label}-STOP] 時間の上限 {TSUM_GACHA_MAX_SECONDS}秒に到達 "
                      f"calls={call_no - 1} draws={draws}")
                last_res.update({
                    "retcode": -1,
                    "_status": "time_limit",
                    "_calls": call_no - 1,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "retmsg": f"時間の安全上限 {TSUM_GACHA_MAX_SECONDS}秒に到達",
                })
                return last_res
            if max_count > 0 and draws >= max_count:
                last_res.update({
                    "_status": "max_draws_reached",
                    "_calls": call_no - 1,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                })
                return last_res
            if call_no > 1:
                # 引き続けるときも機械の連打にしない(GAP の説明を参照)。
                await asyncio.sleep(random.uniform(TSUM_GACHA_CALL_GAP_MIN,
                                                   TSUM_GACHA_CALL_GAP_MAX))
            # purchaseProcedureはPickupへ分岐する前にticket/currency不足を判定する。
            uses_ticket = ticket_count >= 1
            if not uses_ticket and price > 0 and balance < price:
                print(
                    f"[{label}-STOP] {currency_jp}不足: balance={balance} "
                    f"need={price} tickets={ticket_count}"
                )
                return {
                    "retcode": -2,
                    "_status": "insufficient_funds",
                    "_currency": currency,
                    "_currency_jp": currency_jp,
                    "_balance": balance,
                    "_need": price,
                    "_ticket_count": ticket_count,
                    "_calls": call_no - 1,
                    "_draws": draws,
                    "retmsg": f"{currency_jp}不足 ({balance:,} / 必要 {price:,})",
                }

            print(
                f"[{label}-SINGLE] call={call_no} draws={draws} "
                f"payment={'ticket' if uses_ticket else currency} "
                f"balance={balance} tickets={ticket_count}"
            )
            try:
                res = await self.pickup_result(gacha_id=gacha_id)
            except Exception as e:
                return {
                    "retcode": -998,
                    "_status": "exception",
                    "_calls": call_no,
                    "_draws": draws,
                    "retmsg": f"{type(e).__name__}: {e}",
                }
            if not isinstance(res, dict):
                return {"retcode": -997, "_status": "invalid_response"}
            last_res = dict(res)
            retcode = res.get("retcode")
            print(
                f"[{label}-RESULT] call={call_no} retcode={retcode} "
                f"retsubcode={res.get('retsubcode')}"
            )
            if retcode != 0:
                last_res.update({
                    "_status": "server_error",
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                })
                return last_res

            prev_balance = balance
            prev_tickets = ticket_count

            new_balance, balance_found = self._gacha_balance_from_response(
                res, currency, balance
            )
            if balance_found:
                balance = new_balance

            new_tickets, ticket_found = self._gacha_ticket_count_from_response(
                res, gacha_type, ticket_count
            )
            if ticket_found:
                ticket_count = new_tickets

            completed = self._gacha_completed_in_response(res, gacha_id)

            if price == 0:
                progressed = True
            elif uses_ticket:
                progressed = ticket_found and ticket_count < prev_tickets
            else:
                progressed = balance_found and balance < prev_balance

            # サーバーが残高/チケットを返さない旧互換時のみローカル推定する。
            if not balance_found and not ticket_found:
                if uses_ticket and ticket_count > 0:
                    ticket_count = max(0, ticket_count - 1)
                    progressed = True
                elif not uses_ticket and price > 0 and balance >= price:
                    balance = max(0, balance - price)
                    progressed = True

            if progressed:
                draws += 1
                no_progress_streak = 0
                print(
                    f"[{label}-PROGRESS] call={call_no} draws={draws} "
                    f"balance={balance} tickets={ticket_count}"
                )
            else:
                no_progress_streak += 1
                print(
                    f"[{label}-NO-PROGRESS] call={call_no} retcode=0 "
                    f"balance={balance} tickets={ticket_count} "
                    f"streak={no_progress_streak}"
                )

            if completed:
                print(f"[{label}-COMPLETE] compflg=1 calls={call_no} draws={draws}")
                last_res.update({
                    "_status": "completed",
                    "_completed": True,
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                })
                return last_res

            if no_progress_streak >= 3:
                last_res.update({
                    "_status": "no_progress",
                    "_calls": call_no,
                    "_draws": draws,
                    "_balance": balance,
                    "_ticket_count": ticket_count,
                    "retmsg": "retcode=0だが購入成立を3回連続で確認できませんでした",
                })
                return last_res

        last_res.update({
            "_status": "call_limit",
            "_calls": max_calls,
            "_draws": draws,
            "_balance": balance,
            "_ticket_count": ticket_count,
            "retmsg": f"HTTP呼び出し安全上限 {max_calls} 回に到達",
        })
        return last_res

    async def gacha_comp_h(self, gacha_id: int = 104, bonus_id: int = 0):
        

        def completed_in_response(res: dict) -> bool:
            comp = res.get("gachacompinfo")
            entries = comp if isinstance(comp, list) else [comp] if isinstance(comp, dict) else []
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                if entry.get("gachaid") == gacha_id and entry.get("compflg") == 1:
                    return True
            return False

        print(
            f"[HAPPINESS-COMP] gachaid={gacha_id} "
            f"single=True bonus_id={bonus_id}"
        )

        for loop_no in range(1, 1001):
            try:
                res = await self.gacha_result(
                    gacha_id=gacha_id,
                    bonus_id=bonus_id,
                )
            except Exception as e:
                print(f"[HAPPINESS-CALL-ERROR] loop={loop_no} {type(e).__name__}: {e}")
                return {"retcode": -998, "retmsg": f"{type(e).__name__}: {e}"}

            if not isinstance(res, dict):
                return {"retcode": -997, "retmsg": "non-dict response"}

            retcode = res.get("retcode")
            print(f"[HAPPINESS-LOOP] loop={loop_no} retcode={retcode}")

            if completed_in_response(res):
                print("[HAPPINESS-COMP] compflg=1 detected")
                return res

            if retcode in (31, 34, 35):
                return res

            if retcode != 0:
                return res

        return {"retcode": -1, "retmsg": "ループ上限到達"}
    async def buy_heart(self, setid: int = 11) -> dict:
        """POST /buyHeart.nhn"""
        params = self._base_params()
        ordered = {
            "requestid": params.pop("requestid"),
            "setid":     setid,
            **params,
        }
        return await self._post("/buyHeart.nhn", ordered)
    async def get_event(self, eventid: int, updateflg: int = 0) -> dict:
        """POST /getEvent.nhn"""
        params = self._base_params()

        ordered = {
            "requestid": params.pop("requestid"),
            "eventid": eventid,
            "updateflg": updateflg,
            **params,
        }

        data = await self._post("/getEvent.nhn", ordered)
        # 各マスのミッション(desc / subtype)は、gameEnd でイベントの結果を
        # 決めるのに要る(_mission_kinds を参照)。参加確認で一度取っているので、
        # ここで控えておけばプレイのたびに取り直さずに済む。
        if isinstance(data, dict) and data.get("retcode", -1) == 0:
            self._event_cache[int(eventid)] = data
        return data
    
    async def tsum_level(self,tsum_id:int):
        
        for i in range(6):
            await self.game_play(tsum_id=tsum_id)
            await self.release_tsum_lv(tsumid=tsum_id)

    async def player_level(self):
        return await self.game_play(exp=100000000)
    def extract_gacha_ids(self, gachamst):
        gacha_type_map = {
            1: "happiness",
            11: "premium",
            21: "pickup",
            31: "pickup_tower",
            41: "select",
            53: "invite",
            64: "premiumplus",
        }

        result = {}
        for g in gachamst or []:
            if not isinstance(g, dict):
                continue
            name = gacha_type_map.get(g.get("type"))
            gacha_id = g.get("gachaid")
            if name and isinstance(gacha_id, int):
                result.setdefault(name, []).append(gacha_id)

        return result

    def resolve_active_gacha_targets(self, gachamst, available_gachas):
        type_names = {
            1: "happiness",
            11: "premium",
            21: "pickup",
            31: "pickup_tower",
            41: "select",
            53: "invite",
            64: "premiumplus",
        }
        available_by_id = {g.gachaid: g for g in available_gachas}

        resolved = {}
        for row in gachamst or []:
            if not isinstance(row, dict):
                continue
            name = type_names.get(row.get("type"))
            gacha_id = row.get("gachaid")
            if not name or not isinstance(gacha_id, int):
                continue
            info = available_by_id.get(gacha_id)
            if info is None:
                continue
            current = resolved.get(name)
            if current is not None:
                # 同じ種類が並んで開催されていることがある(セレクトBOXは弾ごと
                # に別のgachaid)。先に見つけたほうを使うが、それがそのアカウント
                # ではもう完売していて、こちらがまだなら乗り換える。完売済みの
                # ほうを掴むと、1回も回さずに「すでに完売しています」で終わる。
                if current["compflg"] != 1 or info.compflg == 1:
                    continue

            list_price = row.get("listprice", row.get("price", 0))
            curr_price = row.get("currprice", 0)
            if not isinstance(list_price, int):
                list_price = 0
            if not isinstance(curr_price, int):
                curr_price = 0
            effective_price = curr_price if curr_price > 0 else list_price

            resolved[name] = {
                "gachaid": gacha_id,
                "type": row.get("type"),
                "name": row.get("name", ""),
                "maxcnt": row.get("maxcnt"),
                "listprice": list_price,
                "currprice": curr_price,
                "price": effective_price,
                "multiflg": info.multiflg,
                "compflg": info.compflg,
            }

        return resolved


def set_versions(app_ver: str = None, res_ver: str = None):
    """使うゲームバージョンを実行中に差し替える(再デプロイ不要)。

    appver / resver はクラス変数なので、ここで書き換えれば次に作る
    クライアントから新しいバージョンで通信する。User-Agentのバージョンも
    一緒に直さないと、名乗りとパラメータがずれる。
    """
    global TSUM_APP_VER, TSUM_RES_VER
    if app_ver:
        TSUM_APP_VER = str(app_ver)
        LGTMTMClient.APP_VER = TSUM_APP_VER
        LineOAuthLogin.UA_APP = _user_agent(TSUM_APP_VER)
        LineTokenManager.USER_AGENT = _user_agent(TSUM_APP_VER)
    if res_ver:
        TSUM_RES_VER = str(res_ver)
        LGTMTMClient.RES_VER = TSUM_RES_VER
