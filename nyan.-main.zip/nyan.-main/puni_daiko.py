"""ぷにぷに代行の中身(ログイン・周回・価格・売上・アプリ版の管理)。

Discordの都合はここに持ち込まない(Cogs/puni.py が受け持つ)。こうしておくと
「支払いは受け取れたのに代行が走らない」ときに、どちらの層で止まったのかを
切り分けられる(ツムツム代行の tsum_daiko.py と同じ考え方)。

売り物は1つだけ:「最後に遊んだステージを指定回数だけ自動周回する」。周回すれば
Yポイントもドロップも自然に貯まるので、メニューを増やさず回数だけを
お客さんに決めてもらう。価格は管理者がコマンドで決める。

低レイヤのゲーム通信(暗号・L5ログイン・gameStart/gameEnd)は、動作実績のある
スクリプトをそのまま持ち込んでいる。requests は同期なので、外へ出す入口では
ゲーム通信専用のスレッド(_GAME_POOL)で回して、Botのイベントループを塞がないようにする
(asyncio 既定のスレッドは Discord への接続の名前解決と共用なので使わない)。
PuniRunner の中の呼び出しには上限の秒数を付け、戻らなければそこまでの結果で終える
(PuniRunner._blocking / PuniGameTimeout)。

BAN対策として、1プレイの結果は毎回散らし、gameStart→gameEnd は申告する
クリア秒数と釣り合うだけ間を空け、周と周のあいだもゆらぎと小休止を入れる
(build_game_end / Client.battle / PuniRunner.farm)。端末(機種・OS・電池)は
udkey ごとに固定した「その人のスマホ」を名乗り、全アカウント共通の癖を作らない
(DeviceProfile)。同じサーバから複数の垢を同時に回すときは、全体で叩く間隔も
空ける(_pace)。IPごと弾かれた気配(HTTP 403/429 の連発)があれば、全部の周回を
いったん止める(global_hold_remaining)。

周回するステージはお客さんに選ばせない。注文の前にそのステージを一度プレイ(クリアかリタイア)して
もらい、ログイン後に「最後に遊んだステージ」(ywp_user_data.nowStageId)を読んで
それを回す(PuniRunner.pick_farm_stage)。名前は puni_stages で引く。

【バージョン追従】ぷにぷにが更新されると古いアプリ版は rc=20 / rc=101 で
丸ごと弾かれる。App Store の最新版を定期的に見て自動で切り替える
(check_and_update_app_version)。周回中に rc=20/101 を踏んだら、その場でも
更新して回し直す。暗号鍵・署名だけはアプリから抽出した固定値なので、それらが
変わる大型アップデートのときは手で更新が要る(`/puni_version set`)。
"""
import asyncio
import base64
import concurrent.futures
import functools
import hashlib
import hmac
import json
import os
import random
import re
import threading
import time
import zlib
from urllib.parse import urljoin, urlparse, parse_qs

import requests
from Crypto.Cipher import AES

import puni_stages
from datapath import data_path, read_json, write_json

# ============================================================================
# ゲーム通信の定数(アプリから抽出した固定値)
# ============================================================================

AESK = bytes.fromhex('a865d7e5e2458f8ce1b5ecd087e54594')
K = b'0bk2kvtFE2'
APKEY = 'a-zrhgm09pgcgjc1iv9cxvpk3xm9b0ynyo4u00sny6bjq10nrx3up2yrhjnq2lhg'
SIGNATURE = ('s4X9CoyxGma3kGuAp5woThgvBX3dCi77Slh5RcOo6ybmMTt0J4CGiZwyiCsil7P3'
             'MVgjiVt+kGE1MqvttCXLB+hlOpyTkJp5a78TXthBNVw=')
GS = 'https://gameserver.yw-p.com'
L5 = 'https://api.level5-id.com'

# 元スクリプトが名乗っていた端末。いまは udkey ごとの DeviceProfile を使い、
# これは「プロファイルが無いとき」の既定値としてだけ残す。
MODEL = 'GA00747-UK'
OSVER = '9'
BUILD_ID = 'PI'
# アプリ版だけは更新のたびに変わる。config.json で差し替えられるようにする。
DEFAULT_APP_VER = os.getenv("PUNI_APP_VER", '4.175.0')
BATTERY = {'level': 100, 'state': 3, 'technology': 'Li-poly',
           'temperature': 261, 'voltage': 4300}

# --- 端末プロファイル(udkeyごとに固定) ----------------------------------
#
# 全アカウントが同じ機種・同じOS・電池100%固定・温度固定で名乗ると、それ自体が
# 「同じ道具で回している」目印になる。udkey(=端末の鍵)ごとに機種を1つ決めて
# ずっと同じものを名乗り、電池はセッション中に少しずつ減る/充電で増える、
# 温度は使うほど上がる、という実機の振る舞いに寄せる。
# (機種名, Androidの版, Build ID)。日本で普通に使われている端末に限る。
DEVICE_POOL = (
    ("SM-G991B", "13", "TP1A.220624.014"),     # Galaxy S21
    ("SM-S908B", "14", "UP1A.231005.007"),     # Galaxy S22 Ultra
    ("SM-A536D", "14", "UP1A.231005.007"),     # Galaxy A53 (docomo)
    ("SC-51E", "14", "UP1A.231005.007"),       # Galaxy S23 (docomo)
    ("SCG15", "14", "UP1A.231005.007"),        # Galaxy A54 (au)
    ("SO-52C", "13", "64.1.A.0.921"),          # Xperia 5 IV
    ("SO-51D", "14", "67.1.A.2.153"),          # Xperia 1 V
    ("SOG08", "14", "67.1.C.2.153"),           # Xperia 10 V (au)
    ("SH-54B", "13", "S6222"),                 # AQUOS sense6
    ("SH-53C", "13", "S3250"),                 # AQUOS sense7
    ("SH-52D", "14", "S2140"),                 # AQUOS sense8
    ("Pixel 6a", "14", "UP1A.231105.001"),
    ("Pixel 7", "14", "UQ1A.240205.004"),
    ("Pixel 7a", "14", "UP1A.231005.007"),
    ("Pixel 8", "15", "AP3A.241005.015"),
    ("CPH2523", "14", "UKQ1.230924.001"),      # OPPO Reno9 A
    ("XT2335-3", "13", "T1SUS33.30-9-2"),      # moto g53j 5G
    ("A302SH", "14", "S3110"),                 # AQUOS wish4 (SoftBank)
)
DEVICES_FILE = data_path("puni_devices.json")
_DEVICE_LOCK = threading.Lock()


class DeviceProfile:
    """1台のスマホの名乗り(機種・OS・Build)と電池の推移。

    電池はこのプロセスでこのプロファイルを作った時刻を起点に、放電なら数分に
    1%ずつ減り、充電中なら増える。温度は使い込むほど少し上がる。数値は
    Android の BatteryManager の単位(温度は0.1℃、電圧はmV)。
    """

    def __init__(self, model=MODEL, osver=OSVER, build=BUILD_ID, *,
                 level=None, state=None):
        self.model = str(model)
        self.osver = str(osver)
        self.build = str(build)
        self.started = time.time()
        # 実機のありがちな残量。満充電固定にはしない。
        self.level0 = int(level) if level is not None else random.randint(28, 97)
        # 2=充電中 3=放電中 (BatteryManager.BATTERY_STATUS_*)。多くは放電中。
        self.state0 = int(state) if state is not None else random.choices((3, 2), (4, 1))[0]
        # 放電の速さ(1%減るのにかかる分)。端末ごとに違う。
        self.drain_min = random.uniform(3.0, 6.0)
        self.temp0 = random.randint(235, 305)

    @property
    def device_cd(self) -> str:
        return '%s_%s' % (self.model, self.osver)

    def user_agent(self, app_ver: str) -> str:
        return ('Dalvik/2.1.0 (Linux; U; Android %s; %s Build/%s) com.Level5.YWP/%s'
                % (self.osver, self.model, self.build, app_ver))

    def battery(self) -> dict:
        minutes = max(0.0, (time.time() - self.started) / 60.0)
        if self.state0 == 2:
            level = min(100, self.level0 + int(minutes / 1.5))
            state = 5 if level >= 100 else 2        # 5=満充電
        else:
            level = max(3, self.level0 - int(minutes / self.drain_min))
            state = 3
        temperature = self.temp0 + int(min(minutes, 90) * 0.4) + random.randint(-4, 4)
        voltage = 3480 + level * 8 + random.randint(-35, 35)
        return {'level': level, 'state': state, 'technology': 'Li-ion',
                'temperature': temperature, 'voltage': voltage}

    def to_dict(self) -> dict:
        return {"model": self.model, "osver": self.osver, "build": self.build}

    @classmethod
    def from_dict(cls, d: dict):
        return cls(d.get("model") or MODEL, d.get("osver") or OSVER,
                   d.get("build") or BUILD_ID)

    @classmethod
    def random(cls):
        model, osver, build = random.choice(DEVICE_POOL)
        return cls(model, osver, build)


# このプロセスで作った/読んだプロファイル(udkey→DeviceProfile)。電池の推移を
# セッションの間だけ持つので、ファイルには機種だけ書く。
_DEVICES: dict = {}


def device_for(udkey: str) -> DeviceProfile:
    """その udkey が名乗る端末。覚えていればそれ、以後ずっと同じにする。

    新しい udkey は new_udkey() が作るときに機種を決めて紐づける。ここで初めて
    見る udkey は、この仕組みより前(元の固定端末で)作られたものなので、途中で
    機種が変わらないよう元の固定端末のまま名乗る。
    """
    if not udkey:
        return DeviceProfile()
    with _DEVICE_LOCK:
        prof = _DEVICES.get(udkey)
        if prof is not None:
            return prof
        stored = read_json(DEVICES_FILE, {})
        if not isinstance(stored, dict):
            stored = {}
        d = stored.get(udkey)
        if isinstance(d, dict) and d.get("model"):
            prof = DeviceProfile.from_dict(d)
        else:
            prof = DeviceProfile()
            stored[udkey] = {**prof.to_dict(), "created": time.time()}
            # 古いものを溜め込まない(渡し終わった udkey は二度と使わない)。
            if len(stored) > 3000:
                oldest = sorted(stored, key=lambda k: stored[k].get("created", 0))
                for k in oldest[:len(stored) - 3000]:
                    stored.pop(k, None)
            try:
                write_json(DEVICES_FILE, stored)
            except Exception as e:
                print(f"[PUNI] 端末プロファイルを保存できません: {e}", flush=True)
        _DEVICES[udkey] = prof
        return prof


def bind_device(udkey: str, prof: DeviceProfile):
    """新しく作った udkey に、作るときに名乗った端末を紐づける(以後同じ機種)。"""
    if not udkey or prof is None:
        return
    with _DEVICE_LOCK:
        _DEVICES[udkey] = prof
        stored = read_json(DEVICES_FILE, {})
        if not isinstance(stored, dict):
            stored = {}
        stored[udkey] = {**prof.to_dict(), "created": time.time()}
        try:
            write_json(DEVICES_FILE, stored)
        except Exception as e:
            print(f"[PUNI] 端末プロファイルを保存できません: {e}", flush=True)


# --- 全体のペース(同じサーバから複数の垢を回すとき) ------------------------
#
# 1垢ずつは人のペースでも、5垢を同時に回すとサーバから見た「この送信元」は
# 5倍速で叩いている。gameStart/gameEnd/購入の呼び出しは全体で最低これだけ
# 間隔を空ける(各垢の待ちはそのまま)。
# 1つの垢の周回では、gameStart→gameEnd の間はプレイ時間、gameEnd→次の gameStart の間は
# 休みが必ず入るので、この間隔は効かない。効くのは複数の垢を同時に回すときだけ
# (同じ出口から別々の垢の送信が重なりすぎないように)。
PACE_GAP_MIN = float(os.getenv("PUNI_PACE_GAP_MIN", "0.6"))
PACE_GAP_MAX = float(os.getenv("PUNI_PACE_GAP_MAX", "1.6"))
PACED_CALLS = ("gameStart.nhn", "gameEnd.nhn", "buyHitodama.nhn")
# IPごと弾かれた気配(HTTP 403/429)がこの回数/この秒数の中で出たら、全部の周回を
# BLOCK_HOLD_SECONDS だけ止める。叩き続けると本当に締め出される。
BLOCK_HITS = int(os.getenv("PUNI_BLOCK_HITS", "3"))
BLOCK_WINDOW_SECONDS = float(os.getenv("PUNI_BLOCK_WINDOW", "120"))
BLOCK_HOLD_SECONDS = float(os.getenv("PUNI_BLOCK_HOLD", "300"))
_PACE = {"lock": threading.Lock(), "next_ok": 0.0, "hold_until": 0.0, "hits": [],
         # サーバに拒まれた(HTTP 5xx/403/429 で init/login が落ちた)回数の段階。
         # 段階ごとに止める時間を延ばす(5分→10分→20分→40分→60分)。通ったら戻す。
         "refusals": 0}
# 拒まれた直後に止める時間(秒)。段階が上がるごとに倍にし、上限まで。
REFUSAL_HOLD_SECONDS = float(os.getenv("PUNI_REFUSAL_HOLD", "300"))
REFUSAL_HOLD_MAX_SECONDS = float(os.getenv("PUNI_REFUSAL_HOLD_MAX", "3600"))


def _pace(name: str):
    """全体の送信間隔を空ける(ブロッキング。post_nhn のスレッドで呼ぶ)。"""
    if name not in PACED_CALLS:
        return
    with _PACE["lock"]:
        now = time.time()
        start = max(now, _PACE["next_ok"])
        _PACE["next_ok"] = start + random.uniform(PACE_GAP_MIN, PACE_GAP_MAX)
    wait = start - now
    if wait > 0:
        time.sleep(wait)


def note_http_block(status_code):
    """HTTP 403/429/5xx を見たと記録する。短時間に続いたら全体を止める。

    5xx も数える。サーバ側が落ちているか、こちらの出口(IP)を拒んでいるかの
    どちらでも、叩き続けて良いことは無い(実測: ログインが HTTP 500 で落ちる
    状態が起きた)。
    """
    try:
        status_code = int(status_code)
    except (TypeError, ValueError):
        return
    if status_code not in (403, 429) and not 500 <= status_code < 600:
        return
    held = False
    with _PACE["lock"]:
        now = time.time()
        hits = [t for t in _PACE["hits"] if now - t <= BLOCK_WINDOW_SECONDS]
        hits.append(now)
        _PACE["hits"] = hits
        if len(hits) >= BLOCK_HITS:
            _PACE["hold_until"] = max(_PACE["hold_until"], now + BLOCK_HOLD_SECONDS)
            _PACE["hits"] = []
            held = True
    # 出力はロックの外で(標準出力が詰まったときに、全部の垢の _pace まで巻き込んで止めない)。
    if held:
        print(f"[PUNI] HTTP {status_code} が続いたため、周回を"
              f"{int(BLOCK_HOLD_SECONDS)}秒止めます", flush=True)


def note_server_refusal(where: str = "") -> float:
    """入口(init / getGdkeyAccounts / login)でサーバに拒まれた。全体を止める。

    1回でも止める(入口で拒まれているのに周回や別の注文を流しても、全部同じ
    ように落ちて締め出しを延ばすだけ)。続けて拒まれるたびに止める時間を倍に
    する(5分→10分→…→60分)。通ったら note_server_ok で戻す。戻り値は止める秒数。
    """
    with _PACE["lock"]:
        now = time.time()
        level = _PACE["refusals"]
        hold = min(REFUSAL_HOLD_SECONDS * (2 ** level), REFUSAL_HOLD_MAX_SECONDS)
        _PACE["refusals"] = level + 1
        _PACE["hold_until"] = max(_PACE["hold_until"], now + hold)
    print(f"[PUNI] サーバに拒まれました({where})。{int(hold // 60)}分ほど全体を止めます",
          flush=True)
    return hold


def note_server_ok():
    """ゲームサーバが普通に応えた。拒まれた段階を戻す。"""
    with _PACE["lock"]:
        if _PACE["refusals"]:
            _PACE["refusals"] = 0


def global_hold_remaining() -> float:
    """全体停止の残り秒数。0 なら止まっていない。"""
    with _PACE["lock"]:
        return max(0.0, _PACE["hold_until"] - time.time())


def _reset_pace_for_tests():
    with _PACE["lock"]:
        _PACE.update({"next_ok": 0.0, "hold_until": 0.0, "hits": [], "refusals": 0})

# ゲーム側の resultCode。原因を追う唯一の手掛かりになるので、決まり文句で
# 塗り潰さずそのまま残す。
RC = {0: 'OK', -1: 'IPブロック/復号不可', 4: '一時エラー', 5: '人魂(スタミナ)不足', 20: 'appVerかマスタ版が古い',
      30: '署名の不整合', 32: 'tokenズレ', 37: 'チュートリアル未完了',
      100: 'データの更新があります(その形のステージ/商品が無い)', 102: '該当ステージなし',
      101: 'マスタ版が現行と違う/ブロック終端', 202: 'BAN', 1303: '該当ステージなし/ブロック終端',
      # イベントで「今は入れないステージ」に入ろうとしたときに返る(実測: 29903004/005 =
      # 裏マップ 1-4/1-5。ステージ表では state=0(ロック)。封印バトルや日付などの開放待ち)。
      # 存在しない会場の頭では 1311 が返った(実測: 29912001)。
      508: '今は入れないステージ(未開放/条件未達)', 1311: '該当ステージなし/ブロック終端',
      # 1000周の周回で5回だけ出て、次の周はそのまま通った(実測)。サーバ側の一時的なもの。
      1701: 'サーバ側の一時エラー(次の周は通る)'}
# 周回で「その周だけ失敗、次は通る」ことが分かっている一時的なコード。少し待って同じ周を
# やり直す(失敗に数えない)。rc=4 とは別扱い(rc=4 は叩きすぎの警告として RC4_* で数える)。
RETRY_ONCE_RC = (1701,)
RETRY_ONCE_WAIT = (8.0, 15.0)
# 強敵(ボス)のステージで使う battleType。別 bot は過去イベントのボスのブロック(28805 など)
# だけにこれを使っている。実機(iPhone)で裏マップの強敵 29704006 に入ったときの gameStart も
# battleType 6 だった(復号した通信で確認)。
BOSS_BATTLE_TYPE = 6
# battleType を指定しないプレイで、強敵の battleType を使うステージIDの頭(古いイベント
# の強敵)。ここに無い強敵ステージは、呼び出し側が BOSS_BATTLE_TYPE を明示する
# (hunt_boss・farm。強敵かどうかは垢のチュートリアル一覧で見る)。
AUTO_BOSS_PREFIXES = ('28805', '28904', '29008', '29304')


def auto_battle_type(stage_id) -> int:
    """battleType を指定しないときに使う battleType。"""
    return BOSS_BATTLE_TYPE if str(stage_id).startswith(AUTO_BOSS_PREFIXES) else 1


# 垢のチュートリアル一覧(ywp_user_tutorial_list。行は "種別|ID|済み")のうち、強敵ステージの
# 初回案内に使われる種別。実機では強敵の戦闘を終えて画面に戻るときに
# updateTutorialFlg(tutorialType 13, tutorialId=ステージID, tutorialStatus 1) が飛ぶ。
# この種別で並ぶIDが、その垢が知っている強敵ステージ(過去イベント分も含む)になる。
BOSS_TUTORIAL_TYPE = 13
# gameStart の敵の dropItemType のうち「宝箱」。宝箱は dropItemFlg ではなく
# dropTreasureFlg / dropTreasureId で申告する(実機の gameEnd で確認)。
TREASURE_ITEM_TYPE = 15

# gameEnd に必ず添える定数。中身はアプリの実測値をそのまま使う。
GAME_CONST = [
    {"constType": 5, "mstKey": "blockComboAdjustNumA", "mstValue": "0.051800"},
    {"constType": 5, "mstKey": "blockComboAdjustNumB", "mstValue": "0.995500"},
    {"constType": 5, "mstKey": "blockSizeAdjustA", "mstValue": "0.000800"},
    {"constType": 5, "mstKey": "blockSizeAdjustB", "mstValue": "0.077000"},
    {"constType": 5, "mstKey": "blockSizeAdjustC", "mstValue": "-0.058500"},
    {"constType": 5, "mstKey": "blockSizeAdjustSkillA", "mstValue": "5.780200"},
    {"constType": 5, "mstKey": "blockSizeAdjustSkillB", "mstValue": "-2.201000"},
    {"constType": 5, "mstKey": "blockSizeAdjustSkillC", "mstValue": "1.000000"},
    {"constType": 5, "mstKey": "blockSizeRate1", "mstValue": "0.019300"},
    {"constType": 5, "mstKey": "blockSizeRate2", "mstValue": "0.058600"},
    {"constType": 5, "mstKey": "blockSizeRate3", "mstValue": "0.137900"},
    {"constType": 5, "mstKey": "comboEnableSec", "mstValue": "3.000000"},
    {"constType": 5, "mstKey": "comboEnableSize", "mstValue": "2"},
    {"constType": 5, "mstKey": "damageSwitchSize", "mstValue": "3"},
    {"constType": 5, "mstKey": "feverDamageAdjustNum", "mstValue": "0.100000"},
    {"constType": 5, "mstKey": "feverScoreAdjustNum", "mstValue": "0.100000"},
    {"constType": 5, "mstKey": "saBlockSizeAdjustSubA", "mstValue": "0.006200"},
    {"constType": 5, "mstKey": "saBlockSizeAdjustSubB", "mstValue": "-0.024500"},
    {"constType": 5, "mstKey": "saBlockSizeAdjustSubC", "mstValue": "0.416900"},
    {"constType": 5, "mstKey": "scoreAdjustNumA", "mstValue": "11.223000"},
    {"constType": 5, "mstKey": "scoreAdjustNumB", "mstValue": "0.047700"},
    {"constType": 5, "mstKey": "skillGaugeIncrementSize1", "mstValue": "0.100000"},
    {"constType": 5, "mstKey": "skillGaugeIncrementSize2", "mstValue": "1.200000"},
    {"constType": 5, "mstKey": "skillGaugeIncrementSize3", "mstValue": "2.400000"},
]

# ============================================================================
# 設定(価格・回数の上限・アプリ版)
# ============================================================================

# main.py と同じ設定ファイルを共有する(置き場所を増やさない)。
CONFIG_FILE = data_path("config.json")
PRICES_FILE = data_path("puni_prices.json")

# ステージ周回の1周あたりの単価(合計 = 単価 × 周回数)。管理者パネルの0円の動作確認でしか使わない。
DEFAULT_PRICE = int(os.getenv("PUNI_DEFAULT_PRICE", "300"))
# メイン/イベント進行の既定価格。進めるステージ数に関わらず1回いくら。
DEFAULT_MAIN_PRICE = int(os.getenv("PUNI_DEFAULT_MAIN_PRICE", "500"))
DEFAULT_EVENT_PRICE = int(os.getenv("PUNI_DEFAULT_EVENT_PRICE", "500"))
DEFAULT_BOSS_PRICE = int(os.getenv("PUNI_DEFAULT_BOSS_PRICE", "500"))
DEFAULT_BOSS_MAX_PRICE = int(os.getenv("PUNI_DEFAULT_BOSS_MAX_PRICE", "1000"))

# 注文の種類。
KIND_FARM = "farm"     # ステージ周回(ID指定・回数指定・1周いくら)
KIND_MAIN = "main"     # メインステージ進行(現在地から何ステージまで・1件いくら)
KIND_EVENT = "event"   # イベントステージ進行(現在地から何ステージまで・1件いくら)
KIND_BOSS = "boss"     # 強敵取得(強敵の妖怪を1体取得できるまで挑戦・1件いくら)
KIND_BOSS_MAX = "boss_max"   # 強敵完凸(強敵の妖怪が完凸するまで挑戦し続ける・1件いくら)
# 強敵に挑戦する種類(ステージの決め方・ロックの扱い・進め方は同じ。違うのは止めどころ)。
BOSS_KINDS = (KIND_BOSS, KIND_BOSS_MAX)
# 1回の注文で回せる周回数の上限。3000周までにする(1周 約20秒＋休憩で約18時間)。
DEFAULT_MAX_ROUNDS = int(os.getenv("PUNI_MAX_ROUNDS", "3000"))
# 強敵取得で挑戦する回数の上限。取得できるまで回すのが本筋だが、ドロップ率が低いときに
# 人魂の買い足しでワイマネーを使い切らないための保険(1回 約20秒なので約1時間半)。
BOSS_MAX_TRIES = int(os.getenv("PUNI_BOSS_MAX_TRIES", "300"))
# 限界突破の上限(ゲームの表示で「+10MAX」)。ここに届いたら、もう1体取って確かめずに
# 完凸として終える。上限がこれより低い妖怪は、取っても段階が上がらないことで分かる。
LIMIT_MAX_LEVEL = int(os.getenv("PUNI_LIMIT_MAX", "10"))

# 強敵ステージごとに、そこで取れる強敵の妖怪のID {stageId: youkaiId}。
#
# 強敵完凸は「すでに持っている強敵の妖怪を完凸させる」メニューなので、持っていない垢は
# 挑戦する前に断りたい。ところが、どの強敵ステージでどの妖怪が取れるかは、戦って
# 取れるまで分からない(gameStart の敵の欄にIDらしきものはあるが、取れる妖怪と同じかは
# 確かめていない)。そこで、強敵取得・強敵完凸で実際に取れた妖怪を覚えておく(gameEnd の
# youkai / rewardYoukaiId。実機で確かめた欄)。強敵取得はお客さんが毎日使っているので、
# 今のイベントの強敵はすぐ埋まる。
BOSS_YOUKAI_FILE = data_path("puni_boss_youkai.json")


def boss_youkai_for(stage_id):
    """その強敵ステージで取れる妖怪のID(覚えていなければ None)。"""
    try:
        value = read_json(BOSS_YOUKAI_FILE, {}).get(str(int(stage_id)))
        return int(value) if value else None
    except (TypeError, ValueError, AttributeError):
        return None


def remember_boss_youkai(stage_id, youkai_id) -> None:
    """強敵ステージで実際に取れた妖怪を覚える。書けなくても代行は止めない。"""
    try:
        stage, youkai = str(int(stage_id)), int(youkai_id)
        data = read_json(BOSS_YOUKAI_FILE, {})
        if not isinstance(data, dict):
            data = {}
        if data.get(stage) == youkai:
            return
        data[stage] = youkai
        write_json(BOSS_YOUKAI_FILE, data)
    except Exception as e:
        print(f"[PUNI] 強敵の妖怪を覚えられませんでした: {type(e).__name__}: {e}", flush=True)


# 上限として許す最大値(コマンドでこれ以上には設定させない)。
MAX_ROUNDS_CAP = int(os.getenv("PUNI_MAX_ROUNDS_CAP", "3000"))
# 連続で何回失敗したら打ち切るか。スタミナ切れ等でずっと空振りするのを止める。
MAX_CONSECUTIVE_FAILS = int(os.getenv("PUNI_MAX_FAILS", "3"))

# --- 人魂(スタミナ)の自動購入 --------------------------------------------
#
# 周回で人魂が尽きると gameStart が rc=5 で弾かれる(＝スタミナ切れ)。人魂は
# ワイマネー(ymoney。周回で貯まるゲーム内通貨)で買い足せるので、切れたら自動で
# 補充して周回を続ける。※課金通貨(ルビー)や現金は使わない。ワイマネーが
# 足りなくなったら止めて知らせる。
AUTO_BUY_HITODAMA = os.getenv("PUNI_AUTO_BUY_HITODAMA", "1") not in ("0", "false", "False")
# 買い足しに使う goodsId の候補。安い順に並べる(先に成功したもので確定)。
# ※ 必ず「ワイマネー建て」の goodsId だけを並べること。課金通貨(ルビー)建てを
#   混ぜると現金/課金石を使ってしまう。
# 実機の通信(iPhone で人魂こうかん ×5 を買ったときの buyHitodama.nhn)で確認した本物の形:
#   本文は共通の欄(call の base) ＋ goodsId だけ。×5(1000ワイマネー) は goodsId=1001。
#   応答は resultCode 0、before/after(人魂の数)、ywp_user_data(残高込み)。
# 既定は 1001。
def _parse_goods_ids(raw: str) -> list:
    return [int(x) for x in str(raw).replace(",", " ").split()
            if x.strip().lstrip("-").isdigit()]

HITODAMA_GOODS_IDS = _parse_goods_ids(os.getenv("PUNI_HITODAMA_GOODS_IDS", "1001"))
# 設定の候補で買えなかったとき(原因を詰めるとき=PROBE だけ)、goodsId を順に当たって
# 「上限内で買える一番手前のパック」を探す。人魂こうかんはワイマネー建てオンリー
# (現金・課金石は動かない)と確認済みなので安全。見つけたら次回のため設定に覚える。
# ID は 1001 から並ぶ(×5=1001。×20/×50 は隣の番号のはず)ので範囲は 1000〜1004。
HITODAMA_AUTO_DISCOVER = os.getenv("PUNI_HITODAMA_AUTO_DISCOVER", "1") not in ("0", "false", "False")
HITODAMA_DISCOVER_MIN = int(os.getenv("PUNI_HITODAMA_DISCOVER_MIN", "1000"))
HITODAMA_DISCOVER_MAX = int(os.getenv("PUNI_HITODAMA_DISCOVER_MAX", "1004"))
# 1回の人魂購入で使ってよいワイマネーの上限。これを超えるパック(×20=3000, ×50=6000
# など)は「買いすぎ」なので使わない。いちばん安い ×5(=1000ワイマネー) だけで
# 買い足していく。超えた買い物は覚えない(繰り返さない)。
HITODAMA_MAX_PRICE = int(os.getenv("PUNI_HITODAMA_MAX_PRICE", "1000"))
# 普段の注文では、確定した形(goodsId=1001)だけを投げて、外れたら止める(失敗の嵐を投げ
# ない)。原因を詰めるときだけ、残りの探索(販売の一覧・店の一覧・goodsId の順当たり)を順に
# 投げる。admin が /puni の検証で使う想定。
HITODAMA_PROBE = os.getenv("PUNI_HITODAMA_PROBE", "0") in ("1", "true", "True")
# 人魂を買い足す回数に上限は無い。注文が終わるまで買う(止まるのはワイマネーが
# 足りないときと、買った直後にまた rc=5 になったとき)。
# スタミナ切れを表す resultCode。
STAMINA_RC = int(os.getenv("PUNI_STAMINA_RC", "5"))
# 「ロック(未開放)のステージに入ろうとした」ことを表す内部用の疑似コード。
# サーバはロックのステージにも rc=5 を返すことがあり、そのままだと「スタミナ切れ」と
# 誤認して(実際は人魂があるのに)購入を試みて止まってしまう。人魂が残っているのに
# rc=5 が返った=スタミナではなくロック、と判断してこのコードに置き換える。実サーバの
# コードとぶつからない負値にしておく。
STAGE_LOCKED_RC = -100

# rc の意味(配布界隈の実測)。用途で分けて使う:
#   ・STAGE_END_RC … そのステージが無い/ブロック終端。イベント自動進行で「次の
#     ブロックへジャンプ」の合図にする(101 は通常周回では「バージョン古い」だが、
#     イベント進行の文脈ではブロック終端として使われている)。
#   ・TRANSIENT_RC … 一時的な失敗。少し待って再試行すれば通ることがある。
# ステージ終端(「その先のステージが無い」)としてブロック送りにする resultCode。
# 1311 は実測(イベント299): 存在しない会場の頭(29912001)で返った。以前はどこにも無い
# コードで「想定外のエラー」として注文ごと中止していた。
STAGE_END_RC = (1303, 101, 102, 1311)
# 「そのステージは今は入れない(未開放)」の resultCode。実測(イベント299): 29903004/005 は
# ステージ表に state=0 で載っていて 508、同じ会場の 006 は通った(裏マップは入れば順に開く
# ので、004/005 は隠しステージなどの別枠らしい)。終端と違って会場がそこで終わりとは限らない
# ので、進行では同じ会場の次の番号を続けて試し、先が通ったら1回だけやり直す。rc=5 が
# ロックだったとき(STAGE_LOCKED_RC)と、強敵(rc=100)も「その番号は飛ばして次へ」は同じ。
STAGE_CLOSED_RC = (508,)
# 同じ会場で、入れないステージ(508/ロック/強敵)が何個続いたら「会場の終わり」と見るか。
# 実測(イベント299 会場3): 004:508 → 005:508 → 006:OK → 007:強敵 → 008 以降は未確認。
# 強敵のあとで会場を替えてしまうと、強敵の先にある通常ステージ(裏 1-5 など)に届かない。
MISS_RUN_LIMIT = int(os.getenv("PUNI_MISS_RUN", "3"))
TRANSIENT_RC = (4,)
# rc=4(一時エラー)の扱い。BAN(rc=202)になった周回の記録では、10周目からほぼ毎周 rc=4 が
# 出て 22周目で 202 だった。rc=4 はサーバの「叩きすぎ」の警告と見て、
#   ・1回目/2回目/3回目は RETRY_WAITS(±30%)だけ空けてやり直す(4/8/16秒から延ばした)
#   ・RC4_WINDOW_SECONDS の間に RC4_REST_COUNT 回出たら、さらに RC4_REST_* 秒の長い休み
#   ・RC4_STOP_COUNT 回出たら中止する(垢を守る。時間をおいて注文し直してもらう)
# 窓は 30分。待ち(20〜90秒)と長い休み(3〜5分)を足すと、4回目以降は1回ごとに 5分前後
# 空くので、10分の窓では中止の回数(7回)に届く前に古い分が窓から抜けてしまい、
# 「rc=4 が出続けているのに止まらない」形になっていた。
RETRY_WAITS = (20.0, 45.0, 90.0)
RC4_WINDOW_SECONDS = float(os.getenv("PUNI_RC4_WINDOW", "1800"))
RC4_REST_COUNT = int(os.getenv("PUNI_RC4_REST_COUNT", "4"))
RC4_REST_MIN = float(os.getenv("PUNI_RC4_REST_MIN", "180"))
RC4_REST_MAX = float(os.getenv("PUNI_RC4_REST_MAX", "300"))
RC4_STOP_COUNT = int(os.getenv("PUNI_RC4_STOP_COUNT", "7"))
# 「rc=4 が続いたので中止」を進行(_battle_with_retry)から呼び出し側へ伝える内部用の疑似コード。
TRANSIENT_STOP_RC = -101
# 「停止ボタンが押された(または一時停止)」を進行(_battle_with_retry)から呼び出し側へ伝える
# 内部用の疑似コード。どちらだったかは呼び出し側が PuniRunner._halt_text で見分ける。
STOP_RC = -102
# 停止ボタンで止めたときの説明(お客さんのDMにそのまま出る)。
STOP_TEXT = "停止ボタンで停止しました（ここまでの結果で終了）"
# bot の更新(再デプロイ・再起動)で、今の周を終えたところで抜けたときの説明。注文は終わって
# いない(結果の DM・売上は出さない)。Cog が途中経過(checkpoint)から新しいプロセスで続きを流す。
SUSPEND_TEXT = "bot の更新のため一時停止しました（再起動後に続きから再開します）"
# 進行(ステージ進行・イベント自動進行)で処理する最大ステージ数。暴走の保険。
PROGRESS_MAX = int(os.getenv("PUNI_PROGRESS_MAX", "500"))
# イベント進行で、ブロック(会場)の頭に続けて何個入れなかったら「もう先が無い」と見るか。
# 表→裏のマップは会場01, 02, 03… と続き番号で並ぶ(実測: イベント299 は表=01/02、
# 裏=03。297 は裏=04)。離れた番号の会場は GTオイル給油所(299 の会場11)のような別マップで、
# イベント進行では触らない(お客さんが頼んだのは表・裏のステージ)。だから遠くまで探さず、
# 強敵(rc=100)の会場を1〜2個またぐぶんだけ見る。開始位置そのものが無いステージ(クリア済みの
# 最大+1 が終端)だったときも1個に数える。
EMPTY_BLOCKS_LIMIT = int(os.getenv("PUNI_EMPTY_BLOCKS", "3"))
# イベントステージとみなす下限ID。メイン(7桁,〜1999999)・サブ(5xxxxxx)・強敵/夜叉
# (28xx/29xx台)は7桁で、イベントは8桁(例 29701001, 90020000)。この値以上を
# イベント扱いにして、垢のクリア済みから「今どのイベントを進めるべきか」を自動判定する。
EVENT_ID_MIN = int(os.getenv("PUNI_EVENT_ID_MIN", "10000000"))
# メインストーリーのステージIDの範囲。1章(100x台)・2章以降(19xx台)を含む。
# サブ(5xxxxxx)や強敵/夜叉(28/29xx)より小さい7桁に収まる。
MAIN_ID_MIN = int(os.getenv("PUNI_MAIN_ID_MIN", "1000000"))
MAIN_ID_MAX = int(os.getenv("PUNI_MAIN_ID_MAX", "2000000"))


def next_block_start(current_id: int) -> int:
    """次の「ブロック(千の位のまとまり)」の1ステ目を返す。

    ステージIDは <エリア/ブロック><ステージ(下3桁)> の形。千の位のまとまりを
    1つ進めて下3桁を001に戻す(例: 29701045 → 29702001, 1009016 → 1010001)。
    算術で出すので 9→10 の桁上がりも正しく扱える(文字列の1桁いじりだと壊れる)。
    """
    n = int(current_id)
    if n < 1000:
        return n + 1
    return (n // 1000 + 1) * 1000 + 1

# --- BAN対策 ---------------------------------------------------------------
#
# 足がつく原因は2つ。「毎回まったく同じ結果を送る」ことと「人間には無理な速さで
# 叩き続ける」こと。前者は結果の数値を1プレイずつ散らして防ぐ。後者は1周にかける
# 時間で決まる。
#
# 【実測】元になった別bot(ywp_panel)の値は request_delay 4.5〜6秒 → gameStart → プレイ
# 8〜10秒 → gameEnd → cooldown 4.5〜6秒、つまり 1周 約19〜22秒。これで100周エラー無し。
# 以前このコメントは「5秒+5秒=10秒/周で安全」と読み違えていて(プレイ時間を数えて
# いなかった)、それを信じて 10〜12秒/周まで詰めた結果、22周目で rc=202(BAN)になった
# (10周目からほぼ毎周 rc=4 が出ていた)。12〜16秒/周では 70プレイほど無事だった。
# 既定は実証済みの別botと同じ 18〜22秒/周に置く。PUNI_ROUND_SECONDS_MIN/MAX で変えられるが、
# これより短くして BAN になった実績がある。
ROUND_SECONDS_MIN = float(os.getenv("PUNI_ROUND_SECONDS_MIN", "20"))
ROUND_SECONDS_MAX = float(os.getenv("PUNI_ROUND_SECONDS_MAX", "26"))
# 申告するクリア秒数(clearTimeSec)の幅。別botは 8〜10秒で100周無事、実機の人は 18〜21秒。
# 実機では gameEnd はクリアの瞬間ではなく、リザルトの演出が終わってから飛ぶ
# (復号したセッション: clearTimeSec 18〜21 に対して gameStart→gameEnd は 31〜34秒、
# つまりクリア秒数 + 13秒ほど)。bot がクリア秒数ちょうどで gameEnd を送ると
# 「演出の時間が 0 秒」という実機に無い形になるので、クリア秒数に END_LAG_* 秒の
# 演出待ちを足してから送る。申告クリア秒数は必ず実際の待ちより短くする
# (「かかった時間より長くプレイした」不整合を作らない)。残りは周と周のあいだの休み
# (リザルト画面〜マップ〜ステージ選択)で、REST_SECONDS_MIN より短くはしない。
MIN_CLEAR_SEC = int(os.getenv("PUNI_MIN_CLEAR_SEC", "8"))
MAX_CLEAR_SEC = int(os.getenv("PUNI_MAX_CLEAR_SEC", "11"))
END_LAG_MIN = float(os.getenv("PUNI_END_LAG_MIN", "3"))
END_LAG_MAX = float(os.getenv("PUNI_END_LAG_MAX", "6"))
REST_SECONDS_MIN = float(os.getenv("PUNI_REST_SECONDS_MIN", "5"))
# 実機の1プレイは gameStart / gameEnd だけではない(復号したセッションで確認):
#   getL5IdStatus(マップ) → 2〜3秒 → userStageRanking(ステージをタップ・stageId付き)
#   → 約1秒 → gameStart → プレイ → gameEnd → リザルト画面 10〜16秒 → getL5IdStatus(マップへ)
# botが gameStart / gameEnd だけを送り続けると、それ自体が目印になる。周と周のあいだの
# 休みの中で同じ順番・同じ間隔で送る(_rest / _before_start)。0 で止められる。
MIMIC_MAP_FLOW = os.getenv("PUNI_MIMIC_MAP_FLOW", "1") not in ("0", "false", "False")
# 人は毎周同じ速さでは回さない。この割合の周は「ゆっくりな周」(結果画面を眺めた、
# 広告が出た、通知を見た)として、合計時間を SLOW_ROUND_FACTOR の倍率で伸ばす。
SLOW_ROUND_RATE = float(os.getenv("PUNI_SLOW_ROUND_RATE", "0.12"))
SLOW_ROUND_FACTOR = (float(os.getenv("PUNI_SLOW_ROUND_FACTOR_MIN", "1.4")),
                     float(os.getenv("PUNI_SLOW_ROUND_FACTOR_MAX", "2.4")))
# 長い周回では時々ひと息入れる(1000周などの長丁場の保険)。
BREAK_EVERY_MIN = int(os.getenv("PUNI_BREAK_EVERY_MIN", "25"))
BREAK_EVERY_MAX = int(os.getenv("PUNI_BREAK_EVERY_MAX", "40"))
BREAK_SECONDS_MIN = float(os.getenv("PUNI_BREAK_SEC_MIN", "20"))
BREAK_SECONDS_MAX = float(os.getenv("PUNI_BREAK_SEC_MAX", "50"))
# さらに何百周かに一度は席を外すくらいの長い休み(1000周をぶっ通しで回す人はいない)。
# 別botは奇数時の29分に5分止めていた。ここでは 150〜260周(約1時間〜1時間半)ごとに 2〜5分。
LONG_BREAK_EVERY_MIN = int(os.getenv("PUNI_LONG_BREAK_EVERY_MIN", "150"))
LONG_BREAK_EVERY_MAX = int(os.getenv("PUNI_LONG_BREAK_EVERY_MAX", "260"))
LONG_BREAK_SECONDS_MIN = float(os.getenv("PUNI_LONG_BREAK_SEC_MIN", "120"))
LONG_BREAK_SECONDS_MAX = float(os.getenv("PUNI_LONG_BREAK_SEC_MAX", "300"))
# ログインしてから最初の gameStart までの間(タイトル→マップ→ステージ選択の時間)。
WARMUP_SECONDS_MIN = float(os.getenv("PUNI_WARMUP_MIN", "3"))
WARMUP_SECONDS_MAX = float(os.getenv("PUNI_WARMUP_MAX", "8"))
# 結果の数値の散らし幅。1プレイずつ変えて、同じログが並ばないようにする。
# 消した回数はクリア秒数から決める(1秒に 1.3〜2.4 回なぞる)。これは下限と上限。
ERASE_NUM_RANGE = (12, 60)      # 消した数
ERASE_PER_SEC_RANGE = (1.3, 2.4)
COMBO_MAX_RANGE = (3, 24)       # 最大コンボ(消した数の半分を超えない)
LINK_SIZE_RANGE = (3, 7)        # 最大リンク(実測 6, 7)
# ぷにの大きさの単位は実機の gameEnd に合わせる(復号した2プレイの実測):
#   ・妖怪ごとの eraseSize は「消した数 × 1.6〜3.0」(6/2, 18/9, 14/5, 11/4, 15/5, 18/8, 9/5, …)
#   ・全体の eraseSizeAve は Σ eraseSize ÷ eraseNumTotal(64÷25=2.56 → "2.56"、
#     66÷31=2.129 → "2.12"。切り捨てで2桁)。妖怪ごとの値から計算する。
#   ・全体の eraseSizeMax / linkSizeMax は妖怪ごとの最大値(7=max(5,4,6,4,7)、10=max(10,4,3,4,6))
#   ・妖怪ごとの damageMax は damageTotal の 0.33〜0.95 倍
ERASE_SIZE_RATIO_RANGE = (1.6, 3.0)    # 妖怪ごとの eraseSize ÷ eraseNum
ERASE_SIZE_MAX_RANGE = (4, 10)         # いちばん大きく育てたぷに(実測 7, 10)
DAMAGE_MAX_RATIO_RANGE = (0.33, 0.95)  # 妖怪ごとの damageMax ÷ damageTotal
SCORE_PER_DAMAGE_RANGE = (14.0, 22.0)  # ダメージあたりのスコア(実測 15.4〜19.2)


def _round_timing() -> tuple:
    """1周の時間配分を決める。戻り値 (プレイ秒, 休み秒, 申告クリア秒)。

    申告クリア秒を MIN_CLEAR_SEC〜MAX_CLEAR_SEC で振り、それに演出待ち(END_LAG_*)を
    足したものをプレイ(=gameStart→gameEnd の間)にする。合計を ROUND_SECONDS_MIN〜MAX
    で振り、残りを周間の休みに充てる(REST_SECONDS_MIN より短くしない)。たまに
    「ゆっくりな周」を混ぜて、間隔がきれいな一様分布にならないようにする。
    """
    total = random.uniform(ROUND_SECONDS_MIN, ROUND_SECONDS_MAX)
    if random.random() < SLOW_ROUND_RATE:
        total *= random.uniform(*SLOW_ROUND_FACTOR)
    clear = random.randint(MIN_CLEAR_SEC, max(MIN_CLEAR_SEC, MAX_CLEAR_SEC))
    play = clear + random.uniform(END_LAG_MIN, END_LAG_MAX)
    rest = max(REST_SECONDS_MIN, total - play)
    return play, rest, clear


def _split(total: int, weights: list) -> list:
    """total を weights の比で整数に分ける。端数は一番大きい枠に寄せて合計を保つ。"""
    if not weights:
        return []
    s = float(sum(weights)) or 1.0
    parts = [int(total * w / s) for w in weights]
    parts[max(range(len(parts)), key=lambda i: weights[i])] += total - sum(parts)
    return parts

# --- ゲームバージョンの自動追従 -------------------------------------------
#
# ぷにぷにが更新されると古いアプリ版では rc=20 / rc=101 で丸ごと弾かれる。
# ツムツム代行と同じく、App Store の最新版を定期的に見て自動で切り替える。
# 引くのはバンドルID(アプリ本体の識別子。変わらない)を主にして、数値IDは保険。
# 数値IDを推測で決めていたら取得できていなかったので、バンドルIDを正とする。
PUNI_BUNDLE_ID = os.getenv("PUNI_BUNDLE_ID", "com.Level5.YWP")
PUNI_APPSTORE_ID = os.getenv("PUNI_APPSTORE_ID", "1032346221")  # 妖怪ウォッチ ぷにぷに
VERSION_CHECK_INTERVAL_HOURS = float(os.getenv("PUNI_VERSION_CHECK_HOURS", "6"))
# バージョンが古くて弾かれたことを表す resultCode。ここに当たったら即チェックする。
STALE_VERSION_RC = (20, 101)


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


def _save_config(cfg: dict):
    write_json(CONFIG_FILE, cfg)


def get_app_version() -> str:
    """使うアプリ版。設定 → 起動時の既定。"""
    return str(_config().get("puni_app_version") or DEFAULT_APP_VER)


def set_app_version(version: str):
    cfg = _config()
    cfg["puni_app_version"] = str(version)
    _save_config(cfg)


def get_hitodama_goods_ids() -> list:
    """人魂の買い足しに使う goodsId(安い順)。設定 → 起動時の既定。

    ※ 必ずワイマネー建ての goodsId だけ。課金通貨(ルビー)建てを混ぜないこと。
    """
    v = _config().get("puni_hitodama_goods_ids")
    if isinstance(v, list) and v:
        try:
            return [int(x) for x in v]
        except (TypeError, ValueError):
            pass
    return list(HITODAMA_GOODS_IDS)


def set_hitodama_goods_ids(ids: list):
    cfg = _config()
    cfg["puni_hitodama_goods_ids"] = [int(x) for x in ids]
    _save_config(cfg)


def get_proxy() -> str:
    return (os.getenv("PUNI_PROXY", "") or "").strip()


def _proxies():
    url = get_proxy()
    return {"http": url, "https": url} if url else None


# アカウントごとの udkey(端末キー)の覚え。
#
# 以前は注文のたびに「新しい udkey を作って L5 にメール/パスを紐づける」をして
# いた。同じ出口(IP)から短時間に何十台も新しい端末が湧いて、そのたびに連携が
# 走る形で、不正検知が一番嫌う足取り。実測でも、そのあと init.nhn から HTTP 500
# で拒まれるようになった。
# アカウント(メール)ごとに udkey と userId を覚えておき、次からはそれで入る。
# 連携そのものを省くので、反映待ち(getGdkeyAccounts に載るまで)も無くなる。
# 覚えるのは udkey と userId、それにパスワードの「照合用のハッシュ」(鍵はメールの
# ハッシュ。メール/パスそのものは覚えない)。覚えている udkey で入るときは、入力された
# パスワードがこのハッシュと合うときだけにする。合わなければ L5 の連携(そこで本物の
# パスワード確認が行われる)からやり直す。これが無いと、メールアドレスさえ知っていれば
# パスワード無しで他人の垢の代行を注文できてしまう。
# 使えなくなっていたら(紐づけの解除・別の垢)、忘れて連携からやり直す。
UDKEY_FILE = data_path("puni_udkeys.json")
REMEMBER_UDKEY = os.getenv("PUNI_REMEMBER_UDKEY", "1") not in ("0", "false", "False")
UDKEY_TTL_DAYS = float(os.getenv("PUNI_UDKEY_TTL_DAYS", "30"))
_PW_ITERATIONS = 200_000


def _account_key(email: str) -> str:
    return hashlib.sha256((email or "").strip().lower().encode("utf-8")).hexdigest()[:32]


def _password_digest(password: str, salt_hex: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                               bytes.fromhex(salt_hex), _PW_ITERATIONS).hex()


def recall_udkey(email: str, password: str = None):
    """覚えている (udkey, userId)。無い・古い・止めているときは None。

    password を渡したときは、覚えたときのパスワードと照合して、合うときだけ返す
    (照合用のハッシュを覚えていない古い記録も None。連携からやり直して覚え直す)。
    """
    if not REMEMBER_UDKEY:
        return None
    rec = read_json(UDKEY_FILE, {}).get(_account_key(email))
    if not isinstance(rec, dict) or not rec.get("udkey"):
        return None
    try:
        if time.time() - float(rec.get("at") or 0) > UDKEY_TTL_DAYS * 86400:
            return None
    except (TypeError, ValueError):
        return None
    if password is not None:
        salt, digest = rec.get("salt"), rec.get("pw")
        if not salt or not digest:
            return None
        try:
            if not hmac.compare_digest(_password_digest(password, str(salt)), str(digest)):
                return None
        except ValueError:
            return None
    return str(rec["udkey"]), rec.get("user_id")


def remember_udkey(email: str, udkey: str, user_id, password: str = None, *,
                   keep_at: bool = False):
    """udkey と userId を覚える。password を渡すと照合用のハッシュも作り直す
    (渡さなければ、前に覚えたハッシュをそのまま引き継ぐ)。

    keep_at=True は覚えの期限(at)を延ばさない。覚えた udkey で入るたびに期限を延ばすと、
    L5 側でパスワードを変えた後も古いパスワードで覚えが使え続ける(照合用ハッシュは
    L5 で確かめ直せない)。連携したとき(本物のパスワード確認を通ったとき)だけ期限を
    引き直し、UDKEY_TTL_DAYS ごとに必ず連携をやり直す。
    """
    if not REMEMBER_UDKEY or not udkey:
        return
    data = read_json(UDKEY_FILE, {})
    key = _account_key(email)
    old = data.get(key) if isinstance(data.get(key), dict) else {}
    same_udkey = old.get("udkey") == str(udkey)
    # userId と照合用ハッシュは、同じ udkey の覚えからだけ引き継ぐ(別の udkey の userId を
    # 持ち越すと、次の login で「指定のアカウントが見つかりません」になって入り直しが要る)。
    rec = {"udkey": str(udkey),
           "user_id": user_id if user_id is not None else (old.get("user_id") if same_udkey else None),
           "at": (old.get("at") or time.time()) if (keep_at and same_udkey) else time.time()}
    if password is not None:
        rec["salt"] = os.urandom(16).hex()
        rec["pw"] = _password_digest(password, rec["salt"])
    elif same_udkey and old.get("salt") and old.get("pw"):
        rec["salt"], rec["pw"] = old["salt"], old["pw"]
    data[key] = rec
    try:
        write_json(UDKEY_FILE, data)
    except Exception as e:
        print(f"[PUNI] udkey を保存できませんでした: {e}", flush=True)


def forget_udkey(email: str):
    data = read_json(UDKEY_FILE, {})
    if data.pop(_account_key(email), None) is not None:
        try:
            write_json(UDKEY_FILE, data)
        except Exception as e:
            print(f"[PUNI] udkey の覚えを消せませんでした: {e}", flush=True)


def version_tuple(v: str) -> tuple:
    parts = []
    for p in str(v).split("."):
        m = re.match(r"\d+", p.strip())
        parts.append(int(m.group()) if m else 0)
    return tuple(parts)


def is_newer_version(candidate: str, current: str) -> bool:
    a, b = version_tuple(candidate), version_tuple(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def looks_stale_rc(rc) -> bool:
    """その resultCode が「アプリ版が古い」を表すか。"""
    try:
        return int(rc) in STALE_VERSION_RC
    except (TypeError, ValueError):
        return False


def get_version_check_state() -> dict:
    return _config().get("puni_version_check", {}) or {}


def _record_version_check(latest, updated_from=None, updated_to=None):
    cfg = _config()
    st = cfg.setdefault("puni_version_check", {})
    st["last_checked_at"] = time.time()
    st["last_seen_latest"] = latest
    if updated_to:
        st["last_updated_at"] = time.time()
        st["last_updated_from"] = updated_from
        st["last_updated_to"] = updated_to
    _save_config(cfg)


def fetch_latest_app_version():
    """App Storeの最新バージョンを取る(ブロッキング/失敗時None)。

    バンドルID(変わらない)で引くのを主にする。数値IDは変わったり推測が外れたり
    するので保険。片方が取れなければもう片方を試す。
    """
    lookups = ({"bundleId": PUNI_BUNDLE_ID, "country": "jp"},
               {"id": PUNI_APPSTORE_ID, "country": "jp"})
    for params in lookups:
        try:
            r = requests.get("https://itunes.apple.com/lookup", params=params, timeout=15)
            j = r.json()
            if j.get("resultCount"):
                ver = j["results"][0].get("version")
                if ver:
                    return ver
        except Exception as e:
            print(f"[PUNI VERSION] 最新版の取得に失敗({params}): {e}", flush=True)
    return None


def check_and_update_app_version() -> dict:
    """最新版を見て、今より新しければ切り替える(ブロッキング)。

    戻り値 {"latest","current","updated","before"}。latest が None なら取得失敗。
    古いほうへは下げない(手で新しめに寄せた設定を尊重する)。
    """
    current = get_app_version()
    latest = fetch_latest_app_version()
    if not latest:
        return {"latest": None, "current": current, "updated": False, "before": current}
    if is_newer_version(latest, current):
        set_app_version(latest)
        _record_version_check(latest, updated_from=current, updated_to=latest)
        print(f"[PUNI VERSION] {current} -> {latest} へ自動更新", flush=True)
        return {"latest": latest, "current": latest, "updated": True, "before": current}
    _record_version_check(latest)
    return {"latest": latest, "current": current, "updated": False, "before": current}


def load_prices() -> dict:
    return read_json(PRICES_FILE, {})


def save_prices(data: dict):
    write_json(PRICES_FILE, data)


def get_price() -> int:
    """ステージ周回の1周あたりの単価(合計=単価×周回数)。"""
    value = load_prices().get("stage")
    try:
        return max(0, int(value)) if value is not None else DEFAULT_PRICE
    except (TypeError, ValueError):
        return DEFAULT_PRICE


def _flat_price(key: str, default: int) -> int:
    value = load_prices().get(key)
    try:
        return max(0, int(value)) if value is not None else default
    except (TypeError, ValueError):
        return default


def get_main_price() -> int:
    """メインステージ進行の価格(進めるステージ数に関わらず1件いくら)。"""
    return _flat_price("main_progress", DEFAULT_MAIN_PRICE)


def set_main_price(price: int):
    prices = load_prices()
    prices["main_progress"] = max(0, int(price))
    save_prices(prices)


def get_event_price() -> int:
    """イベントステージ進行の価格(進めるステージ数に関わらず1件いくら)。"""
    return _flat_price("event_progress", DEFAULT_EVENT_PRICE)


def set_event_price(price: int):
    prices = load_prices()
    prices["event_progress"] = max(0, int(price))
    save_prices(prices)


def get_boss_price() -> int:
    """強敵取得の価格(1件いくら。取得できるまで挑戦する分の代金)。"""
    return _flat_price("boss_get", DEFAULT_BOSS_PRICE)


def set_boss_price(price: int):
    prices = load_prices()
    prices["boss_get"] = max(0, int(price))
    save_prices(prices)


def get_boss_max_price() -> int:
    """強敵完凸の価格(1件いくら。完凸するまで挑戦する分の代金)。"""
    return _flat_price("boss_max", DEFAULT_BOSS_MAX_PRICE)


def set_boss_max_price(price: int):
    prices = load_prices()
    prices["boss_max"] = max(0, int(price))
    save_prices(prices)


def price_for(kind: str, rounds: int = 0, count: int = 0) -> int:
    """種類ごとの合計金額。周回は単価×回数、進行と強敵(取得・完凸)は1件いくら。"""
    if kind == KIND_FARM:
        return get_price() * max(0, int(rounds))
    if kind == KIND_MAIN:
        return get_main_price()
    if kind == KIND_EVENT:
        return get_event_price()
    if kind == KIND_BOSS:
        return get_boss_price()
    if kind == KIND_BOSS_MAX:
        return get_boss_max_price()
    return 0


def get_max_rounds() -> int:
    value = load_prices().get("max_rounds")
    try:
        return max(1, min(int(value), MAX_ROUNDS_CAP)) if value else DEFAULT_MAX_ROUNDS
    except (TypeError, ValueError):
        return DEFAULT_MAX_ROUNDS


def summary(stage_id, rounds) -> str:
    """注文の要約(見張りの一覧やDMに出す短い1行)。周回用。

    ステージはログイン後に決まるので、決まる前(0)は「未確定」と出す。
    """
    if not stage_id:
        return f"{int(rounds):,}周（ステージはログイン後に自動で決定）"
    return f"ステージ{puni_stages.describe(stage_id)} を {int(rounds):,}周"


def kind_label(kind: str) -> str:
    return {KIND_FARM: "ステージ周回", KIND_MAIN: "メインステージ進行",
            KIND_EVENT: "イベントステージ進行",
            KIND_BOSS: "強敵取得", KIND_BOSS_MAX: "強敵完凸"}.get(kind, "ぷにぷに代行")


def summary_for(kind: str, *, stage_id=0, rounds=0, count=0) -> str:
    """種類ごとの注文要約(1行)。"""
    if kind == KIND_FARM:
        return summary(stage_id, rounds)
    if kind == KIND_EVENT and not int(count or 0):
        # 数を指定しない = 今のイベントを現在地から最後(裏ステージまで)まで。
        return f"{kind_label(kind)}（現在地から最後まで）"
    if kind in (KIND_MAIN, KIND_EVENT):
        return f"{kind_label(kind)} {int(count):,}ステージ"
    if kind in BOSS_KINDS:
        if stage_id:
            return f"{kind_label(kind)}（{puni_stages.describe(stage_id)}）"
        return f"{kind_label(kind)}（1体）" if kind == KIND_BOSS else kind_label(kind)
    return kind_label(kind)


# ============================================================================
# 売上
# ============================================================================

# ツムツム(tsum_sales.json)・にゃんこ(sales.json)とは商品体系が違うので、
# 混ぜない(混ぜると商品別の内訳が読めなくなる)。
SALES_FILE = data_path("puni_sales.json")


def load_sales() -> list:
    return read_json(SALES_FILE, [])


def record_sale(amount: int, user_id, stage_id=0, rounds=0, method: str = "paypay",
                tx_id: str = None, kind: str = KIND_FARM, count: int = 0):
    """実際に受け取った金額だけを1件記録する。

    kind で商品を分ける(周回=farm / メイン進行=main / イベント進行=event / 強敵取得=boss)。
    tx_id はログに出したのと同じ取引番号。売上とログを後から突き合わせる手がかり。
    """
    if int(amount or 0) <= 0:
        return
    data = load_sales()
    if tx_id and any(isinstance(e, dict) and str(e.get("tx_id")) == str(tx_id) for e in data):
        # 同じ取引は1回だけ(版を合わせて流し直したときなどに二重に数えない)。
        return
    entry = {"ts": time.time(), "amount": int(amount), "method": method,
             "user_id": str(user_id), "kind": kind}
    if kind == KIND_FARM:
        entry["stage_id"] = str(stage_id)
        entry["rounds"] = int(rounds)
    elif kind in BOSS_KINDS:
        entry["stage_id"] = str(stage_id)
    else:
        entry["count"] = int(count)
    if tx_id:
        entry["tx_id"] = str(tx_id)
    data.append(entry)
    write_json(SALES_FILE, data)


# ============================================================================
# 暗号化・復号化
# ============================================================================

def salt20(body):
    return hashlib.sha1(K + hashlib.sha1(K + b' ' + body).digest()).digest()


def enc(body):
    pt = salt20(body) + body
    p = 16 - len(pt) % 16
    pt += bytes([p]) * p
    return base64.urlsafe_b64encode(
        AES.new(AESK, AES.MODE_ECB).encrypt(pt)).decode().rstrip('=')


def dec(s):
    s = s.strip()
    ct = base64.urlsafe_b64decode(s + '=' * (-len(s) % 4))
    pt = AES.new(AESK, AES.MODE_ECB).decrypt(ct)
    rest = pt[20:]
    g = rest.find(b'\x1f\x8b')
    if g >= 0:
        try:
            return zlib.decompress(rest[g:], 47)
        except Exception:
            pass
    try:
        rest = rest[:-pt[-1]]
    except Exception:
        pass
    e = max(rest.rfind(b'}'), rest.rfind(b']'))
    return rest[:e + 1] if e >= 0 else rest


def jbody(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False).encode('utf-8')


# ============================================================================
# HTTP(アプリ版はそのつど設定から読む)
# ============================================================================

def _ua(app_ver: str, device: DeviceProfile = None) -> str:
    return (device or DeviceProfile()).user_agent(app_ver)


def _hdr(app_ver: str, device: DeviceProfile = None) -> dict:
    return {'Accept-Encoding': 'identity', 'User-Agent': _ua(app_ver, device),
            'Accept': 'application/json', 'Content-Type': 'application/json',
            'Connection': 'Keep-Alive'}


# --- ゲーム/L5 へ出るときの HTTP -------------------------------------------
#
# 素の requests は TLS(と HTTP/2)の指紋が OpenSSL/Python のままで、ゲーム側の
# 入口(WAF)から「本物のアプリではない」と見分けられて弾かれる(実測: 素の
# requests だと init.nhn が HTTP 500 のまま。出口の IP を替えても直らない)。
# ツムツム代行が LINE 側でしているのと同じく、curl_cffi で本物の端末の TLS/HTTP2
# 指紋になりすます。アプリは Android の okhttp なので Android の指紋に寄せる。
# HTTP のバージョンは固定しない(本物と同じく h2/1.1 を素直に交渉させる。1.1 に
# 固定すると Android の指紋と食い違ってかえって怪しくなる)。UA はアプリのもの
# (Dalvik…)をそのまま使う(暗号化した本文と揃える。ゲーム側の本処理はこれを見る)。
IMPERSONATE = os.getenv("PUNI_IMPERSONATE", "chrome131_android")
try:
    from curl_cffi import requests as _curl_requests
    from curl_cffi.requests import exceptions as _curl_exc
    _CURL_TIMEOUT = (_curl_exc.Timeout,)
    _CURL_CONN = (_curl_exc.ConnectionError, _curl_exc.ProxyError, _curl_exc.SSLError)
    _CURL_ANY = (_curl_exc.RequestException,)
    # 入っている curl_cffi がその指紋の名前を知らない(版が古い)ときは、知っている
    # Android の指紋 → chrome の順に落とす。知らない名前のままだと毎回 ImpersonateError。
    try:
        from curl_cffi.requests.impersonate import BrowserType as _BrowserType
        _known = {b.name for b in _BrowserType}
        if IMPERSONATE not in _known:
            _fallback = next((n for n in ("chrome131_android", "chrome99_android", "chrome")
                              if n in _known), "chrome")
            print(f"[PUNI] curl_cffi は指紋 {IMPERSONATE!r} を知らないので {_fallback!r} にします",
                  flush=True)
            IMPERSONATE = _fallback
    except Exception:
        pass
except Exception:                       # 入っていない環境では素の requests に戻る
    _curl_requests = None
    _CURL_TIMEOUT = _CURL_CONN = _CURL_ANY = ()


def _impersonating() -> bool:
    return _curl_requests is not None and bool(IMPERSONATE)


# curl_cffi は指紋の「ブラウザ」に合わせて sec-ch-ua / Sec-Fetch-* / Accept-Language
# などのヘッダを勝手に足す。アプリ(okhttp)はそんなヘッダを送らないので、Dalvik の
# UA と食い違って目印になる。既定のヘッダは切り、こちらで渡すものだけを送る。
def _http_post(url, session=None, **kw):
    if session is not None:
        return session.post(url, **kw)
    if _impersonating():
        return _curl_requests.post(url, impersonate=IMPERSONATE, default_headers=False, **kw)
    return requests.post(url, **kw)


# ゲームサーバへの接続は垢(Client)ごとに使い回す。curl_cffi の post() は呼ぶたびに
# 新しい接続(TCP + TLS、プロキシ越しなら CONNECT も)を張り直すので、1周 4通信の
# それぞれに接続の手間が乗っていた。アプリ(okhttp)も接続を使い回す(keep-alive /
# HTTP/2)ので、使い回すほうが実機に近い。クッキーはアプリと同じく持たない
# (okhttp は既定でクッキーを保存しない)。0 で以前の「毎回つなぎ直す」に戻せる。
KEEP_ALIVE = os.getenv("PUNI_KEEP_ALIVE", "1") not in ("0", "false", "False")


def _new_http_session():
    """垢ごとに使い回す接続を作る。作れなければ None(毎回つなぎ直す)。"""
    if not (KEEP_ALIVE and _impersonating()):
        return None
    try:
        # use_thread_local_curl=False: 呼び出しはゲーム通信用のスレッド(_GAME_POOL)の
        # どれかで動き、スレッドは毎回変わるので、スレッドごとの接続にすると使い回しに
        # ならない。同じ垢の通信は1本ずつ順に流れる(Client._post のロック)ので、
        # 1つの接続を共有して良い。
        return _curl_requests.Session(impersonate=IMPERSONATE, default_headers=False,
                                      discard_cookies=True, use_thread_local_curl=False)
    except Exception as e:
        print(f"[PUNI] 接続の使い回しを作れないため毎回つなぎ直します"
              f"（{type(e).__name__}: {str(e)[:80]}）", flush=True)
        return None


def _http_get(url, **kw):
    if _impersonating():
        return _curl_requests.get(url, impersonate=IMPERSONATE, default_headers=False, **kw)
    return requests.get(url, **kw)


class PuniError(Exception):
    """ゲーム通信でのエラー(復号不可・HTTP異常など)。"""


class PuniGameTimeout(PuniError):
    """ゲーム通信が上限の秒数(BATTLE_TIMEOUT など)を過ぎても戻らなかった(PuniRunner._blocking)。

    走っているスレッドは外から止められないので、置き去りにする(pending_game_calls で追える)。
    固まったスレッドが同じ client(token)を握ったままなので、その client で通信を続けず、
    周回はそこで終えてそこまでの結果を返す(farm / hunt_boss / _progress が受け止める)。
    """

    def __init__(self, step: str = ""):
        super().__init__(f"ゲームのサーバから応答が戻らないため中止しました（{step}）")
        self.step = step


class PuniLoginError(Exception):
    """ログインできなかった(メール連携失敗・rc異常など)。

    やり直しても同じ結果になるものはこれにする。呼び出し側はお客さんに
    入れ直してもらう。
    """


class PuniServerError(PuniLoginError):
    """ログインの途中で、サーバに繋がらない/拒まれた(HTTP 5xx・403・タイムアウト等)。

    メール・パスワードの問題ではない。時間をおけば通ることが多いので、
    呼び出し側は「入れ直してください」ではなく「しばらく待って」と伝え、
    後追いのお渡しは注文を捨てずに次の巡回で流し直す。

    retry_ok=True は「少し待てば通る見込み」のもの(連携の反映待ち・rc=4 の一時エラー)。
    _open_with_retry はこれだけ数秒おいて入り直し、全体停止(note_server_refusal)は
    かけない(1回の rc=4 で全お客さんの代行を5分止めない)。
    """

    def __init__(self, message: str = "", retry_ok: bool = False):
        super().__init__(message)
        self.retry_ok = retry_ok


class PuniUdkeyError(PuniLoginError):
    """覚えていた udkey ではもう入れない(紐づけの解除・別の垢・ゲームデータ無し)。

    L5 もゲームサーバも普通に応えたうえで「この udkey には何も無い」と言っている
    ときだけ。login_with_email はこれのときだけ覚えを捨てて連携からやり直す
    (サーバの都合や BAN で捨てると、そのたびに新しい端末が湧いて目印になる)。
    """


class PuniStaleVersionError(PuniLoginError):
    """アプリ版/マスタ版が古くてログインを弾かれた(rc=20/101)。

    メール・パスワードの問題ではなく、覚えている udkey の問題でもない。版を
    合わせてからやり直す。
    """


class PuniAccountError(PuniLoginError):
    """この udkey(L5 アカウント)に、指定のゲームアカウント(userId)が無い。

    注文と違う L5 アカウントで入れ直した等。udkey そのものは生きていて、連携し直しても
    同じ結果になるので、覚えは捨てない(PuniUdkeyError とは別)。
    """


def post_nhn(name, obj, app_ver, timeout=30, retry=3, device: DeviceProfile = None,
             session=None):
    """ゲームサーバAPI(リトライ付き)。戻り値 (status_code, dict)。

    device はその垢が名乗る端末(User-Agent)。gameStart/gameEnd/購入は全体の
    送信間隔(_pace)にも乗せる。session はその垢で使い回す接続(無ければ毎回つなぐ)。
    """
    for attempt in range(1, retry + 1):
        try:
            _pace(name)
            r = _http_post('%s/%s' % (GS, name), session=session, data=enc(jbody(obj)),
                           headers={**_hdr(app_ver, device),
                                    'Host': 'gameserver.yw-p.com'},
                           timeout=timeout, proxies=_proxies())
            if r.status_code != 200:
                note_http_block(r.status_code)
                if attempt < retry:
                    time.sleep(2 ** attempt)
                    continue
                return r.status_code, {'resultCode': -1, '_error': f'HTTP{r.status_code}'}
            try:
                out = dec(r.text)
            except Exception:
                if attempt < retry:
                    time.sleep(2 ** attempt)
                    continue
                return r.status_code, {'resultCode': -1, '_raw': (r.text or '')[:200]}
            note_server_ok()
            try:
                return r.status_code, json.loads(out)
            except Exception:
                if attempt < retry:
                    time.sleep(2 ** attempt)
                    continue
                return r.status_code, {'_raw': out[:300].decode('utf-8', 'replace')}
        except (requests.exceptions.Timeout,) + _CURL_TIMEOUT:
            if attempt < retry:
                time.sleep(3 * attempt)
                continue
            return None, {'resultCode': -1, '_error': 'Timeout'}
        except (requests.exceptions.ConnectionError,) + _CURL_CONN:
            if attempt < retry:
                time.sleep(3 * attempt)
                continue
            return None, {'resultCode': -1, '_error': 'ConnectionError'}
        except _CURL_ANY as e:
            if attempt < retry:
                time.sleep(3 * attempt)
                continue
            return None, {'resultCode': -1, '_error': f'{type(e).__name__}: {str(e)[:80]}'}
    return None, {'resultCode': -1, '_error': 'Max retries exceeded'}


def active(app_ver, udkey=None, timeout=30, device: DeviceProfile = None):
    if device is None:
        device = device_for(udkey) if udkey else DeviceProfile()
    p = {'apkey': APKEY, 'device_cd': device.device_cd,
         'device_type_cd': 'Android', 'sign': 'true', 'version': app_ver}
    if udkey:
        p['udkey'] = udkey
    r = _http_get('%s/api/v1/active/' % L5, params=p,
                  headers={'User-Agent': _ua(app_ver, device)}, timeout=timeout,
                  proxies=_proxies())
    if r.status_code != 200:
        # L5 に拒まれた(5xx・403 など)。中身(HTML のエラー画面)を JSON として読んで
        # 落ちると「udkey が使えない」と誤認して連携をやり直してしまう。サーバの都合として返す。
        note_http_block(r.status_code)
        raise PuniServerError('L5 active: HTTP %s' % r.status_code)
    out = r.json()
    if not isinstance(out, dict):
        raise PuniServerError('L5 active: 応答が読めません')
    return out


def new_udkey(app_ver, timeout=30, device: DeviceProfile = None):
    """新しい udkey を作る。作るときに名乗った端末を、その udkey に紐づける。"""
    if device is None:
        device = DeviceProfile.random()
    udkey = active(app_ver, timeout=timeout, device=device)['udkey']['value']
    bind_device(udkey, device)
    return udkey


def _parse_forms(html):
    out = []
    for fm in re.finditer(r'<form\b[^>]*>(.*?)</form>', html, re.S | re.I):
        block = fm.group(0)
        am = re.search(r'action="([^"]*)"', block, re.I)
        inputs = {}
        for im in re.finditer(r'<input\b[^>]*>', block, re.I):
            nm = re.search(r'name="([^"]*)"', im.group(0), re.I)
            vm = re.search(r'value="([^"]*)"', im.group(0), re.I)
            if nm:
                inputs[nm.group(1)] = vm.group(1) if vm else ''
        out.append({'action': am.group(1) if am else '', 'inputs': inputs})
    return out


def link_email(app_ver, udkey, email, pw, timeout=25):
    """udkey にメール/パスを連携(L5 OAuth)。失敗は PuniLoginError。"""
    device = device_for(udkey)
    s = requests.Session()
    s.proxies = _proxies() or {}
    s.headers.update({'User-Agent': _ua(app_ver, device),
                      'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
                      'Accept-Language': 'ja'})
    r = s.get('%s/api/v1/link_account' % L5, params={'apkey': APKEY, 'udkey': udkey},
              allow_redirects=True, timeout=timeout)
    lf = [x for x in _parse_forms(r.text) if any('email' in k.lower() for k in x['inputs'])]
    if not lf:
        raise PuniLoginError('ログイン画面が出ませんでした(既に連携済み、またはメール不正)')
    inp = dict(lf[0]['inputs'])
    inp['form[email]'] = email
    inp['form[password]'] = pw
    r = s.post(urljoin(r.url, lf[0]['action']), data=inp, allow_redirects=True,
               timeout=timeout)
    ap = [x for x in _parse_forms(r.text)
          if 'client_id' in x['inputs'] and x['inputs'].get('_method', '') != 'delete']
    if not ap:
        raise PuniLoginError('認可画面が出ませんでした(メール/パスワードが違う可能性)')
    inp = dict(ap[0]['inputs'])
    inp.setdefault('commit', 'Authorize')
    r2 = s.post(urljoin(r.url, ap[0]['action']), data=inp, allow_redirects=False,
                timeout=timeout)
    code = (parse_qs(urlparse(r2.headers.get('Location', '')).query).get('code') or [None])[0]
    if not code:
        raise PuniLoginError('認可コードが取得できませんでした')
    fin = s.get('%s/api/v1/link_account' % L5,
                params={'code': code, 'apkey': APKEY, 'udkey': udkey,
                        'device_cd': device.device_cd, 'device_type_cd': 'Android'},
                timeout=timeout).json()
    if not fin.get('result'):
        raise PuniLoginError('連携の確定に失敗しました: %s' % str(fin)[:150])
    return fin


def rows(s):
    """セーブの行(行='*'、列='|')を配列にする。"""
    if isinstance(s, str):
        s = json.loads(s) if s.startswith('{') else s
    if isinstance(s, str):
        return [r.split('|') for r in s.split('*') if r]
    if isinstance(s, dict):
        return s.get('rows') or []
    return s or []


# ============================================================================
# ゲームクライアント
# ============================================================================

class Client:
    def __init__(self, udkey, app_ver=None):
        self.udkey = udkey
        self.app_ver = app_ver or get_app_version()
        self.device = device_for(udkey)     # この垢が名乗る端末(udkeyごとに固定)
        self.gdkey = None
        self.userId = None
        self.token = '0'
        self.mst = 16897
        self.save = {}
        self.active_deck_id = 1       # ゲームで選択中のデッキ番号(login の save から読む)
        self.init_raw = {}            # init.nhn の応答(マスタ版らしい欄を探すのに使う)
        self.last_bought_goods_id = None
        self.last_battle_type = None  # 直近の gameStart で使った battleType(強敵なら 6)
        self.last_fail_call = ''      # 直近の battle() で失敗した呼び出し('gameStart'/'gameEnd')
        self.last_drops = {"youkai": [], "items": []}   # 直近の周でもらった妖怪・アイテム
        self.last_start = {}          # 直近の gameStart の応答(味方・敵・抽選の欄)
        self.last_end = {}            # 直近の gameEnd の応答(妖怪の差分・チュートリアル一覧)
        self.last_lot_hit = False     # 直近の gameStart で妖怪の抽選が当たりだったか
        self.last_buy_raw = None      # 直近の buyHitodama の生レスポンス(診断用)
        self.last_buy_fail_rc = None  # 直近で買えなかったときの resultCode
        self.last_buy_how = None      # 買えたときに、どの投げ方で通ったか
        # save の ywp_user_data(人魂・ワイマネー)が古いかもしれない印。gameStart が通ったのに
        # 応答に ywp_user_data が無かったときに立て、stamina_now が入り直して読む。
        self._user_data_stale = False
        self._user_data_at = 0.0      # ywp_user_data を最後に取り込んだ時刻(無料人魂の回復の見積もり用)
        # 人魂の購入で「何を投げて・何が返ったか」の記録(非公開ログにファイルで添付)。
        # 買えなかったときに原因を詰められるよう、試した形とサーバの応答を残す。
        self.buy_diag = []
        self._master_refreshed = False
        # 人魂こうかんの「販売の一覧」を返してくれたエンドポイントの応答(見つかれば)。
        self._sale_probe = {}
        self._sale_probe_done = False
        self._sources_recorded = False
        # ゲームサーバへの接続(使い回す)。最初の通信で作る。通信は1本ずつ順に流す。
        self._http = None
        self._http_lock = threading.Lock()

    def _post(self, name, obj, **kw):
        with self._http_lock:
            if self._http is None:
                self._http = _new_http_session() or False
            return post_nhn(name, obj, self.app_ver, device=self.device,
                            session=self._http or None, **kw)

    @staticmethod
    def _active_ok(a) -> bool:
        """L5 の active の応答が「この udkey の状態」を表す形か(udkey と署名の欄がある)。"""
        return isinstance(a, dict) and isinstance(a.get('udkey'), dict) and 'sign_nonce' in a

    def _active_with_gdkeys(self, retries=6):
        a = active(self.app_ver, self.udkey, device=self.device)
        for _ in range(retries):
            if a.get('gdkeys') or not self._active_ok(a):
                break
            time.sleep(1.2)
            a = active(self.app_ver, self.udkey, device=self.device)
        if not self._active_ok(a):
            if isinstance(a, dict) and a.get('result') is False:
                # L5 が「駄目」と明言している(link_account と同じ result フラグ)。この udkey を
                # もう受け付けていない(削除・無効)と見て、覚えを捨てて連携からやり直す。
                raise PuniUdkeyError('L5 active: 断られました %s' % str(a)[:120])
            # HTTP 200 で返ったが中身が読めない(udkey や署名の欄が無い)。L5 の都合と見て
            # 少し待って入り直す(続くなら _open_with_retry が全体を止める)。覚えは捨てない。
            raise PuniServerError('L5 active: 応答の形が想定外 %s' % str(a)[:120], retry_ok=True)
        if not a.get('gdkeys'):
            # L5 は普通に応えたが、この udkey には紐づくゲームデータが無い(連携前・
            # 紐づけの解除)。覚えていた udkey なら捨てて連携からやり直す合図。
            raise PuniUdkeyError('このアカウントに紐づくゲームデータが見つかりません')
        return a

    def _enum(self, a):
        """udkey に紐づくゲームアカウントの一覧(getGdkeyAccounts)。

        連携の直後は、L5 側の紐づけがゲームサーバに反映されるまで間がある。
        載っていないまま login.nhn を投げると userId が空のリクエストになり、
        サーバは HTTP 500 で返す(実測: ログインが「rc=-1 HTTP500」で落ち続けた。
        混んでいる時間帯ほど反映が遅く、時々だけ通る)。反映されるまで少しずつ
        間を空けて待ち(合計30秒ほど)、それでも載らなければ login を投げずに
        PuniServerError にする。
        取得自体が HTTP エラー(5xx・タイムアウト)のときは待たずにすぐ返す
        (post_nhn の中で既に3回試している。ここでさらに8回繰り返すと、拒まれている
        入口を 24回叩くことになり、締め出しを延ばすだけ)。
        """
        gds = a['gdkeys']
        pl = []
        last_err = None
        waits = (1.2, 2.0, 3.0, 4.0, 5.0, 6.0, 8.0)
        for i in range(len(waits) + 1):
            rc, j = self._post('getGdkeyAccounts.nhn', {
                'appVer': self.app_ver, 'deviceId': self.udkey,
                'gdkeys': [{'gdkey': g['value']} for g in gds],
                'level5UserId': '0', 'mstVersionVer': self.mst, 'osType': 2,
                'userId': '0', 'ywpToken': '0'})
            if not isinstance(j, dict) or j.get('resultCode') == -1:
                last_err = ((j or {}).get('_error') or (j or {}).get('_raw')
                            or ('HTTP%s' % rc))
                pl = []
                break
            code = j.get('resultCode')
            if code not in (0, None):
                # サーバは応えたが断っている。反映待ちではないので繰り返さない(版が古い・
                # 一時エラー・その他)。それぞれ login と同じ種類で伝える。
                msg = 'getGdkeyAccounts.nhn: rc=%s (%s)' % (code, RC.get(code, '不明なエラー'))
                if looks_stale_rc(code):
                    raise PuniStaleVersionError(msg)
                if code in TRANSIENT_RC:
                    raise PuniServerError(msg, retry_ok=True)
                raise PuniLoginError(msg)
            last_err = None
            pl = j.get('udkeyPlayerList') or []
            if len(pl) >= len(gds):
                break
            if i < len(waits):
                time.sleep(waits[i])
        by_g = {str(p.get('gdkey')): p for p in pl if p.get('gdkey')}
        out = []
        for i, g in enumerate(gds):
            p = by_g.get(g['value'], {})
            out.append({'idx': i, 'userId': p.get('userId'),
                        'playerName': p.get('playerName'),
                        'gdkey': g['value'], 'gdsig': g['signature']})
        if any(x['userId'] in (None, '', 0) for x in out):
            if last_err:
                raise PuniServerError('getGdkeyAccounts.nhn: %s' % str(last_err)[:100])
            raise PuniServerError(
                'getGdkeyAccounts.nhn: 連携したアカウントがまだゲームサーバに載っていません'
                '(反映待ち。ゲームを一度も起動していない垢でも同じになります)', retry_ok=True)
        return out

    def init_nhn(self):
        rc, j = self._post('init.nhn', {
            'appGuardDeviceId': hashlib.sha256(self.udkey.encode()).hexdigest(),
            'appVer': self.app_ver, 'deviceId': self.udkey, 'level5UserId': '0',
            'mstVersionVer': self.mst, 'osType': 2, 'signature': SIGNATURE,
            'userId': '0', 'ywpToken': '0'})
        if isinstance(j, dict) and j.get('resultCode') == -1:
            # HTTP 異常・タイムアウト。黙って進むと古いマスタ版のまま login を投げる
            # ことになるので、どの段階で拒まれたかを添えて止める。
            raise PuniServerError('init.nhn: %s' % str(j.get('_error') or j.get('_raw')
                                                       or 'HTTP異常')[:100])
        v = j.get('mstVersionMaster')
        self.init_raw = j if isinstance(j, dict) else {}
        if isinstance(v, int) and v > 0:
            self.mst = v
        else:
            # フィールド名や型が変わっても最新のマスタ版を拾えるようにする。
            # self.mst が初期値(16897)のまま古いと、店(buyHitodama)だけが
            # 「データの更新があります(rc=100)」で弾く原因になるため。
            self._apply_master_version(j)
        return j

    def accounts(self):
        """このログインで選べるゲームアカウントの一覧。"""
        self.init_nhn()
        return [{k: v for k, v in a.items() if k != 'gdsig'}
                for a in self._enum(self._active_with_gdkeys())]

    def login(self, userId=None):
        """ゲームサーバへログイン。init → active → login の順が要る。

        サーバに繋がらない/拒まれた(HTTP 5xx・403・タイムアウト・JSONでない応答)
        ときは PuniServerError。メール・パスワードの問題と区別して伝えるため。
        """
        try:
            self.init_nhn()
            a = self._active_with_gdkeys()   # 署名一式は同じ active から揃える(混ぜると rc=30)
            accs = self._enum(a)
        except PuniLoginError:
            raise
        except (requests.exceptions.RequestException, ValueError, KeyError, TypeError,
                OSError) + _CURL_ANY as e:
            # 接続の失敗(curl_cffi の例外も含む)、L5 の応答が JSON でない/欄が無い
            # (KeyError: HTML のエラー画面など)。どれもサーバの都合で、メール・パスや
            # udkey の問題ではない。
            raise PuniServerError(
                'ゲームサーバ/L5に接続できません: %s: %s' % (type(e).__name__, str(e)[:100])) from e
        sel = None
        if userId is not None:
            sel = next((x for x in accs if str(x['userId']) == str(userId)), None)
            if sel is None:
                # この L5 アカウントの垢の中に、指定の userId が無い(注文と違うアカウントで
                # 入れ直した等)。udkey は生きているので、捨てて連携し直しても同じ。
                raise PuniAccountError('指定のアカウント(%s)が見つかりません' % userId)
        if sel is None:
            sel = accs[0]
        dev = self.device
        rc, j = self._post('login.nhn', {
            'appVer': self.app_ver, 'batteryInfo': dev.battery(), 'deviceId': self.udkey,
            'deviceName': dev.model, 'gdkeySignature': sel['gdsig'], 'gdkeyValue': sel['gdkey'],
            'isL5IDLinked': 1, 'level5UserId': sel['gdkey'],
            'modelName': dev.model, 'mstVersionVer': self.mst, 'osType': 2,
            'osVersion': dev.osver,
            'signNonce': a['sign_nonce'], 'signTimestamp': str(a['sign_timestamp']),
            'signature': SIGNATURE, 'udkeySignature': a['udkey']['signature'],
            'udkeyValue': self.udkey, 'userId': sel['userId'], 'ywpToken': '0'})
        if j.get('resultCode') != 0:
            code = j.get('resultCode')
            desc = RC.get(code, '不明なエラー')
            detail = j.get('_raw') or j.get('_error') or j.get('dialogMsg') or ''
            msg = 'login.nhn: rc=%s (%s) %s' % (code, desc, str(detail)[:100])
            if code == -1:
                # HTTP異常・タイムアウト・復号不可。BAN(202)ではなく、サーバ側が
                # 落ちているか、こちらの出口(IP)を拒んでいる。全体を止めて時間をおく。
                raise PuniServerError(msg)
            if code in TRANSIENT_RC:
                # 一時エラー。数秒おいて入り直せば通ることが多い(全体は止めない)。
                raise PuniServerError(msg, retry_ok=True)
            if looks_stale_rc(code):
                # アプリ版/マスタ版が古い。版を合わせてやり直す(udkey は悪くない)。
                raise PuniStaleVersionError(msg)
            if code == 30:
                # 署名の不整合。覚えていた udkey と L5 側の紐づけが食い違っている。
                raise PuniUdkeyError('ログイン失敗: ' + msg)
            raise PuniLoginError('ログイン失敗: rc=%s (%s) %s' % (code, desc, str(detail)[:100]))
        self.gdkey, self.userId, self.token = sel['gdkey'], sel['userId'], j.get('token')
        self.save = j
        self._user_data_stale = False
        self._user_data_at = time.time()
        self.active_deck_id = self.active_deck()["deck_id"]
        return j

    def active_deck(self) -> dict:
        """ゲームで選択中のデッキ。save の ywp_user_youkai_deck の行
        "デッキ番号|妖怪1|妖怪2|妖怪3|妖怪4|妖怪5|選択中|時計ID" から、選択中(7列目が 1)の行を
        取る(実機: "1|9002931|9001330|9001291|9001497|9001327|1|10101" で、その後の
        gameStart の activeDeckId も 1)。選択中の行が無ければ最初の行、行が無ければデッキ1。

        Yポイントアップなどのイベントの特殊能力・スキル・とくせいは、サーバがこのデッキを見て
        計算する(実機: 白雪姫入りのデッキでも gameEnd の申告は同じで、応答の eventPoint だけ
        6→8 になった)。だから代行では「お客さんが選んでいるデッキで戦う」ことがそのまま
        全部の反映になる。

        戻り値 {"deck_id", "youkai": [妖怪ID...], "watch_id", "active"}
        """
        parsed = []
        for r in rows(self.save.get('ywp_user_youkai_deck') if isinstance(self.save, dict) else None):
            try:
                deck_id = int(r[0])
            except (ValueError, IndexError, TypeError):
                continue
            youkai = []
            for x in r[1:6]:
                try:
                    v = int(x)
                except (ValueError, TypeError):
                    continue
                if v > 0:
                    youkai.append(v)
            active = len(r) >= 7 and str(r[6]).strip() == '1'
            watch = int(r[7]) if len(r) >= 8 and str(r[7]).strip().isdigit() else 0
            parsed.append({"deck_id": deck_id, "youkai": youkai, "watch_id": watch, "active": active})
        if not parsed:
            return {"deck_id": 1, "youkai": [], "watch_id": 0, "active": False}
        return next((d for d in parsed if d["active"]), parsed[0])

    def call(self, name, extra=None, retry=None):
        if not self.token or self.token == '0':
            raise PuniError('先に login() が必要です')
        # activeDeckId はお客さんが選んでいるデッキ。特性・スキルの反映はサーバがこれを見て行う。
        body = {'activeDeckId': int(self.active_deck_id or 1), 'appVer': self.app_ver,
                'deviceId': self.udkey,
                'level5UserId': self.gdkey, 'mstVersionVer': self.mst, 'osType': 2,
                'token': self.token, 'userId': str(self.userId), 'ywpToken': '0'}
        if extra:
            body.update(extra)
        rc, j = self._post(name, body, **({'retry': retry} if retry else {}))
        t = j.get('token')
        if t and t != 'null':
            self.token = t     # 持ち越さないと次が rc=32
        # gameStart / gameEnd / 購入の応答には ywp_user_data(人魂・ワイマネー・今のステージ)が
        # 載る(実機の通信で確認)。取り込んでおけば、周回の途中で人魂や残高を測るのに
        # 入り直す(init → active → getGdkeyAccounts → login を投げ直す)必要が無い。
        # 実機はプレイ中に login を投げ直さないので、投げ直さないほうが目立たない。
        if isinstance(j, dict) and j.get('resultCode') == 0:
            self._absorb_user_data(j)
        return rc, j

    def stage_ranking(self, stage_id):
        """ステージをタップしたときにアプリが送る userStageRanking(そのステージの順位表)。
        実機: 共通の欄 + stageId。gameStart の約1秒前に飛ぶ。失敗しても周回は止めない。"""
        try:
            rc, js = self.call('userStageRanking.nhn', {'stageId': int(stage_id)}, retry=1)
        except Exception:
            return None
        return js.get('resultCode') if isinstance(js, dict) else None

    def l5_status(self):
        """マップ画面に戻ったときにアプリが送る getL5IdStatus(L5 ID の連携状態の確認)。
        実機: 共通の欄 + afterPurchaseCheck 0 + isNotDistReward 0。失敗しても周回は止めない。"""
        try:
            rc, js = self.call('getL5IdStatus.nhn',
                               {'afterPurchaseCheck': 0, 'isNotDistReward': 0}, retry=1)
        except Exception:
            return None
        return js.get('resultCode') if isinstance(js, dict) else None

    def info(self) -> dict:
        d = self.save.get('ywp_user_data')
        if isinstance(d, str):
            try:
                d = json.loads(d)
            except Exception:
                d = {}
        return d or {}

    def hitodama(self) -> int:
        """今の人魂(スタミナ)の総数。ゲーム画面の「5 +6」= freeHitodama(5)＋hitodama(6)。
        読めなければ大きい値を返して「足りている」扱いにする。
        """
        info = self.info()
        if "freeHitodama" not in info and "hitodama" not in info:
            return 999
        try:
            return int(info.get("freeHitodama") or 0) + int(info.get("hitodama") or 0)
        except (TypeError, ValueError):
            return 999

    def stamina_now(self) -> int:
        """今の人魂(スタミナ)総数。rc=5 が「本当にスタミナ切れ」か「ロックのステージ」かを
        見分けるときに使う。読めなければ -1(判別不能)。

        人魂は gameStart で減り、その応答の ywp_user_data に減った後の値が載る(call が
        取り込む)ので、普段は入り直さずに読める。入り直して読むのは、
          ・取り込めていない(直近の gameStart の応答に載っていなかった・購入の応答に無かった)
          ・取り込んだ値が 0 で、無料人魂の回復(hitodamaRecoverSec 秒後に +1。サーバ側で
            勝手に増える)がその後に来たかもしれない
        とき。0 を鵜呑みにして買うと、本当は「入れないステージ」だったときに 1000
        ワイマネーを無駄にする(サーバは無料人魂が戻っていれば rc=5 を返さない)。
        """
        info = self.info()
        need_login = getattr(self, "_user_data_stale", False) or (
            "freeHitodama" not in info and "hitodama" not in info)
        if not need_login:
            try:
                total = int(info.get("freeHitodama") or 0) + int(info.get("hitodama") or 0)
            except (TypeError, ValueError):
                total = -1
            if total <= 0:
                rec = info.get("hitodamaRecoverSec")
                at = getattr(self, "_user_data_at", 0.0) or 0.0
                try:
                    need_login = (rec is None or not at
                                  or (time.time() - at) >= float(rec) - 2.0)
                except (TypeError, ValueError):
                    need_login = True
        if need_login:
            try:
                self.login(self.userId)
            except Exception:
                return -1
            info = self.info()
        if "freeHitodama" not in info and "hitodama" not in info:
            return -1
        try:
            return int(info.get("freeHitodama") or 0) + int(info.get("hitodama") or 0)
        except (TypeError, ValueError):
            return -1

    def ymoney(self) -> int:
        """今のワイマネー(ymoney)。"""
        try:
            return int(self.info().get("ymoney", 0))
        except (TypeError, ValueError):
            return 0

    # rc=100 のレスポンスに「本当はこのマスタ版でないとダメ」という版番号が入って
    # いることがある。入っていれば拾って self.mst を更新するために、それらしいキーを
    # 順に探す。
    _MST_VERSION_KEYS = ("mstVersionMaster", "mstVersion", "masterVersion",
                         "mstVer", "requiredMstVersion", "version")

    def _apply_master_version(self, obj) -> bool:
        """dict の中からマスタ版番号らしき値を探して self.mst を上げる。上げたら True。"""
        if not isinstance(obj, dict):
            return False
        for k in self._MST_VERSION_KEYS:
            v = obj.get(k)
            if isinstance(v, int) and v > self.mst:
                self.mst = v
                return True
            if isinstance(v, str) and v.isdigit() and int(v) > self.mst:
                self.mst = int(v)
                return True
        return False

    def refresh_master(self) -> None:
        """「データの更新があります(rc=100)」で店が弾かれたとき用のマスタ再取得。

        init.nhn を叩き直して最新のマスタ版を self.mst に取り込み、ログインし直して
        token とマスタ版を揃える。読み取りのみで消費はしない。

        以前はここで getMaster.nhn を「ありそうな形」7通りで当てずっぽうに叩いて
        いた(各3回リトライ)。一度も通らないうえ、人魂が切れるたびに goodsId の数
        (最大15)ぶん繰り返して、数百件の失敗リクエストを短時間に投げていた。
        その直後にログインが HTTP 500 で落ち続ける状態になったので、やめる
        (出口ごと拒まれる原因になり得る)。
        """
        try:
            j = self.init_nhn()          # self.mst を最新へ
            self._apply_master_version(j)
        except Exception as e:
            print(f"[PUNI] マスタ再取得(init)に失敗: {e}", flush=True)
        try:
            self.login(self.userId)      # 更新した mst で入り直す
        except Exception as e:
            print(f"[PUNI] マスタ再取得後の再ログインに失敗: {e}", flush=True)

    def _buy_call(self, gid, how: str, extra: dict = None, mst: int = None,
                  endpoint: str = "buyHitodama.nhn", retry: int = None,
                  aliases: bool = False) -> tuple:
        """人魂の購入を1回投げて (resultCode, 応答) を返す。試した形と応答は記録に残す。

        本物の形(実機の通信で確認)は共通の欄 ＋ goodsId だけ。aliases=True のとき
        (探索用)だけ、ID の別名と個数の欄も添える。
        mst を渡すと、その版番号で投げる(購入だけ。投げ終わったら元に戻す。バトルで
        通っている版を動かすと、進行のほうが rc=101 で崩れる)。
        endpoint を替えて投げるときは retry=1 にして、無い名前(404)を何度も
        叩かない。gid が None なら goodsId は載せない(販売IDだけで買う形)。
        """
        body = {}
        if gid is not None:
            body["goodsId"] = gid
            if aliases:
                # 探索用: 表の名前から導いた ID の別名と個数の欄を全部添える(知らない欄は
                # 無視されるので、1回のリクエストで全部の名前を試せる)。
                for name in self._HITODAMA_ID_PARAMS:
                    body[name] = gid
                body.update(self._BUY_QTY_PARAMS)
        if extra:
            body.update(extra)
        saved = self.mst
        if mst:
            self.mst = int(mst)
        try:
            rc, result = self.call(endpoint, body, retry=retry)
        finally:
            self.mst = saved
        result = result if isinstance(result, dict) else {"resultCode": rc}
        self.last_buy_raw = result
        code = result.get("resultCode", rc)
        if len(self.buy_diag) < 40:
            self.buy_diag.append({
                "endpoint": endpoint, "goodsId": gid, "how": how,
                "mstVersionVer": mst or saved,
                "extra": {k: v for k, v in (extra or {}).items()},
                "sent": sorted(body),
                "http": rc, "rc": code,
                "response": {k: (v if len(str(v)) <= 300 else str(v)[:300] + "…")
                             for k, v in result.items() if k not in ("token", "ywp_user_data")},
            })
        return code, result

    # ---- 人魂こうかん: 探索用(原因を詰めるとき=PROBE だけ) ----
    #
    # 本物の形は実機の通信で確認済み(buyHitodama.nhn に共通の欄 ＋ goodsId だけ。
    # ×5=1000ワイマネー は goodsId=1001)。普段はそれだけを投げる(buy_hitodama)。
    # 以下は、店の中身が変わって設定の ID が rc=100(「データの更新があります」= その ID の
    # エントリが無い)になったときに、別の ID を探すための道具。
    #   ・ログイン/init の応答に hitodamaShopSaleList などが載っていればセール ID で
    #     (_buy_with_sale。ID の別名と個数の欄も添える)
    #   ・店の一覧を返す呼び方の候補(_SHOP_LIST_ENDPOINTS。実測では全部 404)
    #   ・getMaster.nhn で店の表を取る(_MASTER_VARIANTS。key=表の名前 は別 bot の形)
    #   ・goodsId を 1000〜1004 で順に当たる

    _SALE_BUY_ENDPOINTS = ("buyHitodama.nhn", "buyHitodamaShopSale.nhn",
                           "buyShopSale.nhn")
    _SALE_ID_PARAMS = ("hitodamaShopSaleId", "shopSaleId", "saleId", "ymoneyShopSaleId")
    _HITODAMA_ID_PARAMS = ("shopHitodamaId", "hitodamaShopId", "mstShopHitodamaId",
                           "shopHitodamaNo", "hitodamaId", "hitodamaShopSaleId",
                           "goodsSaleId", "shopSaleId", "saleId", "shopItemId", "id")
    # 個数の欄が要る作りかもしれない(無ければ無視される)。
    _BUY_QTY_PARAMS = {"num": 1, "buyNum": 1, "count": 1, "quantity": 1}
    # 店の一覧を返す呼び方(表の名前 ywp_mst_shop_hitodama から導いた候補)。1プロセスで
    # 1回だけ順に確かめ、取れたらその中身(ID の欄の名前・価格)で買う。
    _SHOP_LIST_ENDPOINTS = ("getShopHitodama.nhn", "shopHitodama.nhn", "getHitodamaShop.nhn",
                            "hitodamaShop.nhn", "getShopSaleList.nhn", "getSaleList.nhn")
    _shop_list_cache = {"done": False, "data": None, "endpoint": None}
    # マスタ(表)を返す getMaster.nhn は実在する(未ログインだと rc=3)。ログインした状態で
    # 1プロセス1回だけ、欄の当たりを数通り試す。店の表 ywp_mst_shop_hitodama が取れたら、
    # その行(ID・価格・個数)で買う。
    _MASTER_VARIANTS = (
        # 同じ暗号・同じ call を使う別の bot は getMaster.nhn を key=表の名前 で呼んでいる
        # (その bot の中で使われてはいないが、唯一の根拠のある形)。先頭で試す。
        ("表の名前を key で", {"key": "ywp_mst_shop_hitodama"}),
        ("そのまま", {}),
        ("版 0", {"mstVersionVer": 0}),
        ("表ごとの版を添えて(店だけ 0)", None),        # 実行時に組み立てる
    )
    # 普段の注文で試すのは根拠のある形(key)だけ。残りは原因を詰めるとき(PROBE)だけ。
    _MASTER_VARIANTS_LEAN = _MASTER_VARIANTS[:1]
    _master_cache = {"done": False, "data": None, "how": None}

    def _sale_sources(self) -> list:
        """販売の一覧を探す場所 [(名前, dict)]。"""
        out = []
        if isinstance(self.save, dict):
            out.append(("login", self.save))
        if isinstance(self.init_raw, dict):
            out.append(("init", self.init_raw))
        if isinstance(self._sale_probe, dict) and self._sale_probe:
            out.append(("probe", self._sale_probe))
        if isinstance(self.last_buy_raw, dict):
            out.append(("buy", self.last_buy_raw))
        return out

    @staticmethod
    def _sale_like_items(obj) -> list:
        """dict の直下で、名前に sale / shop / hitodama を含む list を [(名前, list)] で返す。
        (sale 以外は、中身が dict の並びのときだけ。ユーザーの人魂の数などは拾わない)"""
        out = []
        if not isinstance(obj, dict):
            return out
        for k, v in obj.items():
            kl = str(k).lower()
            if not isinstance(v, list):
                continue
            if "sale" in kl:
                out.append((str(k), v))
            elif ("shop" in kl or "hitodama" in kl) and not kl.startswith("ywp_user") \
                    and v and all(isinstance(x, dict) for x in v):
                out.append((str(k), v))       # ユーザーの表(ywp_user_*)は一覧ではない
        return out

    @staticmethod
    def _entry_num(entry: dict, names) -> int:
        """エントリから、名前が names のどれかに当たる数値を1つ取る。無ければ None。"""
        lowered = {str(k).lower(): v for k, v in entry.items()}
        for name in names:
            v = lowered.get(name.lower())
            if isinstance(v, bool):
                continue
            if isinstance(v, int):
                return v
            if isinstance(v, str) and v.isdigit():
                return int(v)
        return None

    @staticmethod
    def _entry_id(entry: dict):
        """エントリの id。名前が …Id で終わる欄のうち sale を含むものを優先、次に id。"""
        cands = []
        for k, v in entry.items():
            kl = str(k).lower()
            if not (kl.endswith("id") and isinstance(v, (int, str))):
                continue
            if isinstance(v, str) and not v.isdigit():
                continue
            rank = 0 if "sale" in kl else (1 if kl == "id" else 2)
            cands.append((rank, str(k), int(v)))
        if not cands:
            return None, None
        cands.sort()
        _, key, value = cands[0]
        return key, value

    def _hitodama_sale_candidates(self) -> list:
        """今買える人魂の販売エントリ。安い順・上限(HITODAMA_MAX_PRICE)以内・最大3つ。"""
        cap = HITODAMA_MAX_PRICE
        seen = set()
        out = []
        for src_name, src in self._sale_sources():
            for key, items in self._sale_like_items(src):
                for entry in items:
                    if not isinstance(entry, dict):
                        continue
                    id_key, sid = self._entry_id(entry)
                    if sid is None or (key, sid) in seen:
                        continue
                    seen.add((key, sid))
                    price = self._entry_num(entry, ("price", "ymoney", "salePrice",
                                                    "priceYmoney", "cost", "needYmoney"))
                    count = self._entry_num(entry, ("hitodama", "hitodamaNum", "num",
                                                    "count", "quantity", "amount"))
                    is_hito = ("hitodama" in key.lower()
                               or any("hitodama" in str(k).lower() for k in entry))
                    if price is not None and price > cap:
                        continue
                    out.append({"source": f"{src_name}.{key}", "id_key": id_key, "id": sid,
                                "price": price, "count": count, "hitodama": is_hito,
                                "goodsId": self._entry_num(entry, ("goodsId",)),
                                "entry": {k: entry[k] for k in list(entry)[:12]}})
        out.sort(key=lambda c: (not c["hitodama"],
                                c["price"] if c["price"] is not None else 10 ** 9))
        return out[:3]

    def _record_sources_once(self):
        """販売の一覧を探した場所の中身を、購入の記録に1回だけ残す(次の切り分け用)。"""
        if self._sources_recorded:
            return
        self._sources_recorded = True
        snap = {}
        for src_name, src in self._sale_sources():
            snap[src_name] = {
                "keys": [str(k) for k in list(src)[:60]],
                "sale_like": {key: items[:3] for key, items in self._sale_like_items(src)},
            }
        # 店に関わる欄の中身(先頭だけ)。人魂こうかんの ID の欄の名前を当てる手掛かり。
        shop_fields = {}
        if isinstance(self.save, dict):
            for key in ("ywp_user_shop_item_remain_cnt", "ywp_user_shop_item_unlock",
                        "monthlyPurchasableLeft", "ywp_user_item"):
                v = self.save.get(key)
                if isinstance(v, str):
                    try:
                        v = json.loads(v)
                    except Exception:
                        pass
                if isinstance(v, list):
                    v = v[:5]
                shop_fields[key] = v if len(str(v)) <= 600 else str(v)[:600] + "…"
        if isinstance(self.init_raw, dict):
            vm = str(self.init_raw.get("ywp_mst_version_master") or "")
            shop_fields["mst_shop_tables"] = [
                x for x in vm.split("*") if any(k in x for k in ("shop", "sale", "goods"))]
        # ユーザーデータの欄の名前(値は人魂・店・購入に関わるものだけ)。欄の名前の
        # 付け方から、購入リクエストの ID の欄の名前を当てるため。
        info = self.info()
        if isinstance(info, dict):
            shop_fields["user_data_keys"] = sorted(str(k) for k in info)[:120]
            shop_fields["user_data_related"] = {
                str(k): v for k, v in info.items()
                if any(w in str(k).lower() for w in ("hitodama", "shop", "buy", "purchase",
                                                       "ymoney", "sale", "goods"))
                and len(str(v)) <= 80}
        if len(self.buy_diag) < 40:
            self.buy_diag.append({"how": "販売の一覧を探した場所", "sources": snap,
                                  "shop_fields": shop_fields})

    def _load_shop_list(self) -> None:
        """人魂こうかんの一覧を返す呼び方を、表の名前から導いた候補で確かめる。

        1プロセスで1回だけ(結果はクラスで共有)。取れたら self._sale_probe に入れ、
        _hitodama_sale_candidates がそこから ID の欄の名前と価格を拾う。
        無い名前は 404 で返るだけ(リトライ無し)。何を返したかは記録に残す。
        """
        cache = Client._shop_list_cache
        if cache["done"]:
            if cache["data"]:
                self._sale_probe = cache["data"]
            return
        cache["done"] = True
        for name in self._SHOP_LIST_ENDPOINTS:
            try:
                rc, j = self.call(name, retry=1)
            except Exception as e:
                j, rc = {"resultCode": -1, "_error": f"{type(e).__name__}: {e}"}, None
            j = j if isinstance(j, dict) else {}
            if len(self.buy_diag) < 40:
                entry = {"how": "店の一覧を探す", "endpoint": name, "http": rc,
                         "rc": j.get("resultCode"), "keys": [str(k) for k in list(j)[:30]]}
                if j.get("resultCode") == 0:
                    entry["lists"] = {k: v[:3] for k, v in j.items()
                                      if isinstance(v, list) and v}
                self.buy_diag.append(entry)
            if j.get("resultCode") == 0 and any(isinstance(v, list) and v for v in j.values()):
                cache["data"], cache["endpoint"] = j, name
                self._sale_probe = j
                print(f"[PUNI] 人魂こうかんの一覧は {name} で取れました", flush=True)
                return

    def _load_master_tables(self, variants=None) -> None:
        """getMaster.nhn で表を取る(1プロセス1回。結果はクラスで共有)。

        欄の当たりを variants(既定 _MASTER_VARIANTS)の順に試し、ywp_mst_ で始まる欄が
        返ったらそれを持つ。何を返したかは記録に残す(店に関わる表は中身の先頭も)。
        """
        cache = Client._master_cache
        if cache["done"]:
            return
        cache["done"] = True
        for label, extra in (variants or self._MASTER_VARIANTS):
            if extra is None:
                vm = str((self.init_raw or {}).get("ywp_mst_version_master") or "")
                if not vm:
                    continue
                parts = []
                for x in vm.split("*"):
                    name, _, ver = x.partition("|")
                    parts.append(f"{name}|0" if any(k in name for k in ("shop", "sale", "goods"))
                                 else f"{name}|{ver}")
                extra = {"ywp_mst_version_master": "*".join(parts)}
            try:
                rc, j = self.call("getMaster.nhn", extra, retry=1)
            except Exception as e:
                j, rc = {"resultCode": -1, "_error": f"{type(e).__name__}: {e}"}, None
            j = j if isinstance(j, dict) else {}
            mst_keys = [k for k in j if str(k).startswith("ywp_mst")]
            if len(self.buy_diag) < 40:
                entry = {"how": f"表を取る(getMaster {label})", "http": rc,
                         "rc": j.get("resultCode"), "keys": [str(k) for k in list(j)[:30]],
                         "mst_keys": mst_keys[:40], "size": len(str(j))}
                for k in mst_keys:
                    if any(w in k for w in ("shop", "sale", "goods")):
                        entry[k] = str(j.get(k))[:400]
                self.buy_diag.append(entry)
            if mst_keys:
                cache["data"], cache["how"] = j, label
                print(f"[PUNI] 表が取れました(getMaster {label}): {len(mst_keys)} 表", flush=True)
                return

    @staticmethod
    def _rows(value) -> list:
        """表の値(文字列 'a|b*c|d' か list)を行ごとの欄の並びに。"""
        if isinstance(value, str):
            return [row.split("|") for row in value.split("*") if row]
        if isinstance(value, list):
            out = []
            for row in value:
                if isinstance(row, dict):
                    out.append([str(v) for v in row.values()])
                elif isinstance(row, (list, tuple)):
                    out.append([str(v) for v in row])
                else:
                    out.append(str(row).split("|"))
            return out
        return []

    def _hitodama_candidates_from_master(self) -> list:
        """取れた表の ywp_mst_shop_hitodama から、買える候補(安い順・上限内)を作る。

        欄の並びは分かっていないので、先頭を ID、100 の倍数で一番大きい欄を価格、
        残りの小さい欄を個数と見る。行はそのまま記録に残す(次の切り分け用)。
        """
        data = Client._master_cache.get("data")
        if not isinstance(data, dict):
            return []
        table = next((data[k] for k in data if str(k).endswith("shop_hitodama")), None)
        if table is None:
            return []
        cap = HITODAMA_MAX_PRICE
        out = []
        rows = self._rows(table)
        if len(self.buy_diag) < 40:
            self.buy_diag.append({"how": "店の表の行", "rows": rows[:12]})
        for row in rows:
            nums = []
            for x in row:
                try:
                    nums.append(int(str(x).strip()))
                except ValueError:
                    nums.append(None)
            if not nums or nums[0] is None:
                continue
            sid = nums[0]
            rest = [n for n in nums[1:] if isinstance(n, int)]
            prices = [n for n in rest if n >= 100 and n % 100 == 0]
            price = max(prices) if prices else None
            # 小さい欄のうち一番大きいものを個数と見る(末尾の 0/1 はフラグのことが多い)。
            counts = [n for n in rest if 0 < n < 100 and n != price]
            count = max(counts) if counts else None
            if price is not None and price > cap:
                continue
            out.append({"source": "master.shop_hitodama", "id_key": "shopHitodamaId", "id": sid,
                        "price": price, "count": count, "hitodama": True, "goodsId": sid,
                        "entry": {"row": row}})
        out.sort(key=lambda c: c["price"] if c["price"] is not None else 10 ** 9)
        return out[:3]

    def _buy_with_sale(self, cand: dict, endpoints=None) -> tuple:
        """販売エントリを指定して買う。戻り値 (買えたか, 使ったワイマネー)。

        買う先のエンドポイントは endpoints(既定: buyHitodama を先頭に、ありそうな名前を
        順に。無い名前は 404 で返るだけ・リトライ無し)。rc=100 以外の断り(残高不足など)
        が返ったら、そこで打ち切る(形は合っている)。
        """
        y_before = self.ymoney()
        sid = cand["id"]
        extra = {name: sid for name in self._SALE_ID_PARAMS}
        if cand.get("id_key") and cand["id_key"] not in extra:
            extra[cand["id_key"]] = sid
        # 価格と個数が分かっていれば添える(価格の確認欄を要求する作りに備える。
        # 「データの更新があります」は、こちらの価格が表と合わないときの返し方でもあり得る)。
        if cand.get("price") is not None:
            for name in ("ymoney", "price", "useYmoney", "payYmoney"):
                extra[name] = cand["price"]
        if cand.get("count") is not None:
            for name in ("hitodamaNum", "hitodamaCnt", "hitodama"):
                extra[name] = cand["count"]
        label = (f"販売ID {sid}({cand['source']}"
                 + (f" {cand['price']}y" if cand.get("price") is not None else "")
                 + (f" ×{cand['count']}" if cand.get("count") is not None else "") + ")")
        for endpoint in (endpoints or self._SALE_BUY_ENDPOINTS):
            code, result = self._buy_call(
                cand.get("goodsId"), f"{label} を {endpoint} で", extra=extra,
                endpoint=endpoint, retry=None if endpoint == "buyHitodama.nhn" else 1,
                aliases=True)
            if code == 0:
                self.last_bought_goods_id = cand.get("goodsId")
                self.last_buy_fail_rc = None
                self.last_buy_how = self.buy_diag[-1]["how"] if self.buy_diag else label
                self._buy_winner = ("sale", (endpoint, dict(extra), cand.get("goodsId")))
                print(f"[PUNI] 人魂を購入: {self.last_buy_how}", flush=True)
                self._absorb_user_data(result)
                return True, max(0, y_before - self.ymoney())
            if code not in (100, -1):
                # 形は通っている(別の理由で断られた)。他の名前を当たっても同じ。
                self.last_buy_fail_rc = code
                return False, 0
        self.last_buy_fail_rc = code
        return False, 0

    def _buy_hitodama_once(self, gid) -> tuple:
        """goodsId 1つで buyHitodama を投げる(本物の形)。戻り値 (買えたか, 使ったワイマネー)。

        使ったワイマネーは購入前後の残高差。買えなければ (False, 0)。
        rc=100(「データの更新があります」= その ID のエントリが無い/マスタが古い)のとき
        だけ、1接続で1回、マスタを取り直して(init → 再ログイン)もう一度投げる。
        買えたら、応答の ywp_user_data(残高・人魂)を save に取り込む(入り直さない)。
        """
        y_before = self.ymoney()
        code, result = self._buy_call(gid, "そのまま")
        if code == 100 and not self._master_refreshed:
            # マスタの取り直しは1接続で1回だけ(goodsId ごとに繰り返さない)。
            self._master_refreshed = True
            self._apply_master_version(result)
            self.refresh_master()
            y_before = self.ymoney()
            code, result = self._buy_call(gid, "マスタ再取得後")
        if code == 0:
            self.last_bought_goods_id = gid
            self.last_buy_fail_rc = None
            self.last_buy_how = (self.buy_diag[-1]["how"] if self.buy_diag else None)
            print(f"[PUNI] 人魂を購入: goodsId={gid} ({self.last_buy_how})", flush=True)
            self._absorb_user_data(result)
            return True, max(0, y_before - self.ymoney())
        # 買えなかった理由(rc)を控える。切れたときの案内・調査に出す。
        self.last_buy_fail_rc = code
        return False, 0

    def _absorb_user_data(self, result) -> None:
        """応答の ywp_user_data(残高・人魂・今のステージ)を save に取り込む。

        載っていなければ何もしない(入り直さない)。人魂や残高を測る側(stamina_now)が、
        取り込めていないと分かったときだけ入り直す。
        """
        data = result.get("ywp_user_data") if isinstance(result, dict) else None
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except ValueError:
                data = None
        if isinstance(data, dict) and data:
            if not isinstance(self.save, dict):
                self.save = {}
            self.save["ywp_user_data"] = data
            self._user_data_stale = False
            self._user_data_at = time.time()

    def buy_hitodama(self, goods_id=None) -> bool:
        """人魂をワイマネーで買い足す。買えたら True。

        買いすぎ防止のため、1回に使うワイマネーは HITODAMA_MAX_PRICE(既定1000=×5)まで。
        それより高いパック(×20=3000, ×50=6000)は掴んでも覚えず、繰り返さない。
        1) goods_id 指定ならそれだけ試す(指定時は上限チェックしない)。
        2) 省略時は設定の候補(既定 1001=×5。実機の通信で確認した本物の形)を順に試す。
           安く(≤上限)買えたらそれを使う。残高不足などの断りはそこで止める。
        3) rc=100(その ID のエントリが無い)なら、別 bot の getMaster(key=表の名前) を
           1プロセス1回試し、店の表の行が取れたら一番安い行の ID で1回だけ。
        4) それでも買えなければ、原因を詰めるとき(PUNI_HITODAMA_PROBE=1)だけ探索
           (販売の一覧・店の一覧・goodsId の順当たり)。普段はここで False。
        """
        # 残高は直近の gameStart / gameEnd / 購入の応答から取り込んである(call)。入り直さない。
        if goods_id is not None:
            ok, _ = self._buy_hitodama_once(goods_id)
            return ok

        # 1) 本物の形: 共通の欄 ＋ goodsId(既定 1001 = ×5 1000ワイマネー)。
        cap = HITODAMA_MAX_PRICE
        for gid in get_hitodama_goods_ids():
            ok, cost = self._buy_hitodama_once(gid)
            if ok:
                if cost > cap:
                    # 高すぎるパックを掴んだ。補充はできたが、この設定は使い続けない
                    # (安いのを探し直せるよう覚えを消す)。
                    set_hitodama_goods_ids([g for g in get_hitodama_goods_ids()
                                            if g != gid])
                return True
            if self.last_buy_fail_rc not in (100, -1):
                # 形は通っている(残高不足など別の理由)。他の ID を当たっても同じ。
                return False
            # rc=100 は「その ID のエントリが無い」。次の ID へ(1回1リクエスト)。

        # 2) 別 bot の getMaster(key=表の名前)。根拠のある形なので普段も1プロセス1回だけ
        #    試し、店の表(ywp_mst_shop_hitodama)の行が取れたら、上限内で一番安い行の ID で
        #    本物の形で1回だけ(注文ごとに増えるのは最大1回)。
        self._load_master_tables(variants=None if HITODAMA_PROBE else self._MASTER_VARIANTS_LEAN)
        tried = set(get_hitodama_goods_ids())
        for cand in self._hitodama_candidates_from_master()[:1]:
            gid = cand["goodsId"]
            if gid in tried:
                continue
            ok, cost = self._buy_hitodama_once(gid)
            if ok:
                if cost <= cap:
                    set_hitodama_goods_ids([gid] + [g for g in get_hitodama_goods_ids()
                                                    if g != gid])
                return True
            if self.last_buy_fail_rc not in (100, -1, None):
                return False

        # 探索(販売の一覧・店の一覧・goodsId の順当たり)は、注文ごとに投げると失敗の嵐に
        # なる(前に IP を拒まれた原因)。普段は投げない。原因を詰めるときだけ。
        if not HITODAMA_PROBE:
            return False

        # 1) 販売の一覧(セールID)から買う。前に通った形があればそれから。
        winner = getattr(self, "_buy_winner", None)
        if winner and winner[0] == "sale":
            endpoint, extra, gid = winner[1]
            y_before = self.ymoney()
            code, result = self._buy_call(gid, "前に通った販売の形", extra=extra,
                                          endpoint=endpoint, retry=1)
            if code == 0:
                self.last_buy_fail_rc = None
                self._absorb_user_data(result)
                return True
        self._record_sources_once()
        cands = self._hitodama_sale_candidates()
        if not cands:
            self._load_shop_list()
            cands = self._hitodama_sale_candidates()
        if not cands:
            self._load_master_tables()
            cands = self._hitodama_candidates_from_master()
        for cand in cands:
            ok, _ = self._buy_with_sale(cand)
            if ok:
                return True
            if self.last_buy_fail_rc not in (100, -1, None):
                return False        # 形は通っているが別の理由(残高など)で断られた

        # goodsId の順当たり(1000〜1004)。上限内で買えた ID を次回のため先頭に覚える。
        if HITODAMA_AUTO_DISCOVER:
            tried = set(get_hitodama_goods_ids())
            for gid in range(HITODAMA_DISCOVER_MIN, HITODAMA_DISCOVER_MAX + 1):
                if gid in tried:
                    continue
                ok, cost = self._buy_hitodama_once(gid)
                if not ok:
                    if self.last_buy_fail_rc not in (100, -1, None):
                        return False      # 形は通っている(残高不足など)。探しても同じ
                    continue              # 無い ID(rc=100)は次へ
                if cost <= cap:
                    # 上限内の安いパック。次回のため先頭に覚える。
                    remaining = [g for g in get_hitodama_goods_ids() if g != gid]
                    set_hitodama_goods_ids([gid] + remaining)
                    return True
                # 上限超えを掴んでしまった。これ以上は探さない(高いのを買い続けない)。
                return True
        return False

    def stages(self) -> dict:
        out = {}
        for r in rows(self.save.get('ywp_user_stage')):
            try:
                out[int(r[0])] = r
            except (ValueError, IndexError, TypeError):
                continue
        return out

    def stage_states(self) -> dict:
        """stageId → 状態。ywp_user_stage の2列目(実データで確認):
          0 = 未開放/ロック(まだ入れない。隠し・先の章・別条件待ちなど)
          1 = クリア済み(再挑戦できる)
          2 = 開放済み・未クリア(=今の続き。フロンティア)
        それ以外の値はそのまま入れておく(将来の値ゆらぎの保険)。
        """
        out = {}
        for r in rows(self.save.get('ywp_user_stage')):
            try:
                out[int(r[0])] = int(r[1]) if len(r) >= 2 else 0
            except (ValueError, IndexError, TypeError):
                continue
        return out

    def cleared_stage_ids(self) -> set:
        """クリア済み(2列目が '1')のステージIDだけを集める。"""
        return {sid for sid, st in self.stage_states().items() if st == 1}

    def _latest(self, key: str):
        """その欄を、直近の gameEnd の応答 → ログインの save の順で探す。"""
        for src in (self.last_end, self.save):
            if isinstance(src, dict) and src.get(key) not in (None, ""):
                return src.get(key)
        return None

    def tutorial_flags(self) -> dict:
        """(種別, ID) → 済みかどうか(0/1)。ywp_user_tutorial_list の行 "種別|ID|済み"。"""
        out = {}
        for r in rows(self._latest("ywp_user_tutorial_list")):
            try:
                out[(int(r[0]), int(r[1]))] = int(r[2]) if len(r) >= 3 else 0
            except (ValueError, IndexError, TypeError):
                continue
        return out

    def boss_stage_ids(self) -> list:
        """その垢が知っている強敵ステージのID(昇順)。チュートリアル一覧の種別 13 から拾う。

        過去イベントの分も混ざるので、今のイベントに絞るのは呼び出し側(boss_target)。
        """
        return sorted(tid for (ttype, tid) in self.tutorial_flags() if ttype == BOSS_TUTORIAL_TYPE)

    @staticmethod
    def youkai_tables(src) -> list:
        """src(save や応答)に載っている、妖怪ごとの表の名前(デッキの表は除く)。"""
        if not isinstance(src, dict):
            return []
        return [str(k) for k in src
                if str(k).startswith("ywp_user_youkai") and "deck" not in str(k)
                and src.get(k) not in (None, "", [], {})]

    def owns_youkai(self, youkai_id):
        """ログイン時の save で、その妖怪を持っているか。True / False / None(表が無く分からない)。

        持っているかは「妖怪の表(差分ではない全体の表)にその妖怪の行があるか」で見る。
        表そのものが無ければ持っていないとは言えないので None(断る理由にしない)。
        """
        tables = [t for t in self.youkai_tables(self.save) if not t.endswith("_diff")]
        if not tables:
            return None
        _, row = self.youkai_row(youkai_id, {t: self.save.get(t) for t in tables})
        return row is not None

    @staticmethod
    def youkai_row(youkai_id, src) -> tuple:
        """垢の妖怪の表から、その妖怪の行を探す。戻り値 (表の名前, 行=欄の list)。無ければ (None, None)。

        探すのは名前が ywp_user_youkai で始まる表(ログインの save の全体表や、gameEnd の
        差分 ywp_user_youkai_diff)。デッキの表は妖怪ごとの行ではないので除く。列の並びは
        分かっていないので、IDがそのまま1つの欄になっている行を拾う(先頭の欄が一致する
        行を優先する。IDと同じ数字がたまたま別の妖怪の行に入っていても取り違えないため)。
        本体の表(ywp_user_youkai / _diff)を先に見る。名前順だとボーナス効果などの
        付属の表が先に来て、凸では動かないその行を見比べてしまう。
        """
        if not isinstance(src, dict):
            return None, None
        try:
            target = str(int(youkai_id))
        except (TypeError, ValueError):
            return None, None
        main = ("ywp_user_youkai", "ywp_user_youkai_diff")
        found = None
        for key in sorted(src, key=lambda k: (str(k) not in main, str(k))):
            name = str(key)
            if not name.startswith("ywp_user_youkai") or "deck" in name:
                continue
            value = src.get(key)
            if isinstance(value, str) and value.startswith("{"):
                try:
                    value = json.loads(value)
                except ValueError:
                    continue
            if isinstance(value, dict):
                value = value.get("rows") or []
            for row in Client._rows(value):
                cells = [str(c).strip() for c in row]
                if not cells or target not in cells:
                    continue
                if cells[0] == target:
                    return name, cells
                if found is None:
                    found = (name, cells)
        return found or (None, None)

    def mark_tutorial(self, tutorial_type: int, tutorial_id: int):
        """チュートリアルを済みにする(updateTutorialFlg)。実機は強敵の初回に戦闘のあと送る。

        送らなくても強敵の gameStart/gameEnd は通る(実測)ので、失敗しても止めない。
        戻り値 resultCode(通信できなければ None)。
        """
        try:
            rc, js = self.call('updateTutorialFlg.nhn', {
                'tutorialId': int(tutorial_id), 'tutorialStatus': 1,
                'tutorialType': int(tutorial_type)})
        except Exception:
            return None
        if isinstance(js, dict) and js.get('resultCode') == 0:
            lst = js.get('ywp_user_tutorial_list')
            if lst and isinstance(self.save, dict):
                self.save['ywp_user_tutorial_list'] = lst
            if isinstance(self.last_end, dict) and lst:
                self.last_end['ywp_user_tutorial_list'] = lst
        return js.get('resultCode') if isinstance(js, dict) else None


    def build_game_end(self, stageId, battleType, start, clear_sec=None):
        """1プレイぶんの結果を作る。数値は毎回散らして、同じ結果が並ばないようにする。

        clear_sec を渡すと、その申告クリア秒数をそのまま載せる(呼び出し側が
        「その秒数ぶん待ってから送る」ために先に決める)。
        """
        reqId = start.get('requestId')
        yk = start.get('userYoukaiList') or []
        en = start.get('enemyYoukaiList') or []
        ehp = sum(e.get('hp', 0) for e in en)
        # 敵のHPを超えるダメージにする(超えないとクリアにならない)。倒せる範囲で散らす。
        if ehp:
            dmg = ehp + random.randint(int(ehp * 0.03) + 50, int(ehp * 0.30) + 500)
        else:
            dmg = random.randint(40_000, 120_000)
        if clear_sec is None:
            clear_sec = _round_timing()[2]

        # 消した回数はクリア秒数に釣り合わせる(6秒で40回なぞるのは無理)。
        lo, hi = ERASE_NUM_RANGE
        erase_num = int(clear_sec * random.uniform(*ERASE_PER_SEC_RANGE))
        erase_num = max(lo, min(hi, erase_num))
        combo_max = random.randint(COMBO_MAX_RANGE[0],
                                   max(COMBO_MAX_RANGE[0] + 1,
                                       min(COMBO_MAX_RANGE[1], erase_num // 2)))
        link_size = random.randint(*LINK_SIZE_RANGE)
        erase_size_max = random.randint(*ERASE_SIZE_MAX_RANGE)
        score = min(int(dmg * random.uniform(*SCORE_PER_DAMAGE_RANGE)), 2_000_000_000)
        # 受けたダメージ = 受けた攻撃の回数 × 敵の攻撃力(実機: 198 = 2 × atkPower 99、
        # 強敵のリタイアでは 32300 = 1 × 32300)。残りHP = 味方のHP合計 − 受けたダメージ。
        team_hp = sum(int(y.get('hp') or 0) for y in yk)
        atk = max([int(e.get('atkPower') or 0) for e in en] or [0]) or random.randint(60, 120)
        recv_atk = random.randint(0, 3)
        while recv_atk > 0 and team_hp and recv_atk * atk >= team_hp:
            recv_atk -= 1            # 倒れるほどは受けない
        recv = recv_atk * atk
        result_hp = (team_hp - recv) if team_hp else random.randint(500, 900)
        # フィーバーは実機の2プレイ(18秒・21秒)でも 0。短い周ではまず起きない。
        fever = 1 if (clear_sec >= 10 and random.random() < 0.1) else 0

        # ダメージ・消した数はチーム全員に散らす。実機では盤面のぷにの出方で
        # 5体それぞれが攻撃するので、先頭1体が全部やった記録にはならない。
        n = len(yk)
        weights = [random.uniform(0.6, 1.6) for _ in range(n)]
        if weights:
            weights[random.randrange(n)] *= random.uniform(1.3, 2.0)   # 主力が1体いる
        dmg_parts = _split(dmg, weights)
        erase_parts = _split(erase_num, weights)
        top = max(range(n), key=lambda i: weights[i]) if n else -1
        skill_budget = random.randint(0, 4)
        users = []
        # 妖怪ごとの値を先に決め、全体の値(eraseSizeAve / eraseSizeMax / linkSizeMax)は
        # そこから計算する(実機の gameEnd はそうなっている。別々に乱数で決めると
        # 「合計と平均が合わない」申告になる)。
        erase_size_total = 0
        for i, y in enumerate(yk):
            d_i = dmg_parts[i]
            e_i = erase_parts[i]
            skill = min(skill_budget, random.randint(0, 2))
            skill_budget -= skill
            e_size = int(e_i * random.uniform(*ERASE_SIZE_RATIO_RANGE)) if e_i else 0
            erase_size_total += e_size
            # いちばん大きく消した1回(eraseSizeMax)は、その妖怪が消した合計(eraseSize)を
            # 超えない。最大リンクも eraseSizeMax を超えない(実機の10行すべてでそうなっている)。
            e_max = (erase_size_max if i == top else random.randint(3, erase_size_max)) if e_i else 0
            e_max = min(e_max, e_size) if e_i else 0
            l_max = (link_size if i == top else random.randint(2, link_size)) if e_i else 0
            l_max = min(l_max, e_max) if e_i else 0
            users.append({
                'damageMax': int(d_i * random.uniform(*DAMAGE_MAX_RATIO_RANGE)) if d_i else 0,
                'damageTotal': d_i,
                'eraseNum': e_i,
                'eraseSize': e_size,
                'eraseSizeMax': e_max,
                'linkSizeMax': l_max,
                'recoveryActual': 0, 'recoveryMax': 0, 'sSkillUseNum': 0,
                'skillUseNum': skill,
                'youkaiId': y.get('youkaiId'),
            })
        if users:
            erase_size_max = max(u['eraseSizeMax'] for u in users)
            link_size = max(u['linkSizeMax'] for u in users)
        # 平均は切り捨てで2桁(実測: 66÷31=2.129 → "2.12")。
        avg_block = (int(erase_size_total * 100 / erase_num) / 100.0) if erase_num else 0.0
        # 敵ごとのドロップ。抽選はサーバが gameStart で済ませていて、結果は
        #   lotItemInfoList   "確認キー|1"        … 1 ならアイテム(dropItemId)が落ちる
        #   lotYoukaiInfoList "確認キー|10111"    … 5桁は[好物なし, 小, 中, 大, 特大]ごとの
        #                                         結果。好物は使わないので先頭の桁を使う
        #   lotTreasureFlg    1                   … 宝箱(dropItemType 15 の dropItemId)が落ちる。
        #                                         こちらは dropTreasureFlg/dropTreasureId で申告
        #                                         する(実機: 29701001 で lotTreasureFlg 1 →
        #                                         dropTreasureFlg 1, dropTreasureId 21309012 →
        #                                         応答 treasureData で受け取り)
        # で渡される。クライアントはそれをそのまま申告する(実機の gameEnd で確認)。
        # deadEndType は実機の gameEnd では常に 0(復号した2プレイとも)。妖怪IDを入れると
        # 実機に無い形になるので 0 にする。
        enemies = []
        for i, e in enumerate(en):
            item_key, item_lot = self._lot(e.get('lotItemInfoList'))
            youkai_key, youkai_lot = self._lot(e.get('lotYoukaiInfoList'))
            item_id = int(e.get('dropItemId') or 0)
            is_treasure = int(e.get('dropItemType') or 0) == TREASURE_ITEM_TYPE
            treasure_flg = 1 if (is_treasure and item_id
                                 and str(e.get('lotTreasureFlg') or '0') == '1') else 0
            item_flg = 1 if (not is_treasure and item_lot[:1] == '1' and item_id) else 0
            youkai_flg = 1 if youkai_lot[:1] == '1' else 0
            enemies.append({
                'deadEndOrder': i + 1, 'deadEndType': 0,
                'dropItemCheckKey': item_key,
                'dropItemFlg': item_flg, 'dropItemId': item_id if item_flg else 0,
                'dropTreasureFlg': treasure_flg,
                'dropTreasureId': item_id if treasure_flg else 0,
                'dropYoukaiCheckKey': youkai_key,
                'dropYoukaiFlg': youkai_flg, 'enemyId': e.get('enemyId'), 'itemId': 0,
                'useItemLLarge': 0, 'useItemLarge': 0, 'useItemMiddle': 0, 'useItemSmall': 0,
            })
        return {
            'stageId': stageId, 'battleType': battleType, 'requestId': str(reqId),
            'damageTotal': dmg, 'score': score,
            'userYoukaiResultList': users, 'enemyYoukaiResultList': enemies,
            'bonusBlockNum': random.randint(0, 3), 'cheatFlg': 0, 'clearTimeLongSec': 0,
            'clearTimeSec': int(clear_sec),
            'comboMax': combo_max, 'eraseNumTotal': erase_num,
            'eraseSizeAve': f"{avg_block:.2f}",
            'eraseSizeMax': erase_size_max, 'eventPoint': 0, 'eventSubPoint': 0,
            'eventTeamPoint': 0, 'feverTimeNum': fever,
            'linkSizeMax': link_size, 'pauseAtkNum': 0, 'recvDamageTotal': recv,
            'resultRecvAtkNum': recv_atk,
            'resultYoukaiHP': result_hp, 'scoreLog': '',
            'spMissionIntValue1': 0, 'suspendFlg': 0, 'themeResultList': [],
            'ywp_mst_game_const': GAME_CONST,
        }

    @staticmethod
    def _lot(value) -> tuple:
        """gameStart の抽選の欄 "確認キー|結果" を (確認キー, 結果の文字列) に分ける。
        無ければ ("00000", "0")。"""
        parts = str(value or '').split('|')
        key = parts[0] if parts and parts[0] else '00000'
        lot = parts[1] if len(parts) > 1 and parts[1] else '0'
        return key, lot

    @staticmethod
    def drops_from_end(js) -> dict:
        """gameEnd の応答から、もらった妖怪とアイテムを取り出す。
        {"youkai": [youkaiId, ...], "items": [(itemId, 個数), ...]}"""
        out = {"youkai": [], "items": []}
        if not isinstance(js, dict):
            return out
        y = js.get("youkai")
        if isinstance(y, dict):
            try:
                yid = int(y.get("youkaiId") or 0)
            except (TypeError, ValueError):
                yid = 0
            if yid:
                out["youkai"].append(yid)
        ug = js.get("userGameResultData")
        if isinstance(ug, dict):
            try:
                rid = int(ug.get("rewardYoukaiId") or 0)
            except (TypeError, ValueError):
                rid = 0
            if rid and rid not in out["youkai"]:
                out["youkai"].append(rid)
        for it in js.get("userItemResultList") or []:
            if not isinstance(it, dict):
                continue
            try:
                iid = int(it.get("itemId") or 0)
                cnt = int(it.get("itemCnt") or 1)
            except (TypeError, ValueError):
                continue
            if iid:
                out["items"].append((iid, cnt))
        return out

    def battle(self, stageId, battleType=None, wait=None, clear_sec=None):
        """1周(gameStart → gameEnd)。戻り値 (rc, gameEndの応答)。

        gameStart のあと wait 秒だけ空けてから gameEnd を送る。申告するクリア秒数
        clear_sec は必ず wait より短くする(実機はクリアのあと演出が終わってから
        gameEnd を送るので、「かかった時間より長くプレイした」形にはならない)。
        wait / clear_sec 未指定なら _round_timing() の値を使う。
        """
        self.last_drops = {"youkai": [], "items": []}
        self.last_start = {}
        self.last_end = {}
        self.last_lot_hit = False
        auto_type = battleType is None
        if auto_type:
            battleType = auto_battle_type(stageId)
        # 強敵(ボス)のステージは通常の battleType では rc=100(「データの更新があります」=
        # その形のステージが無い)で弾かれる(実測: 裏会場のボス 29704007)。強敵はイベント
        # 進行では扱わない(別メニュー)ので、ここでは入り直さない。強敵を叩くときは呼び出し側が
        # battleType を明示する。
        rc, js = self.call('gameStart.nhn', {'stageId': stageId, 'battleType': battleType,
                                             'battleCode': '', 'retryFlg': 0})
        self.last_battle_type = battleType
        self.last_fail_call = ''
        if js.get('resultCode') != 0:
            self.last_fail_call = 'gameStart'
            return js.get('resultCode'), js
        self.last_start = js
        if not js.get('ywp_user_data'):
            # 人魂はこの gameStart で減ったのに、減った後の値を取り込めていない。
            self._user_data_stale = True
        # 妖怪の抽選(サーバが gameStart で済ませる)が当たりの敵がいるか。強敵取得の記録用。
        self.last_lot_hit = any(self._lot(e.get('lotYoukaiInfoList'))[1][:1] == '1'
                                for e in (js.get('enemyYoukaiList') or []) if isinstance(e, dict))
        if wait is None or clear_sec is None:
            play, _, clear = _round_timing()
            if wait is None:
                wait = play
            if clear_sec is None:
                clear_sec = clear
        wait = max(0.0, float(wait))
        clear_sec = max(MIN_CLEAR_SEC, int(clear_sec))
        if wait < clear_sec + END_LAG_MIN:
            # 待ちが申告より短い(呼び出し側の指定が短すぎる)。申告を縮めるのではなく、
            # 待ちを申告 + 演出待ちまで延ばす(「かかった時間より長くプレイした」形にしない)。
            wait = clear_sec + random.uniform(END_LAG_MIN, END_LAG_MAX)
        time.sleep(wait)
        ge = self.build_game_end(stageId, battleType, js, clear_sec=clear_sec)
        rc, end = self.call('gameEnd.nhn', ge)
        # もらった妖怪・アイテム(周回の記録とまとめに出す)。
        if isinstance(end, dict) and end.get('resultCode') == 0:
            self.last_end = end
            self.last_drops = self.drops_from_end(end)
        else:
            self.last_fail_call = 'gameEnd'
            self.last_drops = {"youkai": [], "items": []}
        return rc, end



# ============================================================================
# 代行のランナー(Cogから使う入口)
# ============================================================================

# アプリ版が古くて弾かれて止まったときの説明(お客さんのDMにそのまま出る)。「更新して
# やり直します」とは書かない。やり直すかどうかは呼び出し側(Cog)が決める(その場で版を
# 合わせて1回だけ流し直す/後追いに回す/人に引き継ぐ)。
STALE_STOP_TEXT = ("アプリのバージョンが古い可能性があります（{detail}）。"
                   "こちらでバージョンを合わせて対応します")

# --- ゲーム通信のスレッド ---------------------------------------------------
#
# ゲームの通信(requests / curl_cffi)は同期なので、スレッドで回す。asyncio.to_thread は
# イベントループ既定のスレッドプール(CPU数+4本)を使うが、そこは aiohttp が discord.com の
# 名前解決(getaddrinfo)にも使っている。周回を何本も同時に回して既定のプールを埋めると、
# 名前解決が順番待ちになり、Discord への返信(DM・進捗・ボタンの応答)まで止まる。
# だからゲーム通信は専用のプールに分ける。本数は同時に回せる人数(PUNI_MAX_CONCURRENT。
# Cogs/puni.py と同じ既定)の2倍に余裕を足す(1人が同時に使うのは1本だが、応答が戻らず
# 置き去りにしたスレッドが残っても、ほかの人の周回が順番待ちにならないように)。
# Cog はこのモジュールを import するので、ここから Cog は読まない(env を直接読む)。
GAME_THREADS = max(1, int(os.getenv(
    "PUNI_GAME_THREADS", str(int(os.getenv("PUNI_MAX_CONCURRENT", "10")) * 2 + 4))))
_GAME_POOL = concurrent.futures.ThreadPoolExecutor(max_workers=GAME_THREADS,
                                                   thread_name_prefix="puni-game")

# PuniRunner がゲーム通信の戻りを待つ上限(秒。プールの順番待ちも含む)。
# post_nhn の1回の送信は curl_cffi の timeout=30(接続から受け取りまで全部で30秒)で切れ、
# 間を空けて3回までやり直すので、1回の呼び出しは長くても2分ほどで戻る。1周(gameStart →
# プレイの待ち → gameEnd)はその2回分に、プレイの待ち(十数秒)と全体の送信間隔(_pace)の
# 順番待ちを足しても数分に収まる。ログイン(init → active を数回 → getGdkeyAccounts の
# 反映待ち → login)と人魂の購入(候補を順に当たる・マスタを読む)は通信の回数が多いので
# 長めに取る。マップの動きをまねる軽い通信(1〜数回の送信)は短く。これを超えても戻らない
# のは、スレッドがどこかで固まっている(通信の途中で止まったまま)ということ。待ち続けると
# 周回ごと黙って止まり、結果もお客さんに届かないので、見切りをつけてそこまでの結果で終える。
BATTLE_TIMEOUT = float(os.getenv("PUNI_BATTLE_TIMEOUT", "600"))
SLOW_CALL_TIMEOUT = float(os.getenv("PUNI_SLOW_CALL_TIMEOUT", "1800"))
LIGHT_CALL_TIMEOUT = float(os.getenv("PUNI_LIGHT_CALL_TIMEOUT", "180"))

# 応答が戻らず置き去りにしたゲーム通信(ゲームの userId(文字列) → concurrent.futures.Future の
# リスト)。走っているスレッドは止められない。固まったスレッドは古い token を持ったまま、
# いつか通信を終えるかもしれない。その間に同じ垢へ入り直すと(再注文・後追い)、token が
# 食い違って両方おかしくなる。Cog はこれが空になるまで、その垢の次の代行を始めない
# (pending_game_calls / wait_pending_game_calls)。asyncio の Future ではなくスレッド側の
# Future を持つのは、ループに関係なく「スレッドが終わったか」をそのまま読めるから。
_PENDING_CALLS: dict = {}
_PENDING_LOCK = threading.Lock()


async def _in_game_pool(fn, *args):
    """fn(*args) をゲーム通信用のスレッド(_GAME_POOL)で回して待つ(asyncio.to_thread の代わり)。"""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(_GAME_POOL, functools.partial(fn, *args))


def _consume_result(fut) -> None:
    """置き去りにした呼び出しの結果を読み捨てる(例外を誰も読まないと asyncio が警告を出す)。"""
    if not fut.cancelled():
        fut.exception()


def _note_pending_call(user_id, step: str, cfut) -> None:
    key = str(user_id)
    with _PENDING_LOCK:
        _PENDING_CALLS.setdefault(key, []).append(cfut)
    # いつか戻ったら記録に残す(固まっていたのか、ただ遅かったのかを後で追える)。
    cfut.add_done_callback(lambda f: print(
        f"[PUNI] 置き去りにしたゲーム通信が戻りました（{step}・userId {key}）", flush=True))


def pending_game_calls(user_id) -> list:
    """その垢(ゲームの userId)で、応答が戻らず置き去りにしたまま、まだ終わっていない
    ゲーム通信(concurrent.futures.Future)の一覧。終わったものはここで捨てる。

    空なら、その垢の token を握ったまま走っているスレッドは残っていない。
    """
    key = str(user_id)
    with _PENDING_LOCK:
        left = [f for f in _PENDING_CALLS.get(key, ()) if not f.done()]
        if left:
            _PENDING_CALLS[key] = left
        else:
            _PENDING_CALLS.pop(key, None)
        return list(left)


async def wait_pending_game_calls(user_id, timeout: float) -> bool:
    """置き去りにしたゲーム通信が終わるのを最大 timeout 秒待つ。全部終わっていれば True。

    待つだけで取り消しはしない(走っているスレッドは止められない)。
    """
    left = pending_game_calls(user_id)
    if not left:
        return True
    waits = [asyncio.wrap_future(f) for f in left]
    for w in waits:
        w.add_done_callback(_consume_result)
    await asyncio.wait(waits, timeout=max(0.0, float(timeout)))
    return not pending_game_calls(user_id)


# --- 途中経過(再起動をまたいで続きから流す) ----------------------------------
#
# bot の更新で止めた注文は、Cog が保存した途中経過(farm / hunt_boss / _progress が
# on_checkpoint に渡した state)を resume に渡して、新しいプロセスで続きを流す。数(成功した
# 周・人魂を買った回数など)は前回までの分から数え始めるので、上限(試行の上限・目標の数)も
# 結果の数字も注文全体の通しになる。どこから進めるか(進行のステージ)は
# 途中経過ではなく垢の実際の進み具合から決める(run_progress_*)。
def _resume_int(resume, key: str) -> int:
    """途中経過の数を読む。無い・壊れているときは 0。"""
    try:
        return max(0, int((resume or {}).get(key) or 0))
    except (TypeError, ValueError, AttributeError):
        return 0


def _resume_drops(resume) -> dict:
    d = resume.get("drops") if isinstance(resume, dict) else None
    return {"youkai": _resume_int(d, "youkai"), "items": _resume_int(d, "items")}


def _resume_flag(resume, key: str) -> bool:
    return isinstance(resume, dict) and bool(resume.get(key))


# 人魂の購入は、投げる直前に「買いかけ」(buy_inflight)を途中経過に残し、結果が分かって
# から消す(先に書く)。購入の最中に落ちると、買えたかどうかが分からない。買えなかった側に
# 数えると、再開のたびに上限より1回多く買えてしまう(ワイマネーを上限以上に使う)。
# だから買いかけは買った側に数える(表示が1回多くなることはあるが、上限は超えない)。
def _resume_bought(resume) -> int:
    """途中経過の、人魂を買った回数。買いかけ(buy_inflight)も1回として数える。"""
    return _resume_int(resume, "bought") + (1 if _resume_flag(resume, "buy_inflight") else 0)


# ---- 強敵完凸の判定 ----
#
# 完凸かどうかは、ゲームが持っている「その妖怪の行」(ywp_user_youkai の表)で見る。
# 同じ妖怪をもう1体取ったときに行が動くうちは、まだ重ねる余地がある。取ったのに
# 行が動かなくなったら、それ以上は重ならない＝完凸。列の並び(どの欄が凸の数か)は
# 分かっていないので、欄の意味は決め打ちしない。どの欄がどう動いたかは毎回記録に残す。
#
# 取得と関係なく動く欄(デッキに入れていれば戦うたびに増える経験値など)は「雑音」として
# 覚えておき、取得のときの比較から外す(外さないと、完凸しても経験値が動くせいで
# いつまでも止まらない)。時刻らしい欄(UNIX 秒・ミリ秒)の変化も同じく外す。

def _looks_like_time(value) -> bool:
    try:
        x = int(str(value))
    except (TypeError, ValueError):
        return False
    return (1_000_000_000 <= x <= 4_102_444_800
            or 1_000_000_000_000 <= x <= 4_102_444_800_000)


def _row_changes(before, after, ignore=()) -> list:
    """2つの行の、意味のある違い [(欄の番号, 前, 後), ...]。前が無ければ新しく入った印。"""
    if after is None:
        return []
    if before is None:
        return [(-1, "", "新規")]
    skip = {int(i) for i in ignore}
    out = []
    for i in range(max(len(before), len(after))):
        a = before[i] if i < len(before) else ""
        b = after[i] if i < len(after) else ""
        if a == b or i in skip:
            continue
        if _looks_like_time(a) and _looks_like_time(b):
            continue
        out.append((i, a, b))
    return out


def _changes_text(changes) -> str:
    if any(i == -1 for i, _, _ in changes):
        return "新しく入った"
    return ", ".join(f"欄{i}: {a}→{b}" for i, a, b in changes)[:160]


def _dup_result(info, target):
    """gameEnd の youkai から、同じ妖怪を重ねて取ったときに何が上がったかを読む。

    ぷにぷには重ねると、まずひっさつわざ(LV1→MAX)が上がり、ひっさつわざが MAX に
    なってから限界突破(+0→+10)が上がる。ゲームがどちらも前後の値で返すので、完凸か
    どうかは行の見比べよりこちらで決める。完凸の妖怪を重ねるとワイマネーに換わる
    (exchgYmoney)。

    戻り値 {"limit": (前, 後), "skill": (前LV, 後LV, 前exp, 後exp, MAXか) か None,
    "exchg": ワイマネー}。その妖怪でない・限界突破が読めないときは None。
    """
    if not isinstance(info, dict):
        return None
    try:
        if int(info.get("youkaiId") or 0) != int(target):
            return None
        before, after = info.get("limitLevelBefore"), info.get("limitLevelAfter")
        if before is None or after is None:
            return None
        out = {"limit": (int(before), int(after)), "skill": None,
               "exchg": int(info.get("exchgYmoney") or 0)}
    except (TypeError, ValueError):
        return None
    skill = info.get("skill")
    if isinstance(skill, dict):
        sb, sa = skill.get("before") or {}, skill.get("after") or {}
        try:
            out["skill"] = (int(sb.get("level") or 0), int(sa.get("level") or 0),
                            int(sb.get("exp") or 0), int(sa.get("exp") or 0),
                            bool(skill.get("isMaxLevel")))
        except (TypeError, ValueError, AttributeError):
            pass
    return out


def _limit_stage(lim: dict) -> str:
    """結果の文面に添える、いまの段階(「ひっさつわざLV2・限界突破+0・」の形)。"""
    parts = []
    if lim.get("skill") is not None and not lim.get("skill_max"):
        parts.append(f"ひっさつわざLV{lim['skill']}")
    if lim.get("limit") is not None:
        parts.append(f"限界突破+{lim['limit']}")
    return "".join(f"{p}・" for p in parts)


def _resume_limit(resume) -> dict:
    """強敵完凸の途中経過(取得した数・その妖怪の最後の行・判定の結果)を読む。

    target  … 完凸させる妖怪のID(最初に取れた妖怪)
    count   … その妖怪を取った数
    row     … その妖怪の最後に見えた行(次の取得と見比べる)
    row_init… 1体目の前の行(ログイン時の表)を読んだか
    seen    … 取得のあとの応答で、その妖怪の行が見えたことがあるか
    noise   … 取得と関係なく動いた欄の番号(比較から外す)
    maxed   … True=完凸 / False=判定できずに止めた / None=まだ
    not_owned … 頼まれた時点でその妖怪を持っていなかった(=強敵完凸の対象外。止める)
    block   … 始める前に止めた理由(持っていると確かめられなかった。空なら始めた)
    limit   … ゲームが返した、いまの限界突破の段階(読めていなければ None)
    skill   … いまのひっさつわざのLV(読めていなければ None)
    skill_max … ひっさつわざが MAX か
    """
    lim = {"target": None, "count": 0, "row": None, "row_init": False,
           "seen": False, "noise": [], "maxed": None, "not_owned": False, "block": "",
           "limit": None, "skill": None, "skill_max": None}
    old = resume.get("limit") if isinstance(resume, dict) else None
    if isinstance(old, dict):
        for key in lim:
            if key in old:
                lim[key] = old[key]
    return lim


class PuniRunner:
    """1回のログインで、指定ステージをまとめて周回する。

    email/パスからログインしたあとに得られる udkey は、その L5 アカウントに
    紐づいた状態で残る。以降のやり直し(保留から承認された後のお渡し)は、
    メール/パスではなく udkey だけで入れる。だから注文に預けるのは udkey と
    userId だけにして、生パスワードは保存しない。
    """

    def __init__(self, client: Client):
        self.client = client
        self.trace = []
        self.drops = {"youkai": 0, "items": 0}   # この注文でもらった妖怪・アイテムの数
        self._rc4 = []                # rc=4(一時エラー)が出た時刻(RC4_WINDOW_SECONDS 内)
        self._transient_stop = None   # rc=4 が続いて中止したときの説明
        # 停止の合図(DM の停止ボタンなどから立てる)。立ったら、今の周(gameEnd まで)を
        # 終えてから止め、そこまでの結果を返す。待ちの途中でも立った時点で抜ける。
        self._stop = asyncio.Event()
        # 一時停止の合図(bot の更新で Cog がプロセス全体に立てる)。止まり方は停止ボタンと同じ
        # (今の周を終えて抜ける)だが、注文は終わらせない。結果は suspended=True で返し、
        # Cog が途中経過から新しいプロセスで続きを流す。
        self._suspend = None
        self._tap_rtt = None          # userStageRanking の往復にかかる時間(ならした値。_rest で引く)
        self._last_fail = {}          # 直近に弾かれた gameStart/gameEnd の応答(記録に説明を添える)

    def attach_stop(self, event) -> None:
        """外(Cog)の停止の合図を使う。"""
        if event is not None:
            self._stop = event

    def attach_suspend(self, event) -> None:
        """外(Cog)の一時停止の合図を使う(None なら何もしない)。"""
        if event is not None:
            self._suspend = event

    def request_stop(self) -> None:
        self._stop.set()

    @property
    def stop_requested(self) -> bool:
        """停止ボタンか一時停止のどちらかが立っているか(止まるところは同じ)。"""
        return self._stop.is_set() or (self._suspend is not None and self._suspend.is_set())

    def _halt_text(self) -> str:
        """止まったときの説明。お客さんの停止ボタンが立っていれば、そちらを優先する。"""
        return STOP_TEXT if self._stop.is_set() else SUSPEND_TEXT

    def _halt_note(self) -> str:
        """記録(trace)に残す、止まった理由の短い言い方。"""
        return "停止ボタンで停止" if self._stop.is_set() else "bot の更新のため一時停止"

    def _final_stopped(self, stopped):
        """一時停止で抜けたあとに停止ボタンも押されていたら、停止ボタンを優先する
        (再起動のあとに、お客さんが止めた注文を流し直さない)。"""
        if stopped == SUSPEND_TEXT and self._stop.is_set():
            return STOP_TEXT
        return stopped

    def _checkpoint(self, on_checkpoint, state: dict, where) -> None:
        """途中経過を呼び出し側(Cog)に渡す。再起動のあと、ここから続きを流すのに使う。
        保存でこけても周回は止めない。"""
        if on_checkpoint is None:
            return
        try:
            on_checkpoint(state)
        except Exception as e:
            self.trace.append(f"{where}: 途中経過の保存に失敗({type(e).__name__})")

    async def _sleep(self, seconds: float) -> None:
        """待つ。ただし停止・一時停止の合図が立ったらすぐ抜ける(長い休みの途中でも止められる)。"""
        seconds = max(0.0, float(seconds))
        if self.stop_requested:
            return
        events = [self._stop] if self._suspend is None else [self._stop, self._suspend]
        waiters = [asyncio.ensure_future(ev.wait()) for ev in events]
        try:
            await asyncio.wait(waiters, timeout=seconds, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for w in waiters:
                w.cancel()

    def _transient_plan(self, attempt: int) -> tuple:
        """rc=4(一時エラー)が出た。どれだけ待つか、それとも止めるかを決める。

        rc=4 はサーバの「叩きすぎ」の警告と見る(BAN になった周回では 10周目から
        ほぼ毎周出て 22周目で 202 だった)。attempt はその周で何回目のやり直しか(0始まり)。
        戻り値 (待つ秒数, 中止の理由 or None)。待つのは呼び出し側。
        """
        now = time.time()
        self._rc4 = [t for t in self._rc4 if now - t <= RC4_WINDOW_SECONDS]
        self._rc4.append(now)
        n = len(self._rc4)
        if n >= RC4_STOP_COUNT:
            reason = (f"一時エラー(rc=4)が{int(RC4_WINDOW_SECONDS // 60)}分間に{n}回続いたため"
                      "中止しました（サーバに警告されている可能性があります。"
                      "時間をおいてからご注文ください）")
            self._transient_stop = reason
            return 0.0, reason
        wait = RETRY_WAITS[min(attempt, len(RETRY_WAITS) - 1)] * random.uniform(0.7, 1.3)
        if n >= RC4_REST_COUNT:
            wait += random.uniform(RC4_REST_MIN, RC4_REST_MAX)
        return wait, None

    def _fail_where(self) -> str:
        where = getattr(self.client, "last_fail_call", "") or ""
        return f"・{where}" if where else ""

    # 弾かれた応答でサーバの説明が入っていそうな欄(login.nhn では dialogMsg に入る)。
    _FAIL_MSG_KEYS = ("dialogMsg", "dialogMessage", "errorMsg", "errorMessage",
                      "resultMsg", "resultMessage", "message", "msg")
    _FAIL_SUB_KEYS = ("resultSubCode", "subCode", "errorCode")

    def _fail_hint(self) -> str:
        """直近に弾かれた gameStart/gameEnd の応答から、サーバの説明を短く添える。

        rc だけでは「今は入れない(508)」の理由が分からない(矢印の出ているステージでも
        返る)。サーバの文言があればそれを、無ければ応答にある欄の名前を残し、次に同じ
        場面を見たときの手掛かりにする。
        """
        js = getattr(self, "_last_fail", None)
        if not isinstance(js, dict) or not js:
            return ""
        parts = []
        for key in self._FAIL_MSG_KEYS:
            v = js.get(key)
            if v not in (None, ""):
                parts.append(str(v).replace("\n", " ")[:80])
                break
        for key in self._FAIL_SUB_KEYS:
            v = js.get(key)
            if v not in (None, "", 0):
                parts.append(f"{key}={v}")
        if not parts:
            keys = ",".join(sorted(str(k) for k in js.keys()))[:100]
            return f"（応答の欄: {keys}）" if keys else ""
        return "「" + " / ".join(parts) + "」"

    async def _blocking(self, step: str, fn, *args, timeout: float):
        """ゲーム通信 fn(*args) を専用のスレッド(_GAME_POOL)で回し、最大 timeout 秒待つ。

        戻れば結果を返す(例外もそのまま上げる)。時間内に戻らなければ、スレッドは取り消さずに
        (走っているスレッドは止められない)置き去りにして記録し(pending_game_calls)、
        PuniGameTimeout を投げる。呼び出し側はそこで周回を終えて、そこまでの結果を返す。
        """
        cfut = _GAME_POOL.submit(functools.partial(fn, *args))
        fut = asyncio.wrap_future(cfut)
        try:
            done, _ = await asyncio.wait({fut}, timeout=timeout)
        except asyncio.CancelledError:
            # 周回のタスクごと取り消された。スレッドは走り続けるので、同じく追えるようにする。
            self._abandon(step, cfut, fut)
            raise
        if fut not in done:
            running = self._abandon(step, cfut, fut)
            self.trace.append(f"{step}: {int(timeout)}秒待っても応答が戻らないため打ち切り"
                              + ("(スレッドは残したまま)" if running else "(順番待ちのまま取り消し)"))
            raise PuniGameTimeout(step)
        return fut.result()

    def _abandon(self, step: str, cfut, fut) -> bool:
        """戻りを待つのをやめる。まだ始まっていない(プールの順番待ち)なら取り消して、あとから
        古い token で送られないようにする。走り出したものは止められないので記録して残す
        (pending_game_calls)。戻り値は、スレッドが走ったまま残ったか。"""
        fut.add_done_callback(_consume_result)
        if cfut.cancel() or cfut.done():
            return False
        _note_pending_call(self.client.userId, step, cfut)
        return True

    async def _rest(self, seconds: float):
        """周と周のあいだの休み。実機と同じく、リザルト画面を眺めたあとマップに戻る
        (getL5IdStatus)ところまでを再現する。seconds 全体を「リザルト → マップ → 次の
        ステージをタップする直前」に配る(タップ〜gameStart の約1秒は _before_start)。

        seconds は「gameEnd が返ってから次の gameStart を送るまで」の長さ。途中の通信
        (getL5IdStatus と、このあとの userStageRanking)にかかった時間はこの中に含める。
        以前は通信の時間がまるごと上乗せされて、1周が狙い(ROUND_SECONDS)より
        通信の数ぶん長くなっていた。サーバから見た間隔(休み・プレイ時間)は狙いのまま。"""
        seconds = max(0.0, float(seconds))
        if not MIMIC_MAP_FLOW:
            await self._sleep(seconds)
            return
        loop = asyncio.get_running_loop()
        go_at = loop.time() + seconds
        rtt = self._tap_rtt or 0.0
        # リザルト画面のぶんは、通信2本(getL5IdStatus・userStageRanking)とタップ〜gameStart
        # (約1.2秒)を除いた残りから取る(短い休みでも全部が seconds の中に収まるように)。
        on_result = max(0.0, seconds - 1.2 - 2 * rtt) * random.uniform(0.55, 0.75)
        await self._sleep(on_result)
        if self.stop_requested:
            return          # 止めるときはマップに戻る通信も送らない
        # 飾りの通信でも、戻らなければ周回ごと終える(固まったスレッドが同じ token を
        # 握ったままなので、その client で通信を続けない)。
        await self._blocking("getL5IdStatus", self.client.l5_status,
                             timeout=LIGHT_CALL_TIMEOUT)
        # 残りから、タップ〜gameStart のぶん(userStageRanking の往復 + 約1.2秒)を引いて待つ。
        await self._sleep(go_at - loop.time() - 1.2 - rtt)

    async def _before_start(self, stage_id):
        """ステージをタップしてから gameStart までを再現する(userStageRanking → 約1秒)。"""
        if not MIMIC_MAP_FLOW or self.stop_requested:
            return          # 止めるときはステージをタップする通信も送らない
        loop = asyncio.get_running_loop()
        t0 = loop.time()
        await self._blocking("userStageRanking", self.client.stage_ranking, stage_id,
                             timeout=LIGHT_CALL_TIMEOUT)
        # 往復にかかった時間をならして覚え、次の休みから先に引いておく(_rest)。
        # たまの詰まり(タイムアウト等)で休みを削りすぎないよう、1回ぶんは3秒で頭打ち。
        rtt = min(3.0, loop.time() - t0)
        prev = self._tap_rtt
        self._tap_rtt = rtt if prev is None else prev * 0.7 + rtt * 0.3
        await self._sleep(random.uniform(0.8, 1.6))

    def _drop_note(self) -> str:
        """直近の周でもらった妖怪・アイテムを数えに足して、記録に添える文字列を返す。"""
        d = getattr(self.client, "last_drops", None) or {}
        ys = d.get("youkai") or []
        its = d.get("items") or []
        if not ys and not its:
            return ""
        tot = getattr(self, "drops", None)
        if not isinstance(tot, dict):
            tot = self.drops = {"youkai": 0, "items": 0}
        tot["youkai"] += len(ys)
        tot["items"] += sum(c for _, c in its)
        parts = []
        if ys:
            parts.append("妖怪 " + ",".join(str(y) for y in ys))
        if its:
            parts.append("アイテム " + ",".join(f"{i}x{c}" for i, c in its))
        return " ドロップ: " + " / ".join(parts)

    def _drop_line(self) -> str:
        """まとめに出す「ドロップ: 妖怪 n体・アイテム m個」。無ければ空。"""
        tot = getattr(self, "drops", None) or {}
        if not (tot.get("youkai") or tot.get("items")):
            return ""
        return f"ドロップ: 妖怪 {tot.get('youkai', 0)}体・アイテム {tot.get('items', 0)}個"

    @property
    def udkey(self):
        return self.client.udkey

    @property
    def user_id(self):
        return self.client.userId

    def player_name(self) -> str:
        return self.client.info().get("playerName") or "(名前不明)"

    def account_line(self) -> str:
        """お客さんに見せるアカウントの1行要約。

        通貨のキー名は版で変わりうるので、確実に読めるものだけ出す
        (名前・ユーザーID・レベル・クリア済みステージ数)。
        """
        info = self.client.info()
        name = info.get("playerName") or "(名前不明)"
        parts = [name, f"ID {self.client.userId}"]
        lv = info.get("level") or info.get("rank") or info.get("userLevel")
        if lv:
            parts.insert(1, f"Lv.{lv}")
        try:
            parts.append(f"クリア済み{len(self.client.stages())}ステージ")
        except Exception:
            pass
        # 戦うデッキ(ゲームで選択中)。特性・スキルの反映はこのデッキで決まるので、
        # お客さんが「入れたつもりのデッキ」と違うときに気づけるよう出す。
        try:
            deck = self.client.active_deck()
            parts.append(f"デッキ{deck['deck_id']}（{len(deck['youkai'])}体）")
        except Exception:
            pass
        # 人魂(スタミナ)は「無料分 freeHitodama + ボーナス分 hitodama」。ゲーム画面の
        # 「5 +6」はこの2つ(5=freeHitodama, +6=hitodama)。合計が実際の所持数。
        if "freeHitodama" in info or "hitodama" in info:
            try:
                free = int(info.get("freeHitodama") or 0)
                bonus = int(info.get("hitodama") or 0)
                parts.append(f"人魂{free}+{bonus}（計{free + bonus}）")
            except (TypeError, ValueError):
                pass
        if "ymoney" in info:
            try:
                parts.append(f"ワイマネー{int(info['ymoney']):,}")
            except (TypeError, ValueError):
                pass
        return " / ".join(str(p) for p in parts)

    def pick_farm_stage(self) -> dict:
        """周回するステージを、その垢のデータから自動で決める。

        お客さんには「周回したいステージを一度プレイ(クリアかリタイア)してから注文
        する」と案内する(強敵取得と同じ)。なので第一候補は「最後に遊んだステージ」
        (ywp_user_data.nowStageId。戦闘を終えた/リタイアした時点で更新される)。
        クリア済み(1)でも開放済み・未クリア(2 = リタイアした)でも採用する。
        強敵ステージもそのまま採用する(周回は強敵の battleType で叩く。farm を参照)。

        nowStageId が読めない/使えないときは、クリア回数(ywp_user_stage の
        7列目)が多いステージを候補にする(前に周回していたステージ)。それも無ければ
        イベントとメインの最新クリアを候補にする。

        戻り値 {"stage_id": 第一候補 or None, "how": "now"|"count"|"latest"|None,
                "candidates": [(stage_id, 短い説明), …]  # 第一候補を含む、確認画面の選び直し用
                "now_stage_id": nowStageId の生の値}
        """
        states = self.client.stage_states()
        rows_ = self.client.stages()
        cleared = {sid for sid, st in states.items() if st == 1}
        enterable = {sid for sid, st in states.items() if st in (1, 2)}

        def count_of(sid) -> int:
            row = rows_.get(sid) or []
            try:
                return int(row[6]) if len(row) >= 7 else 0
            except (TypeError, ValueError):
                return 0

        now_raw = self.client.info().get("nowStageId")
        try:
            now = int(now_raw)
        except (TypeError, ValueError):
            now = None

        candidates = []      # [(sid, note)] 順序つき・重複なし
        seen = set()

        def add(sid, note):
            if sid in seen or sid not in enterable:
                return
            seen.add(sid)
            candidates.append((int(sid), note))

        primary = None
        how = None
        if now in enterable:
            primary, how = now, "now"
            add(now, f"最後に遊んだステージ（クリア{count_of(now)}回）" if now in cleared
                else "最後に遊んだステージ（リタイア・未クリア）")

        by_count = sorted((sid for sid in cleared if count_of(sid) > 0),
                          key=lambda x: (-count_of(x), -x))
        for sid in by_count[:5]:
            add(sid, f"クリア{count_of(sid)}回")
        events = [sid for sid in cleared if sid >= EVENT_ID_MIN]
        if events:
            add(max(events), "イベントの最新クリア")
        mains = [sid for sid in cleared if MAIN_ID_MIN <= sid < MAIN_ID_MAX]
        if mains:
            add(max(mains), "メインの最新クリア")
        if primary is None and candidates:
            # nowStageId が使えない。前に周回していた(クリア回数の多い)ものを第一に。
            first = candidates[0][0]
            if now is not None and first == now:
                first = candidates[1][0] if len(candidates) > 1 else None
            if first is not None:
                primary = first
                how = "count" if count_of(first) > 1 else "latest"
        return {"stage_id": primary, "how": how, "candidates": candidates,
                "now_stage_id": now_raw}

    def stage_available(self, stage_id) -> bool:
        """周回してよいステージか。クリア済み(1)か開放済み(2)だけ許す。

        未開放/ロック(0=隠し・先の章・別条件待ち)は False にして、周回の注文を
        お代を取る前に断れるようにする(入れないステージで課金しない)。
        """
        try:
            return self.client.stage_states().get(int(stage_id)) in (1, 2)
        except (ValueError, TypeError):
            return False

    def _frontier(self, lo, hi, blocks=None):
        """[lo, hi) の範囲で「今から挑む続きのステージID」を返す。

        1) 開放済み・未クリア(state=2)があればその最小(=すぐ挑める続き。メインは
           ここが 1002001 のように save に載る)。
        2) 無ければクリア済みの最大ID+1(=次の番号)。イベントの続き(例 29701014)は
           まだ save に載っていない(未突入)ことがあり、その場合はこちらで拾う。
        3) どちらも無ければ None(=そのカテゴリは今のところ進めない)。
        ロック(state=0)の隠し/先章は「開放済み」に含めないので、そこへは自分から
        突っ込まない(進んだ結果ぶつかったら、その場で安全に止まる)。
        blocks を渡すと、その会場(千の位のまとまり)のステージだけを見る(イベントの
        表・裏に限り、別マップの会場を続きに選ばないため。_event_main_blocks)。
        """
        states = self.client.stage_states()
        in_range = [(sid, st) for sid, st in states.items()
                    if lo <= sid < hi and (blocks is None or sid // 1000 in blocks)]
        frontier = [sid for sid, st in in_range if st == 2]
        if frontier:
            return min(frontier)
        cleared = [sid for sid, st in in_range if st == 1]
        if cleared:
            return max(cleared) + 1
        return None

    @staticmethod
    def event_range(event_no) -> tuple:
        """そのイベントのステージIDの範囲 [lo, hi)。ID = イベント番号×100000 + 会場×1000 + 番号。"""
        lo = int(event_no) * 100_000
        return lo, lo + 100_000

    def current_event(self):
        """いま進めるべきイベントの番号。無ければ None。

        1) 最後に遊んだステージ(nowStageId)がイベントのものなら、そのイベント。
        2) 開放済み・未クリア(state=2)のステージがあるイベントのうち番号が最大のもの。
        3) クリア済みがあるイベントのうち番号が最大のもの。
        古いイベントの開放済みが残っていても、番号の大きい(=新しい)ほうを取る。
        """
        states = self.client.stage_states()
        try:
            now = int(self.client.info().get("nowStageId"))
        except (TypeError, ValueError):
            now = None
        if now is not None and now >= EVENT_ID_MIN and now in states:
            return now // 100_000
        for wanted in ((2,), (1,)):
            events = [sid // 100_000 for sid, st in states.items()
                      if sid >= EVENT_ID_MIN and st in wanted]
            if events:
                return max(events)
        return None

    def _event_main_blocks(self, event_no) -> set:
        """そのイベントで「表・裏のマップ」とみなす会場(千の位)の集まり。

        表→裏のマップは会場01, 02, 03… と続き番号で並ぶ(実測: 299 は表=01/02・裏=03、
        297 は裏=04)。GTオイル給油所(299 の会場11)のような別マップは離れた番号に置かれ、
        お客さんが頼んだ「イベントステージ進行」の対象ではない。垢の表に載っている会場の
        うち、01 から切れ目なく続いているところまでを対象にし、離れた会場は含めない
        (続きの開始・残りの数え・飛び先のどれにも使わない)。
        """
        lo, hi = self.event_range(event_no)
        present = {sid // 1000 for sid in self.client.stage_states() if lo <= sid < hi}
        first = lo // 1000 + 1              # 会場01
        main = set()
        block = first
        while block in present:
            main.add(block)
            block += 1
        return main

    def event_known_ids(self, event_no) -> list:
        """そのイベントの表・裏の会場で、垢のステージ表に載っている全ID(ロック中も含む)を
        昇順で。終端やロックで飛ぶ先の候補になる(_progress の known_ids)。

        離れた会場(別マップ。_event_main_blocks を参照)は入れない。入れると、表・裏を
        進め終わったあとにそこへ飛んで、頼まれていないマップを進めてしまう
        (実測: 299 の GTオイル給油所 29911001〜003 を進めた)。
        """
        lo, hi = self.event_range(event_no)
        main = self._event_main_blocks(event_no)
        return sorted(sid for sid in self.client.stage_states()
                      if lo <= sid < hi and sid // 1000 in main)

    def event_remaining(self, event_no) -> int:
        """そのイベントの表・裏の会場で、表に載っていてまだクリアしていないステージの数。

        0 なら表の上では全部クリア済み。お代を受け取る前にこれを見て、
        「進めるものが無い」注文を断る(表に載っていない先のステージは
        分からないので、0 でないときだけ進める)。別マップの残りは数えない。
        """
        lo, hi = self.event_range(event_no)
        main = self._event_main_blocks(event_no)
        return sum(1 for sid, st in self.client.stage_states().items()
                   if lo <= sid < hi and sid // 1000 in main and st != 1)

    def event_locked_ids(self, event_no) -> list:
        """そのイベントの表・裏の会場で、表に state=0(未開放・ロック)で載っているID(昇順)。

        実測(イベント299): 29903004/005 がこの状態で gameStart は 508(隠しステージなどの
        別枠らしく、裏マップの続きは別の番号で通る)。結果の説明に添えるだけで、これを理由に
        注文を断ったり続きを決めたりはしない(表に載っていない続きが分からないため)。
        """
        lo, hi = self.event_range(event_no)
        main = self._event_main_blocks(event_no)
        return sorted(sid for sid, st in self.client.stage_states().items()
                      if lo <= sid < hi and sid // 1000 in main and st == 0)

    def event_stage_rows(self, event_no) -> list:
        """そのイベントのステージ表の行をそのまま(診断用。非公開ログに添付する)。

        どのIDがどの会場に載っていて、状態の欄が何か、会場のどれを表・裏とみなしたかを
        実際の垢で確かめる材料。"""
        lo, hi = self.event_range(event_no)
        main = self._event_main_blocks(event_no)
        out = [f"表・裏とみなした会場: {sorted(main) or 'なし'}"]
        for sid, row in sorted(self.client.stages().items()):
            if lo <= sid < hi:
                out.append("|".join(str(c) for c in row)
                           + ("" if sid // 1000 in main else "   (別マップ)"))
        return out

    def event_resume_point(self, event_no=None):
        """今進めるべきイベントの続きのステージID(開放済み・未クリアの最小)。

        event_no を省くと current_event() で決める。開放済み・未クリアが無ければ
        クリア済みの最大+1(まだ表に載っていない続き)、それも無ければ None。
        無理にロックへ突っ込まない(進んだ結果ぶつかったら、その場で止まる)。
        """
        if event_no is None:
            event_no = self.current_event()
        if event_no is None:
            return None
        lo, hi = self.event_range(event_no)
        # 表・裏の会場だけを見る(別マップが開放済みで残っていても、そこを続きにしない)。
        return self._frontier(lo, hi, self._event_main_blocks(event_no))

    def main_resume_point(self):
        """メインストーリーの続きのステージID(開放済み・未クリア state=2 の最小)。

        例: 1001016 までクリア → 次は 1002001(state=2)。ロックの先章には行かない。
        """
        return self._frontier(MAIN_ID_MIN, MAIN_ID_MAX)

    def boss_target(self, event_no=None) -> dict:
        """強敵取得で挑戦する強敵ステージを、その垢のデータから決める。

        今のイベントの強敵ステージ(裏マップ。チュートリアル一覧の種別 13 に並ぶID)のうち、
          1) 最後にプレイしたステージ(nowStageId。戦闘を終えた/リタイアした時点で更新される)
             がその1つなら、それ(お客さんが選んだ強敵)。
          2) でなければ、裏マップの「続き」(_frontier: 開放済み・未クリアの最小、無ければ
             クリア済みの最大+1)。まだ届いていない先の強敵は選ばない(ロックで入れない)。
          3) 続きが無い(全部クリア済み)なら、いちばん番号の大きいもの(裏マップの最後＝
             本命の強敵。実測のイベント297では 29704006 が HP 1,270万)。
        イベントの強敵ステージが1つも無ければ stage_id は None。

        チュートリアル一覧はマスタ由来で、まだ開放していない(過去イベントも含む)強敵まで
        並ぶ。だから「その垢が裏マップ(強敵)を開いているか」は別にステージ表で見る:
        venue_open = 強敵のブロック(千の位のまとまり)のどれかが表に開放済み/クリア済み
        (1/2)で載っているか。表に無い(None)強敵は、裏マップを開いていれば「まだ入っていない
        続き」、開いていなければ「未解放」なので、locked は venue_open と合わせて決める。

        戻り値 {"stage_id", "event_no", "how": "now"|"next"|"last"|None, "candidates": [...],
                "state": ステージ表の状態(1=クリア済み/2=開放済み/0=ロック/None=表に無い),
                "venue_open": 裏マップを開いているか, "locked": 入れないと分かっているか}
        """
        if event_no is None:
            event_no = self.current_event()
        out = {"stage_id": None, "event_no": event_no, "how": None,
               "candidates": [], "state": None, "venue_open": False, "locked": False}
        if event_no is None:
            return out
        lo, hi = self.event_range(event_no)
        ids = [sid for sid in self.client.boss_stage_ids() if lo <= sid < hi]
        if not ids:
            return out
        out["candidates"] = ids
        try:
            now = int(self.client.info().get("nowStageId"))
        except (TypeError, ValueError):
            now = None
        if now in ids:
            out["stage_id"], out["how"] = now, "now"
        else:
            block_lo = (max(ids) // 1000) * 1000
            frontier = self._frontier(block_lo, block_lo + 1000)
            if frontier in ids:
                out["stage_id"], out["how"] = frontier, "next"
            else:
                out["stage_id"], out["how"] = max(ids), "last"
        states = self.client.stage_states()
        out["state"] = states.get(out["stage_id"])
        block = out["stage_id"] // 1000
        out["venue_open"] = any(sid // 1000 == block and st in (1, 2)
                                for sid, st in states.items())
        out["locked"] = out["state"] == 0 or (out["state"] is None and not out["venue_open"])
        return out

    def _stamina_stop_message(self) -> str:
        """スタミナ切れ＋買い足し不可で止まるときの説明。今のワイマネーを添える。

        ワイマネーは直近の gameStart / gameEnd / 購入の応答から取り込んだ値(call)。
        入り直して読み直すことはしない(実機はプレイ中に login を投げ直さない)。
        値段は固定せず「買えるパックが見つからなかった」と正直に伝える(安いパックから
        順に探して、どれも買えなかったときにここへ来る)。
        """
        ymoney = None
        try:
            if "ymoney" in self.client.info():
                ymoney = self.client.ymoney()
        except Exception:
            ymoney = None
        if ymoney is not None:
            base = (f"人魂(スタミナ)が切れました。今のワイマネー({ymoney:,})で買える"
                    "人魂パックが見つからず中止しました")
        else:
            base = "人魂(スタミナ)が切れ、買える人魂パックが見つからず中止しました"
        # 買えなかった理由(rc)と送信中のマスタ版を添える。rc=100(データの更新が
        # あります)なら、店だけがマスタ版を厳しく見て弾いている＝原因の切り分けになる。
        rc = getattr(self.client, "last_buy_fail_rc", None)
        if rc:
            base += f"（購入は rc={rc}・マスタ版{self.client.mst} で弾かれました）"
        return base

    async def farm(self, stage_id, rounds, on_progress=None, resume=None,
                   on_checkpoint=None) -> dict:
        """指定ステージを rounds 回まわす。

        戻り値 {"ok", "warning", "cleared", "failed", "bought", "stopped", "suspended",
        "stale_version", "account", "lines", "trace", "buy_diag", "state"}。
        BAN(202)・署名やtokenの致命的エラー(30/32)は即中止。
        アプリ版が古い(rc=20/101)ときも即中止して stale_version を立てる
        (呼び出し側がバージョンを更新して立て直す)。スタミナ切れ等で連続して
        空振りするようなら、MAX_CONSECUTIVE_FAILS で打ち切る。

        BAN対策として、周ごとの待ちは毎回ゆらがせ、何周かに一度は人がひと息
        つくくらいの長い休みを入れる(1プレイの結果や所要時間の散らしは
        Client.battle / build_game_end 側で行う)。

        途中経過 state = {"cleared", "failed", "bought", "drops": {"youkai", "items"},
        "attempts"}。成功した周・人魂の購入のたびと、返す直前に on_checkpoint(state)
        (同期の関数)を呼ぶ。人魂の購入を投げてから結果が分かるまでは "buy_inflight": True も
        付く(先に書く。再開のときは購入1回として数え、続けて rc=5 なら買い直さずに止める)。
        resume にこの形を渡すと、その数から続きを回す(rounds は注文全体の周数のまま。
        試行の上限も全体で数える)。
        一時停止(attach_suspend)で抜けたときは suspended=True・ok=False で返す。
        """
        stage_id = int(stage_id)
        rounds = int(rounds)
        self.drops = _resume_drops(resume)
        cleared = _resume_int(resume, "cleared")
        failed = _resume_int(resume, "failed")
        streak = 0
        transient_tries = 0   # この周で一時エラー(rc=4)をやり直した回数
        bought = _resume_bought(resume)   # 人魂を買い足した回数(注文全体。買いかけも数える)
        bought_since_battle = 0   # 直近の戦闘から人魂を買った回数(rc=5 が続くときの歯止め)
        buy_inflight = False      # 人魂の購入を投げて、まだ結果が分からない(途中経過に残す)
        relogged = False      # tokenズレ(rc=32)で入り直したか(1回だけ)
        stopped = None
        stale_version = False
        # 強敵ステージは強敵の battleType で叩く(強敵取得の hunt_boss と同じ)。通常の
        # battleType では rc=100 で弾かれる。強敵かどうかは垢のチュートリアル一覧
        # (種別 13)で見る。古いイベントの一部は battle() が自分で強敵の型にする。
        try:
            is_boss = stage_id in set(self.client.boss_stage_ids())
        except Exception:
            is_boss = False
        is_boss = is_boss or auto_battle_type(stage_id) == BOSS_BATTLE_TYPE
        battle_type = BOSS_BATTLE_TYPE if is_boss else None
        tutorial_done = not is_boss
        if is_boss:
            self.trace.append("強敵ステージのため、強敵の形(battleType 6)で周回します")

        # 「n周」は成功した周の数。失敗した周(サーバの一時エラーなど)は数に入れず、成功が
        # n に届くまで回す。暴走よけに、試行の回数には上限を置く(失敗続きは streak で止まる)。
        # 上限は注文全体の周数で決め、再開したときは前回までの試行の続きから数える。
        max_attempts = rounds + max(10, rounds // 10)
        retried_once = False   # この周を RETRY_ONCE_RC でやり直したか
        i = max(_resume_int(resume, "attempts"), cleared)
        attempts = i           # 実際に gameStart を投げた試行の番号(途中経過に残す)
        if resume:
            self.trace.append(f"再開: 前回までに成功{cleared}周・試行{attempts}回"
                              + (f"・人魂購入{bought}回" if bought else ""))
        if _resume_flag(resume, "buy_inflight"):
            # 前回は人魂の購入の途中で落ちた。買えたものとして数え(二重に買わない)、続けて
            # rc=5 なら買い直さずに止める(買い足した直後の rc=5 と同じ扱い)。
            bought_since_battle = 1
            self.trace.append("再開: 前回は人魂の購入の途中で止まったため、購入1回として数えます")
        # 次に長い休みを入れる周。人は同じ間隔では休まないので、都度ずらす(再開したときは
        # そこから数える。再開の直後にいきなり長い休みを入れない)。
        next_break = i + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
        next_long_break = i + random.randint(LONG_BREAK_EVERY_MIN, LONG_BREAK_EVERY_MAX)

        def state() -> dict:
            st = {"cleared": cleared, "failed": failed, "bought": bought,
                  "drops": dict(self.drops), "attempts": attempts}
            if buy_inflight:
                st["buy_inflight"] = True
            return st

        try:
            # ログイン直後にいきなり gameStart しない(タイトル→マップ→ステージ選択の時間)。
            if cleared < rounds:
                await self._rest(random.uniform(WARMUP_SECONDS_MIN, WARMUP_SECONDS_MAX))
            while cleared < rounds and i < max_attempts:
                i += 1
                if self.stop_requested:
                    stopped = self._halt_text()
                    self.trace.append(f"{i}: {self._halt_note()}")
                    break
                if on_progress is not None:
                    try:
                        await on_progress(i, rounds, cleared)
                    except Exception as e:
                        # 進捗の表示(DM の書き換え)がこけても周回は止めない。
                        self.trace.append(f"{i}: 進捗の通知に失敗({type(e).__name__})")
                # IPごと弾かれた気配があれば、全体停止が解けるまで待つ。
                hold = global_hold_remaining()
                if hold > 0:
                    self.trace.append(f"{i}: 全体停止中のため{int(hold)}秒待機")
                    await self._sleep(hold + random.uniform(1.0, 5.0))
                    if self.stop_requested:
                        # 待っている間に停止ボタン。明けてから gameStart を送らない。
                        stopped = self._halt_text()
                        self.trace.append(f"{i}: {self._halt_note()}")
                        break
                # 1周の時間配分を決める。プレイ時間と申告クリア秒は battle に渡し、残りは周間の休みに使う。
                play_sec, rest_sec, clear_sec = _round_timing()
                await self._before_start(stage_id)
                if self.stop_requested:
                    # ステージを選ぶ間に停止ボタン。gameStart を送る前なので、ここで止めても
                    # 始めたプレイを放り出すことにはならない。
                    stopped = self._halt_text()
                    self.trace.append(f"{i}: {self._halt_note()}")
                    break
                rc, result = await self._blocking("gameStart/gameEnd", self.client.battle,
                                                  stage_id, battle_type, play_sec, clear_sec,
                                                  timeout=BATTLE_TIMEOUT)
                attempts = i
                code = result.get("resultCode") if isinstance(result, dict) else None
                if code == 0:
                    cleared += 1
                    streak = 0
                    transient_tries = 0
                    bought_since_battle = 0
                    retried_once = False
                    self.trace.append(f"{i}: OK" + self._drop_note())
                    self._checkpoint(on_checkpoint, state(), i)
                    if not tutorial_done:
                        # 実機は強敵の初回、戦闘のあとに初回案内を済ませる(hunt_boss と同じ)。
                        tutorial_done = True
                        await self._finish_boss_tutorial(stage_id)
                elif code in RETRY_ONCE_RC and not retried_once:
                    # サーバ側の一時的なもの(実測: 次の周は通る)。少し待って同じ周をやり直す。
                    retried_once = True
                    wait = random.uniform(*RETRY_ONCE_WAIT)
                    self.trace.append(f"{i}: 一時エラー(rc={code}{self._fail_where()})。"
                                      f"{int(wait)}秒待ってやり直し")
                    i -= 1
                    await self._sleep(wait)
                    continue
                elif code == 32 and not relogged:
                    if self.stop_requested:
                        # 止めるなら入り直さない(この周は gameStart で弾かれていて、始まっていない)。
                        stopped = self._halt_text()
                        self.trace.append(f"{i}: tokenズレ(rc=32)。{self._halt_note()}")
                        break
                    # tokenズレ。入り直して同じ周を1回だけやり直す(2回目は致命的エラー扱い)。
                    relogged = True
                    self.trace.append(f"{i}: tokenズレ(rc=32)。入り直してやり直し")
                    try:
                        await self._blocking("入り直し(login)", self.client.login,
                                             self.client.userId, timeout=SLOW_CALL_TIMEOUT)
                    except PuniGameTimeout:
                        raise       # 応答が戻らない。下の except で「応答が戻らない」として終える
                    except Exception as e:
                        stopped = f"入り直しに失敗したため中止しました（{type(e).__name__}）"
                        break
                    i -= 1
                    await self._sleep(random.uniform(1.5, 3.0))
                    continue
                elif code in TRANSIENT_RC and transient_tries < len(RETRY_WAITS):
                    # 一時エラー(rc=4)。サーバの警告と見て長めに待って同じ周をやり直す(失敗に
                    # 数えない)。短い間に続くようなら中止する(_transient_plan)。
                    wait, stop_reason = self._transient_plan(transient_tries)
                    transient_tries += 1
                    if stop_reason:
                        self.trace.append(f"{i}: 一時エラー(rc={code}{self._fail_where()})。中止")
                        stopped = stop_reason
                        break
                    self.trace.append(f"{i}: 一時エラー(rc={code}{self._fail_where()})。"
                                      f"{int(wait)}秒待ってやり直し")
                    i -= 1
                    await self._sleep(wait)
                    continue
                else:
                    transient_tries = 0
                    if code in TRANSIENT_RC:
                        # やり直しの上限まで rc=4 だった。数えには入れて(短い間に続けば中止)、
                        # 決めた分だけ待ってから、この周は失敗として次へ。
                        wait, stop_reason = self._transient_plan(len(RETRY_WAITS))
                        if stop_reason:
                            self.trace.append(f"{i}: 一時エラー(rc={code}{self._fail_where()})。中止")
                            stopped = stop_reason
                            break
                        self.trace.append(f"{i}: 一時エラー(rc={code}{self._fail_where()})が続く。"
                                          f"{int(wait)}秒待って次へ")
                        await self._sleep(wait)
                    # スタミナ切れ(rc=5)。ワイマネーで人魂を買い足して、同じ周をやり直す。
                    # 課金通貨・現金は使わない(ワイマネー建てのみ)。goods_id は指定せず、
                    # 上限(既定1000=×5)内で買える一番安いパックを探して買う(買いすぎ防止)。
                    # 周回は入れるステージ(事前チェック済み)なので、rc=5 は素直にスタミナ切れ。
                    # ただし買い足した直後にまた rc=5 なら、スタミナではない(買った分が
                    # 反映されていない・別の理由で入れない)。買い続けてワイマネーを溶かさない。
                    if code == STAMINA_RC and bought_since_battle >= 1:
                        stopped = ("人魂を買い足してもスタミナ不足(rc=5)のまま入れないため中止しました"
                                   "（買った分が反映されていないか、ステージに入れない状態です）")
                        self.trace.append(f"{i}: 人魂を買い足しても rc=5 のまま。中止")
                        break
                    if code == STAMINA_RC and AUTO_BUY_HITODAMA:
                        if self.stop_requested:
                            # 止めるのに人魂を買ってワイマネーを使わない。
                            stopped = self._halt_text()
                            self.trace.append(f"{i}: スタミナ切れ(rc=5)。{self._halt_note()}(人魂は買わない)")
                            break
                        # 投げる前に「買いかけ」を残す(購入の最中に落ちても、再開で二重に買わない)。
                        # 戻らない(PuniGameTimeout)・例外のときは買えたか分からないので残したまま。
                        buy_inflight = True
                        self._checkpoint(on_checkpoint, state(), i)
                        ok_buy = await self._blocking("人魂の購入", self.client.buy_hitodama,
                                                      timeout=SLOW_CALL_TIMEOUT)
                        buy_inflight = False
                        if ok_buy:
                            bought += 1
                            bought_since_battle += 1
                            self.trace.append(f"{i}: 人魂を購入({bought}回目)")
                            # 買った回数はすぐ残す(再開したときも購入の上限を通しで数える)。
                            self._checkpoint(on_checkpoint, state(), i)
                            i -= 1      # この周はまだ回っていないのでやり直す
                            await self._sleep(random.uniform(2.0, 4.0))
                            continue
                        self._checkpoint(on_checkpoint, state(), i)   # 買えなかった(確定)
                        stopped = self._stamina_stop_message()
                        self.trace.append(f"{i}: 人魂購入に失敗(ワイマネー不足)")
                        break
                    failed += 1
                    streak += 1
                    retried_once = False
                    label = RC.get(code, "不明なエラー")
                    detail = f"rc={code}（{label}）"
                    self.trace.append(f"{i}: NG {detail}")
                    if looks_stale_rc(code):
                        stale_version = True
                        stopped = STALE_STOP_TEXT.format(detail=detail)
                        break
                    if code in (202, 30, 32):
                        stopped = ("BAN(アカウント停止)を検知しました"
                                   if code == 202 else
                                   f"致命的なエラーで中止しました（{detail}）")
                        break
                    if streak >= MAX_CONSECUTIVE_FAILS:
                        stopped = (f"{MAX_CONSECUTIVE_FAILS}回続けて失敗したため中止しました"
                                   f"（{detail}）。スタミナ切れかもしれません")
                        break
                    # 失敗した周のぶんは、あとでもう1周まわして埋める。続けて叩かず少し空ける。
                    await self._sleep(random.uniform(*RETRY_ONCE_WAIT))
                if cleared >= rounds:
                    break
                # 周と周のあいだ。区切りごとに長めの休みを入れ、それ以外はこの周に
                # 割り当てた休み時間を使う(合計が ROUND_SECONDS の狙いどおりになる)。
                # 何百周かに一度は席を外すくらいの長い休み。休みは実機と同じく
                # リザルト→マップ(getL5IdStatus)の形で過ごす(_rest)。
                if i >= next_long_break:
                    await self._rest(random.uniform(LONG_BREAK_SECONDS_MIN, LONG_BREAK_SECONDS_MAX))
                    next_long_break = i + random.randint(LONG_BREAK_EVERY_MIN,
                                                         LONG_BREAK_EVERY_MAX)
                    next_break = i + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
                elif i >= next_break:
                    await self._rest(random.uniform(BREAK_SECONDS_MIN, BREAK_SECONDS_MAX))
                    next_break = i + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
                else:
                    await self._rest(rest_sec)
        except PuniGameTimeout as e:
            # ゲーム通信が戻らない(スレッドが固まった)。同じ client で続けず、ここまでの結果で
            # 終える(結果のDM・ログ・売上は普段どおり流れる。置き去りのスレッドは
            # pending_game_calls で Cog が見る)。
            stopped = str(e)
            self.trace.append(f"{i}: {stopped}")

        if stopped is None and cleared < rounds:
            stopped = f"試行の上限（{max_attempts:,}回）に達したため、{cleared:,}周で終えました"
        stopped = self._final_stopped(stopped)
        suspended = stopped == SUSPEND_TEXT
        # 失敗した周はやり直しているので、成功が指定の周数に届いていれば完了。
        ok = (cleared >= rounds) and (stopped is None)
        warning = (cleared > 0) and not ok
        lines = [f"{cleared:,}/{rounds:,}周 成功"]
        if failed:
            lines.append(f"失敗した周: {failed:,}回（やり直し済み）")
        if bought:
            lines.append(f"人魂を自動購入: {bought}回（ワイマネー消費）")
        if self._drop_line():
            lines.append(self._drop_line())
        if stopped:
            lines.append(stopped)
        final = state()
        self._checkpoint(on_checkpoint, final, i)
        return {"ok": ok, "warning": warning, "cleared": cleared, "failed": failed,
                "bought": bought, "stopped": stopped, "suspended": suspended,
                "stale_version": stale_version,
                "account": self.account_line(), "lines": lines,
                "trace": list(self.trace),
                "buy_diag": list(getattr(self.client, "buy_diag", None) or []),
                "state": final}

    async def _battle_with_retry(self, stage_id, battle_type=None,
                                 before_buy=None, on_bought=None) -> tuple:
        """1ステージを、一時エラー・token切れ・スタミナ切れをさばきつつクリアする。

        戻り値 (code, bought)。code は最終的な resultCode(0=クリア)、bought は
        この呼び出しで人魂を買い足した回数。進行(progress_range / progress_event)から
        使う共通部品で、farm と同じ BAN対策(プレイ時間のゆらぎは battle 側)に乗る。
        人魂の購入の数は呼び出し側が持つ(途中経過の保存用): before_buy() は購入を投げる
        直前に、on_bought(買えたか) は購入の結果が分かった直後に呼ぶ(戻らない・例外の
        ときは呼ばない = 買えたか分からないまま)。数を戻り値で足すと、買ったあとの戦闘が
        例外で抜けたときにその1回が消えるので、呼び出し側は on_bought で数える。
        停止ボタン・一時停止で抜けるときは STOP_RC(どちらかは呼び出し側が _halt_text で見る)。
          ・rc=32(tokenズレ) … 入り直して1回だけやり直す。
          ・rc=4(一時エラー) … RETRY_WAITS の秒数だけ空けて順に再試行。
          ・rc=5 … サーバは「スタミナ切れ」だけでなく「ロック(未開放)のステージに
            入ろうとした」ときにも rc=5 を返す。そこで、入り直して今の人魂を測り、
              - 人魂が残っている → スタミナではなくロック。買わずに STAGE_LOCKED_RC を
                返す(人魂があるのに買ってしまう/「スタミナ切れ」と誤表示する事故を防ぐ)。
              - 人魂が尽きている → 本当にスタミナ切れ。ワイマネーで1回だけ買い足して
                同じステージをやり直す(AUTO_BUY_HITODAMA 有効のとき)。買い足しても
                まだ rc=5 なら返す。
        """
        bought = 0
        relogged = False
        wait_idx = 0
        stamina_checked = False
        await self._before_start(stage_id)
        while True:
            if self.stop_requested:
                return STOP_RC, bought
            play_sec, _, clear_sec = _round_timing()
            rc, result = await self._blocking("gameStart/gameEnd", self.client.battle,
                                              stage_id, battle_type, play_sec, clear_sec,
                                              timeout=BATTLE_TIMEOUT)
            code = result.get("resultCode") if isinstance(result, dict) else rc
            # 弾かれた応答を残す(進行の記録にサーバの説明を添える。_fail_hint)。
            self._last_fail = result if (code != 0 and isinstance(result, dict)) else {}
            if code == 0:
                return 0, bought
            # tokenズレ: 入り直して1回だけやり直す。止めるなら入り直さない。
            if code == 32 and not relogged:
                if self.stop_requested:
                    return STOP_RC, bought
                relogged = True
                try:
                    await self._blocking("入り直し(login)", self.client.login,
                                         self.client.userId, timeout=SLOW_CALL_TIMEOUT)
                except PuniGameTimeout:
                    raise           # 応答が戻らない。_progress が「応答が戻らない」として終える
                except Exception:
                    return 32, bought
                await self._sleep(random.uniform(1.5, 3.0))
                continue
            # rc=5: 「本当にスタミナ切れ」か「ロックのステージ」かを、今の人魂で見分ける。
            if code == STAMINA_RC:
                if self.stop_requested:
                    # 止めるなら、人魂を測るための入り直しも、人魂の購入もしない。
                    return STOP_RC, bought
                # stamina_now は save が古いと入り直して読む(login 一式)ので、上限は長いほう。
                if not stamina_checked:
                    stamina_checked = True
                    stamina = await self._blocking("人魂の確認", self.client.stamina_now,
                                                   timeout=SLOW_CALL_TIMEOUT)
                    # 人魂が残っているのに rc=5 = 入れないステージ(ロック)。買わない。
                    if stamina > 0:
                        return STAGE_LOCKED_RC, bought
                elif bought and await self._blocking("人魂の確認", self.client.stamina_now,
                                                     timeout=SLOW_CALL_TIMEOUT) > 0:
                    # 買い足した直後(購入の応答で人魂は戻っている)なのにまた rc=5 = スタミナでは
                    # なく入れないステージ。「スタミナ切れで中止」ではなく、ロックとして次へ。
                    return STAGE_LOCKED_RC, bought
                # 本当にスタミナ切れ(0 か判別不能)。1回だけ買い足してやり直す。
                if AUTO_BUY_HITODAMA and bought == 0:
                    if before_buy is not None:
                        before_buy()
                    ok_buy = await self._blocking("人魂の購入", self.client.buy_hitodama,
                                                  timeout=SLOW_CALL_TIMEOUT)
                    if on_bought is not None:
                        on_bought(bool(ok_buy))
                    if ok_buy:
                        bought += 1
                        await self._sleep(random.uniform(2.0, 4.0))
                        continue
                return STAMINA_RC, bought
            # 一時エラー: サーバの警告と見て長めに待って再試行。続くようなら中止を伝える。
            if code in TRANSIENT_RC and wait_idx < len(RETRY_WAITS):
                wait, stop_reason = self._transient_plan(wait_idx)
                wait_idx += 1
                if stop_reason:
                    return TRANSIENT_STOP_RC, bought
                await self._sleep(wait)
                continue
            return code, bought

    async def _progress(self, start, count=None, stale_is_end=True,
                        on_progress=None, skip_cleared=True, until_id=None,
                        known_ids=None, resume=None, on_checkpoint=None) -> dict:
        """start から順にクリアして進める共通処理(イベント・メイン兼用)。

        ・count を渡すと「新規に count ステージ進めたら終了」。None なら最後まで。
        ・until_id を渡すと「そのステージIDに到達(クリア/既クリアで通過)したら終了」。
          テスト垢を「◯◯まで」作るときに使う。count とは併用しない想定。
        ・skip_cleared=True なら、その垢が既にクリア済みのステージは戦わず飛ばす
          (垢の進行状況に合わせて「続きから」進める)。
        ・ブロック終端(該当ステージなし)に当たったら next_block_start で
          次エリア/次ブロックの1ステ目へ飛ぶ。連続で頭にも入れなければ終わりとみなす。
        ・known_ids を渡すと(垢のステージ表に載っているID)、終端やロックで飛ぶ先に
          「表にある次のID」も使う(同じ会場の中の飛び番や、強敵の会場の次)。表にある
          IDが先に残っているあいだは止めず、空のブロックを2つ試したらそこへ飛ぶ。ただし
          EMPTY_BLOCKS_LIMIT 個より先の会場へは飛ばない(離れた会場は別マップ)。表に先が
          無いときは次ブロックを EMPTY_BLOCKS_LIMIT 個まで連番で試してから終わる。
        ・「今は入れない」(508)・ロック(rc=5)・強敵(rc=100)のステージは会場の終わりとは
          限らないので、同じ会場の次の番号を続けて試す(MISS_RUN_LIMIT 個続いたら終端と同じに
          次ブロックへ)。508/ロックで飛ばしたステージは、同じ会場の先のステージがクリア
          できたあとに1回だけやり直す(開放の前提が ID の順どおりでない会場がある)。
        ・stale_is_end=True(イベント): 101/1303/102/1311 は「ステージ無し＝ブロック終端」。
          False(メイン): 101 は「バージョン古い」で中止、他だけブロック終端。
        BAN(202)・署名(30)は即中止。スタミナ切れ＋買い足し不可も中止。

        途中経過 state = {"cleared", "skipped", "bought", "blocks", "entered": [ID...],
        "drops": {"youkai", "items"}, "hit_lock", "hit_boss", "steps"}。進めたステージ・人魂の
        購入のたびと、返す直前に on_checkpoint(state)(同期の関数)を呼ぶ。人魂の購入を投げて
        から結果が分かるまでは "buy_inflight": True も付く(再開のときは購入1回として数える)。
        resume にこの形を渡すと、その数から続ける(count は注文全体の数のまま。あと
        count - cleared だけ進める)。
        どこから進めるか(start)は途中経過ではなく、呼び出し側が垢の進み具合から決める。

        戻り値 {"ok","cleared","skipped","entered","blocks","bought","stopped","suspended",
                "stale_version","account","lines","trace","buy_diag","state"}。
        """
        self.drops = _resume_drops(resume)
        # メインは 101 を「バージョン古い」として中止に回すので、終端からは外す(他は共通)。
        end_codes = STAGE_END_RC if stale_is_end else tuple(c for c in STAGE_END_RC if c != 101)
        target = int(count) if count else None
        goal_id = int(until_id) if until_id else None
        known = sorted(int(k) for k in (known_ids or []))
        sid = int(start)
        cleared = _resume_int(resume, "cleared")
        skipped = _resume_int(resume, "skipped")
        bought = _resume_bought(resume)   # 買いかけ(前回の購入の途中で落ちた)も1回と数える
        buy_inflight = False              # 人魂の購入を投げて、まだ結果が分からない
        try:
            entered = [int(x) for x in ((resume or {}).get("entered") or [])]
        except (TypeError, ValueError, AttributeError):
            entered = []
        blocks = _resume_int(resume, "blocks")
        stopped = None
        stale_version = False
        # 開始時点でクリア済みのステージ集合(進行状況)。走行中に増える分は数えない。
        pre_cleared = self.client.cleared_stage_ids() if skip_cleared else set()
        empty_blocks = 0      # ブロック頭に連続で入れなかった回数(=終わりの判定)
        block_head = True     # 今から挑むのがブロックの1ステ目か
        # ロック(未開放)で入れなかったステージ(終了理由の説明用。やり直しで通ったら外す)
        hit_lock_resume = _resume_flag(resume, "hit_lock")
        locked_ids = set()
        # 強敵(ボス)のステージに当たったか(イベント進行では扱わない)
        hit_boss = _resume_flag(resume, "hit_boss")
        # 同じ会場で「今は入れない」(508 など)・ロックだったステージ。その会場の先のステージを
        # クリアできたら1回だけやり直す(実測: 裏マップ 1-4/1-5 は矢印が出ているのに 508 で、
        # 同じ会場の 006 は通った。開放の前提が ID の順どおりではないらしい)。
        deferred = {}         # 会場(千の位) → [ID...]
        retry_queue = []      # いまからやり直す ID(先頭から)
        miss_run = 0          # 同じ会場で続けて入れなかった(508/ロック/強敵)数
        known_set = set(known)
        refused = set()       # 表に載っているのに入れなかったステージ(結果の説明用)
        steps = _resume_int(resume, "steps")   # 暴走の保険(PROGRESS_MAX)も注文全体で数える
        if resume:
            self.trace.append(f"再開: 前回までに{cleared}ステージ進めた"
                              + (f"・人魂購入{bought}回" if bought else "") + f"。{sid} から")
        if _resume_flag(resume, "buy_inflight"):
            self.trace.append("再開: 前回は人魂の購入の途中で止まったため、購入1回として数えます")

        def state() -> dict:
            st = {"cleared": cleared, "skipped": skipped, "bought": bought,
                  "blocks": blocks, "entered": list(entered), "drops": dict(self.drops),
                  "hit_lock": hit_lock_resume or bool(locked_ids), "hit_boss": hit_boss,
                  "steps": steps}
            if buy_inflight:
                st["buy_inflight"] = True
            return st

        # 人魂の購入の数はここで持つ(_battle_with_retry の戻り値で足すと、買ったあとの戦闘が
        # 戻らない・取り消されたときに、買った1回が数えから消える)。投げる前に「買いかけ」を
        # 残し、結果が分かったら消す。
        def before_buy() -> None:
            nonlocal buy_inflight
            buy_inflight = True
            self._checkpoint(on_checkpoint, state(), sid)

        def on_bought(ok: bool) -> None:
            nonlocal bought, buy_inflight
            buy_inflight = False
            if ok:
                bought += 1
            self._checkpoint(on_checkpoint, state(), sid)

        def defer(cur: int) -> None:
            """飛ばしたステージを、同じ会場の先が通ったときのやり直し候補に入れる。"""
            lst = deferred.setdefault(cur // 1000, [])
            if cur not in lst:
                lst.append(cur)
            if cur in known_set:
                refused.add(cur)     # 表にあるのに入れなかった(無いステージとは区別する)

        def next_after(cur: int):
            """終端/ロックで飛ぶ先。None なら、もう進める先が無い。

            表(known)に cur より先のIDがあれば、次ブロックの頭がそれより手前に
            ある間は次ブロックを試し(表に無い会場を飛ばさない)、空のブロックが
            2つ続いたら表のIDへ飛ぶ。表に先が無ければ、次ブロックを EMPTY_BLOCKS_LIMIT
            個空振りした時点で終わり。表にあるIDでも EMPTY_BLOCKS_LIMIT 個より先の
            会場(離れた別マップ)へは飛ばない。
            """
            nonlocal empty_blocks
            blind = next_block_start(cur)
            far = (cur // 1000 + EMPTY_BLOCKS_LIMIT + 1) * 1000
            ahead = next((k for k in known if cur < k < far), None)
            if ahead is not None and (ahead <= blind or empty_blocks >= 2):
                empty_blocks = 0
                self.trace.append(f"→ 表にある次のステージ {ahead} へ")
                return ahead
            if empty_blocks >= EMPTY_BLOCKS_LIMIT:
                self.trace.append(f"{cur}: この先に進める会場が見つからず終了"
                                  f"（次ブロックを{EMPTY_BLOCKS_LIMIT}個試した）")
                return None
            self.trace.append(f"→ 次ブロック {blind} へ")
            return blind

        def must_stop(code) -> bool:
            """やり直しの段階でも注文ごと止めるコード(停止・一時エラー続き・BAN・署名・
            スタミナ切れ・版古い)。それ以外は、やり直しで駄目でも記録だけ残して先へ。"""
            return (code in (STOP_RC, TRANSIENT_STOP_RC, 202, 30, STAMINA_RC)
                    or code in TRANSIENT_RC
                    or (looks_stale_rc(code) and not (stale_is_end and code == 101)))

        try:
            while steps < PROGRESS_MAX:
                steps += 1
                # 目標に届いていれば、止め(停止・一時停止)より先に「完了」として終える
                # (再開した注文が、目標に届いたまま「一時停止」に見えないように)。
                if target is not None and cleared >= target:
                    break         # 指定ステージ数を進め終えた(正常終了)
                if self.stop_requested:
                    stopped = self._halt_text()
                    self.trace.append(f"{sid}: {self._halt_note()}")
                    break
                # 同じ会場の先がクリアできたあとの、飛ばしたステージのやり直し(1回だけ)。
                # やり直しの間は本線(sid)を動かさない。
                retry = bool(retry_queue)
                cur = retry_queue.pop(0) if retry else sid
                # 既にクリア済みなら戦わずに飛ばす(垢の進行状況に合わせて続きから)。
                if not retry and skip_cleared and sid in pre_cleared:
                    skipped += 1
                    miss_run = 0
                    self.trace.append(f"{sid}: skip(クリア済み)")
                    if goal_id is not None and sid >= goal_id:
                        break     # 目標IDは既にクリア済み(正常終了)
                    if block_head:
                        block_head = False
                        empty_blocks = 0
                    sid += 1
                    continue
                if on_progress is not None:
                    try:
                        await on_progress(cleared, target, cur)
                    except Exception as e:
                        # 進捗の表示(DM の書き換え)がこけても進行は止めない。
                        self.trace.append(f"{cur}: 進捗の通知に失敗({type(e).__name__})")
                # 人魂の購入は、戦い終わるのを待たずにその場で数えて残す。
                code, _ = await self._battle_with_retry(
                    cur, before_buy=before_buy, on_bought=on_bought)
                if code == 0:
                    cleared += 1
                    entered.append(cur)
                    miss_run = 0
                    boss = getattr(self.client, "last_battle_type", None) == BOSS_BATTLE_TYPE
                    self.trace.append(f"{cur}: OK" + ("(やり直し)" if retry else "")
                                      + ("(強敵)" if boss else "") + self._drop_note())
                    if retry:
                        # やり直しで通った。ロック・入れなかった説明は要らない(その場所は越えた)。
                        locked_ids.discard(cur)
                        refused.discard(cur)
                        self._checkpoint(on_checkpoint, state(), cur)
                        _, rest_sec, _ = _round_timing()
                        await self._rest(rest_sec)
                        continue
                    if block_head:
                        blocks += 1
                        empty_blocks = 0
                        block_head = False
                    self._checkpoint(on_checkpoint, state(), sid)
                    if goal_id is not None and sid >= goal_id:
                        break     # 目標のステージIDまで到達(正常終了)
                    # この会場で飛ばしたステージがあれば、先が通ったので1回だけやり直す。
                    pending = deferred.pop(sid // 1000, None)
                    if pending:
                        retry_queue.extend(pending)
                        self.trace.append("→ 飛ばした " + ", ".join(str(p) for p in pending)
                                          + " をやり直す")
                    sid += 1
                    _, rest_sec, _ = _round_timing()
                    await self._rest(rest_sec)
                    continue
                if retry and not must_stop(code):
                    # やり直しでも入れなかった。記録だけ残して先へ(会場送りの判断はしない)。
                    self.trace.append(f"{cur}: やり直しても入れない rc={code}"
                                      f"（{RC.get(code, '不明なエラー')}）" + self._fail_hint())
                    await self._sleep(random.uniform(1.5, 3.0))
                    continue
                # 入れないステージ: 今は入れない(508 = 未開放)・ロック(rc=5)・強敵(rc=100。通常の
                # battleType だと「その形のステージが無い」で弾かれる。強敵は別メニュー)。人魂は
                # 減っていない。どれも会場の終わりとは限らない(実測: 004/005 が 508 でも 006 は
                # 通り、007 の強敵の先に通常ステージが続くことがある)ので、同じ会場の次の番号を
                # 続けて試す。MISS_RUN_LIMIT 個続いたら終端と同じに次ブロックへ。508/ロックで
                # 飛ばした分は、同じ会場の先が通ったら1回だけやり直す(defer。強敵はやり直さない)。
                is_boss = code == 100 and stale_is_end
                if code == STAGE_LOCKED_RC or code in STAGE_CLOSED_RC or is_boss:
                    if is_boss:
                        hit_boss = True
                        why = "強敵(ボス)。イベント進行では扱わない"
                    elif code == STAGE_LOCKED_RC:
                        locked_ids.add(cur)
                        defer(cur)
                        why = "ロック(未開放)"
                    else:
                        defer(cur)
                        why = f"今は入れない(rc={code})"
                    miss_run += 1
                    self.trace.append(f"{cur}: {why}。次を試す" + self._fail_hint())
                    if miss_run < MISS_RUN_LIMIT:
                        sid += 1
                        await self._sleep(random.uniform(1.5, 3.0))
                        continue
                    miss_run = 0
                    if block_head:
                        empty_blocks += 1
                    nxt = next_after(sid)
                    if nxt is None or nxt <= sid:
                        break
                    sid = nxt
                    block_head = True
                    await self._sleep(random.uniform(1.5, 3.0))
                    continue
                if code == STOP_RC:
                    stopped = self._halt_text()
                    self.trace.append(f"{cur}: {self._halt_note()}")
                    break
                if code == TRANSIENT_STOP_RC or code in TRANSIENT_RC:
                    # rc=4 が続いた(やり直しの上限まで、または短い間に何度も)。進行は飛ばせないので
                    # ここで止める。叩き続けるより、時間をおいて注文し直してもらう。
                    stopped = (self._transient_stop or
                               "一時エラー(rc=4)が続いたため中止しました（サーバに警告されている"
                               "可能性があります。時間をおいてからご注文ください）")
                    self.trace.append(f"{cur}: {stopped}")
                    break
                label = RC.get(code, "不明なエラー")
                detail = f"rc={code}（{label}）"
                self.trace.append(f"{cur}: NG {detail}" + self._fail_hint())
                if code in (202, 30):
                    stopped = ("BAN(アカウント停止)を検知しました" if code == 202
                               else f"致命的なエラーで中止しました（{detail}）")
                    break
                if code == STAMINA_RC:
                    stopped = self._stamina_stop_message()
                    break
                # メインでは 101 は「バージョン古い」を優先(イベントは終端扱い)。
                if looks_stale_rc(code) and not (stale_is_end and code == 101):
                    stale_version = True
                    stopped = STALE_STOP_TEXT.format(detail=detail)
                    break
                # ステージ終端(該当なし) → 次のブロック(次エリア)か、表にある次のIDへ飛ぶ。
                if code in end_codes:
                    miss_run = 0
                    if block_head:
                        empty_blocks += 1
                    nxt = next_after(sid)
                    if nxt is None or nxt <= sid:
                        break            # これ以上進めるステージが無い(正常終了)
                    sid = nxt
                    block_head = True
                    await self._sleep(random.uniform(1.5, 3.0))
                    continue
                stopped = f"想定外のエラーで中止しました（{detail}）"
                break
        except PuniGameTimeout as e:
            # ゲーム通信が戻らない(スレッドが固まった)。同じ client で続けず、ここまでの結果で
            # 終える(farm と同じ)。
            stopped = str(e)
            self.trace.append(f"{sid}: {stopped}")

        stopped = self._final_stopped(stopped)
        suspended = stopped == SUSPEND_TEXT
        hit_lock = hit_lock_resume or bool(locked_ids)
        lock_at = max(locked_ids) if locked_ids else None   # 説明用: いちばん先のロック
        ok = (cleared > 0) and (stopped is None)
        lines = [f"新たに{cleared:,}ステージ進めました"]
        if target:
            lines[0] += f"（目標 {target:,}）"
        if skipped:
            lines.append(f"クリア済みで飛ばした: {skipped}ステージ")
        if entered:
            lines.append(f"今回進めたID: {min(entered)} 〜 {max(entered)}")
        if bought:
            lines.append(f"人魂を自動購入: {bought}回（ワイマネー消費）")
        if self._drop_line():
            lines.append(self._drop_line())
        if hit_boss:
            lines.append("強敵(ボス)のステージはイベントステージ進行では扱いません（飛ばしました）")
        if refused:
            # 表に載っている(ゲームの画面にも出ている)のにサーバに断られたステージ。無いステージの
            # 終端(508/1311)とは分けて、どこが残ったかをお客さんにも分かるようにする。
            shown = sorted(refused)
            lines.append("入れなかったステージ: "
                         + ", ".join(puni_stages.describe(s) for s in shown[:5])
                         + ("…" if len(shown) > 5 else "")
                         + "（ゲーム側の条件で、今は入れない状態でした）")
        if stopped:
            lines.append(stopped)
        elif hit_lock and not entered:
            lines.append("この先のステージはまだ開放されていません（ロック中）。"
                         "垢のクリア状況では、ここから自動では進められませんでした"
                         + (f"（ロック: {puni_stages.describe(lock_at)}）" if lock_at else ""))
        elif hit_lock:
            lines.append("この先はまだ開放されていない（ロック）ため、ここまでで止めました"
                         + (f"（ロック: {puni_stages.describe(lock_at)}）" if lock_at else ""))
        elif not entered and skipped:
            lines.append("すでにここまで進めていました（新たに進めた分はありません）")
        elif not entered and not refused:
            # 入れなかったステージがあるときは、その行が理由なので「開始位置を確認」は出さない。
            lines.append("進められるステージがありませんでした（開始位置を確認してください）")
        final = state()
        self._checkpoint(on_checkpoint, final, sid)
        return {"ok": ok, "cleared": cleared, "skipped": skipped, "entered": entered,
                "blocks": blocks, "bought": bought, "stopped": stopped,
                "suspended": suspended, "refused": sorted(refused),
                "stale_version": stale_version, "account": self.account_line(),
                "lines": lines, "trace": list(self.trace),
                "buy_diag": list(getattr(self.client, "buy_diag", None) or []),
                "state": final}

    async def progress_event(self, start, count=None, on_progress=None,
                             skip_cleared=True, known_ids=None, resume=None,
                             on_checkpoint=None) -> dict:
        """イベントを進める。count 指定でそのステージ数だけ、None で最後まで。

        known_ids(そのイベントで表に載っている全ID)を渡すと、裏ステージのように
        離れたブロックにも届く(_progress を参照)。resume / on_checkpoint も _progress を参照。
        """
        return await self._progress(start, count=count, stale_is_end=True,
                                    on_progress=on_progress, skip_cleared=skip_cleared,
                                    known_ids=known_ids, resume=resume,
                                    on_checkpoint=on_checkpoint)

    async def progress_main(self, start, count=None, on_progress=None,
                            skip_cleared=True, until_id=None, resume=None,
                            on_checkpoint=None) -> dict:
        """メインを進める。count 指定でそのステージ数だけ、None で最後まで。
        until_id 指定でそのステージIDに到達したら終了(テスト垢作成で使う)。

        101 は「バージョン古い」で中止(イベントと違いブロック終端扱いしない)。
        resume / on_checkpoint は _progress を参照。
        """
        return await self._progress(start, count=count, stale_is_end=False,
                                    on_progress=on_progress, skip_cleared=skip_cleared,
                                    until_id=until_id, resume=resume,
                                    on_checkpoint=on_checkpoint)

    async def _finish_boss_tutorial(self, stage_id: int):
        """強敵の初回案内(種別 13)がまだなら、実機と同じく戦闘のあとに済みにする。"""
        status = self.client.tutorial_flags().get((BOSS_TUTORIAL_TYPE, int(stage_id)))
        if status != 0:
            return
        rc = await self._blocking("updateTutorialFlg", self.client.mark_tutorial,
                                  BOSS_TUTORIAL_TYPE, stage_id, timeout=LIGHT_CALL_TIMEOUT)
        self.trace.append(f"強敵の初回案内を済ませた(rc={rc})")

    def boss_max_block(self, stage_id) -> tuple:
        """強敵完凸を始めてよいか。戻り値 (止める理由, 強敵の妖怪のID, 種類)。始めてよければ理由は空。

        強敵完凸は「すでに持っている強敵の妖怪を完凸させる」メニューなので、ログインの
        時点で持っていると確かめられたときだけ始める。種類:
          "unknown"    … この強敵で取れる妖怪をまだ覚えていない(強敵取得で取れたことが無い)
          "unreadable" … 垢の持っている妖怪の表が読めない
          "not_owned"  … 持っていない
        どれも、確かめるために挑戦したりはしない(1回も回さない)。
        """
        known = boss_youkai_for(stage_id)
        if not known:
            return (BOSS_UNKNOWN_TEXT.format(stage=puni_stages.describe(stage_id)),
                    None, "unknown")
        owns = self.client.owns_youkai(known)
        if owns is None:
            return OWNED_UNREADABLE_TEXT.format(youkai=known), known, "unreadable"
        if owns is False:
            return NOT_OWNED_TEXT.format(youkai=known), known, "not_owned"
        return "", known, ""

    def _limit_step(self, lim: dict, got: list, tries: int) -> None:
        """強敵完凸の判定。撃破した回ごとに呼び、lim(_resume_limit の形)を書き換える。

        その妖怪を取った回は、取る前と後の行を見比べる。意味のある欄が動けばまだ途中、
        動かなければ完凸(maxed=True)。取ったあとの応答にその妖怪の行が無いときは、
        前の取得で行が見えていたなら「変わらなかったので載っていない」とみて完凸、
        一度も見えていなければ判定できないので止める(maxed=False。当てずっぽうで回し
        続けない)。取らなかった回に行が動いた欄は雑音として覚え、以後の比較から外す。
        """
        got = [int(g) for g in (got or [])]
        if lim.get("target") is None:
            if not got:
                return
            lim["target"] = got[0]
        target = int(lim["target"])
        end = getattr(self.client, "last_end", None) or {}
        table, after = self.client.youkai_row(target, end)

        if target not in got:
            # 取れなかった回。行が見えていて動いていれば、その欄は取得と関係なく動く。
            if after is not None and lim.get("row") is not None:
                moved = [i for i, _, _ in _row_changes(lim["row"], after) if i >= 0]
                if moved:
                    lim["noise"] = sorted(set(lim.get("noise") or []) | set(moved))
                lim["row"] = after
            return

        lim["count"] = int(lim.get("count") or 0) + 1
        n = lim["count"]
        before = lim.get("row")
        if before is None and not lim.get("row_init"):
            # 1体目の前の状態はログイン時の表から(持っていなければ無し＝新しく入る)。
            _, before = self.client.youkai_row(target, self.client.save)
            lim["row_init"] = True
            if self.client.owns_youkai(target) is False:
                # 頼まれた時点で持っていなかった。強敵完凸は持っている妖怪を完凸させる
                # メニューなので、ここで止める(今の1体は取れたまま)。
                lim["not_owned"] = True
                self.trace.append(f"{tries}: 強敵の妖怪 {target} は、頼まれた時点で"
                                  "持っていなかった。強敵完凸の対象外として止める")
                if len(self._limit_diag) < 60:
                    self._limit_diag.append({"obtain": n, "try": tries, "not_owned": True,
                                             "tables": self.client.youkai_tables(self.client.save)})
                return
        diag = {"obtain": n, "try": tries, "table": table, "before": before, "after": after,
                "noise": list(lim.get("noise") or []),
                "youkai": end.get("youkai"),
                "tables": [str(k) for k in end if str(k).startswith("ywp_user_youkai")]}
        head = f"{tries}: {n}体目(妖怪 {target})"
        dup = _dup_result(end.get("youkai"), target)
        if dup is not None:
            # ゲームが返したひっさつわざ・限界突破の前後で決める。どちらかが上がれば途中。
            (lv_before, lv_after), skill, exchg = dup["limit"], dup["skill"], dup["exchg"]
            diag["limit"] = {"before": lv_before, "after": lv_after, "exchgYmoney": exchg,
                             "skill": list(skill) if skill else None}
            lim["limit"] = lv_after
            if skill:
                lim["skill"], lim["skill_max"] = skill[1], skill[4]
            if after is not None:
                lim["seen"] = True
                lim["row"] = after
            skill_up = bool(skill) and (skill[1] > skill[0] or skill[3] > skill[2])
            if lv_after >= LIMIT_MAX_LEVEL:
                lim["maxed"] = True
                self.trace.append(f"{head}。限界突破 +{lv_before}→+{lv_after}（上限）＝完凸")
            elif exchg:
                lim["maxed"] = True
                self.trace.append(f"{head}。ワイマネー {exchg:,} に換算＝完凸")
            elif lv_after > lv_before:
                self.trace.append(f"{head}。限界突破 +{lv_before}→+{lv_after}")
            elif skill_up:
                self.trace.append(f"{head}。ひっさつわざ LV{skill[0]}→LV{skill[1]}"
                                  f"（経験値 {skill[2]:,}→{skill[3]:,}）")
            elif skill and skill[4]:
                # ひっさつわざは MAX なのに限界突破が上がらない＝この妖怪の上限が +10 より下
                lim["maxed"] = True
                self.trace.append(f"{head}。ひっさつわざ MAX・限界突破 +{lv_after} のまま＝完凸")
            else:
                # 何も上がらないのに、ひっさつわざが MAX とも読めない。当てずっぽうで
                # 完凸と言わずに止める。
                lim["maxed"] = False
                self.trace.append(f"{head}。取ってもひっさつわざ・限界突破が上がらず、"
                                  "完凸か判定できない")
            if len(self._limit_diag) < 60:
                self._limit_diag.append(diag)
            return
        if after is not None:
            lim["seen"] = True
            changes = _row_changes(before, after, ignore=lim.get("noise") or [])
            diag["changes"] = changes
            lim["row"] = after
            if changes:
                self.trace.append(f"{head}。変化 {_changes_text(changes)}")
            else:
                lim["maxed"] = True
                self.trace.append(f"{head}。取っても妖怪のデータが変わらない＝完凸")
        elif lim.get("seen"):
            lim["maxed"] = True
            self.trace.append(f"{head}。妖怪のデータに変化が載らなくなった＝完凸")
        else:
            lim["maxed"] = False
            self.trace.append(f"{head}。応答に妖怪のデータが無く、完凸か判定できない")
        if len(self._limit_diag) < 60:
            self._limit_diag.append(diag)

    async def hunt_boss(self, stage_id, on_progress=None, max_tries=None, resume=None,
                        on_checkpoint=None, until_max=False) -> dict:
        """強敵のステージに、強敵の妖怪を取得できるまで挑戦する。

        毎回 gameStart(battleType=6) → gameEnd(撃破の申告) を送る。クリア済みかどうかは
        問わない(撃破した強敵は同じIDで HP が戻って再挑戦できる。実測: 29704006 を
        クリア済みの垢で gameStart すると HP 満タンの強敵が返る)。取得したかは gameEnd の
        応答(youkai / rewardYoukaiId。実機の gameEnd で確かめた欄)で判定し、取得した
        時点で終える。妖怪の差分(ywp_user_youkai_diff)は形式が未確認なので判定には
        使わず、記録に残すだけ(実運用の記録から形を確かめてから使う)。

        さばき方は farm / _battle_with_retry と同じ:
          ・rc=4 … だんだん長く待って同じ回をやり直す(回数に数えない)
          ・rc=32 … 入り直して1回だけやり直す
          ・rc=5 … 人魂を測り、残っていれば「入れないステージ(ロック)」として中止、
            尽きていればワイマネーで買い足して続ける(回数の上限は無い)。買い足した
            直後にまた rc=5 ならスタミナではないので、それ以上は買わずに中止する
            (_battle_with_retry の「1回だけ買う」と同じ。ロックのステージで買い続けない)
          ・rc=100/102/1303 … その形のステージが無い(イベント終了・裏マップ未開放)で中止
          ・rc=20/101 … アプリ版が古いので中止して stale_version を立てる
          ・202/30 … BAN・署名で即中止
        max_tries(既定 BOSS_MAX_TRIES)回戦っても取れなければ打ち切る(ワイマネーの保険)。

        途中経過 state = {"tries", "cleared", "failed", "bought", "drops": {"youkai", "items"},
        "obtained"}。1回戦うたび・人魂の購入のたびと、返す直前に on_checkpoint(state)
        (同期の関数)を呼ぶ。人魂の購入を投げてから結果が分かるまでは "buy_inflight": True も
        付く(再開のときは購入1回として数える)。resume にこの形を渡すと、その数から続ける
        (max_tries は注文全体で数える)。取得済み(obtained あり)の
        途中経過なら戦わずに取得済みとして返す(取れたあとに流し直さない)。

        until_max=True は強敵完凸。取れても止めず、その妖怪が完凸するまで挑戦し続ける
        (判定は _limit_step。回数の上限は無い)。途中経過に "limit" が加わる。

        戻り値 {"ok", "warning", "obtained", "tries", "cleared", "failed", "bought",
                "stopped", "suspended", "stale_version", "account", "lines", "trace",
                "buy_diag", "state"}。強敵完凸は "maxed", "obtained_count", "limit_diag" も。
        """
        stage_id = int(stage_id)
        # 強敵完凸は完凸するまで回す(回数では止めない)。
        limit = int(max_tries) if max_tries else (float("inf") if until_max else BOSS_MAX_TRIES)
        lim = _resume_limit(resume) if until_max else None
        self._limit_diag = []
        self.drops = _resume_drops(resume)
        tries = _resume_int(resume, "tries")       # 戦った回数(gameStart が通った回数)
        cleared = _resume_int(resume, "cleared")   # 撃破(rc=0)の回数
        failed = _resume_int(resume, "failed")
        streak = 0
        # 買いかけ(前回の購入の途中で落ちた)も1回と数える。続けて rc=5 なら、買い直す前に
        # 人魂を測る(stamina_now)ので、買えていれば「入れないステージ」として止まる。
        bought = _resume_bought(resume)
        buy_inflight = False      # 人魂の購入を投げて、まだ結果が分からない
        obtained = (resume.get("obtained") if isinstance(resume, dict) else None) or None
        stopped = None
        stale_version = False
        transient_tries = 0
        relogged = False
        stamina_checked = False
        bought_since_battle = 0   # 直近の戦闘から人魂を買った回数(rc=5 が続くときの歯止め)
        tutorial_done = False
        locked_msg = ("この強敵ステージには入れませんでした（未開放・ロック中か、"
                      "イベントが終わっています）")
        if resume:
            self.trace.append(f"再開: 前回までに挑戦{tries}回・撃破{cleared}回"
                              + (f"・人魂購入{bought}回" if bought else "")
                              + (f"・取得済み(妖怪 {obtained})" if obtained is not None else "")
                              + (f"・取得{lim['count']}体" if until_max and lim["count"] else ""))
        if (until_max and lim["maxed"] is None and lim.get("limit") is not None
                and int(lim["limit"]) >= LIMIT_MAX_LEVEL):
            # 上限に届いたあと、もう1体を待って回っていた注文。再開ではもう回さない。
            lim["maxed"] = True
            self.trace.append(f"再開: 限界突破 +{lim['limit']} で上限に届いているため完凸として終える")
        if _resume_flag(resume, "buy_inflight"):
            self.trace.append("再開: 前回は人魂の購入の途中で止まったため、購入1回として数えます")
        # 長い休みを入れる回。再開したときはそこから数える。
        next_break = tries + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
        next_long_break = tries + random.randint(LONG_BREAK_EVERY_MIN, LONG_BREAK_EVERY_MAX)

        def state() -> dict:
            st = {"tries": tries, "cleared": cleared, "failed": failed, "bought": bought,
                  "drops": dict(self.drops), "obtained": obtained}
            if buy_inflight:
                st["buy_inflight"] = True
            if until_max:
                st["limit"] = dict(lim)
            return st

        def finished() -> bool:
            # 強敵取得は1体取れたら、強敵完凸は完凸(か判定できない・持っていない)と
            # 分かったら終わり。
            if until_max:
                return (lim["maxed"] is not None or bool(lim.get("not_owned"))
                        or bool(lim.get("block")))
            return obtained is not None

        if until_max and not resume and lim["target"] is None:
            # 強敵完凸は、持っていると確かめられた垢でしか回さない(注文の画面でも同じ
            # boss_max_block で断っている。ここは後追い・再起動の道の念押し)。取れる妖怪を
            # 覚えていない・持ち物が読めない・持っていない、のどれでも1回も挑戦しない。
            block, known, why = self.boss_max_block(stage_id)
            if block:
                lim["target"], lim["block"] = known, block
                lim["not_owned"] = why == "not_owned"
                self.trace.append(f"強敵完凸を始めずに止める（{why}）")

        try:
            if not finished() and tries < limit:
                await self._rest(random.uniform(WARMUP_SECONDS_MIN, WARMUP_SECONDS_MAX))

            while not finished() and tries < limit:
                if self.stop_requested:
                    stopped = self._halt_text()
                    self.trace.append(f"{tries + 1}: {self._halt_note()}")
                    break
                if on_progress is not None:
                    try:
                        if until_max:
                            await on_progress(tries, cleared, bought, lim["count"])
                        else:
                            await on_progress(tries, cleared, bought)
                    except Exception as e:
                        # 進捗の表示(DM の書き換え)がこけても挑戦は止めない。
                        self.trace.append(f"{tries + 1}: 進捗の通知に失敗({type(e).__name__})")
                hold = global_hold_remaining()
                if hold > 0:
                    self.trace.append(f"{tries + 1}: 全体停止中のため{int(hold)}秒待機")
                    await self._sleep(hold + random.uniform(1.0, 5.0))
                    if self.stop_requested:
                        # 待っている間に停止ボタン。明けてから gameStart を送らない。
                        stopped = self._halt_text()
                        self.trace.append(f"{tries + 1}: {self._halt_note()}")
                        break
                play_sec, rest_sec, clear_sec = _round_timing()
                await self._before_start(stage_id)
                if self.stop_requested:
                    # gameStart を送る前なので、ここで止めても始めた戦闘を放り出すことにはならない。
                    stopped = self._halt_text()
                    self.trace.append(f"{tries + 1}: {self._halt_note()}")
                    break
                rc, result = await self._blocking("gameStart/gameEnd", self.client.battle,
                                                  stage_id, BOSS_BATTLE_TYPE, play_sec, clear_sec,
                                                  timeout=BATTLE_TIMEOUT)
                code = result.get("resultCode") if isinstance(result, dict) else rc
                if code == 0:
                    tries += 1
                    cleared += 1
                    streak = 0
                    transient_tries = 0
                    stamina_checked = False
                    bought_since_battle = 0
                    got = list(self.client.last_drops.get("youkai") or [])
                    lot = "（抽選あり）" if self.client.last_lot_hit else ""
                    self.trace.append(f"{tries}: 撃破{lot}" + self._drop_note())
                    diff = result.get("ywp_user_youkai_diff") if isinstance(result, dict) else None
                    if diff and not got:
                        self.trace.append(f"{tries}: 妖怪の差分(参考): {str(diff)[:120]}")
                    # 取得は初回案内より先に記録する(初回案内の通信が戻らず打ち切っても、
                    # 取れた妖怪を「取れなかった」と伝えない)。
                    if got and obtained is None:
                        obtained = got[0]
                        self.trace.append(f"{tries}: 強敵の妖怪 {obtained} を取得")
                        # この強敵で取れる妖怪を覚える(強敵完凸で、戦う前に持っているかを
                        # 見るのに使う)。
                        remember_boss_youkai(stage_id, obtained)
                    if until_max:
                        # 取れても止めず、完凸かどうかをその妖怪のデータで見る。
                        self._limit_step(lim, got, tries)
                    # 取得も含めて残す(取れたあとに落ちても、再開で戦い直さない)。
                    self._checkpoint(on_checkpoint, state(), tries)
                    if not tutorial_done:
                        tutorial_done = True
                        await self._finish_boss_tutorial(stage_id)
                    if finished():
                        break
                elif code in TRANSIENT_RC and transient_tries < len(RETRY_WAITS):
                    wait, stop_reason = self._transient_plan(transient_tries)
                    transient_tries += 1
                    if stop_reason:
                        self.trace.append(f"{tries + 1}: 一時エラー(rc={code}{self._fail_where()})。中止")
                        stopped = stop_reason
                        break
                    self.trace.append(f"{tries + 1}: 一時エラー(rc={code}{self._fail_where()})。"
                                      f"{int(wait)}秒待ってやり直し")
                    await self._sleep(wait)
                    continue
                elif code == 32 and not relogged:
                    if self.stop_requested:
                        # 止めるなら入り直さない(この回は gameStart で弾かれていて、始まっていない)。
                        stopped = self._halt_text()
                        self.trace.append(f"{tries + 1}: tokenズレ(rc=32)。{self._halt_note()}")
                        break
                    relogged = True
                    self.trace.append(f"{tries + 1}: tokenズレ(rc=32)。入り直してやり直し")
                    try:
                        await self._blocking("入り直し(login)", self.client.login,
                                             self.client.userId, timeout=SLOW_CALL_TIMEOUT)
                    except PuniGameTimeout:
                        raise       # 応答が戻らない。下の except で「応答が戻らない」として終える
                    except Exception as e:
                        stopped = f"入り直しに失敗したため中止しました（{type(e).__name__}）"
                        break
                    await self._sleep(random.uniform(1.5, 3.0))
                    continue
                elif code == STAMINA_RC:
                    transient_tries = 0
                    # rc=5 は「スタミナ切れ」と「入れないステージ(ロック)」の両方で返る。
                    # 買い足した直後にまた rc=5 なら、スタミナではなく入れないステージ。
                    # 買い続けてワイマネーを使い切らない(1回のつまずきにつき購入は1回まで)。
                    if bought_since_battle >= 1:
                        self.trace.append(f"{tries + 1}: 人魂を買い足しても rc=5 のまま＝入れないステージ")
                        stopped = locked_msg
                        break
                    if self.stop_requested:
                        # 止めるなら、人魂を測るための入り直しも、人魂の購入(ワイマネー)もしない。
                        stopped = self._halt_text()
                        self.trace.append(f"{tries + 1}: スタミナ切れ(rc=5)。{self._halt_note()}(人魂は買わない)")
                        break
                    # 人魂が残っているのに rc=5 なら、この強敵には入れない。
                    # stamina_now は save が古いと入り直して読む(login 一式)ので、上限は長いほう。
                    if not stamina_checked:
                        stamina_checked = True
                        stamina = await self._blocking("人魂の確認", self.client.stamina_now,
                                                       timeout=SLOW_CALL_TIMEOUT)
                        if stamina > 0:
                            self.trace.append(f"{tries + 1}: rc=5 だが人魂{stamina}が残っている＝入れないステージ")
                            stopped = locked_msg
                            break
                    if AUTO_BUY_HITODAMA:
                        # 投げる前に「買いかけ」を残す(farm と同じ。購入の最中に落ちても、再開で
                        # 二重に買わない)。戻らない・例外のときは買えたか分からないので残したまま。
                        buy_inflight = True
                        self._checkpoint(on_checkpoint, state(), tries + 1)
                        ok_buy = await self._blocking("人魂の購入", self.client.buy_hitodama,
                                                      timeout=SLOW_CALL_TIMEOUT)
                        buy_inflight = False
                        if ok_buy:
                            bought += 1
                            bought_since_battle += 1
                            stamina_checked = False
                            self.trace.append(f"{tries + 1}: 人魂を購入({bought}回目)")
                            self._checkpoint(on_checkpoint, state(), tries + 1)
                            await self._sleep(random.uniform(2.0, 4.0))
                            continue
                        self._checkpoint(on_checkpoint, state(), tries + 1)   # 買えなかった(確定)
                    stopped = self._stamina_stop_message()
                    self.trace.append(f"{tries + 1}: 人魂購入に失敗(ワイマネー不足)")
                    break
                else:
                    transient_tries = 0
                    if code in TRANSIENT_RC:
                        wait, stop_reason = self._transient_plan(len(RETRY_WAITS))
                        if stop_reason:
                            self.trace.append(f"{tries + 1}: 一時エラー(rc={code}{self._fail_where()})。中止")
                            stopped = stop_reason
                            break
                        self.trace.append(f"{tries + 1}: 一時エラー(rc={code}{self._fail_where()})が続く。"
                                          f"{int(wait)}秒待って次へ")
                        await self._sleep(wait)
                    failed += 1
                    streak += 1
                    label = RC.get(code, "不明なエラー")
                    detail = f"rc={code}（{label}）"
                    self.trace.append(f"{tries + 1}: NG {detail}")
                    if looks_stale_rc(code):
                        stale_version = True
                        stopped = STALE_STOP_TEXT.format(detail=detail)
                        break
                    if code in (202, 30, 32):
                        stopped = ("BAN(アカウント停止)を検知しました" if code == 202 else
                                   f"致命的なエラーで中止しました（{detail}）")
                        break
                    if code in (100, 102, 1303):
                        stopped = (f"強敵ステージ {stage_id} に入れませんでした（{detail}）。"
                                   "イベントが終わっているか、裏マップがまだ開いていない可能性があります")
                        break
                    if streak >= MAX_CONSECUTIVE_FAILS:
                        stopped = f"{MAX_CONSECUTIVE_FAILS}回続けて失敗したため中止しました（{detail}）"
                        break
                if tries >= limit:
                    break
                if tries >= next_long_break:
                    await self._rest(random.uniform(LONG_BREAK_SECONDS_MIN, LONG_BREAK_SECONDS_MAX))
                    next_long_break = tries + random.randint(LONG_BREAK_EVERY_MIN,
                                                             LONG_BREAK_EVERY_MAX)
                    next_break = tries + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
                elif tries >= next_break:
                    await self._rest(random.uniform(BREAK_SECONDS_MIN, BREAK_SECONDS_MAX))
                    next_break = tries + random.randint(BREAK_EVERY_MIN, BREAK_EVERY_MAX)
                else:
                    await self._rest(rest_sec)
        except PuniGameTimeout as e:
            # ゲーム通信が戻らない(スレッドが固まった)。同じ client で続けず、ここまでの結果で
            # 終える(farm と同じ)。取れた妖怪は obtained に残っている。
            stopped = str(e)
            self.trace.append(f"{tries + 1}: {stopped}")

        if not finished() and stopped is None and tries >= limit:
            stopped = (f"{limit:,}回挑戦しても完凸しなかったため中止しました" if until_max
                       else f"{limit:,}回挑戦しても取得できなかったため中止しました")
        if until_max and stopped is None:
            if lim.get("block"):
                stopped = lim["block"]
            elif lim.get("not_owned"):
                stopped = NOT_OWNED_TEXT.format(youkai=lim["target"])
        stopped = self._final_stopped(stopped)
        # 終わっていれば注文は終わり(一時停止でも流し直さない)。完凸の途中なら流し直す。
        suspended = stopped == SUSPEND_TEXT and not finished()
        if until_max:
            ok = lim["maxed"] is True
            count = int(lim["count"] or 0)
            target = lim["target"]
            if lim.get("not_owned") or lim.get("block"):
                # 理由(NOT_OWNED_TEXT など)は stopped として下に付く。ここは何をしたかだけ。
                lines = [f"強敵完凸を止めました（挑戦 {tries:,}回で強敵の妖怪を1体取得。"
                         "その1体はそのまま残っています）" if count else
                         "強敵完凸を止めました（挑戦していません）"]
            elif ok:
                stage = _limit_stage(lim)
                lines = [f"強敵の妖怪（ID {target}）が完凸しました"
                         f"（{stage}取得 {count:,}体・{tries:,}回挑戦）"]
            elif lim["maxed"] is False:
                lines = [f"強敵の妖怪（ID {target}）を取得しましたが、完凸かどうかを"
                         "ゲームのデータから判定できなかったため、ここで止めました"
                         f"（取得 {count:,}体・{tries:,}回挑戦）。"
                         "すでに完凸しているか、判定に使うデータが応答に無いかのどちらかです"]
            elif count:
                stage = _limit_stage(lim)
                lines = [f"強敵の妖怪（ID {target}）は完凸の途中で止まりました"
                         f"（{stage}取得 {count:,}体・{tries:,}回挑戦・撃破 {cleared:,}回）"]
            else:
                lines = [f"強敵の妖怪は取得できませんでした（{tries:,}回挑戦・撃破 {cleared:,}回）"]
        else:
            ok = obtained is not None
            if ok:
                lines = [f"強敵の妖怪（ID {obtained}）を取得しました（{tries:,}回目で取得）"]
            else:
                lines = [f"強敵の妖怪は取得できませんでした（{tries:,}回挑戦・撃破 {cleared:,}回）"]
        warning = ok and (failed > 0 or bought > 0)
        if failed:
            lines.append(f"失敗 {failed:,}回")
        if bought:
            lines.append(f"人魂を自動購入: {bought}回（ワイマネー消費）")
        if self._drop_line():
            lines.append(self._drop_line())
        if stopped:
            lines.append(stopped)
        final = state()
        self._checkpoint(on_checkpoint, final, tries)
        out = {"ok": ok, "warning": warning, "obtained": obtained, "tries": tries,
               "cleared": cleared, "failed": failed, "bought": bought, "stopped": stopped,
               "suspended": suspended,
               "stale_version": stale_version, "account": self.account_line(),
               "lines": lines, "trace": list(self.trace),
               "buy_diag": list(getattr(self.client, "buy_diag", None) or []),
               "state": final}
        if until_max:
            out.update({"maxed": lim["maxed"], "obtained_count": int(lim["count"] or 0),
                        "not_owned": bool(lim.get("not_owned")),
                        # 持っているかを確かめられずに始めなかった(覚えていない・読めない)。
                        "unconfirmed": bool(lim.get("block")) and not lim.get("not_owned"),
                        "boss_youkai": lim["target"],
                        "limit_diag": list(self._limit_diag)})
        return out

LOGIN_RETRY_WAITS = (8.0, 12.0)     # 反映待ちのときの、入り直しまでの待ち(秒)


def _hold_error() -> PuniServerError:
    left = global_hold_remaining()
    return PuniServerError(
        "サーバに拒まれた直後のため、あと%d分は接続を止めています"
        "(叩き続けると締め出しが延びます)" % max(1, int(left // 60) + 1))


async def _open_with_retry(udkey: str, app_ver: str, user_id=None) -> "PuniRunner":
    """udkey でゲームサーバへ入る。

    ・全体停止中(拒まれた直後)は投げずに止める。投げても同じように落ちるうえ、
      同じ出口から叩き続けると締め出しが延びる。
    ・反映待ち(連携したアカウントがまだ載らない)だけ、少し待って入り直す(最大3回)。
    ・HTTP で拒まれたら(init / getGdkeyAccounts / login の 5xx など)、全体を止めて
      すぐ返す。
    やり直すのはゲームサーバへの login だけ。L5 の連携はここではやらない。
    """
    if global_hold_remaining() > 0:
        raise _hold_error()
    last = None
    for attempt, wait in enumerate((0.0,) + LOGIN_RETRY_WAITS):
        if wait:
            await asyncio.sleep(wait + random.uniform(0.0, 4.0))

        def _open():
            client = Client(udkey, app_ver=app_ver)
            try:
                client.login(userId=user_id)
            except PuniLoginError:
                raise
            except Exception as e:
                # login の中で拾い切れなかった例外(応答の形が想定外など)。生のまま上げると
                # 呼び出し側が「想定外のエラー」で注文を止めてしまう。サーバの都合として返す。
                raise PuniServerError('ログイン中に失敗: %s: %s'
                                      % (type(e).__name__, str(e)[:100])) from e
            return client

        try:
            return PuniRunner(await _in_game_pool(_open))
        except PuniServerError as e:
            last = e
            if not getattr(e, "retry_ok", False):
                # 拒まれた(HTTP 5xx・403・応答不正)。全体を止めてすぐ返す。
                note_server_refusal(str(e)[:40])
                raise
            # 反映待ち・一時エラー(rc=4)。全体は止めず、少し待って入り直す。
            print(f"[PUNI] 少し待って入り直します({attempt + 1}回目): {e}", flush=True)
    if "反映待ち" not in str(last):
        # 数秒おいて入り直しても続く = 一時的ではない(叩きすぎの警告など)。全体を止めて
        # 時間をおく(止めないと、見張りの巡回が 20 秒ごとに入口を叩き続ける)。
        note_server_refusal(str(last)[:40])
    raise last


async def login_with_email(email: str, password: str, user_id=None) -> PuniRunner:
    """メール/パスからログインして、開いた状態のランナーを返す。

    そのアカウントの udkey を覚えていて、入力されたパスワードが覚えたときのものと
    合えば、それでそのまま入る(連携しない)。覚えが無い・パスワードが合わない・
    使えなくなっていたときは、新しい udkey を作って L5 に紐づけ(ここで本物の
    パスワード確認が行われる)、入れたら覚える。連携は1回だけで、そのあとの login は
    _open_with_retry の決まりに従う。

    覚えを捨てるのは PuniUdkeyError(udkey そのものがもう使えない)のときだけ。
    サーバの都合(PuniServerError)・版が古い(PuniStaleVersionError)・BAN などは
    捨てても直らないうえ、捨てるたびに新しい端末が湧いて連携が走る(目印になる)。
    """
    app_ver = get_app_version()
    if global_hold_remaining() > 0:
        raise _hold_error()

    known = await _in_game_pool(recall_udkey, email, password)
    if known:
        udkey, saved_uid = known
        try:
            try:
                runner = await _open_with_retry(udkey, app_ver, user_id or saved_uid)
            except PuniAccountError as e:
                if user_id is not None or saved_uid is None:
                    raise           # 注文が指すアカウントが無い(入れ直し用)。そのまま伝える
                # 覚えていた userId がこの L5 アカウントにもう無い(ゲームデータの紐づけ直し等)。
                # udkey は生きているので、連携も忘れもせず、今あるアカウントで入り直す
                # (覚えの userId を引き直す)。
                print(f"[PUNI] 覚えていた userId が見つかりません。今のアカウントで入り直します: {e}",
                      flush=True)
                runner = await _open_with_retry(udkey, app_ver, None)
            remember_udkey(email, udkey, runner.user_id, keep_at=True)   # userId だけ埋める(期限は延ばさない)
            return runner
        except PuniUdkeyError as e:
            # udkey が使えなくなっている(紐づけの解除・別の垢など)。忘れて連携から。
            print(f"[PUNI] 覚えていた udkey では入れません。連携からやり直します: {e}",
                  flush=True)
            forget_udkey(email)
        # それ以外(サーバの都合・版が古い・BAN・その他のログイン失敗)はそのまま伝える。

    def _link():
        try:
            udkey = new_udkey(app_ver)
            link_email(app_ver, udkey, email, password)
            return udkey
        except PuniLoginError:
            raise
        except (requests.exceptions.RequestException, ValueError, KeyError, TypeError,
                OSError) + _CURL_ANY as e:
            raise PuniServerError(
                'L5に接続できません: %s: %s' % (type(e).__name__, str(e)[:100])) from e

    udkey = await _in_game_pool(_link)
    # 連携できた時点で覚える(userId は入れてから埋める)。ここでゲームサーバに拒まれても、
    # 次は連携し直さずにこの udkey で入れる(連携のたびに新しい端末が湧くのを防ぐ)。
    remember_udkey(email, udkey, None, password)
    # 連携直後はサーバ反映に少し間がある。
    await asyncio.sleep(3)
    runner = await _open_with_retry(udkey, app_ver, user_id)
    remember_udkey(email, udkey, runner.user_id, password)
    return runner


async def login_with_udkey(udkey: str, user_id) -> PuniRunner:
    """預かった udkey からログインし直す(保留から承認された後のお渡し用)。"""
    return await _open_with_retry(udkey, get_app_version(), user_id)


def _suspend_now(suspend_event) -> bool:
    return suspend_event is not None and suspend_event.is_set()


def _suspended_result(resume=None, account: str = "") -> dict:
    """始める前から一時停止(bot の更新)が立っていたときの結果。入らずにすぐ返す。

    注文は終わっていない(Cog は締めずに、途中経過 resume のまま次のプロセスへ渡す)。
    数は前回までの分をそのまま載せる。
    """
    res = {"ok": False, "warning": False, "suspended": True, "obtained": None,
           "entered": [], "stopped": SUSPEND_TEXT, "stale_version": False,
           "account": account, "lines": [SUSPEND_TEXT], "trace": [], "buy_diag": [],
           "state": dict(resume or {})}
    for k in ("cleared", "tries", "failed", "skipped", "blocks"):
        res[k] = _resume_int(resume, k)
    res["bought"] = _resume_bought(resume)
    return res


def _carry_resume(res: dict, resume) -> dict:
    """始める前に終えた結果(進める場所・強敵が見つからない等)に、前回までの分を載せる。

    再開した注文で、ここまでに渡した分が 0 に見えると、呼び出し側が「何も渡せていない」と
    判断を誤る(返金・失敗の扱い)。数と途中経過(state)を引き継ぐ。
    """
    if not resume or not isinstance(resume, dict):
        return res
    for k in ("cleared", "tries", "failed", "skipped", "blocks"):
        if _resume_int(resume, k):
            res[k] = _resume_int(resume, k)
    if _resume_bought(resume):
        res["bought"] = _resume_bought(resume)
    if isinstance(resume.get("entered"), list):
        res["entered"] = list(resume["entered"])
    res["state"] = dict(resume)
    if res.get("tries"):
        # お客さんの結果DMに出る。一時停止・再開(裏側)のことは書かない。
        res["lines"] = ([f"ここまでの分: {res['tries']:,}回挑戦・撃破 {res.get('cleared', 0):,}回"]
                        + list(res.get("lines") or []))
    elif res.get("cleared"):
        res["lines"] = ([f"ここまでの分: {res['cleared']:,}ステージ進めました"]
                        + list(res.get("lines") or []))
    return res


async def run_farm(udkey: str, user_id, stage_id, rounds, on_progress=None,
                   runner: "PuniRunner" = None, stop_event=None, resume=None,
                   on_checkpoint=None, suspend_event=None) -> dict:
    """預かった udkey で入り直して周回する(後追いのお渡しから使う)。

    runner を渡せば(呼び出し側が先に入っておいたとき)入り直さずにそれで回す。
    stop_event(asyncio.Event)を渡せば、立った時点で今の周を終えて止まる(DM の停止ボタン)。
    suspend_event(bot の更新)も同じ止まり方で、結果は suspended=True。始める前から立って
    いれば入らずに返す。resume / on_checkpoint は PuniRunner.farm を参照。
    """
    if _suspend_now(suspend_event):
        return _suspended_result(resume, runner.account_line() if runner else "")
    runner = runner or await login_with_udkey(udkey, user_id)
    runner.attach_stop(stop_event)
    runner.attach_suspend(suspend_event)
    return await runner.farm(stage_id, rounds, on_progress=on_progress, resume=resume,
                             on_checkpoint=on_checkpoint)


def _no_progress_result(kind_msg: str) -> dict:
    """進める場所が見つからなかったときの結果(課金前提の入口で使う)。"""
    return {"ok": False, "cleared": 0, "skipped": 0, "entered": [], "blocks": 0,
            "bought": 0, "stopped": kind_msg, "suspended": False, "stale_version": False,
            "account": "", "lines": [kind_msg], "trace": [], "state": {}}


async def run_progress_main(udkey: str, user_id, count, on_progress=None,
                            runner: "PuniRunner" = None, stop_event=None, resume=None,
                            on_checkpoint=None, suspend_event=None) -> dict:
    """預かった udkey で入り直し、メインを現在地から count ステージ進める。

    count は注文全体の数(再開したときは resume の cleared を引いた残りだけ進める)。
    どこから進めるかは、再開のときも垢の今の進み具合(main_resume_point)で決める。
    """
    if _suspend_now(suspend_event):
        return _suspended_result(resume, runner.account_line() if runner else "")
    runner = runner or await login_with_udkey(udkey, user_id)
    runner.attach_stop(stop_event)
    runner.attach_suspend(suspend_event)
    start = runner.main_resume_point()
    if start is None:
        res = _no_progress_result(
            "メインステージのクリア状況が読めず、開始位置が決められませんでした")
        res["account"] = runner.account_line()
        return _carry_resume(res, resume)
    return await runner.progress_main(start, count=count, on_progress=on_progress,
                                      resume=resume, on_checkpoint=on_checkpoint)


NO_EVENT_TEXT = ("進行中のイベントが見つかりませんでした（イベントのステージを1つも"
                 "開いていない垢では、どのイベントを進めるか自動で決められません）")


async def run_progress_event(udkey: str, user_id, count=None, on_progress=None,
                             runner: "PuniRunner" = None, stop_event=None, resume=None,
                             on_checkpoint=None, suspend_event=None) -> dict:
    """預かった udkey で入り直し、今のイベントを現在地から進める。

    count を渡せばそのステージ数だけ、0/None なら最後(裏ステージまで)まで。
    どのイベントか・どこからかは垢のデータから決める(current_event /
    event_resume_point)。表に載っている全IDを飛び先の候補に渡すので、離れた
    ブロックの裏ステージにも届く。再開(resume)のときも、どこからかは垢の今の
    進み具合で決め、count は注文全体の数として数える。
    """
    if _suspend_now(suspend_event):
        return _suspended_result(resume, runner.account_line() if runner else "")
    runner = runner or await login_with_udkey(udkey, user_id)
    runner.attach_stop(stop_event)
    runner.attach_suspend(suspend_event)
    event_no = runner.current_event()
    start = runner.event_resume_point(event_no) if event_no is not None else None
    if start is None:
        res = _no_progress_result(NO_EVENT_TEXT)
        res["account"] = runner.account_line()
        return _carry_resume(res, resume)
    res = await runner.progress_event(start, count=count or None,
                                      on_progress=on_progress,
                                      known_ids=runner.event_known_ids(event_no),
                                      resume=resume, on_checkpoint=on_checkpoint)
    res.setdefault("lines", []).insert(
        0, f"イベント{event_no}：{puni_stages.describe(start)} から進めました")
    res["event_no"] = event_no
    res["start_id"] = start
    try:
        # 表・裏で未開放(state=0)のまま残ったステージを結果に添える(隠しステージなど、進行では
        # 入れない分)。今回進めた分と、走行で入れなかった分(結果にもう出ている)は除く。
        # 何も進まなかった理由がこれなら、管理者向けの「開始位置を確認」は出さない。
        done = set(res.get("entered") or []) | set(res.get("refused") or [])
        locked = [s for s in runner.event_locked_ids(event_no) if s not in done]
        if locked:
            lines = res.setdefault("lines", [])
            lines.append("未開放のまま残ったステージ: "
                         + ", ".join(puni_stages.describe(s) for s in locked[:5])
                         + ("…" if len(locked) > 5 else "")
                         + "（ゲーム側で開放されると進められます）")
            if not res.get("entered"):
                res["lines"] = [l for l in lines if "開始位置を確認してください" not in l]
        # 非公開ログに添える診断: その垢のイベントのステージ表(どの会場を表・裏とみなしたか)。
        res["stage_diag"] = runner.event_stage_rows(event_no)
    except Exception:
        pass
    return res


NOT_OWNED_TEXT = ("このアカウントは、この強敵の妖怪（ID {youkai}）をまだ持っていないため止めました。"
                  "強敵完凸は、すでに持っている強敵の妖怪を完凸させるメニューです"
                  "（持っていない場合は、先に強敵取得をご利用ください）")
# 強敵完凸は「持っている」と確かめられたときしか始めない。確かめられない2つの場合の説明。
BOSS_UNKNOWN_TEXT = ("この強敵ステージ（{stage}）で取れる妖怪をまだ確認できていないため、"
                     "強敵完凸を始めずに止めました（挑戦していません）。"
                     "この強敵で一度強敵取得が成功すると、使えるようになります")
OWNED_UNREADABLE_TEXT = ("このアカウントの持っている妖怪を読み取れず、強敵の妖怪（ID {youkai}）を"
                         "持っているか確認できなかったため、強敵完凸を始めずに止めました"
                         "（挑戦していません）")
NO_BOSS_TEXT = ("挑戦できる強敵ステージが見つかりませんでした（今のイベントの裏マップ(強敵)の"
                "ステージをゲームで一度もプレイしていない垢では、どの強敵に挑むか自動で決められません）")
BOSS_LOCKED_TEXT = ("強敵ステージ {stage} は、このアカウントではまだ開放されていません"
                    "（裏マップ(強敵)が未解放・ロック中）。挑戦せずに中止しました")


async def run_hunt_boss(udkey: str, user_id, stage_id=0, on_progress=None,
                        runner: "PuniRunner" = None, stop_event=None, resume=None,
                        on_checkpoint=None, suspend_event=None, until_max=False) -> dict:
    """預かった udkey で入り直し、強敵の妖怪を取得できるまで挑戦する。

    until_max=True なら強敵完凸(取れても止めず、完凸するまで挑戦し続ける)。

    stage_id を渡せばその強敵に、0/None なら垢のデータから決める(boss_target)。
    どちらでも、未解放と分かっている強敵(boss_target の locked)には挑戦せずに止める
    (注文の時点では開いていた裏マップが、後追いの時点で読めないことはまず無いが、
    入れないステージに gameStart を投げない)。resume / on_checkpoint は
    PuniRunner.hunt_boss を参照(再開のときは前と同じ stage_id を渡す)。
    """
    if _suspend_now(suspend_event):
        return _suspended_result(resume, runner.account_line() if runner else "")
    runner = runner or await login_with_udkey(udkey, user_id)
    runner.attach_stop(stop_event)
    runner.attach_suspend(suspend_event)
    target = runner.boss_target()
    if not stage_id:
        stage_id = target.get("stage_id")
    if not stage_id:
        res = _no_progress_result(NO_BOSS_TEXT)
        res.update({"obtained": None, "tries": 0, "account": runner.account_line()})
        return _carry_resume(res, resume)
    if int(stage_id) == target.get("stage_id") and target.get("locked"):
        res = _no_progress_result(BOSS_LOCKED_TEXT.format(stage=puni_stages.describe(stage_id)))
        res.update({"obtained": None, "tries": 0, "account": runner.account_line(),
                    "stage_id": int(stage_id)})
        return _carry_resume(res, resume)
    res = await runner.hunt_boss(stage_id, on_progress=on_progress, resume=resume,
                                 on_checkpoint=on_checkpoint, until_max=until_max)
    res.setdefault("lines", []).insert(
        0, f"強敵ステージ: {puni_stages.describe(stage_id)}")
    res["stage_id"] = int(stage_id)
    return res
