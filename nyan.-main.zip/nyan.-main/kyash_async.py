"""kyash_mobile(同梱ライブラリ)を discord.py の非同期処理から使うためのブリッジ。

paypay_async と同じ役割・同じ流儀で、Kyash のログイン・受け取り・認証情報の保存を
ここに集約する。ライブラリ本体は requests ベースの同期実装なので、ネットワーク
呼び出しはすべて asyncio.to_thread でスレッドに逃がしてイベントループを止めない。

PayPay との違い:
  - Kyash のアクセストークンは長寿命(おおよそ1か月)で、リフレッシュではなく
    「同じ端末UUIDで再ログインする」ことで取り直す。端末UUIDが登録済みなら
    ワンタイムコードは不要なので、Bot だけで自動復帰できる。
  - 送金リンクに保留(承認待ち)が無いため、受け取りは1回で確定する。
"""
import asyncio
import time
from uuid import uuid4

from crosslock import LockTimeout, cross_process_lock
from datapath import data_path, read_json, write_json
from kyash_mobile import Kyash, KyashError, KyashLoginError, KyashNetWorkError

KYASH_DATA_FILE = data_path("kyash_data.json")
RELOGIN_LOCK_FILE = data_path("kyash_relogin.lock")
FILE_LOCK_TIMEOUT = 60

# Kyashアカウントは1つだけ。誰が /kyash で登録しても同じ共有スロットに保存する。
OWNER_KEY = "owner"

# トークンは長持ちするが、切れる前に自分から取り直しておく。
RELOGIN_AFTER_DAYS = 20
# 生存確認(トークンが有効かどうかだけ見る)の間隔。
KEEP_ALIVE_INTERVAL_MINUTES = 60


class NotRegisteredError(Exception):
    """Kyashアカウントが未登録のときに送出する。"""


class OtpRequiredError(KyashLoginError):
    """自動再ログインができず、ワンタイムコードでの再登録が必要な状態。

    KyashLoginError を継承しているので、既存の except KyashLoginError でも拾える。
    """


class ReloginFailedError(Exception):
    """一時的な理由(通信断など)で再ログインに失敗した。再登録は不要。"""


# ---- 認証情報の保存 ----

def load_kyash_data() -> dict:
    return read_json(KYASH_DATA_FILE, {})


def save_kyash_data(data: dict):
    write_json(KYASH_DATA_FILE, data)


def _resolve_owner(data: dict):
    """受取に使う認証情報を返す。共有スロット優先、無ければ既存の登録を1件使う。"""
    creds = data.get(OWNER_KEY)
    if creds and creds.get("access_token"):
        return OWNER_KEY, creds
    for k, v in data.items():
        if isinstance(v, dict) and v.get("access_token"):
            return k, v
    return None, None


def _store_credentials(ky: Kyash, email: str, password: str) -> dict:
    now = time.time()
    creds = {
        "email": email,
        "password": password,
        "client_uuid": ky.client_uuid,
        "installation_uuid": ky.installation_uuid,
        "access_token": ky.access_token,
        "refresh_token": ky.refresh_token,
        "logged_in_at": now,
        "refreshed_at": now,
    }
    data = load_kyash_data()
    data[OWNER_KEY] = creds
    save_kyash_data(data)
    return creds


def _save_creds(key: str, creds: dict):
    data = load_kyash_data()
    data[key] = creds
    save_kyash_data(data)


def _client(creds: dict) -> Kyash:
    return Kyash(
        email=creds.get("email"),
        password=creds.get("password"),
        client_uuid=creds.get("client_uuid") or str(uuid4()).upper(),
        installation_uuid=creds.get("installation_uuid") or str(uuid4()).upper(),
        access_token=creds.get("access_token"),
        refresh_token=creds.get("refresh_token"),
    )


def _refreshed_at(creds: dict) -> float:
    return float(creds.get("refreshed_at") or creds.get("logged_in_at") or 0)


def _is_stale(creds: dict, days: float = RELOGIN_AFTER_DAYS) -> bool:
    return (time.time() - _refreshed_at(creds)) >= days * 86400


# ---- ログイン ----

async def start_login(email: str, password: str):
    """メールアドレス・パスワードでログインを開始する。

    戻り値 (Kyash, otp_required)。otp_required=False なら端末が登録済みで
    そのままログインできているので、complete_login は不要(保存だけすればよい)。
    """
    ky = Kyash(email=email, password=password)
    logged_in = await asyncio.to_thread(ky.login_start)
    if logged_in:
        await asyncio.to_thread(_store_credentials, ky, email, password)
    return ky, not logged_in


async def complete_login(ky: Kyash, otp: str, email: str, password: str) -> Kyash:
    """届いたワンタイムコードでログインを完了し、認証情報を保存する。"""
    await asyncio.to_thread(ky.login_verify, otp)
    await asyncio.to_thread(_store_credentials, ky, email, password)
    return ky


# ---- 再ログイン(トークンの取り直し) ----

_relogin_lock = asyncio.Lock()


def _relogin_sync(creds: dict) -> dict:
    """保存済みの端末UUIDで入り直して、新しいトークンを取る(同期)。

    端末UUIDが登録済みならワンタイムコード無しで通る。Kyash側でその端末が
    忘れられていると OTP を要求されるので、その場合は OtpRequiredError にする。
    """
    if not creds.get("email") or not creds.get("password"):
        raise OtpRequiredError("メールアドレス・パスワードが保存されていません")

    ky = _client(creds)
    try:
        logged_in = ky.login_start()
    except KyashLoginError as e:
        raise OtpRequiredError(e.args[0] if e.args else str(e))
    except (KyashNetWorkError, OSError) as e:
        raise ReloginFailedError(e)
    except KyashError as e:
        raise ReloginFailedError(e)

    if not logged_in:
        raise OtpRequiredError("この端末はKyashに覚えられていません。ワンタイムコードで再登録してください")

    new = dict(creds)
    new["access_token"] = ky.access_token
    new["refresh_token"] = ky.refresh_token
    new["refreshed_at"] = time.time()
    return new


def _relogin_guarded(held: float) -> dict:
    """ファイルロックの中で再ログインする(同期・スレッドで動かす)。

    待っている間に別プロセスがログインし直していたら、そのトークンを使う。
    """
    try:
        with cross_process_lock(RELOGIN_LOCK_FILE, FILE_LOCK_TIMEOUT):
            data = load_kyash_data()
            key, current = _resolve_owner(data)
            if not current:
                raise NotRegisteredError("Kyash アカウントが登録されていません")
            if _refreshed_at(current) > held:
                return current
            new_creds = _relogin_sync(current)
            _save_creds(key, new_creds)
            return new_creds
    except LockTimeout as e:
        raise ReloginFailedError(e)


async def _relogin_locked(creds: dict) -> dict:
    held = _refreshed_at(creds)
    async with _relogin_lock:
        return await asyncio.to_thread(_relogin_guarded, held)


async def relogin(force: bool = False) -> dict:
    """共有アカウントのトークンを取り直して保存する。

    force=False なら RELOGIN_AFTER_DAYS 未満の場合は何もしない。
    戻り値: {"relogged": bool, "refreshed_at": float}
    """
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("Kyash アカウントが登録されていません")
    if not force and not _is_stale(creds):
        return {"relogged": False, "refreshed_at": creds.get("refreshed_at")}

    new_creds = await _relogin_locked(creds)
    return {
        "relogged": _refreshed_at(new_creds) > _refreshed_at(creds),
        "refreshed_at": new_creds.get("refreshed_at"),
    }


# ---- 受け取り ----

def _try_receive_once(creds: dict, url: str, min_amount, screen=None) -> int:
    """1回分の受け取り試行。成功したら受け取った金額(円)を返す。

    screen(info) を渡すと、受け取る直前(送金元が分かっていて、まだお金が
    動いていない時点)で呼ばれる。文字列を返すとその回は受け取らない。
    """
    ky = _client(creds)
    info = ky.link_check(url)
    if not info.is_send_link:
        raise KyashError("これは請求リンクです。Kyashの「送金リンク」を作って送ってください")
    if min_amount:
        if info.amount <= 0:
            # 金額が読めないまま受け取ると不足に気付けないので、受け取らずに止める
            raise KyashError("リンクの金額を確認できませんでした。もう一度リンクを作り直してお試しください")
        if info.amount < min_amount:
            raise KyashError(f"金額が不足しています(必要: {min_amount}円 / リンク: {info.amount}円)")
    # 安全確認。ここで断れば、リンクは開いたまま送り主の手元に残る
    # (受け取ってから返すと、こちらの残高と履歴に一度入れて送り返すことになる)。
    if screen is not None:
        refused = screen(info)
        if refused:
            print(f"[KYASH] 安全確認で受け取りませんでした: {refused}", flush=True)
            raise KyashError(refused)
    ky.link_receive(link_uuid=info.uuid)
    return int(info.amount)


async def receive_payment(url: str, min_amount: int = None, passcode: str = None,
                          on_pending=None, screen=None) -> int:
    """登録済みの共有Kyashアカウントで送金リンクを受け取り、受取金額を返す。

    passcode / on_pending は PayPay と入口を揃えるための引数で、Kyashでは使わない
    (Kyashの送金リンクにはパスワードも承認待ちも無く、その場で確定する)。
    トークンが切れていたら自動で入り直して1度だけやり直す。
    """
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("受取先の Kyash アカウントが登録されていません")

    # 受け取りの直前にトークンが古ければ先に入り直す(お客さんを待たせる前に直す)
    if _is_stale(creds):
        try:
            creds = await _relogin_locked(creds)
        except (ReloginFailedError, OtpRequiredError):
            pass

    try:
        return await asyncio.to_thread(_try_receive_once, creds, url, min_amount,
                                       screen)
    except KyashLoginError:
        try:
            creds = await _relogin_locked(creds)
        except ReloginFailedError:
            raise KyashError("Kyashとの通信が不安定でログインし直せませんでした。"
                             "少し時間をおいてからもう一度お試しください。")
        return await asyncio.to_thread(_try_receive_once, creds, url, min_amount,
                                       screen)


# ---- その他の操作(残高・プロフィール・リンク作成など) ----

async def run_owner_op(op):
    """登録済みの共有Kyashアカウントで op(ky) を実行する。

    op は同期の Kyash メソッドを呼ぶ関数(例: lambda ky: ky.get_wallet())。
    トークン切れは再ログインして一度だけ再試行。未登録は NotRegisteredError。
    """
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("Kyash アカウントが登録されていません")
    try:
        return await asyncio.to_thread(lambda: op(_client(creds)))
    except KyashLoginError:
        try:
            new_creds = await _relogin_locked(creds)
        except ReloginFailedError:
            raise KyashError("Kyashとの通信が不安定でログインし直せませんでした。"
                             "少し時間をおいてからもう一度お試しください。")
        return await asyncio.to_thread(lambda: op(_client(new_creds)))


async def keep_alive() -> bool:
    """トークンがまだ有効かどうかを確かめる。

    戻り値: True=生存 / False=通信エラーなどで判定できず。
    トークンが無効なら KyashLoginError(呼び出し側で再ログインを試す)。
    """
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("Kyash アカウントが登録されていません")

    try:
        await asyncio.to_thread(lambda: _client(creds).alive())
        return True
    except KyashLoginError:
        raise
    except (KyashError, KyashNetWorkError, OSError, ValueError):
        return False


def owner_login_info():
    """保存済みのメールアドレス・パスワードを返す(再ログイン用)。無ければ (None, None)。"""
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return None, None
    return creds.get("email"), creds.get("password")


def is_registered() -> bool:
    return _resolve_owner(load_kyash_data())[1] is not None


def session_status() -> dict:
    """現在のKyashセッション状態(登録有無・最終ログイン/更新時刻)を返す。"""
    data = load_kyash_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return {"registered": False}
    return {
        "registered": True,
        "email": creds.get("email"),
        "logged_in_at": creds.get("logged_in_at"),
        "refreshed_at": creds.get("refreshed_at"),
        "stale": _is_stale(creds),
    }


def signout_owner() -> bool:
    """登録済みKyashアカウントの情報を削除(サインアウト)する。"""
    data = load_kyash_data()
    removed = False
    for k in list(data.keys()):
        if k == OWNER_KEY or (isinstance(data.get(k), dict) and data[k].get("access_token")):
            del data[k]
            removed = True
    if removed:
        save_kyash_data(data)
    return removed
