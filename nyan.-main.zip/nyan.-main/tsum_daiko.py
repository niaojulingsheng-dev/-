"""ツムツム代行の中身(メニュー・価格・売上・実行・バージョン追従)。

Discordの都合はここに持ち込まない(Cogs/tsum.py が受け持つ)。こうしておくと
「支払いは受け取れたのに代行が走らない」ときに、どちらの層で止まったのかを
切り分けられる。

1メニュー = 1つ以上の作業(タスク)。セット商品は中身を並べただけなので、
実行側はタスクを順に流すだけで済む。1回のログインで選ばれた分をまとめて
流す(ログインはツムツム側にとって重い操作で、続けて何度も投げたくない)。

価格・売上・ログ先の置き場所は、にゃんこ代行(main.py)や自販機(Cogs/shop.py)と
同じ考え方で DATA_DIR 配下に置く。
"""
import asyncio
import json
import os
import random
import re
import time
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

import tsum_api
from datapath import data_path, read_json, write_json

BASE_DIR = Path(__file__).resolve().parent

# --- メニュー -------------------------------------------------------------

# コインの上限。ゲーム側の持てる上限に合わせる(これ以上は指定させない)。
COIN_MAX = 200_000_000
# 画面に出すときの言い方。200,000,000 と書くより桁が読みやすい。
COIN_MAX_LABEL = "2億"
# 1プレイのgameEndで申告してよいコインの上限。大きすぎる枚数(2億など)を1回で
# 申告すると、ゲームサーバが retcode=1/retsubcode=2「ゲームサーバでエラー」で丸ごと
# 弾く(実測: 2億は弾かれ、1億は通る)。最初からこの上限で刻めば、その空振りを
# 避けられる。指定合計がこれを超えるぶんは複数プレイに分けて積む。
COIN_CHUNK_MAX = int(os.getenv("TSUM_COIN_CHUNK_MAX", "90000000"))
# コインをいま付けられるアカウント/ゲーム状態かを、支払いの前に1プレイで確かめる
# ときの枚数(_probe_coin)。gameStart ごとゲーム側に弾かれる(retcode=997/8)ことが
# あり、getInfo だけでは分からない。少量を実際に1回付けてみて、残高が動くかを見る。
# 受け取れればそのぶんはご注文の枚数に含める。メダルの MEDAL_PROBE と同じ役割。
COIN_PROBE = int(os.getenv("TSUM_COIN_PROBE", "1000"))
# プレイは通ったのにコインが1枚も増えなかった/プレイ自体が通らなかったときの説明
# (お客さんに出る)。原因を決めつけず、いまは付けられない事実だけ伝える。
COIN_ZERO_TEXT = ("コインを1回試しに付けましたが、ゲーム側でコインが増えませんでした"
                  "（プレイ自体が通らない状態です）。このアカウントには、いまコインを"
                  "付けられません。")
# メダルの指定上限。ゲーム側に所持の上限(画面に「いっぱいだよ!」と出る。50万ほど)
# があり、それより下にいれば1回でそれを飛び越えて入る(実測 9/22: 2,030 →
# 502,030。512,030 からは +0。使って下がれば、また50万入った)。
# 9/23 以降は、所持が上限より下でもプレイは通る(retcode=0)のに1枚も増えない形が
# 続いている。10/1 の実測で、イベントに参加しているかで分かれると分かった:
# 作ったばかりで何も参加していない口は +200,000 そのまま入り、参加中の口
# (イベント157。ゲスト2つ・Lv282 のお客さん・参加させた新しい垢)は +0。参加中の
# 口はイベントを外して始められない(eventid=0 は 8/2)。otherresult にメダルの記録を
# 足しても +0 だった。9/22 は参加中でも入っていたので、その頃の gameEnd の形
# (tsum_api の LEGACY_END)で確かめる(_medal_with_legacy_end)。それでも入らなければ、
# 支払いの前の1プレイの確かめ(_probe_medal)と、付与で増えなかったら1回の確かめで
# 止める(_capped_next)ところで、お代をいただく前に止まる。
# 10/7 の実測で決着: 参加中の口でも、プラスツム(ミッキー＋ など)をマイツムにして
# プレイすれば申告どおり入る(イベント157・ID 860 で 10 → 100 → 1,000 → 10,000 →
# 38,890 を全部丸ごと。gameStart の medallimit は -1 のまま)。普段のツムでは +0。
# ゲームの決まり「プレイで入るメダルはプラスツムを消したぶん」を、イベントの
# プレイだけサーバが検めている。参加中の口のメダルは、お客さんの注文でも最初から
# プラスツムに替えて投げる(_event_medal_mode / _joined_event_blocks_medal)。
MEDAL_MAX = int(os.getenv("TSUM_MEDAL_MAX", "500000"))
MEDAL_MAX_LABEL = "50万"
# プレイは通ったのにメダルが1枚も増えなかったときの説明(お客さんに出る)。
# 原因が確定していないので、上限などと決めつけない。
MEDAL_ZERO_TEXT = ("メダルを1回試しに付けましたが、ゲーム側でメダルが増えませんでした"
                   "（プレイ自体は通っています）。このアカウントには、いまメダルを"
                   "付けられません。")


# JST。イベントの終了日時はマスタの UNIX 秒で来るので、見せるときだけ日本時間に直す。
JST = timezone(timedelta(hours=9))


def _event_end_label(event_row: dict) -> str:
    """参加中イベントの終了日時を『2026/11/01 00:00』の形(JST)で返す。読めなければ空。

    メダルが入らない口は、参加しているイベントが終わるまで付けられない。いつ
    終わるか(=いつ付けられるようになるか)を、お客さん・管理者に伝えるのに使う。
    イベント期間は enddt(開催終了)で見る。落ちていれば closedt で代える。
    """
    if not isinstance(event_row, dict):
        return ""
    for key in ("enddt", "closedt"):
        value = event_row.get(key)
        try:
            ts = int(value)
        except (TypeError, ValueError):
            continue
        if ts <= 0:
            continue
        return datetime.fromtimestamp(ts, JST).strftime("%Y/%m/%d %H:%M")
    return ""


# イベントに参加中の口に出す説明(お客さんに出る)。参加中の口はゲーム側が
# メダルを受け付けないので、ログインした直後に見分けてここで止める。
MEDAL_EVENT_TEXT = "このアカウントは現在イベントに参加中のためメダルを付与出来ません。"


# 1プレイのgameEndで申告してよいメダルの上限。受け取れる残りがあれば1回で
# 入りきるので、既定は指定できる上限と同じ(= 1プレイで終わる)。弾かれたときは
# 半分に落として通る枚数を探す(下の _grant_currency)。
MEDAL_CHUNK_MAX = int(os.getenv("TSUM_MEDAL_CHUNK_MAX", str(MEDAL_MAX)))
# メダルの申告がサーバに弾かれた(retcode≠0)ときに、半分に落として通る枚数を
# 探す回数。コインと違って「1回で通る枚数」の実測が無いので、多めに持たせる。
# プレイは通ったのに増えないときは半分にしない(_grant_currency を参照)。
MEDAL_RETRY_LIMIT = int(os.getenv("TSUM_MEDAL_RETRY_LIMIT", "6"))
# メダルを受け取れる状態かを1プレイで確かめるときの枚数。支払いの前
# (TsumRunner._probe_medal)と、付与で1枚も入らなかったとき(_capped_next)に
# 使う。受け取れればそのまま付く。ハートを1個使う。
MEDAL_PROBE = int(os.getenv("TSUM_MEDAL_PROBE", "100"))
# イベント参加中の口で、メダルが入る送り方を管理者の動作確認で1つずつ試すか
# (既定: 試さない)。10/7 に「プラスツムでプレイ」で入ると確かめたので、参加中の
# 口は管理者もお客さんも最初からその送り方で投げる(_event_medal_mode)。ゲーム側の
# 検め方が変わって入らなくなったときに、TSUM_MEDAL_EVENT_TRIAL=1 で探索
# (_medal_event_trial: プラスツムの段上げ → medallimit 合わせ → 少ない枚数)を
# 管理者の動作確認でだけ有効にできる。見つかった送り方はイベントごとに覚える
# (tsum_api の remember_medal_mode)。
MEDAL_TRIAL_ENABLED = os.getenv("TSUM_MEDAL_EVENT_TRIAL", "0") != "0"
# 1回の動作確認で試しに使うハートの上限(1つの送り方 = 1プレイ = ハート1個)。
# プラスツムで入ったときは、1プレイで入る上限を知るために枚数を上げながら
# 続けるので(10→100→1,000→…)、そのぶんも含む。
MEDAL_TRIAL_HEARTS = int(os.getenv("TSUM_MEDAL_TRIAL_HEARTS", "8"))
# プラスツムで試すときの申告枚数の段。入った段の次へ上げていき、入らなくなった
# 手前が1プレイの上限。最後の段はご注文の枚数(それより上は試さない)。
MEDAL_TRIAL_LADDER = (10, 100, 1_000, 10_000, 100_000)
# 「ごく少ない枚数なら入るか」(1プレイの上限が小さい)を見るときの枚数。
MEDAL_TRIAL_TINY = int(os.getenv("TSUM_MEDAL_TRIAL_TINY", "10"))
# プラスツムで試すプレイの消去数。ゲームの決まりではメダルはプラスツムを消した
# ぶんで入るので、「ついで」の 8〜16 ではなく実際のプレイに近い数を申告する。
PLUS_VANISH_RANGE = (90, 150)
# イベント参加中で、プラスツムを持っていない口に出す説明(参加中の口のメダルは
# 既定でプラスツムに替えて投げるため。limit / tiny を覚えているイベントでは出さない)。
MEDAL_NEEDS_PLUS_TEXT = ("このアカウントは現在イベントに参加中のため、プラスツムをお持ちで"
                         "ないとメダルを付与出来ません。")
SCORE_MAX_LABEL = "21億"
# スコアの上限。これを超える値は受けない。
SCORE_MAX = int(os.getenv("TSUM_MAX_SCORE", "2100000000"))
# プレイヤーレベルの上限。実機の実測に合わせる。経験値を一度に入れると1200で
# 止まり、そこから指定1350で5回まわしても1200のまま動かなかった。
PLAYER_LEVEL_MAX = int(os.getenv("TSUM_PLAYER_LEVEL_MAX", "1200"))
# 1プレイで申告する経験値の初期上限。大きすぎるとコインと同じで、応答は通るのに
# 付与だけ黙って落とされる(実測: この上限でも垢によっては弾かれる)。弾かれたら
# 半分に落として「1回で通る経験値」を探す。
PLAYER_EXP = int(os.getenv("TSUM_PLAYER_EXP", "100000000"))
# 経験値が1も入らない(弾かれた)ときに、申告を半分に落として通る量を探す回数。
PLAYER_EXP_RETRY = int(os.getenv("TSUM_PLAYER_EXP_RETRY", "6"))
# 指定レベルへ寄せるときのプレイ回数の上限(1回ごとにハートを1個使う)。
#
# 指定を飛び越えないよう、必ず少なめに見積もって手前から寄せる(下の
# _exp_to_target を参照)。1回で届かせず何回かに分けるので、遠い指定
# (Lv2→1200 など)でも足りるだけの回数を持たせる。実測に通した曲線では
# 8回あれば Lv2→1200 まで指定ちょうどに着く。届く前にハートが尽きたら
# そこまでで止めて残りを再依頼してもらう(超過しないので取り返しのつかない
# 事故にはならない)。要る回数 = 要るハートの数なので required_hearts も
# これで数える。
PLAYER_LEVEL_ROUNDS = int(os.getenv("TSUM_PLAYER_LEVEL_ROUNDS", "12"))
# ツムレベル上げは「そのツムを消した数」で上がる。1プレイぶんの申告に入れる
# 消去数と、始める前に確かめるハートの数の目安。プレイ1回につきハートを1個
# 使う。実際は上限に届くまで回すので、回数は上限ではない。
TSUM_LEVEL_ROUNDS = int(os.getenv("TSUM_LEVEL_ROUNDS", "10"))
TSUM_LEVEL_VANISH = int(os.getenv("TSUM_LEVEL_VANISH", "600"))
# 「レベルnまでに累計いくつ消せばいいか」は持っていない。ミッキーの実測
# (246でLv2 / 846でLv4 / 6,246でLv9)とミニーの実測(5,400でLv7)が同じ式に
# 乗らないので、消去数だけで決まるものではない。当てずっぽうの残り回数を
# 出すくらいなら、実際に上がったレベルと消去数をそのまま伝える。
# プレイ1回あたりのハート消費。
HEART_PER_PLAY = 1
# 連続プレイの間隔(秒)。gameEnd を秒間隔で連打するのは、ゲームを遊んでいる
# 端末には出せない足取りで、BANの種になる。実プレイ1回ぶん(数十秒)を待つと
# 代行が何十分にもなるので、せめて結果画面を閉じて次を始めるくらいの間を置く。
# 1プレイ目は待たない(注文からの体感を悪くしないため)。
#
# 間隔は前のプレイの開始から測る(_pace_play)。1プレイは gameStart → gameEnd →
# getInfo の3往復で 1秒前後かかるので、それより短い下限にしても効かない。
# 上限は「結果画面を閉じて次を押す」くらい。以前の 2.0〜4.5 は3往復ぶんを
# 二重に見積もっていて、レベル上げ(10〜12プレイ)で1分近くただ待っていた。
# 足取りを緩めたければ環境変数で戻せる。
PLAY_GAP_MIN = float(os.getenv("TSUM_PLAY_GAP_MIN", "1.0"))
PLAY_GAP_MAX = float(os.getenv("TSUM_PLAY_GAP_MAX", "2.2"))
# コインが1枚も増えなかったときに、枚数を半分に落として「1回で通る枚数」を
# 探る回数。見つかったらその枚数を繰り返して指定の合計まで積む(下の _run_coin)。
# 使うのは「残りのタスクに要らないぶんのハート」だけ(_spare_hearts)。
# 3 だと 9,000万からは 1,125万で打ち切りになる。イベントを外す再試行(tsum_api)
# を入れた後は、ここまで来た失敗は本当に枚数の問題である可能性が高いので、
# もう少し深く(9,000万 → 約280万まで)探す。
COIN_RETRY_LIMIT = int(os.getenv("TSUM_COIN_RETRY_LIMIT", "5"))
# 「いったん付いたのに、そこから先が1枚も入らなくなった」ときに、半分へ落として
# 試せる回数。これは枚数が大きすぎるのではなく、ゲーム側の取得上限に当たって
# いる(実測: メダルは50万入った直後から、25万でも1.5万でも +0)。何度も半分に
# するとハートを捨てるだけなので、数回で見切る。
GRANT_STALL_RETRY = int(os.getenv("TSUM_GRANT_STALL_RETRY", "2"))

# タスクの種類
COIN = "coin"
MEDAL = "medal"
# 注文の params で、支払いの前の確かめ(_probe_medal)で付けたメダルの枚数。
# 本番ではこのぶんを抜いて付ける(ご注文の枚数ちょうどにするため)。
MEDAL_PROBED = "medal_probed"
# 注文の params で、支払いの前の確かめ(_probe_coin)で付けたコインの枚数。
# 本番ではこのぶんを抜いて付ける(ご注文の枚数ちょうどにするため)。
COIN_PROBED = "coin_probed"
# 注文の params で、支払いの前の確かめで「9/22 の gameEnd の形なら入る」と分かった印。
# 本番は最初のプレイからその形で投げる(_medal_with_legacy_end を参照)。
MEDAL_LEGACY_END = "medal_legacy_end"
PLAYER_LEVEL = "playerlv"
SCORE = "score"
TSUM_LEVEL = "tsumlv"
GACHA = "gacha"

# パネルに並べるメニュー。並び順がそのまま表示順・処理順になる。
# tasks の値が None のものは、注文時にお客さんが指定した値を使う。
# detail は説明。中身が2つ以上あるものは「・」で縦に並べて出す(セット商品)。
# admin_only=True のものは管理者の動作確認パネルにだけ出す。中身が通ることを
# 確かめてから、この印を外してお客さんのパネルに並べる(価格もそのとき決める)。
# 通貨(コイン・メダル)は完売より前に置くこと。sort_keys の並び=処理順なので、
# 後ろに置くと「回すお金を用意する前に回す」ことになる。
MENUS = {
    "set_a": {
        "label": "松セット",
        "price": 300,
        "detail": ["コイン2億枚", "プレイヤーレベル(指定可)", "ツムレベル50(1体)"],
        "tasks": [(COIN, COIN_MAX), (PLAYER_LEVEL, None), (TSUM_LEVEL, None)],
    },
    "set_b": {
        "label": "竹セット",
        "price": 600,
        "detail": ["コイン(指定可)", "プレイヤーレベル(指定可)", "ツムレベル50(1体)",
                   "プレミアムボックス完売"],
        "tasks": [(COIN, None), (PLAYER_LEVEL, None),
                  (TSUM_LEVEL, None), (GACHA, "premium")],
    },
    "coin": {
        "label": "コイン",
        "price": 100,
        "detail": [f"0〜{COIN_MAX_LABEL}枚まで指定可能"],
        "tasks": [(COIN, None)],
    },
    "medal": {
        "label": "メダル",
        "price": 100,
        "detail": [f"0〜{MEDAL_MAX_LABEL}枚まで指定可能"],
        "tasks": [(MEDAL, None)],
    },
    "player_level": {
        "label": "プレイヤーレベル",
        "price": 100,
        "detail": ["0〜{player_level_max}Lv指定可能"],
        "tasks": [(PLAYER_LEVEL, None)],
    },
    "score": {
        "label": "スコア更新",
        "price": 100,
        "detail": [f"0〜{SCORE_MAX_LABEL}まで指定可能"],
        "tasks": [(SCORE, None)],
    },
    "tsum_level": {
        "label": "ツムレベル1体",
        "price": 100,
        "detail": ["お好きなツムをレベル50"],
        "tasks": [(TSUM_LEVEL, None)],
    },
    "premium_box": {
        "label": "プレミアムボックス完売",
        "price": 300,
        "detail": ["完売まで"],
        "tasks": [(GACHA, "premium")],
    },
    "pickup_box": {
        "label": "ピックアップガチャ完売",
        "price": 300,
        "detail": ["完売まで"],
        "tasks": [(GACHA, "pickup")],
    },
    "select_box": {
        "label": "セレクトボックス完売",
        "price": 300,
        "detail": ["完売まで"],
        "tasks": [(GACHA, "select")],
    },
    "happiness_box": {
        "label": "ハピネスボックス完売",
        "price": 400,
        "detail": ["完売まで"],
        "tasks": [(GACHA, "happiness")],
    },
}

# 完売系メニューが狙うガチャ。resolve_active_gacha_targets のキーと表示名。
# 中身の数(maxcnt)が分からないボックスを、何回まで回すか。
#
# 実測では、空のアカウントからプレミアムを完売させるのに約4,900回・
# 1億5,000万コイン要る。ここを数千回まで下げると、コインが余っているのに
# 「完売には届きませんでした」で終わる。
#
# 実際の上限は残高のほう。プレミアム(1回30,000コイン)はコインが上限の2億
# あっても6,666回までしか回せず、足りなくなればその時点で止まる。ここは
# その先の暴走よけとして置く。
GACHA_MAX_DRAWS = int(os.getenv("TSUM_GACHA_MAX_DRAWS", "10000"))

# pay は「そのボックスを回すのに使う通貨」。ガチャの type の下1桁で決まる
# (1=コイン / 2=ルビー / 4=メダル。_balance_for_type と同じ)。増やせなかった
# 通貨で回すと、元から持っていたぶんを削るだけになるので、その見送り判断に使う。
#
# premiumplus(プレミアムボックス+)は type=64 = メダル建てで、メダルには所持
# 上限があるため一度に50万ほどしか持てない(1回10,000なら50回で止まる)。完売
# させるにはメダルを足しながら回し続けることになるが、頼まれたのは「完売」で
# あって通貨を増やすことではないので、メニューには出していない。
GACHA_KINDS = {
    "premium": {"label": "プレミアムボックス", "multi": True, "api_label": "PREMIUM",
                "pay": COIN},
    "select": {"label": "セレクトボックス", "multi": True, "api_label": "SELECT",
               "pay": COIN},
    "happiness": {"label": "ハピネスボックス", "multi": False, "api_label": "HAPPINESS",
                  "pay": COIN},
    "pickup": {"label": "ピックアップ", "multi": True, "api_label": "PICKUP",
               "pay": COIN},
    "premiumplus": {"label": "プレミアムボックス+", "multi": True, "api_label": "PREMIUM+",
                    "pay": MEDAL},
}


# セットの中の1項目としての呼び方。1つのメニューが途中で止まったときに
# 「何が残っているか」を伝えるのに使う。
TASK_LABELS = {
    COIN: "コイン",
    MEDAL: "メダル",
    PLAYER_LEVEL: "プレイヤーレベル",
    SCORE: "スコア更新",
    TSUM_LEVEL: "ツムレベル",
}


def gacha_pay(name: str) -> str:
    """その完売を回すのに使う通貨(タスクの種類として返す)。"""
    return (GACHA_KINDS.get(name) or {}).get("pay", COIN)


# 完売までに何回要るかの実績。ボックスの中身の数(maxcnt)はマスタに入っていない
# ことがある(プレミアムボックス+は空だった)。入っていないと「完売までにいくら
# 要るか」が出せず、『足りないうちは1回も回さない』という歯止めが効かない。
# 実際、メダル51万を溶かして未完売で終わっている(51回で止まった)。
# 回した実績を覚えておいて、次からは足りないと分かっている注文を回さない。
GACHA_SIZE_FILE = data_path("tsum_gacha_sizes.json")


def load_gacha_sizes() -> dict:
    return read_json(GACHA_SIZE_FILE, {})


def record_gacha_size(name: str, draws: int, completed: bool, price: int = 0):
    """完売までに要った回数を覚える。

    完売したら確定値。未完売なら「最低でもこれだけは要る」という下限として、
    いちばん多く回せたときの回数を残す。
    """
    draws = int(draws or 0)
    if not name or draws <= 0:
        return
    data = load_gacha_sizes()
    rec = dict(data.get(name) or {})
    known = int(rec.get("draws") or 0)
    if completed:
        rec.update({"draws": draws, "completed": True})
    elif not rec.get("completed") and draws > known:
        rec.update({"draws": draws, "completed": False})
    else:
        return                              # 覚えていることより新しくない
    if price:
        rec["price"] = int(price)
    rec["at"] = int(time.time())
    data[name] = rec
    write_json(GACHA_SIZE_FILE, data)


def gacha_min_draws(name: str) -> tuple:
    """(完売までに要る回数, 実測で確定しているか)。分からなければ (0, False)。"""
    rec = load_gacha_sizes().get(name) or {}
    draws = int(rec.get("draws") or 0)
    if draws <= 0:
        return 0, False
    # 未完売の記録は「そこまで回してもまだだった」なので、要るのはそれより多い。
    return (draws, True) if rec.get("completed") else (draws + 1, False)


# ツムレベル上げの効きかたを決める2つ。環境変数を触れない場所から運用して
# いるので、Discordのコマンドで変えられるようファイルに置く(価格と同じ考え方)。
TUNING_FILE = data_path("tsum_tuning.json")
# 1プレイの申告数の上限。ここまでなら試せる、という枠。
LEVEL_VANISH_MAX = int(os.getenv("TSUM_LEVEL_VANISH_MAX", "1000000"))
LEVEL_ROUNDS_MAX = int(os.getenv("TSUM_LEVEL_ROUNDS_MAX", "50"))
# ツムレベル上げで、上限に届かないまま回り続けないための歯止め(プレイ回数)。
# 普段は上限に届く・ハートが尽きる・経験値が増えない、のどれかで先に止まる。
LEVEL_PLAYS_GUARD = int(os.getenv("TSUM_LEVEL_PLAYS_GUARD", "1000"))
# 実際のプレイで消せる数の目安。これを大きく超える申告は、ゲーム側から見て
# 人間のプレイに見えない。申告60,000で流した直後に検証用アカウントが停止
# されているので、超える設定にするときは断りを出す。
LEVEL_VANISH_SAFE = int(os.getenv("TSUM_LEVEL_VANISH_SAFE", "2000"))


def load_tuning() -> dict:
    return read_json(TUNING_FILE, {})


def save_tuning(data: dict):
    write_json(TUNING_FILE, data)


def level_vanish() -> int:
    """ツムレベル上げで、1プレイあたりに申告する消去数。"""
    value = load_tuning().get("level_vanish")
    return max(1, min(int(value), LEVEL_VANISH_MAX)) if value else TSUM_LEVEL_VANISH


def level_rounds() -> int:
    """ツムレベル上げのプレイ回数(= 使うハートの数)。"""
    value = load_tuning().get("level_rounds")
    return max(1, min(int(value), LEVEL_ROUNDS_MAX)) if value else TSUM_LEVEL_ROUNDS


def player_level_max() -> int:
    """指定できるプレイヤーレベルの上限。

    ゲーム側の本当の上限が分からないので設定で持つ。実機では経験値を一度に
    入れて 1200 まで上がっている。ここが実際の上限より低いと、すでにそれ以上
    いるアカウントでは指定そのものができない(確かめようがない)。
    """
    value = load_tuning().get("player_level_max")
    return max(1, min(int(value), 100_000)) if value else PLAYER_LEVEL_MAX


def menu_detail(key: str) -> list:
    """パネルに出す説明。上限は設定で変わるので、読むたびに作り直す。"""
    return [line.format(player_level_max=player_level_max())
            for line in (menu(key).get("detail") or [])]


def task_label(kind: str, value=None) -> str:
    if kind == GACHA:
        return (GACHA_KINDS.get(value) or {}).get("label", str(value)) + "完売"
    return TASK_LABELS.get(kind, kind)


def menu(key: str) -> dict:
    return MENUS.get(key) or {}


def is_admin_only(key: str) -> bool:
    """まだ売り物にしていない(管理者の動作確認だけの)メニューか。"""
    return bool(menu(key).get("admin_only"))


def menu_items(admin: bool = False) -> list:
    """パネルに並べるメニューを [(key, item), ...] で返す。

    admin=False はお客さん向け。動作確認中のメニューは出さない。売れるように
    なったら MENUS の admin_only を外すだけで、両方のパネルに出る。
    """
    return [(key, item) for key, item in MENUS.items()
            if admin or not item.get("admin_only")]


def menu_label(key: str) -> str:
    return menu(key).get("label", key)


def menu_tasks(key: str) -> list:
    return list(menu(key).get("tasks") or [])


def sort_keys(keys) -> list:
    """選ばれたメニューを表示順に並べ直す(処理順もこの順)。"""
    order = list(MENUS)
    return sorted((k for k in keys if k in order), key=order.index)


def summary(keys) -> str:
    """注文の要約(見張りの一覧やDMに出す短い1行)。"""
    labels = [menu_label(k) for k in keys]
    if len(labels) <= 3:
        return " / ".join(labels)
    return " / ".join(labels[:3]) + f" ほか{len(labels) - 3}件"


# 注文のときに数字で指定してもらうもの。
# (タスクの種類, 表示名, 上限, 上限の言い方, 単位)
# プレイヤーレベルの上限は設定で変わるので、読むたびに作り直す。
def input_specs() -> tuple:
    cap = player_level_max()
    return (
        (COIN, "コインの枚数", COIN_MAX, COIN_MAX_LABEL + "枚", "枚"),
        (MEDAL, "メダルの枚数", MEDAL_MAX, MEDAL_MAX_LABEL + "枚", "枚"),
        (PLAYER_LEVEL, "プレイヤーレベル", cap, f"{cap}Lv", "Lv"),
        (SCORE, "スコア", SCORE_MAX, SCORE_MAX_LABEL, ""),
    )


def needs_inputs(keys) -> list:
    """その注文で数字を聞く必要があるもの。input_specs() の並び順で返す。

    tasks の値が None のものが「お客さんが決める」ぶん。セットのように
    値が決まっているものは聞かない。
    """
    asked = {kind for k in keys for kind, value in menu_tasks(k) if value is None}
    return [item for item in input_specs() if item[0] in asked]


def needs_tsum(keys) -> bool:
    """どのツムを上げるか聞く必要があるか。"""
    return any(kind == TSUM_LEVEL for k in keys for kind, _ in menu_tasks(k))


def _rounds_for(kind: str, value) -> int:
    """その処理に要るプレイ回数(= ハートの数)。"""
    if kind == TSUM_LEVEL:
        # 上限に届くまで回すので本当の回数は決まらない。始める前に確かめる
        # ハートの数として、設定の回数を目安に使う。
        return level_rounds()
    if kind == PLAYER_LEVEL:
        # 上限まで上げるだけなら1回。途中のレベルを狙うときは、今の経験値から
        # 見当をつけて何回か寄せていくので、その回数ぶん要る。
        return 1 if value is not None else PLAYER_LEVEL_ROUNDS
    if kind in (COIN, MEDAL, SCORE):
        return 1
    return 0


def required_hearts(keys) -> int:
    """その注文に要るハートの数。

    ハートはこちらで買わない(ルビーを勝手に使わないため)。足りない注文は
    支払いの前に止めて、用意してもらってからにする。

    メダルは支払いの前に1プレイで受け取れるかを確かめる(TsumRunner._probe_medal)
    ので、そのぶんも数える。
    """
    need = sum(_rounds_for(kind, value) * HEART_PER_PLAY
               for key in keys for kind, value in menu_tasks(key))
    if any(kind == MEDAL for key in keys for kind, _ in menu_tasks(key)):
        need += HEART_PER_PLAY
    if any(kind == COIN for key in keys for kind, _ in menu_tasks(key)):
        # コインも支払いの前に1プレイで確かめる(_probe_coin)。そのぶんを数える。
        need += HEART_PER_PLAY
    return need


def hearts_note(keys) -> str:
    """ハートの用意をお願いする一文(要らない注文では空)。"""
    need = required_hearts(keys)
    return (f"ハートを{need}個使います。足りないと途中で止まるので、ご用意ください。\n"
            "プレゼントBOXのハートは、アプリで受け取るまで使えません。") if need else ""


# --- 価格 -----------------------------------------------------------------

PRICES_FILE = data_path("tsum_prices.json")


def default_price(key: str) -> int:
    return int(menu(key).get("price", 0))


def load_prices() -> dict:
    return read_json(PRICES_FILE, {})


def save_prices(data: dict):
    write_json(PRICES_FILE, data)


def get_price(key: str) -> int:
    return int(load_prices().get(key, default_price(key)))


def compute_item_prices(keys) -> dict:
    """メニューごとの課金額 {key: 円}。"""
    prices = load_prices()
    return {k: int(prices.get(k, default_price(k))) for k in keys}


def compute_total(keys) -> int:
    return sum(compute_item_prices(keys).values())


# --- ゲームバージョンの追従 -----------------------------------------------

# ツムツムが更新されると古いバージョンでは弾かれ、代行が丸ごと止まる。
# にゃんこ大戦争と同じで、App Storeの最新版を定期的に見て自動で切り替える。
TSUM_APPSTORE_ID = os.getenv("TSUM_APPSTORE_ID", "724594093")  # LINE:ディズニー ツムツム
VERSION_CHECK_INTERVAL_HOURS = float(os.getenv("TSUM_VERSION_CHECK_HOURS", "6"))

# main.py と同じ設定ファイルを共有する(設定の置き場所を増やさない)。
CONFIG_FILE = data_path("config.json")


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


def _save_config(cfg: dict):
    write_json(CONFIG_FILE, cfg)


def get_app_version() -> str:
    """使うアプリバージョン。設定(=自動更新の結果)→起動時の既定。"""
    return str(_config().get("tsum_app_version") or tsum_api.DEFAULT_APP_VER)


def set_app_version(version: str):
    cfg = _config()
    cfg["tsum_app_version"] = str(version)
    _save_config(cfg)
    apply_versions()


def derive_res_version(app_ver: str) -> str:
    """アプリのバージョンからリソースのバージョンを見当づける。

    手元にある組み合わせ(app 12.8.1 / res 12.8.0)から、リソース側は
    同じ メジャー.マイナー の .0 と見なす。外れたときは
    `/tsum_version res` で直接指定すれば、こちらの見当は使われない。
    """
    parts = [p for p in str(app_ver).split(".") if p.strip().isdigit()]
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}.0"
    return str(app_ver)


def get_res_version() -> str:
    cfg = _config()
    if cfg.get("tsum_res_version"):
        return str(cfg["tsum_res_version"])
    if os.getenv("TSUM_RES_VER"):
        # env で明示されているならそれを正とする(見当より確かなので)。
        return os.getenv("TSUM_RES_VER").strip()
    return derive_res_version(get_app_version())


def set_res_version(version: str):
    cfg = _config()
    cfg["tsum_res_version"] = str(version)
    _save_config(cfg)
    apply_versions()


def apply_versions():
    """いま使うバージョンをAPIクライアントへ反映する(再デプロイ不要)。"""
    tsum_api.set_versions(get_app_version(), get_res_version())


def version_tuple(v: str) -> tuple:
    parts = []
    for p in str(v).split("."):
        m = re.match(r"\d+", p.strip())
        parts.append(int(m.group()) if m else 0)
    return tuple(parts)


def is_newer_version(candidate: str, current: str) -> bool:
    a, b = version_tuple(candidate), version_tuple(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))


def get_version_check_state() -> dict:
    return _config().get("tsum_version_check", {}) or {}


def _record_version_check(latest, updated_from=None, updated_to=None):
    cfg = _config()
    st = cfg.setdefault("tsum_version_check", {})
    st["last_checked_at"] = time.time()
    st["last_seen_latest"] = latest
    if updated_to:
        st["last_updated_at"] = time.time()
        st["last_updated_from"] = updated_from
        st["last_updated_to"] = updated_to
    _save_config(cfg)


def fetch_latest_app_version():
    """App Storeの最新バージョンを取る(ブロッキング/失敗時None)。"""
    try:
        r = requests.get("https://itunes.apple.com/lookup",
                         params={"id": TSUM_APPSTORE_ID, "country": "jp"}, timeout=15)
        j = r.json()
        if j.get("resultCount"):
            return j["results"][0].get("version")
    except Exception as e:
        print(f"[TSUM VERSION] 最新版の取得に失敗: {e}", flush=True)
    return None


def check_and_update_app_version() -> dict:
    """最新版を見て、今より新しければ切り替える(ブロッキング)。

    戻り値 {"latest","current","updated","before"}。latest が None なら取得失敗。
    古いほうへは下げない(手で新しめに寄せた設定を尊重する)。
    """
    current = get_app_version()
    latest = fetch_latest_app_version()
    if not latest:
        return {"latest": None, "current": current, "updated": False, "before": current}
    if is_newer_version(latest, current):
        set_app_version(latest)
        _record_version_check(latest, updated_from=current, updated_to=latest)
        print(f"[TSUM VERSION] {current} -> {latest} へ自動更新", flush=True)
        return {"latest": latest, "current": latest, "updated": True, "before": current}
    _record_version_check(latest)
    return {"latest": latest, "current": current, "updated": False, "before": current}


# --- ツムの名前(結果の表示に使う) -----------------------------------------

# どのツムを上げるかは名前では受けない。ゲームは名前を画像でしか持っておらず、
# 衣装違いを名前で見分ける手立てがないため、対象はアプリの『マイツム』設定
# (getInfo の setflg)で決める。ここにあるのは、それを画面に出すときの名前。

MASTER_FILE = BASE_DIR / "tsum_master.json"
# 日本語名の対応表。マスタは英語名(画像のファイル名)しか持っていないので、
# 日本語で見せるためにこちらで持つ。
NAMES_JA_FILE = BASE_DIR / "tsum_names_ja.json"
_master_cache = None
_names_ja_cache = None
_names_by_id_cache = None
_base_keys_cache = None


# ゲームが教えてくれたツムを覚えておく先。同梱の表はゲームの更新に追いつけない
# (実際 ID 1020 で止まっているのに、ゲームには 1027 まである)。追いつかないと、
# 新しいツムを指定した注文を「そんなツムは無い」と断ってしまう。
LEARNED_FILE = data_path("tsum_learned.json")


def load_learned_tsums() -> dict:
    """覚えたツム。{id: {...}}。読めなければ空。"""
    out = {}
    for key, value in (read_json(LEARNED_FILE, {}) or {}).items():
        if not isinstance(value, dict):
            continue
        try:
            out[int(value.get("tsumid", key))] = value
        except (TypeError, ValueError):
            continue
    return out


def load_tsum_master() -> dict:
    """{tsumid: {...}} を読む。同梱の表に、覚えたぶんを重ねる。

    同梱の表のほうが詳しい(英語名・上限レベル・画像)ので、同じIDがあれば
    そちらを優先する。覚えたぶんは「そのIDのツムが存在する」ことだけを
    足す役目で、名前は分からないままのこともある。
    """
    global _master_cache
    if _master_cache is None:
        raw = read_json(str(MASTER_FILE), {})
        out = dict(load_learned_tsums())
        for key, value in (raw or {}).items():
            if not isinstance(value, dict):
                continue
            try:
                out[int(value.get("tsumid", key))] = value
            except (TypeError, ValueError):
                continue
        _master_cache = out
    return _master_cache


_plus_ids_cache = None


def plus_tsum_ids() -> set:
    """プラスツム(＋ツム)のID。

    同梱の表では、英語名が plus で終わるもの(donaldplus など)と、rare=2 のもの
    (プラスツムだけがこの値。名前の入っていない 860 = ミッキー＋ なども拾える)。
    ゲームの決まりでは、プレイでメダルが入るのはプラスツムをマイツムにして
    消したときだけ。イベント参加中の口でメダルを付けるときに、どのツムで
    プレイするかを選ぶのに使う。
    """
    global _plus_ids_cache
    if _plus_ids_cache is None:
        ids = set()
        for tsum_id, row in load_tsum_master().items():
            if not isinstance(row, dict):
                continue
            eng = str(row.get("eng_name") or "").lower()
            try:
                rare = int(row.get("rare")) if row.get("rare") is not None else None
            except (TypeError, ValueError):
                rare = None
            if eng.endswith("plus") or rare == 2:
                try:
                    ids.add(int(row.get("tsumid", tsum_id)))
                except (TypeError, ValueError):
                    continue
        _plus_ids_cache = ids
    return _plus_ids_cache


def is_plus_tsum(tsum) -> bool:
    """持ち物の1体(TsumInfo)がプラスツムか。

    表に載っていない新しいプラスツムは、getInfo の wappen(ワッペン。プラスツム
    だけが持つ欄で、普通のツムは null)で見分ける。
    """
    try:
        if int(tsum.tsumid or 0) in plus_tsum_ids():
            return True
    except (TypeError, ValueError):
        pass
    return isinstance(getattr(tsum, "wappen", None), list)


_bundled_ids_cache = None


def bundled_tsum_ids() -> set:
    """同梱の表に載っているIDだけ。覚えたぶんは含めない。

    「こちらが名乗っているバージョンが知っているツム」を判断するのに使う。
    覚えたぶんは『ゲームに存在する』ことしか意味しないので、ここには入れない。
    """
    global _bundled_ids_cache
    if _bundled_ids_cache is None:
        ids = set()
        for key, value in (read_json(str(MASTER_FILE), {}) or {}).items():
            try:
                ids.add(int(value.get("tsumid", key)
                            if isinstance(value, dict) else key))
            except (TypeError, ValueError):
                continue
        _bundled_ids_cache = ids
    return _bundled_ids_cache


def learn_tsums(entries) -> list:
    """ゲームが教えてくれたツムのうち、まだ知らないIDを覚える。

    entries は getInfo の tsuminfo や、getMast のガチャの中身のような
    「tsumid を持つ並び」。同梱の表にあるものには触らない(あちらのほうが
    詳しい)。上限レベルは limitlv を手掛かりとして残すだけで、maxlv として
    は名乗らない(limitlv は今そのアカウントで解放されている上限で、
    そのツムの上限そのものとは限らないため)。

    戻り値は新しく覚えたIDの並び。
    """
    global _master_cache
    known = load_tsum_master()
    learned = load_learned_tsums()
    found = []
    for entry in entries or []:
        if isinstance(entry, dict):
            raw_id = entry.get("tsumid") or entry.get("id")
            limit = entry.get("limitlv")
        else:
            raw_id, limit = entry, None
        try:
            tsum_id = int(raw_id)
        except (TypeError, ValueError):
            continue
        if tsum_id <= 0 or tsum_id in known:
            continue
        learned[tsum_id] = {"tsumid": tsum_id, "learned_at": int(time.time())}
        if limit:
            learned[tsum_id]["limitlv_seen"] = int(limit)
        found.append(tsum_id)
    if found:
        write_json(LEARNED_FILE, {str(k): v for k, v in sorted(learned.items())})
        _master_cache = None          # 次に読むときに重ね直す
        print(f"[TSUM] 知らないツムを覚えました: {found}", flush=True)
    return found


def _load_names_file():
    """日本語名の対応表を読む(基準名ぶんとID指定ぶん)。"""
    global _names_ja_cache, _base_keys_cache, _names_by_id_cache
    if _names_ja_cache is not None:
        return
    raw = read_json(str(NAMES_JA_FILE), {})

    def clean(value):
        if not isinstance(value, list):
            return []
        return [str(v).strip() for v in value if str(v).strip()]

    by_id = {}
    for key, value in (raw.get("_by_id") or {}).items():
        names = clean(value)
        if names:
            try:
                by_id[int(key)] = names
            except (TypeError, ValueError):
                continue
    out = {}
    for key, value in (raw or {}).items():
        if str(key).startswith("_"):
            continue
        names = clean(value)
        if names:
            out[str(key).lower()] = names
    _names_ja_cache = out
    _names_by_id_cache = by_id
    # 長いキーから先に見る。boo と boogie のように片方がもう片方の
    # 先頭に含まれる場合、短いほうへ吸われないようにするため。
    _base_keys_cache = sorted(out, key=len, reverse=True)


def load_names_ja() -> dict:
    """{元の英語名: [日本語名, ...]}。無ければ空(英語名とIDだけ)。"""
    _load_names_file()
    return _names_ja_cache


def load_names_by_id() -> dict:
    """{tsumid: [日本語名, ...]}。英語名から引けない子の上書き。"""
    _load_names_file()
    return _names_by_id_cache


def base_eng_name(eng_name: str) -> str:
    """別バージョンを含む英語名から『元の名前』を取り出す。

    ariel → ariel / arielcm → ariel のように、別バージョンは元の名前に
    語尾が付いた形になっている。一番長く前方一致したキーを元の名前とする。
    """
    load_names_ja()
    name = str(eng_name or "").lower()
    for key in _base_keys_cache or []:
        if name.startswith(key):
            return key
    return ""


def tsum_name_ja(tsum_id: int) -> str:
    """そのツムの日本語名(分からなければ空)。ID指定の上書きを先に見る。"""
    names = _aliases_for(tsum_id)
    return names[0] if names else ""


def _aliases_for(tsum_id: int) -> list:
    """そのツムの日本語名(呼び方)の一覧。ID指定の上書きを先に見る。"""
    tsum_id = int(tsum_id)
    by_id = load_names_by_id().get(tsum_id)
    if by_id:
        return by_id
    entry = load_tsum_master().get(tsum_id) or {}
    return load_names_ja().get(base_eng_name(entry.get("eng_name"))) or []


def tsum_full_name(tsum_id: int) -> str:
    """いちばん詳しい呼び方(フルネーム)。分からなければ空。

    「ミッキー」に対する「ミッキーマウス」のように、代表名をそのまま含んで
    長くなっているものだけをフルネームとして扱う。「チェシャ猫」に対する
    「チェシャネコ」のような書き方違いは、詳しくなっていないので採らない。
    """
    names = _aliases_for(tsum_id)
    if not names:
        return ""
    head = normalize_query(names[0])
    longer = [n for n in names[1:]
              if len(n) > len(names[0]) and head in normalize_query(n)]
    return max(longer, key=len) if longer else ""


def is_variant(tsum_id: int) -> bool:
    """同じキャラの別バージョン(衣装違いなど)かどうか。

    別バージョンは英語名が『元の名前＋語尾』の形になっている。名前で見分ける
    手立てが無いので、指定はIDでしか受けない。ただし素の版が配信されていない
    キャラは、その代表になる1体を『その子本人』として扱う(ハートの女王など、
    別バージョンしか居ないキャラでIDを出しても意味がないため)。
    """
    tsum_id = int(tsum_id)
    if tsum_id in load_names_by_id():
        return False
    eng = str((load_tsum_master().get(tsum_id) or {}).get("eng_name") or "").lower()
    base = base_eng_name(eng)
    if not base or eng == base:
        return False
    # その名前をID指定で持っている子(ハピネスBOXのミッキーなど)が居るなら、
    # こちらは名前が同じでも別バージョン。
    name = tsum_name_ja(tsum_id)
    for other, names in load_names_by_id().items():
        if other != tsum_id and names and names[0] == name:
            return True
    same = _tsums_of_base(base)
    return bool(same) and same[0] != tsum_id


def tsum_name(tsum_id: int) -> str:
    """お客さんに見せる名前。

    名前で当たった子はフルネームまで添えて出す(「ミッキー（ミッキーマウス）」)。
    名前が分からない子・別バージョンはIDでしか区別できないので、IDを添える。
    """
    tsum_id = int(tsum_id)
    names = _aliases_for(tsum_id)
    if not names:
        eng = str((load_tsum_master().get(tsum_id) or {}).get("eng_name") or "")
        return f"{eng}（ID {tsum_id}）" if eng else f"ID {tsum_id}"
    if is_variant(tsum_id):
        return f"{names[0]}（ID {tsum_id}）"
    full = tsum_full_name(tsum_id)
    return f"{names[0]}（{full}）" if full else names[0]


def tsum_exists(tsum_id: int) -> bool:
    master = load_tsum_master()
    return not master or int(tsum_id) in master


# 名前の区切りに使われがちで、あってもなくても同じ字。落として比べる。
_IGNORED_CHARS = " 　・=&\'\"-_.,/、。!?"


def normalize_query(text: str) -> str:
    """名前を見比べるとき用に表記をそろえる。

    半角カナ・全角英数はNFKCでまとめ、ひらがなはカタカナに、英字は小文字に、
    区切りの記号と空白は落とす(「ジャック・スパロウ」と「ジャックスパロウ」を
    同じ扱いにする)。伸ばし棒は名前の一部なので残す。
    """
    out = []
    for ch in unicodedata.normalize("NFKC", str(text or "").strip()):
        code = ord(ch)
        if 0x3041 <= code <= 0x3096:            # ひらがな → カタカナ
            ch = chr(code + 0x60)
        if ch in _IGNORED_CHARS:
            continue
        out.append(ch.lower())
    return "".join(out)


def _tsums_of_base(base: str) -> list:
    """その元の名前を持つツムのID。素の版を先に、あとはID順。"""
    master = load_tsum_master()
    ids = [tsum_id for tsum_id, entry in master.items()
           if base_eng_name(entry.get("eng_name")) == base]
    ids.sort(key=lambda i: (str(master[i].get("eng_name") or "").lower() != base, i))
    return ids


# --- 無料利用券 -----------------------------------------------------------

# にゃんこ代行(main.py)と同じ券をそのまま使う。券の発行・剥奪は main.py 側の
# コマンドが持っているので、こちらは読むだけにする(置き場所を増やさない)。
FREE_TICKET_FILE = data_path("free_tickets.json")


def free_ticket_expiry(user_id) -> float:
    exp = read_json(FREE_TICKET_FILE, {}).get(str(user_id), 0)
    try:
        exp = float(exp)
    except (TypeError, ValueError):
        return 0
    return exp if exp > time.time() else 0


def has_free_ticket(user_id) -> bool:
    return free_ticket_expiry(user_id) > 0


# --- 売上 -----------------------------------------------------------------

# ツムツム代行の売上。にゃんこ代行(sales.json)とは商品キーの体系が違うので、
# 同じファイルに混ぜない(混ぜると商品別の内訳が読めなくなる)。
SALES_FILE = data_path("tsum_sales.json")


def load_sales() -> list:
    return read_json(SALES_FILE, [])


def record_sale(amount: int, user_id, keys, item_prices: dict = None,
                method: str = "paypay", tx_id: str = None):
    """実際に受け取った金額だけを1件記録する。

    tx_id はログに出したのと同じ取引番号。売上とログを後から突き合わせる
    ときの手がかりになる。
    """
    if int(amount or 0) <= 0:
        return
    data = load_sales()
    entry = {"ts": time.time(), "amount": int(amount), "method": method,
             "user_id": str(user_id), "items": list(keys)}
    if tx_id:
        entry["tx_id"] = str(tx_id)
    if item_prices:
        entry["item_prices"] = {k: int(v) for k, v in item_prices.items()}
    data.append(entry)
    write_json(SALES_FILE, data)


def sale_item_amounts(sale: dict) -> dict:
    """1件の売上をメニューごとの金額に配分する {key: 円}。

    単価の記録があればその比率で、無ければ件数で均等割る。合計は必ず実受取額と
    一致させる(内訳の合計と総額がずれると、どちらが本当か分からなくなる)。
    """
    items = list(sale.get("items") or [])
    amount = int(sale.get("amount", 0))
    if not items or amount <= 0:
        return {}
    weights_src = sale.get("item_prices") or {}
    weights = [max(int(weights_src.get(k, 0)), 0) for k in items]
    if sum(weights) <= 0:
        weights = [1] * len(items)
    total_w = sum(weights)
    out, allocated = {}, 0
    for idx, k in enumerate(items):
        amt = amount - allocated if idx == len(items) - 1 else amount * weights[idx] // total_w
        allocated += amt
        out[k] = out.get(k, 0) + amt
    return out


# --- 実行 -----------------------------------------------------------------

class TsumLoginError(Exception):
    """LINE/ゲームサーバーにログインできなかった。

    リフレッシュトークンが失効している場合もここに来る。何度やり直しても
    結果は変わらないので、呼び出し側はお客さんにログインし直してもらう。
    """


async def line_login(line_id: str, password: str, captcha_callback=None,
                     pin_callback=None) -> str:
    """LINEにログインしてリフレッシュトークンを返す。

    メールアドレスとパスワードはここから先へ渡さない(保存もしない)。以降の
    やり直しに使うのはリフレッシュトークンだけ。

    pin_callback(pin) は、LINEがPINコード認証を求めたときにその数字を
    お客さんへ見せるための入口。見せないと、LINEアプリに出た選択肢の
    どれを押せばいいのか分からないまま時間切れになる。
    """
    apply_versions()
    oauth = tsum_api.LineOAuthLogin(
        line_id=line_id, password=password, captcha_callback=captcha_callback,
        pin_callback=pin_callback)
    _, refresh_token = await oauth.login()
    if not refresh_token:
        raise TsumLoginError("LINEのログインに失敗しました")
    return refresh_token


async def validate_guest(migration_id: str, password: str):
    """引き継ぎ番号・パスワードが正しいか、垢を動かさずに確かめる。

    支払いの前に呼ぶ。番号は代行の直前まで消費しない(dryRun)。違っていれば
    TsumLoginError にして返す(お客さんに番号を確かめてもらう)。
    """
    apply_versions()
    try:
        await tsum_api.validate_guest_code(migration_id.strip(), password)
    except tsum_api.TsumMigrationError as e:
        raise TsumLoginError(str(e)) from e


class TsumRunner:
    """1回のログインで、選ばれたメニューを順に流す。

    ログインしてから getInfo までを open() で済ませ、以降は run(key) を呼ぶ。
    残高はメニューごとに変わるので、run() の頭で毎回取り直す。
    """

    def __init__(self, refresh_token: str = None, params: dict = None,
                 guest_id: str = None, guest_password: str = None,
                 medal_trial: bool = False):
        self.refresh_token = refresh_token
        # 管理者の動作確認か。イベント参加中の口でメダルが入る送り方を、ハートを
        # 使って1つずつ試してよいのはこのときだけ(_medal_event_trial。既定では
        # 試さず、お客さんと同じ「プラスツムでプレイ」で投げる。MEDAL_TRIAL_ENABLED)。
        self.medal_trial = bool(medal_trial)
        # 引き継ぎ番号で入るときは refresh_token の代わりにこちらを使う。
        self.guest_id = guest_id
        self.guest_password = guest_password
        # 注文時にお客さんが指定した値 {"coin": 枚数, "tsum_id": ツムID}
        self.params = dict(params or {})
        self.client = None
        self.raw = {}          # getInfo の生応答(チケット数を見るのに要る)
        self.info = None       # GetInfoResponse
        # 調べもの用の記録。コンソールを見られないところから運用しているので、
        # 1プレイずつの入り方は非公開ログに載せて追えるようにする。
        self.trace = []
        # 残っていたプレイの札を閉じたかどうか（1回だけ試す）
        self._closed_pending = False
        # マイツムを一時的に替えたときの、元のツムID（終わったら戻す）
        self._switched_mytsum = None
        # イベント付きのプレイが弾かれた/0枚だったときの中身(1回ぶん)。
        # 非公開ログにファイルで添付する(埋め込みの欄には入りきらないため)。
        self.debug = None
        # 手元の getInfo(self.info / self.raw)が、ゲーム側の今と合っているか。
        # プレイやガチャなど、残高を動かす要求を投げたら False に落とし
        # (_touch)、取り直したら True に戻す(refresh_info)。合っているあいだは
        # 取り直さない。メニューの頭と終わりで毎回 getInfo(応答は大きい)を
        # 投げていたが、直前に取り直したばかりで中身は同じだった。
        self._info_fresh = False
        # 支払いの前のメダルの確かめ(_probe_medal)で、受け取れなかったときの
        # 理由(受け取れれば空)と、確かめで実際に付いた枚数。
        self._medal_block = ""
        self._medal_probed = 0
        # 支払いの前のコインの確かめ(_probe_coin)で、付けられなかったときの理由
        # (付けられれば空)と、確かめで実際に付いた枚数。
        self._coin_block = ""
        self._coin_probed = 0
        # メダルが0枚だったときに、イベントを外して確かめたか(1接続で1回だけ)。
        self._medal_noevent_tried = False
        # 外せなかったときに、9/22 の gameEnd の形で確かめたか(1接続で1回だけ)。
        self._legacy_end_tried = False
        # ハート切れでプレイを投げなかったことを記録に書いたか(1接続で1回だけ)。
        self._no_heart_noted = False
        # メダルが入らない原因が「イベント参加中」と分かったときの、参加している
        # イベントの終了日時(メダルはイベントが終わるまで付けられない)。空なら
        # まだ分かっていない。_capture_event_debug がマスタから拾って入れる。
        self._blocked_event_ends = ""
        # イベント参加中の口でメダルが入る送り方(tsum_api.medal_mode_for の中身)。
        # None はまだ引いていない。{} は「参加していない / 分かっていない」。
        self._medal_mode = None
        # 管理者の動作確認で送り方を試し終えたか(結果は _medal_probed / _medal_block)。
        self._medal_trial_done = False
        # 直近のメダルのプレイで gameStart が返した medallimit(調べもの用)。
        self._medal_limit_seen = None
        # 直近のメダルのプレイを、本当にプラスツムで投げたか(持っていない・替え
        # られなかったときは普段のツムで投げる。その +0 から上限を学ばない)。
        self._last_medal_plus = False
        # メダルのためにマイツムをプラスツムへ替えたか(メダルの処理が終わったら
        # すぐ戻す。同じ注文のツムレベル上げが、お客さんのマイツムを見るため)。
        self._medal_switched = False
        # 支払いの前の確認(preflight)で出た「空振りになる」文の、メニューごとの内訳。
        self.notes_by_key = {}

    # ---- 準備 ----

    async def open(self):
        """ログインしてアカウントの現状を取る。戻り値は GetInfoResponse。"""
        apply_versions()
        try:
            self.client = tsum_api.LGTMTMClient(refresh_token=self.refresh_token)
            if self.params.get(MEDAL_LEGACY_END):
                # 支払いの前の確かめで、9/22 の形なら入ると分かっている口。
                # 最初の1プレイからその形で投げる(今の形だと +0 で1回ぶん無駄になる)。
                self.client._legacy_end = True
                self._legacy_end_tried = True
            if self.guest_id:
                await self.client.login_guest(self.guest_id, self.guest_password)
            else:
                await self.client.login()
            info = await self.refresh_info()
            # 通ったときの中身も残す。断られたアカウントだけを見ていても
            # 「何が違うのか」は分からない。通る口と並べて初めて比べられる。
            note = self._session_note()
            if note:
                self.trace.append(f"getInfo: {note}")
            tsum = self._play_tsum_note()
            if tsum:
                self.trace.append(f"プレイに使うツム: {tsum}")
            await self._dump_mast_kinds()
            return info
        except Exception as e:
            raise TsumLoginError(f"{type(e).__name__}: {e}") from e

    async def close(self):
        """ゲームAPIへの接続を手放す。使い終わったら必ず呼ぶ。

        1回の代行のあいだ接続を張ったままにしているので、放っておくと
        使い終わった接続が残る。ここで失敗しても代行の結果は変えない
        (もう渡し終わっているので、後始末で「失敗」にはしない)。
        """
        # 一時的に替えたマイツムは、接続を手放す前に戻す。
        try:
            await self.restore_mytsum()
        except Exception as e:
            print(f"[TSUM] マイツムの復帰でエラー: {type(e).__name__}: {e}", flush=True)
        closer = getattr(self.client, "close", None)
        if closer is None:
            return
        try:
            await closer()
        except Exception as e:
            print(f"[TSUM] 接続の後始末に失敗: {type(e).__name__}: {e}", flush=True)

    async def _dump_mast_kinds(self):
        """調べもの用。TSUM_MAST_KINDS=1,2,4 のように書いた種類を保存する。

        ツムのレベルに要る消去数の表は、こちらの持ち物には無い
        (tsum_master.json は maxlv までしか持たず、いま使っている
        getMast の 3/7/11/14 はガチャ・イベント・アイテムしか返さない)。
        どの種類に入っているかを探すための足場で、既定では何もしない。
        """
        kinds = [int(n) for n in re.findall(r"\d+", os.getenv("TSUM_MAST_KINDS", ""))]
        for kind in kinds[:32]:
            try:
                res = await self.client.get_mast([kind])
            except Exception as e:
                print(f"[TSUM MAST] kind={kind} 取れません: {type(e).__name__}: {e}",
                      flush=True)
                continue
            found = {k: len(v) for k, v in res.items()
                     if isinstance(v, list) and v} if isinstance(res, dict) else {}
            print(f"[TSUM MAST] kind={kind} -> {found}", flush=True)
            if found:
                write_json(data_path(f"tsum_mast_{kind}.json"), res)

    async def refresh_info(self, force: bool = False):
        """アカウントの現状(getInfo)を取り直す。

        残高を動かす要求(プレイ・ガチャ・上限解放・マイツム替え)を投げてから
        まだ取り直していないときだけ投げる。何も投げていなければ手元のものを
        そのまま返す(応答は持ち物のツム全部を含んでいて大きく、1往復が
        丸ごと無駄になる)。force=True は「ゲーム側の反映が遅れる」ことが
        分かっている場面用で、手元が新しくても必ず取り直す。
        """
        if self._info_fresh and not force and self.info is not None:
            return self.info
        self._absorb_info(await self.client.get_info())
        return self.info

    def _absorb_info(self, raw: dict):
        """getInfo の応答を手元の現状として取り込む。

        取り直し(refresh_info)のほかに、完売の確認(_verify_completed)のように
        別の目的で取った getInfo もここへ通す。同じ応答を2度取らないため。
        """
        # エラー応答(userinfo 無し)なら、今持っている self.info / self.raw は
        # 壊さない。直前の正常な状態を残しておくことで、呼び出し側が後始末
        # (restore_mytsum など)を正しいマイツムで行える。分かる例外を上げて
        # 呼び出し側の except に拾わせる。素の KeyError: 'userinfo' で代行が
        # 丸ごと落ちるのを防ぐ。
        if not tsum_api.is_getinfo_payload(raw):
            raise tsum_api.GetInfoError(raw)
        self.raw = raw
        self.info = tsum_api.GetInfoResponse.from_dict(self.raw)
        self._info_fresh = True
        # お客さんの持ち物は、ゲームが教えてくれる一番確かなツムの一覧。
        # 表に無いIDが出てきたらその場で覚える(次からは注文を断らない)。
        try:
            found = learn_tsums(self.raw.get("tsuminfo") or [])
        except Exception as e:
            print(f"[TSUM] ツムを覚えられませんでした: {type(e).__name__}: {e}",
                  flush=True)
        else:
            if found:
                self.trace.append(
                    "表に無いツムを覚えました: "
                    + "・".join(str(i) for i in found[:20]))

    def _touch(self):
        """ゲーム側の状態を動かす要求を投げた印。次の refresh_info は取り直す。"""
        self._info_fresh = False

    def mytsum(self):
        """アプリで『マイツム』に設定している1体。分からなければ None。

        setflg が立っているツムがそれ。読めないときはホーム画面のツムと
        統計側の記録も見るが、そこまで駄目なら None を返して支払いの前に
        止める。当てずっぽうで別のツムを上げるほうがずっとまずい
        (GetInfoResponse.mytsum は最後に ID 1 を返すので、ここでは使わない)。
        """
        if not self.info:
            return None
        found = next((t for t in self.info.tsuminfo if t.is_mytsum), None)
        if found is not None:
            return found
        data = self.info.mydatainfo
        for tsum_id in (getattr(data, "hometsum", 0), data.mytsum_id):
            found = self.info.get_tsum(tsum_id) if tsum_id else None
            if found is not None:
                return found
        return None

    def mytsum_line(self) -> str:
        """マイツムの見え方。お客さんがアプリの表示と見比べられるようにする。"""
        tsum = self.mytsum()
        if tsum is None:
            return ""
        parts = [tsum_name(tsum.tsumid), f"レベル {tsum.lv}"]
        if tsum.skilllv:
            parts.append(f"スキル {tsum.skilllv}")
        if tsum.tsumcnt:
            parts.append(f"{tsum.tsumcnt:,}個")
        return " / ".join(parts)

    def account_line(self) -> str:
        """お客さんに見せるアカウントの1行要約。"""
        u = self.info.userinfo
        # ハートは手持ちとプレゼントBOXを分けて出す。合算で出すと、受け取り前の
        # ぶんまで「使える」ように見えてしまう(プレイに使えるのは手持ちだけ)。
        heart = f"ハート {u.bheart:,}"
        if u.pheart:
            heart += f"（プレゼントBOXに{u.pheart:,}・未受け取り）"
        return (f"{u.name} / Lv.{u.lv}\n"
                f"コイン {u.coin_total:,} / メダル {u.medal_total:,} / "
                f"{heart} / ルビー {u.ruby_total:,}")

    # ---- ゲーム側の小道具 ----

    def _balance_for_type(self, gacha_type: int) -> tuple:
        mod = int(gacha_type) % 10
        if mod == 1:
            return self.info.userinfo.coin_total, "コイン"
        if mod == 2:
            return self.info.userinfo.ruby_total, "ルビー"
        if mod == 4:
            return self.info.userinfo.medal_total, "メダル"
        return 0, "不明通貨"

    def _ticket_count(self, gacha_type: int) -> int:
        # native: CRecord::getTicketCount(7, uType)。SetTicketInfoの保存順は
        # type, id, count なので getInfo の ticketinfo を優先する。
        for key in ("ticketinfo", "iteminfo"):
            raw_entries = self.raw.get(key, []) if isinstance(self.raw, dict) else []
            entries = raw_entries if isinstance(raw_entries, list) else [raw_entries]
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                if entry.get("type") == 7 and entry.get("id") == int(gacha_type):
                    cnt = entry.get("cnt", entry.get("count", 0))
                    if isinstance(cnt, int):
                        return max(0, cnt)
        return 0

    def _bonus_id(self) -> int:
        raw = self.raw.get("gachabonusinfo") if isinstance(self.raw, dict) else None
        entries = raw if isinstance(raw, list) else [raw] if isinstance(raw, dict) else []
        for entry in entries:
            if isinstance(entry, dict) and isinstance(entry.get("id"), int):
                return max(0, entry["id"])
        return 0

    async def _resolve_targets(self, names=()) -> dict:
        """getMast と getInfo を突き合わせて、今開催中のガチャを特定する。

        固定のガチャIDは使わない(開催が変わるたびに空振りする)。

        names は、この注文で要るガチャ(pickup など)。前の接続が取った
        getMast を借りているときは、始まったばかりのガチャがまだ載って
        いないことがある。要るものが見つからなければ、借りた表を捨てて
        一度だけ引き直す(自分で引いた表に無いなら、本当に開催していない)。
        """
        targets = await self._targets_from_mast()
        if any(not targets.get(n) for n in names) and self.client._forget_mast():
            print("[TSUM] 借りていたマスタに要るガチャが無いので引き直します",
                  flush=True)
            targets = await self._targets_from_mast()
        return targets

    async def _targets_from_mast(self) -> dict:
        mast_res = await self.client.get_mast([3, 7, 11, 14])
        gachamst = mast_res.get("gachamst", []) if isinstance(mast_res, dict) else []
        return self.client.resolve_active_gacha_targets(
            gachamst, self.info.available_gachas)

    async def _verify_completed(self, gacha_id: int) -> bool:
        latest = await self.client.get_info()
        if isinstance(latest, dict) and latest.get("retcode") == 0:
            # 完売の確認に取った getInfo は、そのまま手元の現状にもなる。
            # このあとの残高の集計で、同じものをもう一度取らずに済む。
            # 取り込めない応答でも、完売の確認そのものは続ける。
            try:
                self._absorb_info(latest)
            except Exception as e:
                print(f"[TSUM] getInfo を取り込めません: {type(e).__name__}: {e}",
                      flush=True)
        for g in latest.get("gachainfo", []) if isinstance(latest, dict) else []:
            if (isinstance(g, dict) and g.get("gachaid") == gacha_id
                    and g.get("compflg") == 1):
                return True
        return False

    async def preflight(self, keys) -> tuple:
        """支払いの前に、このアカウントでは何も起きない項目を洗い出す。

        お代を受け取ってから「もう上です」「開催していません」と伝えるのは
        こちらの都合でしかない。ログインした直後のここで見ておく。

        戻り値は (伝えること, 丸ごと空振りになるメニュー)。セット商品は
        中身がいくつもあるので、1つ空振りでも残りには意味がある。丸ごと
        空振りのメニューは、呼び出し側が注文から外す(お代をいただかない)。
        どの文がどのメニューのものかは self.notes_by_key に置く。
        """
        notes, dead = [], []
        self.notes_by_key = {}
        if any(kind == MEDAL for key in keys for kind, _ in menu_tasks(key)):
            await self._probe_medal(keys)
        if any(kind == COIN for key in keys for kind, _ in menu_tasks(key)):
            await self._probe_coin(keys)
        targets = await self._preflight_targets(keys)
        planned = self._planned_currency(keys)
        for key in sort_keys(keys):
            tasks = menu_tasks(key)
            wasted = 0
            for kind, value in tasks:
                note = self._task_note(kind, value, targets, planned)
                if note:
                    notes.append(note)
                    self.notes_by_key.setdefault(key, []).append(note)
                    wasted += 1
            if tasks and wasted == len(tasks):
                dead.append(key)
        return notes, dead

    @property
    def medal_block(self) -> str:
        """支払いの前の確かめでメダルを受け取れなかった理由(受け取れれば空)。"""
        return self._medal_block_message()

    def _medal_block_message(self) -> str:
        """お客さんに見せるメダル不可の理由。参加中イベントの終わりが分かれば添える。

        確かめの途中では原因を決められないので、保存するのは「付かない」という
        事実(MEDAL_ZERO_TEXT)だけにして、イベント参加中と分かったとき(終了日時を
        拾えたとき)だけ、見せる段でイベント終了後の案内に差し替える。
        """
        if self._medal_block == MEDAL_ZERO_TEXT and self._blocked_event_ends:
            # 参加中の判定(card / challenge)に出ない形式のイベントで、確かめて
            # 初めて参加中と分かった場合。文面はログイン直後に止めたときと揃える。
            return MEDAL_EVENT_TEXT
        return self._medal_block

    @property
    def medal_probed(self) -> int:
        """支払いの前の確かめで実際に付いたメダルの枚数(ご注文の枚数に含める)。"""
        return self._medal_probed

    @property
    def coin_block(self) -> str:
        """支払いの前の確かめでコインを付けられなかった理由(付けられれば空)。"""
        return self._coin_block

    @property
    def coin_probed(self) -> int:
        """支払いの前の確かめで実際に付いたコインの枚数(ご注文の枚数に含める)。"""
        return self._coin_probed

    # ---- イベント参加中の口のメダル ----
    #
    # 参加中の口は、普段のツムでプレイすると、プレイが通っても(retcode=0)メダルが
    # +0 で返る(gameEnd の userinfo は bmedal=-1)。参加していない口は同じ送り方で
    # 入る。「9/22 は参加中でも入っていた」は、当時の判定(card>0 だけ)でイベント
    # 無し(eventid=0)として投げていた可能性が高く、イベントのプレイで入った例は無い。
    #
    # ゲームの決まりでは、プレイで入るメダルは「プラスツムをマイツムにして消した
    # ぶん」だけ。イベントのプレイだけサーバがこの決まりで申告を検めていて、
    # 10/7 の動作確認(イベント157・ID 860)で、プラスツムに替えてプレイすれば
    # 10 → 100 → 1,000 → 10,000 → 38,890 が全部丸ごと入ると確かめた(gameStart の
    # medallimit は -1 のまま。上限の印ではない)。
    #
    # なので参加中の口のメダルは、管理者もお客さんも最初から「プラスツムでプレイ」
    # で投げる(_event_medal_mode)。プラスツムを持っていない口は、お代をいただく
    # 前に止めて伝える。本番(_grant_currency)では、ご注文の残りをまず1プレイで
    # 申告し、入り方からイベントごとに学ぶ:
    #   ・途中までしか入らなかった(所持の上限ではない) → そこが1プレイの上限(cap)。
    #     以降はその枚数で刻み、次の注文は支払いの前にハートが足りるか数える
    #   ・丸ごと入った → その枚数まで確かめ済み(verified)。+0 だったときに
    #     この枚数へ落として投げ直す(半分探しでハートを捨てない)
    # 送り方そのものを探す段上げ(_medal_event_trial)は、環境変数で有効にした
    # 管理者の動作確認でだけ動く(MEDAL_TRIAL_ENABLED)。

    @staticmethod
    def _medal_mode_label(mode: dict) -> str:
        """覚えている送り方の、記録に出す言い方。"""
        mode = mode or {}
        kind = mode.get("mode")
        cap = int(mode.get("cap") or 0)
        verified = int(mode.get("verified") or 0)
        parts = []
        if kind == "plus":
            parts.append("プラスツムでプレイ")
        elif kind == "limit":
            parts.append("medallimit までに抑えて申告")
        elif kind == "tiny":
            parts.append("少ない枚数で申告")
        else:
            parts.append(str(kind))
        if cap > 0:
            parts.append(f"1プレイ{cap:,}枚まで")
        elif verified > 0:
            parts.append(f"{verified:,}枚まで丸ごと入ると確認済み")
        return "・".join(parts)

    def _medal_mode_cap(self) -> int:
        """覚えている送り方の、1プレイで申告できる上限(無ければ 0)。

        プラスツムの送り方では、申告より少なく入った実測(partial)があるときだけ
        上限。「丸ごと入ると確かめた枚数」(verified)は上限ではないので含めない
        (_event_medal_mode がそう読み替える)。
        """
        try:
            return max(0, int((self._medal_mode or {}).get("cap") or 0))
        except (TypeError, ValueError):
            return 0

    def _event_medal_mode(self, event_id) -> dict:
        """参加中の口でメダルを投げる送り方(既定: プラスツムでプレイ)。

        イベントごとの記憶(tsum_api の medal_mode_for)があれば合わせる:
          plus 以外(limit / tiny) … 探索を有効にした動作確認で見つけたもの。そのまま使う
          plus … tsum(使ったプラスツム)・cap(1プレイの上限。partial=True のときだけ)・
                 verified(丸ごと入ると確かめた最大の枚数)を引き継ぐ
        partial の印が無い古い記録の cap(10/7 の動作確認が残した 38,890 など)は、
        段上げで丸ごと入った最大の枚数なので、上限ではなく verified に読み替える。
        """
        known = self.client.medal_mode_for(event_id) or {}
        if known.get("mode") and known.get("mode") != "plus":
            return {**known, "event_id": event_id}
        try:
            cap = max(0, int(known.get("cap") or 0))
        except (TypeError, ValueError):
            cap = 0
        try:
            verified = max(0, int(known.get("verified") or 0))
        except (TypeError, ValueError):
            verified = 0
        partial = bool(known.get("partial")) and cap > 0
        if not partial:
            verified = max(verified, cap)
            cap = 0
        return {"mode": "plus", "event_id": event_id, "tsum": known.get("tsum"),
                "cap": cap or None, "partial": partial, "verified": verified,
                "use_limit": True}

    def _remember_plus(self, cap: int = None, verified: int = None):
        """プラスツムでの入り方(1プレイの上限 / 丸ごと入ると確かめた枚数)を、
        手元の送り方とイベントごとの記憶の両方に残す。"""
        mode = self._medal_mode
        if not isinstance(mode, dict) or mode.get("mode") != "plus":
            return
        if cap:
            mode["cap"] = int(cap)
            mode["partial"] = True
        if verified:
            mode["verified"] = max(int(mode.get("verified") or 0), int(verified))
        event_id = mode.get("event_id")
        if not event_id or self.client is None:
            return
        # 同じイベントの別の注文(別の接続)が先に書いたぶんを消さないよう、いまの
        # 記録と合わせてから書く(確かめ済みは大きいほう・上限はどちらかが見つけたもの)。
        try:
            current = self.client.medal_mode_for(event_id) or {}
        except Exception:
            current = {}
        if current.get("mode") == "plus":
            try:
                mode["verified"] = max(int(mode.get("verified") or 0),
                                       int(current.get("verified") or 0))
            except (TypeError, ValueError):
                pass
            try:
                other_cap = int(current.get("cap") or 0) if current.get("partial") else 0
            except (TypeError, ValueError):
                other_cap = 0
            if other_cap > 0 and not mode.get("cap"):
                mode["cap"] = other_cap
                mode["partial"] = True
        detail = {key: mode.get(key) for key in ("cap", "partial", "verified", "tsum", "use_limit")}
        try:
            self.client.remember_medal_mode(event_id, "plus", **detail)
        except Exception as e:
            print(f"[TSUM] メダルの送り方を保存できませんでした: {type(e).__name__}: {e}",
                  flush=True)

    def _last_medal_claim(self, want: int) -> int:
        """直前のメダルのプレイで、実際に gameEnd へ申告した枚数(読めなければ want)。

        gameStart の medallimit が正なら _medal_play がそこまでに抑えるので、
        頼んだ枚数(want)より少ないことがある。入り方を判断するのはこちらと比べる。
        """
        body = getattr(self.client, "_last_end_body", None) or {}
        try:
            claimed = int(body.get("medal") or 0)
        except (TypeError, ValueError):
            claimed = 0
        return claimed if 0 < claimed <= want else want

    def _plus_next(self, got: int, claimed: int, chunk: int, chunk_max: int,
                   balance: int, state: dict) -> tuple:
        """参加中の口(プラスツムでプレイ)で、通ったプレイの次をどうするか。

        claimed は実際に申告した枚数(_last_medal_claim。medallimit で抑えられて
        丸ごと入ったものを「途中までしか入らない」と読まないため)。state は
        _grant_currency が1回の付与のあいだ持つ入れ物:
          fell_back … +0 で確かめ済みの枚数へ落としたか(落とすのは1回だけ)
          growing   … 直前のプレイが「落とした枚数から倍に伸ばす」試しだったか
          grow      … まだ伸ばしてよいか(伸ばして +0 になったら、もう伸ばさない)
        戻り値 (決めたこと, 次の申告の上限)。決めたこと:
          "go"    丸ごと入った(確かめ済みの枚数を更新。落としたあとなら次は倍で試す。
                  確かめの 100枚のまま刻んでハートを何十個も使わないため) /
                  途中まで入った(所持の上限ではない=そこが1プレイの上限。以降その枚数)
          "retry" +0 だが、丸ごと入ると確かめ済みの枚数がある。その枚数で投げ直す
          None    ここでは決めない(従来の判断 _capped_next へ)
        所持の上限(MEDAL_MAX)に届いて途中で切られたのは1プレイの上限ではないので、
        従来どおり「ゲーム側の上限に当たった」で止める(None)。
        """
        mode = self._medal_mode or {}
        verified = int(mode.get("verified") or 0)
        if got > 0 and got >= claimed:
            # この接続で丸ごと入った最大の枚数。伸ばして駄目だったときに戻る先は
            # ここ(記憶の verified は、別の注文が書いたもっと大きな値と合わさる
            # ことがあり、そこへ戻すと、いま落とされた枚数より大きく申告してしまう)。
            state["landed"] = max(int(state.get("landed") or 0), claimed)
            if claimed > verified:
                self._remember_plus(verified=claimed)
                verified = claimed
            if (state.get("fell_back") and state.get("grow") and not mode.get("cap")
                    and chunk < chunk_max):
                state["growing"] = True
                return "go", min(chunk * 2, chunk_max)
            state["growing"] = False
            return "go", chunk
        if 0 < got < claimed:
            if balance >= MEDAL_MAX:
                return None, chunk
            self._remember_plus(cap=got)
            state["grow"] = state["growing"] = False
            self.trace.append(f"1プレイで入るのは{got:,}枚まででした。以降はこの枚数で刻みます"
                              "（次の注文は支払いの前にハートの数で確かめます）")
            return "go", got
        # +0
        landed = int(state.get("landed") or 0)
        if state.get("growing") and (landed > 0 or verified > 0):
            state["grow"] = state["growing"] = False
            back = min(verified, landed) if (landed and verified) else (landed or verified)
            self.trace.append(f"申告{claimed:,}枚は入りませんでした。丸ごと入った"
                              f"{back:,}枚に戻して、以降はこの枚数で刻みます")
            return "retry", back
        if not state.get("fell_back") and 0 < verified < claimed:
            self.trace.append(f"申告{claimed:,}枚は入りませんでした。丸ごと入ると確かめ済みの"
                              f"{verified:,}枚で投げ直します")
            return "retry", verified
        return None, chunk

    def _owned_plus_tsums(self) -> list:
        """持っているプラスツム(レベルの高い順)。"""
        if not self.info:
            return []
        owned = [t for t in self.info.tsuminfo if is_plus_tsum(t)]
        owned.sort(key=lambda t: (int(t.lv or 0), int(t.tsumid)), reverse=True)
        return owned

    def _plus_tsum_for_play(self, preferred=None):
        """プレイに使うプラスツム。覚えている送り方のツムを持っていればそれ、
        無ければ持っているプラスツムのうちレベルの高い1体。持っていなければ None。"""
        owned = self._owned_plus_tsums()
        if not owned:
            return None
        if preferred:
            for tsum in owned:
                if int(tsum.tsumid) == int(preferred):
                    return int(tsum.tsumid)
        return int(owned[0].tsumid)

    async def _switch_mytsum(self, target: int) -> bool:
        """マイツムを一時的に target へ替える(代行が終わったら close が元へ戻す)。

        ゲームは「いまのマイツム」でしかプレイできないので、プラスツムで
        プレイするには先に替える必要がある。替えられたら True。
        """
        mine = self.mytsum()
        if mine is not None and int(mine.tsumid) == int(target):
            return True
        set_here = False
        if self._switched_mytsum is None and mine is not None:
            self._switched_mytsum = int(mine.tsumid)
            set_here = True
        self._touch()
        try:
            switched = await self.client.get_info(mytsumid=int(target))
            if not (tsum_api.is_getinfo_payload(switched) and switched.get("retcode") == 0):
                raise tsum_api.GetInfoError(switched)
            self._absorb_info(switched)
        except Exception as e:
            if set_here:
                self._switched_mytsum = None
            self.trace.append(f"マイツムを{target}へ替えられませんでした: "
                              f"{type(e).__name__}: {str(e)[:120]}")
            return False
        self.trace.append(f"マイツムを{tsum_name(int(target))}へ一時的に替えました（終わったら戻します）")
        return True

    async def _medal_play(self, results: list, amount: int, *, tsum_id: int = None,
                          cap: int = None, use_limit: bool = None,
                          vanish: int = 10, event_id: int = None) -> dict:
        """メダルを申告する1プレイ。覚えている送り方(self._medal_mode)を効かせる。

        引数で渡したものが優先(動作確認で送り方を1つずつ試すとき)。
          tsum_id   … このツム(プラスツム)に替えてプレイする
          cap       … 1プレイの申告をこの枚数までに抑える
          use_limit … gameStart の medallimit が正なら、それまでに抑える
        gameStart が返した medallimit は self._medal_limit_seen に残す(記録用)。
        """
        mode = self._medal_mode or {}
        if tsum_id is None and mode.get("mode") == "plus":
            tsum_id = self._plus_tsum_for_play(mode.get("tsum"))
        if cap is None:
            cap = int(mode.get("cap") or 0)
        if use_limit is None:
            use_limit = bool(mode.get("use_limit"))
        if tsum_id and vanish == 10:
            vanish = random.randint(*PLUS_VANISH_RANGE)
        if tsum_id and not await self._switch_mytsum(tsum_id):
            # 替えられなければ普段のツムで投げる(マイツム以外では gameStart が通らない)。
            tsum_id = None
            vanish = 10
        elif tsum_id:
            if self._switched_mytsum:
                self._medal_switched = True
            if isinstance(self._medal_mode, dict) and self._medal_mode.get("mode") == "plus":
                self._medal_mode["tsum"] = int(tsum_id)     # 記憶に残すのは実際に使ったツム
        self._last_medal_plus = bool(tsum_id)
        self._medal_limit_seen = None

        def claim(start):
            limit = self.client.start_medal_limit(start)
            self._medal_limit_seen = limit
            want = int(amount)
            if cap and cap > 0:
                want = min(want, cap)
            if use_limit and limit > 0:
                want = min(want, limit)
            return max(0, want)

        return await self._play(results, tsum_id=tsum_id, medal=amount, vanish=vanish,
                                event_id=event_id, medal_hook=claim)

    async def _ensure_medal_mode(self):
        """参加中の口なら、メダルの送り方(プラスツムでプレイ)を手元に持つ(本番の付与で使う)。

        支払いの前の確かめ(_joined_event_blocks_medal)を通った接続では決まっている。
        別の接続で付ける道(保留の支払いが通ったあとの配達など)のためにここでも引く。
        """
        if self._medal_mode is not None or self.client is None:
            return
        self._medal_mode = {}
        try:
            event_id = await self.client._resolve_event_id()
        except Exception as e:
            print(f"[TSUM] イベントの参加状況を確認できません: {type(e).__name__}: {e}",
                  flush=True)
            return
        if not event_id:
            return
        self._medal_mode = self._event_medal_mode(event_id)
        self.trace.append(f"イベント{event_id}に参加中。メダルは"
                          f"{self._medal_mode_label(self._medal_mode)}で投げます")

    async def _event_end_label_for(self, event_id) -> str:
        """参加中イベントの終了日時(表示用)。読めなければ空。"""
        try:
            mast = await self.client.get_mast([3, 7, 11, 14])
            for row in mast.get("eventmst", []):
                if str(row.get("eventid")) == str(event_id):
                    return _event_end_label(row)
        except Exception:
            pass            # 終了日時は記録の添え物。読めなくても判断は変わらない
        return ""

    def _block_for_event(self, event_id, ends: str, why: str, text: str = MEDAL_EVENT_TEXT):
        """イベント参加中を理由にメダルを止める(お代はいただかない)。"""
        self._medal_block = text
        if ends:
            self._blocked_event_ends = ends
        line = (f"メダルの事前確認: イベント{event_id}に参加中のため、{why}"
                + (f"（イベント終了 {ends}ごろ）" if ends else ""))
        self.trace.append(line)
        print(f"[TSUM] {line}", flush=True)

    async def _joined_event_blocks_medal(self, amount: int, keys) -> bool:
        """イベントに参加中の口のメダルをどうするか決める。止めるなら True。

        参加中の口は、普段のツムでプレイしてもメダルが +0 で返る。プラスツムを
        マイツムにしてプレイすれば申告どおり入る(10/7 の実測)ので、参加中なら
        送り方を「プラスツムでプレイ」(_event_medal_mode。イベントごとの記憶が
        あれば合わせる)にして、いつもの確かめ(1プレイ)へ進む。
          ・プラスツムを持っていない口は、お代をいただく前に止めて伝える
          ・探索を有効にした管理者の動作確認(MEDAL_TRIAL_ENABLED)では、記憶の無い
            イベントで送り方を1つずつ試す(_medal_event_trial)。入ればその送り方
        参加状況が読めなかったときは止めない(従来どおり1プレイで確かめる)。
        こちらの都合でメダルの注文を断らないため。
        """
        try:
            event_id = await self.client._resolve_event_id()
        except Exception as e:
            print(f"[TSUM] イベントの参加状況を確認できません: {type(e).__name__}: {e}",
                  flush=True)
            return False
        if not event_id:
            self._medal_mode = {}
            return False
        ends = await self._event_end_label_for(event_id)
        self._medal_mode = {}
        if self.medal_trial and MEDAL_TRIAL_ENABLED and not self.client.medal_mode_for(event_id):
            # 24時間以内に試して +0 だった送り方は繰り返さない。試していない送り方だけ試す。
            skip = self.client.medal_failed_modes(event_id)
            outcome = await self._medal_event_trial(amount, keys, event_id, ends, skip=skip)
            if outcome is True:
                return False
            if outcome is False:
                return True             # 試したが入らなかった(止める理由は書き込み済み)
            self.trace.append(f"イベント{event_id}で試せる送り方は、24時間以内に全部試して "
                              "+0 でした。既定の送り方で確かめます")
        mode = self._event_medal_mode(event_id)
        if mode.get("mode") == "plus" and self._plus_tsum_for_play(mode.get("tsum")) is None:
            self._block_for_event(event_id, ends, "プラスツムを持っていないので止めました"
                                  "（参加中の口でメダルが入るのは、プラスツムをマイツムに"
                                  "したプレイだけ）", text=MEDAL_NEEDS_PLUS_TEXT)
            return True
        self._medal_mode = mode
        line = (f"メダルの事前確認: イベント{event_id}に参加中。"
                f"{self._medal_mode_label(mode)}で確かめます")
        self.trace.append(line)
        print(f"[TSUM] {line}", flush=True)
        return False

    def _trial_steps(self, keys, skip: set) -> list:
        """動作確認で試す送り方の並び [(mode, 説明, _medal_play の引数)]。

        実測(10/7・イベント157・ミッキー＋を持つ口): 普段のツムでは 100枚も 10枚も
        +0、gameStart の medallimit は -1(coinlimit も -1 なので「上限なし」の印で、
        メダルの可否とは関係ない)。残るのは「プラスツムでプレイする」で、ゲームの
        決まり(プレイで入るメダルはプラスツムを消したぶん)とも合う。

        プラスツムを持っていれば、プラスツムで 10枚 → 100枚 → 1,000枚 … と上げて
        いき(入った段の次へ。最後の段はご注文の枚数。_medal_event_trial がご注文の
        残りと所持の上限で切り詰める)、入らなくなった手前を1プレイの上限として
        覚える。そのあと(または持っていなければ) medallimit 合わせ → 少ない枚数の順
        (どちらもこの口では +0 だったが、別の口では違うかもしれない。medallimit
        合わせを先にするのは、入るならそちらのほうが1プレイの上限が大きいため)。
        skip にある送り方(24時間以内に +0 だったもの)は並べない。
        """
        steps = []
        plus = self._owned_plus_tsums()
        planned = int(self._planned_currency(keys).get(MEDAL, 0) or 0)
        top = max(1, min(planned, MEDAL_MAX))
        if plus and "plus" not in skip:
            tsum = int(plus[0].tsumid)
            claims = sorted({c for c in MEDAL_TRIAL_LADDER if c < top} | {top})
            for claim in claims:
                steps.append(("plus", f"プラスツム {tsum_name(tsum)} に替えて {claim:,}枚",
                              {"tsum_id": tsum, "cap": claim, "use_limit": True}))
        elif not plus:
            self.trace.append("プラスツムを持っていないので、プラスツムでのプレイは試せません")
        if "limit" not in skip:
            steps.append(("limit", "medallimit に合わせて申告", {"use_limit": True}))
        if "tiny" not in skip:
            steps.append(("tiny", f"{MEDAL_TRIAL_TINY}枚だけ申告",
                          {"cap": MEDAL_TRIAL_TINY, "use_limit": True}))
        return steps[:max(1, MEDAL_TRIAL_HEARTS)]

    async def _medal_event_trial(self, amount: int, keys, event_id, ends: str,
                                 skip: set = None):
        """管理者の動作確認で、参加中の口にメダルが入る送り方を1つずつ試す。

        1つの送り方 = 1プレイ = ハート1個(_trial_steps の順)。プラスツムで入ったら
        枚数を上げて続け、入らなくなった(または途中までしか入らなかった)手前を
        1プレイの上限として、その送り方をイベントごとに覚える(以降のお客さんの
        注文は最初からその送り方)。全部 +0 なら、従来どおり止めて、投げた中身を
        丸ごと添付する(remember_medal_failed で24時間は同じ送り方を繰り返さない)。
        2回目以降のプレイは、注文の残りの項目に要るハートを残して使う。

        戻り値: True=入る送り方が見つかった / False=試したが入らない /
        None=試せる送り方が残っていない(何も投げていない)。
        """
        skip = set(skip or ())
        steps = self._trial_steps(keys, skip)
        if not steps:
            return None
        planned = int(self._planned_currency(keys).get(MEDAL, 0) or 0)
        top = max(1, min(planned, MEDAL_MAX))

        trials, tried, last_res = [], [], None
        got_total = 0            # 試しで実際に付いた合計(ご注文の枚数に含める)
        last_full = 0            # プラスツムで、申告どおり丸ごと入った最大の枚数
        partial = 0              # 申告より少なく入った枚数(=1プレイの上限)
        zero_streak = 0          # 連続で +0 だった回数(プラスツムの段を上げるのをやめる)
        success_mode = None
        success_kwargs = {}
        for index, (mode, desc, kwargs) in enumerate(steps):
            if mode != "plus" and success_mode:
                break            # プラスツムで入ったあとは、ほかの送り方は試さない
            if index > 0 and self.hearts() < required_hearts(keys):
                self.trace.append("ハートに余りが無いため、残りの送り方は試しません")
                break
            if self.hearts() < HEART_PER_PLAY:
                break
            claim_amount = int(kwargs.get("cap") or amount)
            if mode == "plus":
                # ご注文の枚数・所持の上限(50万)を超えては申告しない。超えたぶんは
                # 入らないので、「途中までしか入らなかった=1プレイの上限」と見誤る。
                room = min(top - got_total, MEDAL_MAX - self.medals())
                if room <= 0:
                    self.trace.append("ご注文の枚数（または所持の上限）まで入ったので、"
                                      "ここで止めます")
                    break
                if claim_amount > room:
                    if room <= last_full:
                        self.trace.append(f"残り{room:,}枚は、ご注文の付与で付けます")
                        break
                    claim_amount = room
                    kwargs = {**kwargs, "cap": room}
                    desc = f"{desc.rsplit(' ', 1)[0]} {room:,}枚"
            before = self.medals()
            res = await self._medal_play([], claim_amount, **kwargs)
            last_res = res
            ok = self._play_ok(res)
            got = 0
            if ok:
                await self.refresh_info()
                got = self.medals() - before
            got_total += max(0, got)
            limit = self._medal_limit_seen
            sent = getattr(self.client, "_last_end_body", None) or {}
            claimed = int(sent.get("medal") or 0)
            tried_text = self._short_attempts(res)
            start_info = ""
            for step in (res.get("_raw_trail") if isinstance(res, dict) else None) or []:
                response = step.get("response") if isinstance(step, dict) else None
                if isinstance(response, dict) and "tsuminfo" in response and "playcode" in str(response.get("userinfo")):
                    start_info = json.dumps(response.get("tsuminfo"), ensure_ascii=False)[:120]
                    break
            line = (f"メダルの事前確認（送り方{index + 1}: {desc}）: "
                    + (f"申告{claimed:,}枚 → 実際 +{got:,}枚" if ok else
                       f"プレイが通りません（{(res or {}).get('retmsg') or '不明'}）")
                    + f" [medallimit={limit}]"
                    + (f" [start tsuminfo={start_info}]" if start_info else "")
                    + (f" [{tried_text}]" if tried_text else ""))
            self.trace.append(line)
            print(f"[TSUM] {line}", flush=True)
            trials.append({
                "mode": mode, "desc": desc, "ok": ok, "claimed": claimed, "got": got,
                "medallimit": limit, "tsumid": kwargs.get("tsum_id"),
                "steps": res.get("_raw_trail") if isinstance(res, dict) else None,
                "sent_gameEnd": dict(sent),
                "userinfo_after": (self.raw or {}).get("userinfo"),
            })
            if mode not in tried:
                tried.append(mode)
            if not ok:
                if isinstance(res, dict) and res.get("_stage") == "start":
                    continue     # 開始で断られた(ハートは減っていない)。その送り方は使えないだけ
                if success_mode:
                    break        # 入ったあとで通らなくなった。入った段までで決める
                continue
            if got > 0:
                success_mode, success_kwargs = mode, kwargs
                zero_streak = 0
                if mode != "plus":
                    break        # 少ない枚数・medallimit 合わせは、入ったらそこで決まり
                if got < claimed:
                    partial = got            # 途中までしか入らない = ここが上限
                    break
                last_full = max(last_full, claimed)
                continue         # 丸ごと入った。次の段へ
            # +0
            if success_mode:
                break            # 入った段の次が +0 = 手前が上限
            zero_streak += 1
            if mode == "plus" and zero_streak >= 2:
                # 10枚でも100枚でも入らないなら、枚数を上げても意味がない。
                self.trace.append("プラスツムでも入らないので、枚数を上げるのはやめます")
                # 残りのプラスツムの段は飛ばして、ほかの送り方へ
                while index + 1 < len(steps) and steps[index + 1][0] == "plus":
                    steps.pop(index + 1)

        if success_mode:
            detail = {"cap": None, "tsum": None, "use_limit": bool(success_kwargs.get("use_limit"))}
            if success_mode == "tiny":
                detail["cap"] = MEDAL_TRIAL_TINY
            elif success_mode == "limit":
                detail["cap"] = int(limit) if (limit and limit > 0) else None
            else:
                detail["tsum"] = success_kwargs.get("tsum_id")
                # 途中までしか入らなかった枚数があればそれが1プレイの上限(partial)。
                # 丸ごと入った最大の枚数は「確かめ済み」(verified)として残す(本番は
                # まずご注文の残りを申告し、+0 ならこの枚数へ落として投げ直す)。
                detail["cap"] = partial or None
                detail["partial"] = bool(partial)
                detail["verified"] = last_full
            self._medal_mode = {"mode": success_mode, "event_id": event_id, **detail}
            self._medal_probed = got_total
            self._medal_block = ""
            self._medal_trial_done = True
            self.client.remember_medal_mode(event_id, success_mode, **detail)
            self.trace.append(f"イベント{event_id}でも、この送り方（{self._medal_mode_label(self._medal_mode)}）"
                              f"ならメダルが入りました（試しで合計 +{got_total:,}枚）。"
                              "以降の注文はこの送り方で投げます")
            if success_mode == "plus":
                if partial:
                    self.trace.append(f"1プレイで入るのは{partial:,}枚まででした（申告はこの枚数で刻みます）")
                elif last_full and last_full < MEDAL_MAX:
                    self.trace.append(f"{last_full:,}枚まで丸ごと入ることを確かめました。"
                                      "本番ではご注文の残りをまず1プレイで申告し、"
                                      "入らなければこの枚数で投げ直します")
            self.debug = {"why": "イベント参加中の口でメダルが入る送り方を見つけた",
                          "eventid": event_id, "medal_trials": trials}
            return True

        self._medal_trial_done = True
        self.client.remember_medal_failed(event_id, tried)
        if last_res is not None:
            self._note_medal_earned(last_res)
            await self._capture_event_debug(last_res, "イベント参加中の口のメダルの送り方を試した")
        if self.debug is None:
            self.debug = {"why": "イベント参加中の口のメダルの送り方を試した", "eventid": event_id}
        self.debug["medal_trials"] = trials
        self._block_for_event(event_id, ends,
                              f"送り方を{len(trials)}通り試しましたが入りませんでした")
        return False

    async def _probe_coin(self, keys):
        """コインをいま付けられるアカウント/ゲーム状態かを、支払いの前に1プレイで確かめる。

        ゲーム側が gameStart ごとプレイを弾くこと(retcode=997/8)があり、そのときは
        何枚申告しても1枚も入らない。getInfo の読み取りだけでは見分けられないので、
        少ない枚数(COIN_PROBE)で実際に1回投げて、残高が動くかを見る。付けられれば
        そのぶんは付いたまま残す(ご注文の枚数に含める)。結果は self._coin_block に
        置く(空なら付けられる)。本番の付与(_grant_currency)と同じ投げ方
        (_play(coin=...)・イベント無し)なので、本番で通るかをそのまま映す。
        """
        self._coin_block = ""
        self._coin_probed = 0
        amount = min(COIN_PROBE, self._planned_currency(keys).get(COIN, 0))
        if amount <= 0:
            return
        if self.hearts() < HEART_PER_PLAY:
            # ハート不足は required_hearts で別に止まる。ここで「付けられない」とは
            # しない(プレイしていないだけで、ゲームが拒んだわけではない)。
            return
        before = self.coins()
        res = await self._play([], coin=amount)
        tried = self._short_attempts(res)
        if not self._play_ok(res):
            why = (res or {}).get("retmsg") or "プレイが通りませんでした"
            line = f"コインの事前確認: プレイが通りません（{why}）"
            self._coin_block = ("コインの付与を事前に確かめられませんでした"
                                "（ゲーム側がプレイを受け付けていません）。")
        else:
            await self.refresh_info()
            got = self.coins() - before
            line = f"コインの事前確認: 申告{amount:,}枚 → 実際 +{got:,}枚"
            self._coin_probed = max(0, got)
            if got <= 0:
                self._coin_block = COIN_ZERO_TEXT
        line += f" [{tried}]" if tried else ""
        limits = self._start_limits(res)
        line += f" [{limits}]" if limits else ""
        self.trace.append(line)
        print(f"[TSUM] {line}", flush=True)

    async def _probe_medal(self, keys):
        """メダルをいま受け取れるアカウントかを、支払いの前に1プレイで確かめる。

        プレイが通っても(retcode=0)メダルが1枚も増えないことがある(所持が
        上限より下の 577枚の口・302,030枚の口でも +0。MEDAL_MAX のコメント)。
        getInfo の読み取りだけでは見分けられないので、少ない枚数(MEDAL_PROBE)で
        実際に1回投げて、残高が動くかを見る。受け取れればその枚数は付いたままに
        なる。結果は self._medal_block に置く(空なら受け取れる)。
        参加中の口で確かめのためにプラスツムへ替えていたら、終わりに戻す(この
        あとのツムレベルの判断が、お客さんのマイツムを見るため)。
        """
        try:
            await self._probe_medal_inner(keys)
        finally:
            await self._restore_after_medal()

    async def _probe_medal_inner(self, keys):
        self._medal_block = ""
        self._medal_probed = 0
        # ご注文の枚数より多くは付けない(確かめのぶんはご注文に含めるので)。
        amount = min(MEDAL_PROBE, self._planned_currency(keys).get(MEDAL, 0))
        if amount <= 0:
            return
        if await self._joined_event_blocks_medal(amount, keys):
            return
        if self._medal_trial_done:
            # 管理者の動作確認で送り方を試し、その結果(付いた枚数)がもう入っている。
            # 同じ確かめを重ねてハートを使わない。
            return
        before = self.medals()
        res = await self._medal_play([], amount)
        tried = self._short_attempts(res)
        if not self._play_ok(res):
            why = (res or {}).get("retmsg") or "プレイが通りませんでした"
            line = f"メダルの事前確認: プレイが通りません（{why}）"
            self._medal_block = ("メダルの付与を事前に確かめられませんでした"
                                 "（ゲーム側がプレイを受け付けていません）。")
        else:
            await self.refresh_info()
            got = self.medals() - before
            claimed = self._last_medal_claim(amount)   # 上限で抑えられていれば、その枚数
            line = f"メダルの事前確認: 申告{claimed:,}枚 → 実際 +{got:,}枚"
            self._medal_probed = max(0, got)
            if got >= claimed > 0 and self._last_medal_plus:
                # 参加中の口(プラスツムでプレイ)なら、丸ごと入った枚数として残す
                # (plus 以外の送り方では何もしない)。
                self._remember_plus(verified=claimed)
            if got <= 0:
                await self._capture_event_debug(res, "事前確認でメダルが0枚")
                self._note_medal_earned(res)
                self._medal_block = MEDAL_ZERO_TEXT
        line += f" [{tried}]" if tried else ""
        limits = self._start_limits(res)
        line += f" [{limits}]" if limits else ""
        if self._medal_block == MEDAL_ZERO_TEXT:
            # イベント付きで0枚なら、イベントを外してもう1回だけ確かめる。ご注文の
            # ハート(確かめ1回ぶん込み)とは別にもう1個使うので、余っているときだけ。
            self.trace.append(line)
            print(f"[TSUM] {line}", flush=True)
            if (getattr(self.client, "_event_id", None)
                    and self.hearts() < required_hearts(keys)):
                self.trace.append("ハートに余りが無いため、イベントを外した確かめはしません")
                return
            res2, event_id = await self._medal_without_event([], amount)
            if res2 is None:
                # 参加中でイベントを外して始められない(開始で断られたのでハートは
                # 減っていない)。イベント付きのまま、9/22 の gameEnd の形で確かめる。
                await self._probe_medal_legacy_end(keys, amount, before)
                return
            await self.refresh_info()
            got = self.medals() - before
            tried = self._short_attempts(res2)
            line = (f"メダルの事前確認(イベント{event_id}を外して): 申告{amount:,}枚 → "
                    f"実際 +{got:,}枚" + (f" [{tried}]" if tried else ""))
            if got > 0:
                self._medal_probed = got
                self._medal_block = ""
            else:
                line += "（イベントを外しても増えません）"
            self.trace.append(line)
            print(f"[TSUM] {line}", flush=True)
            if got > 0:
                self._keep_without_event(event_id)
            return
        self.trace.append(line)
        print(f"[TSUM] {line}", flush=True)

    async def _probe_medal_legacy_end(self, keys, amount: int, before: int):
        """支払いの前の確かめの2回目。イベントを外せない口で、9/22 の gameEnd の形で投げる。

        入れば受け取れる口として先へ進め、本番でも最初からその形で投げる
        (medal_legacy_end を注文に持たせる)。本番で今の形のまま投げると、最初の
        1プレイが +0 になり、確かめ直すハートが無い口ではお代だけ受け取って止まる。
        """
        # イベント無しの開始が通って gameEnd で弾かれたときは、ハートを使っている。
        if self.hearts() < required_hearts(keys):
            self.trace.append("ハートに余りが無いため、9/22の送り方での確かめはしません")
            return
        res = await self._medal_with_legacy_end([], amount)
        if res is None or not self._play_ok(res):
            return
        await self.refresh_info()
        got = self.medals() - before
        tried = self._short_attempts(res)
        line = (f"メダルの事前確認(9/22の送り方): 申告{amount:,}枚 → 実際 +{got:,}枚"
                + (f" [{tried}]" if tried else ""))
        self.trace.append(line)
        print(f"[TSUM] {line}", flush=True)
        self._legacy_end_result(got)
        if got > 0:
            self._medal_probed = got
            self._medal_block = ""

    @property
    def medal_legacy_end(self) -> bool:
        """9/22 の gameEnd の形なら入る口だと分かったか(本番へ持ち越す)。"""
        return bool(getattr(self.client, "_legacy_end", False))

    async def _preflight_targets(self, keys):
        """開催中のガチャ。読めなければ None(それを理由に断らない)。"""
        names = [value for key in keys for kind, value in menu_tasks(key)
                 if kind == GACHA]
        if not names:
            return {}
        try:
            return await self._resolve_targets(names)
        except Exception as e:
            # 開催状況を読めないのは、こちらの都合。お客さんを止める理由にしない。
            print(f"[TSUM] 開催中のガチャを確認できません: {type(e).__name__}: {e}",
                  flush=True)
            return None

    def _planned_currency(self, keys) -> dict:
        """このご注文でこれから増やす {通貨: 枚数}。

        完売の「足りません」を出す前に足しておくためのもの。コイン・メダルは
        完売より先に処理される(MENUS の並び=処理順)ので、いまの残高が0でも、
        同じご注文で用意するぶんは当てにしてよい。これを見ないと、コイン指定と
        完売を一緒に頼んだときに「コインが足りません」と出てしまう。
        """
        planned = {}
        for key in keys:
            for kind, value in menu_tasks(key):
                if kind not in (COIN, MEDAL):
                    continue
                if kind == MEDAL and self._medal_block:
                    continue                # 付けられないメダルは当てにしない
                if kind == COIN and self._coin_block:
                    continue                # 付けられないコインは当てにしない
                cap = COIN_MAX if kind == COIN else MEDAL_MAX
                amount = int(self.params.get(kind, 0) if value is None else value)
                planned[kind] = planned.get(kind, 0) + max(0, min(amount, cap))
        return planned

    def _task_note(self, kind: str, value, targets, planned: dict = None) -> str:
        """その処理が空振りになるなら、その理由。動くなら空。"""
        u = self.info.userinfo
        if kind == COIN:
            # コインはプレイ(gameStart)ごとゲーム側に弾かれることがあり、所持枚数
            # からは分からない。支払いの前に1プレイ試した結果(_probe_coin)で決める。
            if self._coin_block:
                return self._coin_block
        elif kind == SCORE:
            target = int(self.params.get(SCORE, SCORE_MAX)
                         if value is None else value)
            now = int(u.score or 0)
            if target <= now:
                return (f"スコアはいまのほう（{now:,}）が高いため、"
                        f"指定の{target:,}には更新できません。")
        elif kind == MEDAL:
            # メダルはプレイが通っても1枚も入らないことがあり、所持枚数からは
            # 分からない(302,030枚の口でも入らなかった)ので、支払いの前に
            # 1プレイ試した結果(_probe_medal)で決める。
            if self._medal_block:
                return self._medal_block_message()
            cap = self._medal_mode_cap()
            if cap > 0:
                # イベント参加中の口で、1プレイの上限が分かっている送り方。ご注文の
                # 枚数に要るプレイ数(=ハート)が手持ちを超えるなら、お代をいただく前に
                # 伝えて外す(途中で止まって「足りません」になるのを避ける)。
                amount = int(self.params.get(MEDAL, 0) if value is None else value)
                amount = max(0, min(amount, MEDAL_MAX)) - int(self._medal_probed or 0)
                plays = -(-amount // cap) if amount > 0 else 0
                if plays > self.hearts():
                    return (f"このアカウントはイベント参加中で、1プレイに付けられるメダルが"
                            f"{cap:,}枚までです。ご注文の枚数には{plays:,}プレイ"
                            f"（ハート{plays:,}個）が必要ですが、いまのハートは"
                            f"{self.hearts()}個です。ハートを用意するか、枚数を減らして"
                            "ご注文ください。")
        elif kind == PLAYER_LEVEL:
            target = int(self.params.get(PLAYER_LEVEL, player_level_max())
                         if value is None else value)
            now = int(u.lv or 0)
            if target <= now:
                return (f"プレイヤーレベルはいまのほう（{now}）が高いため、"
                        f"指定の{target}には上げられません。")
        elif kind == TSUM_LEVEL:
            # 上げる相手がもう上限なら、流しても何も起きない。ツムは注文の
            # 時点では決まっておらず、ログイン後にマイツムから読むので、
            # params ではなくアカウント側を見る。
            tsum = self.mytsum()
            if tsum is not None:
                master = load_tsum_master().get(int(tsum.tsumid)) or {}
                max_lv = int(master.get("maxlv") or 0) or 50
                if int(tsum.lv or 0) >= max_lv:
                    return (f"{tsum_name(int(tsum.tsumid))} はすでに"
                            f"レベル{max_lv}です。これ以上は上げられません。")
        elif kind == GACHA and targets is not None:
            label = (GACHA_KINDS.get(value) or {}).get("label", value)
            target = targets.get(value)
            if not target:
                return f"開催中の{label}がありません。"
            if target.get("compflg") == 1:
                return f"{label}はすでに完売しています。"
            balance, currency = self._balance_for_type(target["type"])
            # 同じご注文でこれから増やすぶんは当てにしてよい(コイン・メダルは
            # 完売より先に処理される)。
            adding = (planned or {}).get(gacha_pay(value), 0)
            need, exact = self._gacha_cost(target, value)
            if need and not self._ticket_count(target["type"]) and balance + adding < need:
                return (f"{label}は完売までに{currency}が"
                        f"{'' if exact else '最低でも'}{need:,}要ります"
                        f"（いま {balance:,}"
                        + (f" / このご注文で +{adding:,}" if adding else "") + "）。")
        return ""

    def hearts(self) -> int:
        """いまプレイに使えるハートの数。

        ゲームがプレイで減らすのは手持ち(bheart)だけ。プレゼントBOXにある
        ぶん(pheart)は、アプリで受け取るまで使えない。ここで足してしまうと
        「2,772個ある」ように見えるのに1回もプレイできず、お代だけ受け取って
        gameStart で弾かれることになる。
        """
        u = self.info.userinfo if self.info else None
        return int(u.bheart if u else 0)

    def hearts_in_box(self) -> int:
        """プレゼントBOXで受け取り待ちのハート。そのままでは使えない。"""
        u = self.info.userinfo if self.info else None
        return int(u.pheart if u else 0)

    def _play_tsum_id(self) -> int:
        """プレイに使うツム。持っていないツムでは gameStart が通らない。

        GetInfoResponse.mytsum は見つからないときに ID 1 を返すので使わない
        (持っていなければそのプレイが丸ごと弾かれる)。
        """
        candidates = self._play_tsum_candidates()
        return candidates[0] if candidates else 0

    def _play_tsum_candidates(self, limit: int = 3) -> list:
        """プレイに使えるツムを、使う順に並べる。

        先頭はマイツム(お客さんが普段使っている1体)。ゲーム開始で弾かれた
        ときにツムが原因かどうかを潰せるよう、持っている別のツムも後ろに
        並べておく。gameStart が弾かれた時点ではハートは減らないので、
        試すこと自体はお客さんの持ち物を減らさない。

        並べ替えはしない。「同梱の表に載っているIDなら通る」ということはなく
        (570/625/512 でも同じように弾かれる)、マイツムから順に使う。
        """
        if not self.info:
            return []
        out = []

        def add(tsum_id):
            tsum_id = int(tsum_id or 0)
            if tsum_id > 0 and tsum_id not in out:
                out.append(tsum_id)

        mine = self.mytsum()
        if mine is not None:
            add(mine.tsumid)
        data = self.info.mydatainfo
        add(getattr(data, "hometsum", 0))
        add(getattr(data, "mytsum_id", 0))
        for tsum in self.info.tsuminfo:
            add(tsum.tsumid)
        return out[:max(1, limit)]

    def _known_owned_tsum(self):
        """持っているツムのうち、こちらのバージョンが知っている1体。

        マイツムを一時的に替える先。レベルの高い子を選ぶ(そのアカウントで
        育てている＝確実に持っている)。知っているツムが1体も無ければ None。
        """
        if not self.info:
            return None
        known = bundled_tsum_ids()
        owned = [t for t in self.info.tsuminfo if int(t.tsumid or 0) in known]
        if not owned:
            return None
        owned.sort(key=lambda t: (int(t.lv or 0), int(t.tsumid)), reverse=True)
        return int(owned[0].tsumid)

    async def restore_mytsum(self):
        """一時的に替えたマイツムを元へ戻す。

        お客さんの設定を黙って変えたままにしない。戻せなくても代行の結果は
        変えない(もう渡し終わっているので、後始末で「失敗」にはしない)。
        """
        original = self._switched_mytsum
        if not original:
            return
        self._touch()
        try:
            restored = await self.client.get_info(mytsumid=original)
            if not (tsum_api.is_getinfo_payload(restored) and restored.get("retcode") == 0):
                raise tsum_api.GetInfoError(restored)
            # 戻した応答も getInfo そのもの。取り込んでおけば、このあとの判断
            # (ツムレベルの対象など)が戻ったマイツムを見る。
            self._absorb_info(restored)
        except Exception as e:
            # 戻せなかった。札(_switched_mytsum)は下ろさない。次の機会(メダルの処理の
            # 直後・close)にもう一度戻す。ここで下ろすと、お客さんの元のマイツムが
            # 分からなくなり、あとでプラスツムのほうを「元」と取り違えて戻してしまう。
            print(f"[TSUM] マイツムを戻せませんでした: {type(e).__name__}: {e}",
                  flush=True)
            self.trace.append(f"マイツムを{original}へ戻せませんでした（あとでもう一度戻します）")
            return
        self._switched_mytsum = None
        self._medal_switched = False
        self.trace.append(f"マイツムを{original}へ戻しました")

    async def _restore_after_medal(self):
        """メダルのためにプラスツムへ替えていたら、メダルの処理の直後に戻す。

        close() まで替えたままにすると、同じ注文のツムレベル上げ(注文時のマイツムを
        上げる)がプラスツムのままプレイして gameStart で弾かれる。支払いの前の
        確かめのあとも同じ(ツムレベルの判断がお客さんのマイツムを見る)。
        戻せなかったときは印を残し、次の機会にもう一度戻す。
        """
        if not self._switched_mytsum:
            self._medal_switched = False
            return
        if self._medal_switched:
            await self.restore_mytsum()

    async def _pace_play(self):
        """連続プレイの間隔を人の足取りに寄せる(BAN対策)。

        前のプレイからの経過で測るので、あいだに getInfo などを挟んで
        時間が経っていれば、それ以上は待たない。
        """
        last = getattr(self, "_last_play_at", 0.0)
        wait = last + random.uniform(PLAY_GAP_MIN, PLAY_GAP_MAX) - time.monotonic()
        if wait > 0:
            await asyncio.sleep(wait)
        self._last_play_at = time.monotonic()

    async def _play(self, results: list, *, tsum_id: int = None, score: int = 0,
                    coin: int = 0, medal: int = 0, exp: int = 0,
                    vanish: int = 10, event_id: int = None, medal_hook=None) -> dict:
        """1プレイ分を投げる。ハートが無ければ何もせずに返す。

        ハートはこちらで買わない。買うとお客さんのルビーが減るし、断りなく
        減らすわけにいかない。足りない注文は支払いの前に止めてある。

        通ったかどうかは _play_ok() で見る。空 = ハート切れで投げていない、
        _failed 付き = 投げたがゲーム側に断られた、で意味が違う。
        medal_hook は tsum_api.game_play のもの(gameStart の応答を見てから
        申告するメダルを決める)。
        """
        if self.hearts() < HEART_PER_PLAY:
            # 理由はお客さんのDMにしか出ず、非公開ログには[失敗]の見出しだけが
            # 残っていた。投げていないのに「投げたが入らなかった」と読み違える
            # (イベントのせいに見えた)ので、プレイごとの記録にも残す。
            if not self._no_heart_noted:
                self._no_heart_noted = True
                line = (f"ハートが{self.hearts()}個のため、ここから先はプレイしていません"
                        "（ゲームには何も投げていません）")
                box = self.hearts_in_box()
                if box:
                    line += f"。プレゼントBOXに{box:,}個ありますが、アプリで受け取るまで使えません"
                self.trace.append(line)
            return {}
        if getattr(self.client, "_event_broken", False):
            # このイベントのプレイは、eventpt / boxcnt の組み合わせを全部
            # 試しても、申告を 0 にしても通らなかった(game_play)。同じものを
            # また投げてもハートを捨てるだけなので、投げずに失敗として返す。
            return {"_failed": True, "_stage": "end", "_reason": "event",
                    "retmsg": "イベント付きのプレイが通らないため、投げていません"}
        await self._pace_play()
        # ここから先はゲーム側の状態(ハート・残高・プレイの札)を動かす。
        self._touch()
        if vanish == 10 and not (medal and getattr(self.client, "_legacy_end", False)):
            # 既定のまま(コイン付与などの「ついで」の消去数)なら、毎回同じ10を
            # 並べない。ツムレベル上げのように意図して渡された値は触らない。
            # 9/22 の形で投げるメダルのプレイ(_medal_with_legacy_end)は 10 のまま。
            vanish = random.randint(8, 16)
        # ツムを指定されたとき(ツムレベル上げ)は差し替えない。その1体を
        # 上げるのが注文なので、別のツムでプレイしても意味がない。
        candidates = [int(tsum_id)] if tsum_id else self._play_tsum_candidates()
        if not candidates:
            return {"_failed": True, "_stage": "tsum",
                    "retmsg": "プレイに使えるツムが見つかりません"}

        # event_id を指定したとき(イベントを外して確かめる)だけ渡す。
        pin = {} if event_id is None else {"event_id": event_id}
        res = None
        for index, tid in enumerate(candidates):
            res = await self.client.game_play(info=self.info, tsum_id=tid,
                                              score=score, coin=coin, medal=medal,
                                              exp=exp, vanish=vanish,
                                              medal_hook=medal_hook, **pin)
            if not isinstance(res, dict):
                return {"_failed": True, "_stage": "end"}
            if not res.get("_failed") or res.get("_stage") != "start":
                return res
            if pin:
                # イベントを外した開始が断られた = 参加中の口は外して始められない。
                # ツムやマイツムの問題ではないので、ほかのツム・マイツムの差し替え・
                # 残ったプレイの片付けには進まない(お客さんの設定を触らない)。
                return res
            # ゲーム開始で弾かれた = ハートはまだ減っていない。ツムが原因の
            # ことがあるので、次の候補で試す。
            if index + 1 < len(candidates):
                self.trace.append(
                    f"ツム{tid}ではゲーム開始が通らなかったので、"
                    f"{candidates[index + 1]}で試します")

        # どのツムでも開始できない。マイツムがこちらの知らないツムだと、
        # ここで詰む。ゲームは「いまのマイツム」でしかプレイできないので、
        #   ・マイツムのIDで投げる → こちらのバージョンに無いIDなので断られる
        #   ・別のツムで投げる     → マイツムではないので断られる
        # の両方がふさがる。先にマイツムを、知っているツムへ替える。
        # 替えたぶんは代行が終わったら元に戻す(close)。
        if tsum_id is None and not self._switched_mytsum:
            target = self._known_owned_tsum()
            mine = self.mytsum()
            if target and mine is not None and int(mine.tsumid) != target:
                self._switched_mytsum = int(mine.tsumid)
                self.trace.append(
                    f"マイツム{mine.tsumid}では始められないので、"
                    f"{target}へ一時的に替えます（終わったら戻します）")
                try:
                    self._touch()
                    # マイツムを替える getInfo も、応答は getInfo そのもの。
                    switched = await self.client.get_info(mytsumid=target)
                    if (tsum_api.is_getinfo_payload(switched)
                            and switched.get("retcode") == 0):
                        # 替えが通った。応答をそのまま取り込んで1往復を省く。
                        # 以降で失敗しても close() で元のマイツムへ戻す。
                        self._absorb_info(switched)
                    else:
                        # 替えが弾かれた(userinfo 無し / retcode≠0)。マイツムは
                        # 変わっていないので、戻す札(_switched_mytsum)を下ろして
                        # close での無駄な復帰(＝同じエラーの再発)を防ぐ。
                        # ここで refresh_info に流すと、替わっていないのに替わった
                        # ものとして target でプレイを続けてしまうので流さない。
                        # 理由(retcode/retmsg)を添えて失敗にする。
                        self._switched_mytsum = None
                        raise tsum_api.GetInfoError(switched)
                except Exception as e:
                    self.trace.append(
                        f"　替えられませんでした: {type(e).__name__}: {e}")
                else:
                    return await self._play(results, tsum_id=target, score=score,
                                            coin=coin, medal=medal, exp=exp,
                                            vanish=vanish, event_id=event_id,
                                            medal_hook=medal_hook)

        # 前のプレイの札が残っているなら、それが邪魔をしている可能性がある。
        # 閉じてから1回だけやり直す。
        code = self._pending_playcode()
        if code and not self._closed_pending:
            self._closed_pending = True
            self.trace.append(f"決着していないプレイが残っていました"
                              f"（playcode={code}）。閉じてからやり直します")
            try:
                await self.client.game_end(tsum_id=candidates[0], play_code=code,
                                           vanish=0)
            except Exception as e:
                self.trace.append(f"　閉じられませんでした: {type(e).__name__}: {e}")
            self._touch()
            await self.refresh_info()
            return await self._play(results, tsum_id=tsum_id, score=score,
                                    coin=coin, medal=medal, exp=exp, vanish=vanish,
                                    event_id=event_id, medal_hook=medal_hook)
        return res

    @staticmethod
    def _play_ok(res) -> bool:
        """そのプレイがゲーム側に通ったか。"""
        return bool(res) and isinstance(res, dict) and not res.get("_failed")

    async def _medal_without_event(self, results: list, amount: int) -> tuple:
        """イベント付きのプレイでメダルが0枚だったときに、イベントを外して1回だけ試す。

        イベントに参加している口のプレイでだけメダルが入らないのか、イベントに
        関係なく入らないのかを切り分ける(テスト垢はイベント156・157の両方で +0
        だったが、イベント無しでは試せていなかった)。参加中の口はイベントを外して
        始められないことがあり、そのときは開始で断られてハートは減らない。

        戻り値 (そのプレイの応答, 外したイベントID)。試せなかったとき(イベント無しで
        プレイしていた・もう試した・外して始められない・通らない)は応答が None。
        外したら入った場合、以降のプレイもイベント無しで投げるのは呼び出し側が決める。
        """
        event_id = getattr(self.client, "_event_id", None)
        if not event_id or self._medal_noevent_tried:
            return None, event_id
        self._medal_noevent_tried = True
        res = await self._play(results, medal=amount, event_id=0)
        if not self._play_ok(res):
            tried = self._short_attempts(res)
            self.trace.append(
                f"イベント{event_id}を外したプレイは通りませんでした"
                + ("（イベントに参加中のため外して始められません）"
                   if res and res.get("_stage") == "start" else "")
                + (f" [{tried}]" if tried else ""))
            return None, event_id
        return res, event_id

    def _note_medal_earned(self, res) -> None:
        """プレイで受け取ったメダルの合計(ゲームの記録)を、記録に1回だけ出す。

        gameEnd の応答の usermissioninfo(はじめてミッション)に「ゲームをプレイして
        合計100メダル稼ごう」があれば、その進み(nowpt)がプレイで受け取ったメダルの
        合計になっている。テスト垢はここが 500,000 のまま動かず、
        2,030 + 500,000 − プレミアムBOX＋ 10回×20,000 = 302,030(所持)とぴったり
        合う。0枚だったときに、その垢がすでにどれだけ受け取っているかを記録で
        見られるようにする(はじめてミッションが無い垢では何も出さない)。
        """
        if getattr(self, "_medal_earned_noted", False):
            return
        for group in (res or {}).get("usermissioninfo") or []:
            for mission in (group or {}).get("missionlist") or []:
                desc = str((mission or {}).get("desc") or "")
                if "メダル" in desc and "稼" in desc:
                    try:
                        total = int(mission.get("nowpt"))
                    except (TypeError, ValueError):
                        return
                    self._medal_earned_noted = True
                    self.trace.append(f"この垢がこれまでにプレイで受け取ったメダル: 合計{total:,}枚"
                                      "（ゲームの記録・はじめてミッション）")
                    return

    def _keep_without_event(self, event_id) -> None:
        """イベントを外したらメダルが入った。この接続の以降のプレイもイベント無しで投げる。"""
        self.client._event_id = 0
        self.trace.append(f"イベント{event_id}付きのプレイではメダルが入らず、イベントを"
                          "外したら入りました。以降のプレイはイベント無しで投げます")

    async def _medal_with_legacy_end(self, results: list, amount: int):
        """イベントを外せない口で、9/22 の gameEnd の形で1回だけ確かめる。

        実測(10/1): イベントに参加していない口ではメダルが入り(新しい垢で
        +200,000)、参加中の口(イベント157。ゲスト2つ・Lv282 のお客さん・
        参加させた新しい垢)ではプレイが通っても +0。応答の userinfo は
        bmedal=-1 で、メダルには手を付けていない。参加中の口はイベントを外して
        始められない(eventid=0 は 8/2)ので、イベント付きのまま入る形を探す
        しかない。otherresult にメダルの記録を足しても +0 だった。

        9/22 は参加中の口でも入っていた(運営の確認)。その頃と今の gameEnd の
        違いは、数字を揺らしていない(playtime 60 / combo 1 / chain 6 /
        消去数 10)ことと、eventpt を空で送っていたことだけなので、その形で投げる
        (tsum_api の LEGACY_END)。

        イベント付きで遊んでいないとき・もう試したときは None(試していない)。
        通らなかったら元の形に戻す。入ったかどうかの判断は呼び出し側
        (残高の実測)がする。
        """
        if not getattr(self.client, "_event_id", None) or self._legacy_end_tried:
            return None
        self._legacy_end_tried = True
        self.client._legacy_end = True
        res = await self._play(results, medal=amount)
        if not self._play_ok(res):
            self.client._legacy_end = False
            tried = self._short_attempts(res)
            self.trace.append("9/22の送り方のプレイは通りませんでした"
                              + (f" [{tried}]" if tried else ""))
        return res

    def _legacy_end_result(self, got: int) -> None:
        """9/22 の形で投げたプレイの結果を残す。入れば以降もその形、入らなければ戻す。"""
        if got > 0:
            self.trace.append("イベント付きのプレイでも、9/22の送り方なら入りました。"
                              "以降のメダルのプレイもこの形で投げます")
        else:
            self.client._legacy_end = False
            self.trace.append("9/22の送り方(数字を固定・eventptを空)でも増えませんでした")

    async def _capture_event_debug(self, res, why: str):
        """イベント付きのプレイが弾かれた/0枚だったときの中身を、1回だけ丸ごと残す。

        イベントに参加している口では、プレイが必ずイベントとして扱われる
        (eventid=0 では開始できない)。そのプレイにサーバが何を渡してきて、
        何を返してほしいのかは、retcode からは分からない。gameStart /
        gameEnd の応答、こちらが送った gameEnd の中身、getEvent、イベントの
        マスタを並べて、実機のプレイと見比べられるようにする。
        """
        # 調べもののために代行そのものを落とさない(どこが欠けていても黙って抜ける)。
        if getattr(self, "debug", None) is not None:
            return
        if getattr(self, "client", None) is None:
            return
        # イベントを外したプレイ(eventid=0)でも残す。プレイは通ったのにメダルが
        # 0枚、はイベント無しで起きていて、ここで抜けると応答が何も残らない。
        ev = getattr(self.client, "_event_id", None)
        dump = {"why": why, "eventid": ev,
                "steps": res.get("_raw_trail") if isinstance(res, dict) else None,
                # このプレイに付いていたミッションと、それをどう読んで eventpt を
                # 決めたか。弾かれたときは、ここと sent_gameEnd の eventpt を
                # 見比べれば「読みが違う」のか「形式が違う」のかが分かる。
                "play_mission": getattr(self.client, "_last_play_mission", None),
                # そのプレイのイベント設定(エネルギーの箱 boxlist など)と、同じ
                # プレイに投げ直した (eventpt, boxcnt) の組。次に別の書き方を
                # 足すときの材料になる。
                "play_event": getattr(self.client, "_last_play_event", None),
                "tried_ends": sorted(list(pair) for pair in
                                     getattr(self.client, "_tried_ends", None) or []),
                "sent_gameEnd": getattr(self.client, "_last_end_body", None),
                # そのときの持ち物の数字(bmedal / pmedal の内訳を含む)。
                "userinfo": (self.raw or {}).get("userinfo")}
        if ev:
            try:
                dump["getEvent"] = await self.client.get_event(ev)
            except Exception as e:
                dump["getEvent"] = f"{type(e).__name__}: {e}"
            try:
                mast = await self.client.get_mast([3, 7, 11, 14])
                rows = [row for row in mast.get("eventmst", [])
                        if str(row.get("eventid")) == str(ev)]
                dump["eventmst"] = rows
                # メダルが入らないのは「この口がイベントに参加中」だから。参加して
                # いるイベントがいつ終わるか(=いつメダルを付けられるようになるか)を
                # マスタから拾っておき、お客さん・管理者への説明に使う。
                ends = _event_end_label(rows[0]) if rows else ""
                if ends:
                    self._blocked_event_ends = ends
                    self.trace.append(
                        f"この口はイベント{ev}に参加中。メダルはイベント終了"
                        f"（{ends}ごろ）まで付けられません")
            except Exception as e:
                dump["eventmst"] = f"{type(e).__name__}: {e}"
        self.debug = dump
        where = f"イベント{ev}" if ev else "イベント無し"
        self.trace.append(f"{where}のプレイの中身を添付しました（{why}）")

    @staticmethod
    def _short_attempts(res) -> str:
        """game_play が投げた順番を1行に縮めたもの(例: ev156→0/0 / gameEnd→1/2)。

        通ったかどうかだけでは、「一発で通ったのか、入り直してから通ったのか」
        「どの開始が通ってハートを使ったのか」が分からない。付与が 0 のときや
        弾かれたときに、どの呼び出しがどう返ったかを追えるようにする。
        """
        steps = res.get("_attempts") if isinstance(res, dict) else None
        if not steps:
            return ""
        out = []
        for step in steps:
            step = re.sub(r"tsumid=\d+\s*", "", str(step))
            step = (step.replace("getInfo後 ", "").replace("retcode=", "")
                    .replace("eventid=", "ev"))
            out.append(step.strip())
        return " / ".join(out)

    def _play_failure(self, label: str, res) -> str:
        """プレイが通らなかった理由。後から追えるように retcode まで載せる。"""
        if not res:
            box = self.hearts_in_box()
            if box:
                return (f"{label}に失敗しました：プレイに使えるハートがありません"
                        f"（プレゼントBOXに{box:,}個ありますが、アプリで"
                        "受け取るまでプレイには使えません）")
            return f"{label}に失敗しました：プレイに使えるハートがありません"
        if res.get("_stage") == "tsum":
            return f"{label}に失敗しました：{res.get('retmsg')}"
        # retcode はこちらが原因を追うためのもの。お客さんのDMには出さず、
        # 非公開ログのほうへ回す。
        stage = "ゲーム開始" if res.get("_stage") == "start" else "ゲーム終了"
        detail = f"{stage} retcode={res.get('retcode')} retsubcode={res.get('retsubcode')}"
        if res.get("retmsg"):
            detail += f" {str(res['retmsg'])[:120]}"
        self.trace.append(f"{label}が通りませんでした（{detail}）")
        # 何を投げて弾かれたのかを残す。retcode だけでは、どのパラメータが
        # 悪いのかも、フォールバックが動いたのかも分からない。
        if res.get("_attempts"):
            self.trace.append("　試したもの: " + " / ".join(res["_attempts"]))
        self.trace.append("　" + self._client_note())
        # ゲームが返したものをそのまま残す。retcode だけでは分からないことが
        # 応答の他の欄に出ていることがある。要約せずに出す（要約すると、
        # 探しているものが落ちる）。
        raw = {k: v for k, v in res.items() if not str(k).startswith("_")}
        if raw:
            self.trace.append(f"　応答: {json.dumps(raw, ensure_ascii=False)[:600]}")
        note = self._session_note()
        if note:
            self.trace.append(f"　getInfo: {note}")
        if res.get("_reason") == "event":
            # 枚数の話ではない。イベントのプレイそのものが受け付けられていない。
            # お客さんには「枚数を変えても同じ」「繰り返してハートを捨てていない」
            # と分かる形で。手元のハート数は取り直す前なのでここでは言わない。
            return (f"{label}に失敗しました：イベント参加中のアカウントで、"
                    "このイベントのプレイがゲーム側に受け付けられませんでした"
                    "（枚数の問題ではないため、枚数を変えて繰り返さず、"
                    "ハートを捨てないよう1回で止めています）")
        return f"{label}に失敗しました"

    def _session_note(self) -> str:
        """getInfo が返している userinfo の中身（欄の名前と、短い値だけ）。

        「一度タイトルに戻ります」はゲーム側から見て状態が食い違っている合図。
        こちらが何を握っているのかが分からないと切り分けられないので、
        欄の名前だけでも残す。長い値は名前だけにする。
        """
        info = ((self.raw or {}).get("userinfo") or {}) if self.raw else {}
        if not isinstance(info, dict) or not info:
            return ""
        parts = []
        for key, value in info.items():
            text = str(value)
            parts.append(f"{key}={text}" if len(text) <= 24 else f"{key}(長)")
        return " ".join(parts)[:600]

    def _play_tsum_note(self) -> str:
        """プレイに使うツムの、ゲームが返している中身そのまま。

        レベル・スキル・上限解放の状態など、こちらが見ていない欄が
        ゲーム開始の可否を分けている可能性がある。要約せずに出す。
        """
        if not self.info:
            return ""
        tsum_id = self._play_tsum_id()
        raw = ((self.raw or {}).get("tsuminfo") or []) if self.raw else []
        for entry in raw:
            if isinstance(entry, dict) and int(entry.get("tsumid") or 0) == tsum_id:
                return json.dumps(entry, ensure_ascii=False)[:400]
        return f"tsumid={tsum_id}（tsuminfo に見当たりません）"

    def _pending_playcode(self):
        """決着していないプレイの札が getInfo に残っていれば、それ。

        前のプレイが gameEnd まで行かずに終わると、ゲーム側にその札が残る。
        残ったままだと新しいプレイを始められず、gameStart が
        「入力パラメータでエラーが発生しました。一度タイトルに戻ります。」で
        断ることがある。
        """
        info = ((self.raw or {}).get("userinfo") or {}) if self.raw else {}
        code = info.get("playcode") if isinstance(info, dict) else None
        return code or None

    def _client_note(self) -> str:
        """名乗っているバージョンと、プレイに使ったツム。

        ゲーム側に断られたとき、こちらが何者として投げていたかが分からないと
        切り分けようがない。名乗りが古ければまずそこを疑う。
        """
        client = self.client
        hash_value = str(getattr(client, "HASH", "") or "")
        parts = [f"appver={getattr(client, 'APP_VER', '?')}",
                 f"resver={getattr(client, 'RES_VER', '?')}",
                 f"mstver={getattr(client, 'MST_VER', '?')}",
                 # hash は応答で書き換わる。名乗りが途中で変わっていないかを見る
                 f"hash…{hash_value[-8:] or '?'}",
                 f"tsumid={self._play_tsum_id()}"]
        tsum = self.mytsum()
        if tsum is not None:
            parts.append(f"マイツムLv{getattr(tsum, 'lv', '?')}")
        return " ".join(parts)

    # ---- 結果の文言 ----

    def _failure_message(self, label: str, result) -> str:
        """完売が通らなかったときの、お客さんに出す一文。

        retcode のようなこちら側の事情はDMに出さず、非公開ログへ回す。
        お客さんに要るのは「何が起きて、次にどうすればいいか」だけ。
        """
        if not isinstance(result, dict):
            return f"{label}の処理に失敗しました"
        status = result.get("_status")
        if status == "insufficient_funds":
            currency = result.get("_currency_jp", "通貨")
            return (f"{label}：{currency}が足りず途中で終了しました\n"
                    f"・現在の{currency}: {result.get('_balance', 0):,}\n"
                    f"・次に必要: {result.get('_need', 0):,}\n"
                    f"・処理できた分: {result.get('_draws', 0)}回")
        if status in ("loop_limit", "max_draws_reached", "time_limit"):
            return (f"{label}：{result.get('_draws', 0)}回まで回しましたが、"
                    "完売には届きませんでした\n"
                    "使ったぶんの中身は付いています。残りは改めてご依頼ください。")
        self.trace.append(
            f"{label}が通りませんでした（status={status} "
            f"retcode={result.get('retcode')} "
            f"retsubcode={result.get('retsubcode')}）")
        return f"{label}の処理に失敗しました"

    # 途中で止まっただけで、失敗ではないもの。どれも回したぶんは付いている
    # (コインは減っている)ので、「失敗」と出して片付けるわけにいかない。
    NONFATAL_STATUS = ("insufficient_funds", "loop_limit", "max_draws_reached",
                       "time_limit")

    def _nonfatal_stop(self, label: str, result):
        """資源不足・上限打ち切りは、失敗ではなく未完了の停止として扱う。"""
        if isinstance(result, dict) and result.get("_status") in self.NONFATAL_STATUS:
            return {"success": True, "warning": True,
                    "message": self._failure_message(label, result)}
        return None

    # ---- 1メニュー ----

    async def run(self, key: str) -> dict:
        """1メニュー(=タスクいくつか)を実行する。

        戻り値 {"success","warning","message"}。
        """
        try:
            return await self._run(key)
        except Exception as e:
            # ここで握るのは「このメニューが駄目でも次のメニューは流す」ため。
            # 支払いは受け取っているので、止めるより残りを進めるほうがいい。
            # 例外の中身はこちらが追うためのもの。DMには出さずログへ回す。
            self.trace.append(
                f"{menu_label(key)}で例外: {type(e).__name__}: {str(e)[:200]}")
            print(f"[TSUM] {menu_label(key)}で例外: {type(e).__name__}: {e}",
                  flush=True)
            return {"success": False, "message": "処理中にエラーが起きました"}

    async def _run(self, key: str) -> dict:
        tasks = menu_tasks(key)
        if not tasks:
            self.trace.append(f"未対応のメニュー: {key}")
            return {"success": False, "message": "このメニューは処理できませんでした"}

        await self.refresh_info()
        before_coin = int(self.info.userinfo.coin_total or 0)
        before_medal = int(self.info.userinfo.medal_total or 0)
        before_ruby = int(self.info.userinfo.ruby_total or 0)

        results, ok, warning = [], True, False
        # 増やせなかった通貨。その通貨で回す完売は見送る(プレミアムボックス+は
        # コインではなくメダルで回すので、通貨ごとに持つ)。
        failed_pay = set()
        for index, (kind, value) in enumerate(tasks):
            if kind == GACHA and gacha_pay(value) in failed_pay:
                # 完売はお客さんの手持ちを使う。増やせなかったところで回すと
                # 元から持っていたぶんを削るだけなので、ここは飛ばす。
                ok = False
                results.append(f"{task_label(kind, value)}は、"
                               f"{task_label(gacha_pay(value))}を増やせなかったため"
                               "実行していません。")
                continue
            outcome = await self._run_task(kind, value, results,
                                           self._spare_hearts(tasks[index:]))
            if not outcome.get("success"):
                ok = False
                if kind in (COIN, MEDAL):
                    failed_pay.add(kind)
                results.append(outcome.get("message", "処理に失敗しました"))
                if self.hearts() < HEART_PER_PLAY:
                    # ハートが無いなら残りも同じ理由で止まる。同じ文言を並べても
                    # 仕方がないので、何を飛ばしたかだけ伝えて抜ける。
                    rest = [task_label(k, v) for k, v in tasks[index + 1:]]
                    if rest:
                        results.append("ハートが足りないため、"
                                       + "・".join(rest) + "は実行していません。")
                    break
                # 1つ駄目でも、残りは別の処理として最後まで流す(セット商品の
                # 中身は互いに独立している)。ここで打ち切ると、お代を受け取った
                # まま手つかずの項目が残る。
                continue
            if outcome.get("warning"):
                warning = True
                results.append(outcome.get("message", ""))
            elif outcome.get("message"):
                results.append(outcome["message"])

        await self._append_balance_diff(results, before_coin, before_medal,
                                        before_ruby, tasks)
        return {"success": ok, "warning": warning,
                "message": "\n".join(line for line in results if line)}

    def _spare_hearts(self, remaining: list) -> int:
        """残りのタスクに要らない、余っているハートの数。

        やり直しに使ってよいのはここまで。注文で見積もった数を超えて使うと、
        後ろのタスクがハート切れで落ちる（お代は受け取っているのに、
        こちらの都合で別の項目を潰すことになる）。
        """
        need = sum(_rounds_for(kind, value) * HEART_PER_PLAY
                   for kind, value in remaining)
        return max(0, self.hearts() - need)

    def coins(self) -> int:
        """いま持っているコイン。増えたかどうかを確かめるのに使う。"""
        u = self.info.userinfo if self.info else None
        return int(u.coin_total if u else 0)

    def medals(self) -> int:
        """いま持っているメダル。増えたかどうかを確かめるのに使う。"""
        u = self.info.userinfo if self.info else None
        return int(u.medal_total if u else 0)

    async def _run_coin(self, amount: int, results: list, spare_hearts: int,
                        already: int = 0) -> dict:
        """コインを付ける。中身は _grant_currency(下の説明)と同じ。
        already は支払いの前の確かめ(_probe_coin)で付いたぶん(結果の文はご注文の
        枚数で書く)。"""
        return await self._grant_currency(
            COIN, amount, results, spare_hearts,
            balance_of=self.coins, chunk_max=COIN_CHUNK_MAX,
            retry_limit=COIN_RETRY_LIMIT, already=already)

    async def _run_medal(self, amount: int, results: list, spare_hearts: int,
                         already: int = 0) -> dict:
        """メダルを付ける。中身は _grant_currency(下の説明)と同じ。

        プレミアムボックス+はメダルで回すので、完売とセットで使う。メダルは
        所持の上限で途中から切られたり、プレイが通っても1枚も入らなかったり
        する(MEDAL_MAX)ので receive_cap で流す。サーバに弾かれたときの半分探しはコインと同じ。already は支払いの
        前の確かめで付いたぶん(結果の文はご注文の枚数で書く)。
        """
        # イベント参加中の口で入ると分かっている送り方があれば、その送り方で投げる。
        # 1プレイの上限が分かっているなら、最初からその枚数で刻む(大きく申告して
        # +0 になるのを避ける)。
        await self._ensure_medal_mode()
        chunk_max = MEDAL_CHUNK_MAX
        cap = self._medal_mode_cap()
        if cap > 0:
            chunk_max = min(chunk_max, cap)
        try:
            return await self._grant_currency(
                MEDAL, amount, results, spare_hearts,
                balance_of=self.medals, chunk_max=chunk_max,
                retry_limit=MEDAL_RETRY_LIMIT, receive_cap=True, already=already)
        finally:
            # プラスツムに替えていたら、ここで戻す(次のタスクがマイツムを使う)。
            await self._restore_after_medal()

    async def _grant_currency(self, kind: str, amount: int, results: list,
                              spare_hearts: int, *, balance_of, chunk_max: int,
                              retry_limit: int, receive_cap: bool = False,
                              already: int = 0) -> dict:
        """コイン・メダルを付ける。**指定した合計が入るまで、実測を見ながら積む。**

        gameEnd が retcode=0 を返しても、ゲーム側が申告どおりのコインを付ける
        とは限らない。1回のプレイとしてあり得ない枚数を申告すると、
        リクエストのほうは通しておいて、付与だけ黙って落とすことがある。
        応答だけを見て「付与しました」と書いていたので、1枚も増えていない注文が
        [完了] のまま流れていた（お客さんはお代を払っている）。増えたかどうかは
        残高を取り直して確かめる。プレイヤーレベルで応答の lv を当てにしないのと
        同じ理由で、ここも自己申告ではなく実測を見る。

        1回で通る枚数には上限がある（2億は弾かれるのに1億は通る、など）。
        弾かれたら枚数を半分に落として「1回で通る枚数」を探し、見つかったら
        **その枚数を繰り返して指定の合計まで積む。** 半分だけ付いて打ち切ると、
        お代は2億ぶんなのに1億しか付かない（実際にこれで起きた）。追加ぶんに
        使うのは余っているハートだけで、後ろのタスクには手を付けない。

        receive_cap=True の通貨(メダル)は、プレイが通っても何枚申告しても +0 に
        なることがある(50万から7,812まで6回半分にしても全部 +0 で、ハート7個を
        捨てただけだった。原因は MEDAL_MAX のコメント)。あといくつ入るかは
        読めないので、プレイが通ったあとは実測でこう決める:
          ・申告より少なく付いた → 上限で切られた。止める
          ・1枚も付かない(まだ付いていない) → MEDAL_PROBE 枚で1回だけ確かめる。
            それも0ならいまは入らない。止める。入れば、さっきの枚数が丸ごと
            落とされただけなので、半分に落として通る枚数を探す
          ・1枚も付かない(一度付いたあと) → 上限。止める
        サーバに弾かれた(retcode≠0)ときの半分探しはコインと同じく行う。
        """
        label = TASK_LABELS.get(kind, kind)
        before = balance_of()
        target_total = int(amount)
        # 最初から「1回で通る上限」で刻む。指定合計をそのまま1回で申告すると、
        # 2億など大きすぎる枚数はサーバに丸ごと弾かれて1枚も付かない(下でさらに
        # 半分に落として探すが、最初からこの上限にしておけば空振りを1回減らせる)。
        chunk = min(target_total, chunk_max)  # 次のプレイで申告する枚数の上限
        retries_left = retry_limit         # 「通る枚数」を探すために半分に落とせる回数
        # 指定額を配り切るのに要る最低プレイ数(弾かれなければこの回数で届く)。
        # この回数までは注文ぶんのハートで配り、超えるぶん(探り直し・積み増し)
        # だけ余っているハートから出す。以前は「1回目だけ」を注文ぶんとしていた
        # ため、2億のように複数プレイ要る付与が、後ろのタスク用に取り置いた
        # ハートに阻まれて90,000,000(1回ぶん)で止まっていた。その結果、完売に
        # 使うコインが足りず、プレミアムボックスが未完売で終わっていた。
        deliver_budget = max(1, -(-target_total // max(1, chunk)))  # ceil
        plays_used = 0                     # これまでに投げたプレイ数
        applied_any = False                # 1回でも実際に増えたか
        stall_left = GRANT_STALL_RETRY     # 増えたあとに止まったときに試せる回数
        stalled = False                    # これ以上ゲーム側が受け付けなくなった
        # receive_cap のとき: 少ない枚数で確かめたか / 確かめている最中か /
        # 確かめが通って通る枚数を探している最中か / 探し始める元の枚数
        checked = checking = searching = False
        search_from = 0
        # 参加中の口(プラスツムでプレイ)の入り方の学び(_plus_next が使う入れ物)。
        plus_state = {"fell_back": False, "growing": False, "grow": True}

        while True:
            delivered = balance_of() - before
            remaining = target_total - delivered
            if remaining <= 0:
                break                       # 指定ぶん付け終わった
            want = min(chunk, remaining)
            if want < 1:
                break

            # 指定額を配り切るぶんのプレイは、注文ぶんのハートで行う。それを
            # 超える積み増し・探り直しだけ、余っているハートから出す(後ろの
            # タスクぶんには手を付けない)。どちらも、実際にハートが無ければ投げない。
            if plays_used >= deliver_budget:
                if spare_hearts < HEART_PER_PLAY:
                    break
                spare_hearts -= HEART_PER_PLAY
            if self.hearts() < HEART_PER_PLAY:
                break

            # 「受け取れる状態か」の確かめ(メダルが1枚も入らなかった直後)は、
            # イベント付きでプレイしていたならイベントを外して投げる。イベントの
            # せいで入らないのか、イベントに関係なく入らないのかを、同じ1プレイで
            # 切り分ける。外して始められない口では、今までどおりイベント付きで投げる。
            # イベントを外して始められない口(参加中)では、同じイベント付きのプレイを
            # もう一度投げても +0 になるだけなので、9/22 の gameEnd の形で確かめる。
            res = noevent = None
            legacy = False
            if receive_cap and checking and not applied_any:
                res, noevent = await self._medal_without_event(results, want)
                if res is None:
                    noevent = None
                    res = await self._medal_with_legacy_end(results, want)
                    legacy = res is not None
            if res is None:
                if kind == MEDAL:
                    # 覚えている送り方(プラスツム・medallimit までに抑える)を効かせる。
                    res = await self._medal_play(results, want)
                else:
                    # _play の引数名はタスクの種類(coin / medal)そのもの。ここで文字列を
                    # 書き分けると増やしたときに食い違うので、種類をそのまま使う。
                    res = await self._play(results, **{kind: want})
            plays_used += 1
            if not self._play_ok(res):
                # プレイそのものが通らない(ハート切れ・ログイン切れなど)。ここまで
                # 積んだぶんは残高に出ているので、下で部分成功として扱う。
                if delivered > 0:
                    break
                # まだ1枚も付いていない。サーバに弾かれた(res があり retcode≠0)なら、
                # 申告が大きすぎる可能性が高い。枚数を半分に落として「1回で通る枚数」を
                # 探す(これをやらずに即失敗していたので、2億などがそのまま[失敗]に
                # なっていた)。プレイを投げていない(空 res=ハート切れ・ツム無し等)なら
                # 半分にしても無意味なので、そのまま失敗にする。探索も配り切る
                # ぶんのプレイ枠(deliver_budget)の内で行う。
                if res:
                    await self._capture_event_debug(res, f"{want:,}枚で弾かれた")
                if legacy:
                    # 9/22 の形で弾かれた。今の形でイベント付きのまま投げ直しても
                    # +0 になるのは分かっているので、ハートを使わずにここで止める。
                    return {"success": False,
                            "message": self._play_failure(f"{label}の付与", res)}
                if res and res.get("_reason") == "event":
                    # イベントの中身がどう投げても通らない(game_play が同じプレイに
                    # 組み合わせを全部投げ、申告を 0 にしても駄目だった)。枚数を
                    # 半分にしても同じで、繰り返すとハートを捨てるだけ。実際に
                    # 6回半分にして 26 個捨てたことがある。ここで止める。
                    return {"success": False,
                            "message": self._play_failure(f"{label}の付与", res)}
                if res and retries_left > 0 and (chunk // 2) >= 1:
                    tried = self._short_attempts(res)
                    chunk //= 2
                    retries_left -= 1
                    self.trace.append(
                        f"{label} 申告{want:,}枚 → 弾かれた"
                        + (f" [{tried}]" if tried else "")
                        + f"。{min(chunk, remaining):,}枚 で試し直します")
                    continue
                return {"success": False,
                        "message": self._play_failure(f"{label}の付与", res)}
            await self.refresh_info()
            got = (balance_of() - before) - delivered   # このプレイでの増分
            tried = self._short_attempts(res)
            limits = self._start_limits(res) if receive_cap else ""
            self.trace.append((f"(イベント{noevent}を外して) " if noevent else
                               "(9/22の送り方) " if legacy else "")
                              + f"{label} 申告{want:,}枚 → 実際 +{got:,}枚"
                              f"（{before + delivered:,} → {balance_of():,}）"
                              + (f" [{tried}]" if tried else "")
                              + (f" [{limits}]" if limits else ""))
            if receive_cap:
                if noevent and got > 0:
                    # イベントを外したら入った = 枚数ではなくイベントのせいで落とされて
                    # いた。半分に落として探さず、以降もイベント無しで元の枚数を積む。
                    applied_any = True
                    checking = searching = False
                    chunk = max(chunk, search_from)
                    self._keep_without_event(noevent)
                    continue
                if legacy:
                    self._legacy_end_result(got)
                    if got > 0:
                        # 今の形のせいで落とされていた。枚数の問題ではないので
                        # 半分に落とさず、以降も 9/22 の形で元の枚数を積む。
                        applied_any = True
                        checking = searching = False
                        chunk = max(chunk, search_from)
                        continue
                if noevent:
                    self.trace.append(f"イベント{noevent}を外しても{label}は増えませんでした"
                                      "（イベントが原因ではありません）")
                if (kind == MEDAL and not noevent and not legacy
                        and not checking and not searching and self._last_medal_plus
                        and (self._medal_mode or {}).get("mode") == "plus"):
                    # 参加中の口(本当にプラスツムで投げたプレイ)。入り方から1プレイの
                    # 上限・確かめ済みの枚数を学び、+0 なら確かめ済みの枚数へ落として
                    # 投げ直す。少ない枚数での確かめ(checking)や半分探し(searching)の
                    # 最中は、従来の判断(_capped_next)に任せる。
                    plus_next, chunk = self._plus_next(
                        got, self._last_medal_claim(want), chunk, chunk_max,
                        balance_of(), plus_state)
                    if plus_next == "go":
                        applied_any = True
                        continue
                    if plus_next == "retry":
                        plus_state["fell_back"] = True
                        continue
                if got <= 0 and not applied_any:
                    await self._capture_event_debug(res, f"{want:,}枚が通ったのに0枚")
                    self._note_medal_earned(res)
                decision, chunk, retries_left = self._capped_next(
                    got, want, chunk, retries_left, applied_any, checked, checking,
                    searching, search_from)
                if got > 0:
                    applied_any = True
                if decision == "check":
                    checked = checking = True
                    search_from = want
                    self.trace.append(
                        f"まず{chunk:,}枚で、受け取れる状態かを確かめます")
                    continue
                if decision == "search":
                    checking, searching = False, True
                    self.trace.append(
                        f"受け取れる余地はあるので、{min(chunk, target_total - (balance_of() - before)):,}枚"
                        " で試し直します")
                    continue
                if decision == "halve":
                    self.trace.append(
                        f"通らなかったので {min(chunk, remaining):,}枚 で試し直します")
                    continue
                if decision == "go":
                    checking = searching = False
                    continue
                # "stop": これ以上は入らない(途中で切られた・確かめても0)
                stalled = True
                self.trace.append(
                    f"{label}はゲーム側の上限に当たったため、ここで止めます"
                    if applied_any else
                    f"プレイは通っても{label}が増えないため、ここで止めます")
                break
            if got > 0:
                applied_any = True
                continue                    # 通った枚数はそのまま次も使う
            if not applied_any:
                await self._capture_event_debug(res, f"{want:,}枚が通ったのに0枚")

            # 1枚も付かなかった。
            #   まだ1回も付いていない → 申告が大きすぎる。半分に落として探す。
            #   すでに付いたあとで止まった → 枚数の問題ではなく、ゲーム側が
            #     これ以上受け付けない(取得の上限)。同じ枚数で通った直後に
            #     半分でも1/8でも入らない、という実測がある。何度も半分にすると
            #     ハートを捨てるだけなので、数回だけ確かめて切り上げる。
            allowed = retries_left if not applied_any else min(retries_left, stall_left)
            if allowed <= 0 or chunk // 2 < 1:
                stalled = applied_any
                break
            if applied_any:
                stall_left -= 1
            chunk //= 2
            retries_left -= 1
            self.trace.append(
                f"通らなかったので {min(chunk, remaining):,}枚 で試し直します")

        delivered = balance_of() - before
        # 原因が確定していないので、上限などと決めつけない(MEDAL_MAX のコメント)。
        zero_note = (f"プレイは通りましたが、ゲーム側で{label}が増えませんでした"
                     "（少ない枚数で確かめても同じでした）。")
        if already:
            # 支払いの前の確かめで付いたぶんも含めて、ご注文の枚数で書く
            # (抜いたまま「499,900枚 付与しました」と出すと足りないように読める)。
            delivered += already
            target_total += already
        if delivered >= target_total:
            return {"success": True,
                    "message": f"{label}を {delivered:,}枚 付与しました"}
        if delivered > 0:
            # 途中まで付いた。なぜ止まったのかを、当てずっぽうではなく実測で書く。
            # ここを「上限か、ハート切れ」と一緒くたに書いていたので、ハートが
            # 残っているのに「ハートが足りず」と読める文が出ていた。
            if stalled and receive_cap:
                why = (f"{balance_of():,}枚 のところで、ゲーム側の上限に当たり、"
                       f"それ以上の{label}は入りませんでした。")
            elif stalled:
                why = (f"{balance_of():,}枚 のところで、ゲーム側がそれ以上の"
                       f"{label}を受け付けなくなりました"
                       "（枚数を落としても入りません）。ハートは残っています。")
            else:
                why = ("ゲーム側が1回で受け付ける枚数の上限に当たっているか、"
                       "ハートが足りず、指定どおりには付いていません。")
            return {"success": True, "warning": True,
                    "message": (f"{label}は {delivered:,}枚 付きました"
                                f"（ご指定は {target_total:,}枚）。\n" + why)}
        return {"success": False,
                "message": (f"{label}が増えませんでした（ご指定 {target_total:,}枚）。\n"
                            + (zero_note if receive_cap and stalled
                               else "ゲーム側がこの付与を受け付けていません。")
                            + "**お代はいただいたままですので、ご連絡ください。**")}

    @staticmethod
    def _capped_next(got: int, want: int, chunk: int, retries_left: int,
                     applied_any: bool, checked: bool, checking: bool,
                     searching: bool, search_from: int) -> tuple:
        """プレイが通っても入らないことがある通貨(メダル)で、通ったプレイの次をどうするか。

        戻り値 (決めたこと, 次の申告の上限, 残りの半分探し回数)。決めたこと:
          "go"     このまま同じ枚数で続ける
          "check"  少ない枚数(MEDAL_PROBE)で、受け取れる状態かを1回確かめる
          "search" 確かめは通った。元の枚数の半分から通る枚数を探す
          "halve"  探している最中に0だった。さらに半分にする
          "stop"   これ以上は入らない(途中で切られた・確かめても0)
        """
        if got > 0:
            if checking:
                # 少ない枚数なら入った = 受け取れる余地はあり、さっきの枚数は
                # 丸ごと落とされただけ。
                if retries_left > 0 and search_from // 2 >= 1:
                    return "search", search_from // 2, retries_left - 1
                return "go", chunk, retries_left
            if got < want:
                return "stop", chunk, retries_left      # 上限で切られた
            return "go", chunk, retries_left
        if not applied_any:
            if not checked and want > MEDAL_PROBE:
                return "check", MEDAL_PROBE, retries_left
            return "stop", chunk, retries_left          # 少ない枚数でも0
        if searching and retries_left > 0 and chunk // 2 >= 1:
            return "halve", chunk // 2, retries_left - 1
        return "stop", chunk, retries_left              # 一度付いたあとで0

    @staticmethod
    def _start_limits(res) -> str:
        """そのプレイの gameStart が返した coinlimit / medallimit(調べもの用)。

        受け取れる残りを表しているのかはまだ分からない(上限に達した口では
        どちらも -1 だった)。別の口の値と見比べられるよう記録に出しておく。
        """
        steps = res.get("_raw_trail") if isinstance(res, dict) else None
        for step in reversed(steps or []):
            response = step.get("response") if isinstance(step, dict) else None
            if isinstance(response, dict) and "medallimit" in response:
                return (f"medallimit={response.get('medallimit')} "
                        f"coinlimit={response.get('coinlimit')}")
        return ""

    async def _run_task(self, kind: str, value, results: list,
                        spare_hearts: int = 0) -> dict:
        # params のキーは注文側(TsumOrder.params)がタスクの種類をそのまま使う。
        # ここで文字列を書くと "playerlv" と "player_level" のように食い違って、
        # お客さんの指定が黙って捨てられるので、定数のまま引く。
        if kind == COIN:
            amount = int(self.params.get(COIN, 0) if value is None else value)
            amount = max(0, min(amount, COIN_MAX))
            # 支払いの前の確かめ(_probe_coin)で付いたぶんは、ご注文の枚数に含める
            # (ご注文の枚数ちょうどにする)。_run_coin の中で残高を取り直すので、
            # 次のタスクは新しい残高・ハート数を見る（セット商品はこの後にレベル
            # 上げや完売が続く）。
            probed = max(0, min(int(self.params.get(COIN_PROBED, 0) or 0), amount))
            if probed:
                self.trace.append(f"コイン {probed:,}枚 は支払いの前の確認で付与済み")
            return await self._run_coin(amount - probed, results, spare_hearts,
                                        already=probed)

        if kind == MEDAL:
            amount = int(self.params.get(MEDAL, 0) if value is None else value)
            amount = max(0, min(amount, MEDAL_MAX))
            # 支払いの前の確かめ(_probe_medal)で付いたぶんは、ご注文の枚数に
            # 含める(ご注文の枚数ちょうどにする。上乗せすると、所持の上限ぎりぎりの
            # ご注文で確かめのぶんだけ余計に付けることになる)。
            probed = max(0, min(int(self.params.get(MEDAL_PROBED, 0) or 0), amount))
            if probed:
                self.trace.append(f"メダル {probed:,}枚 は支払いの前の確認で付与済み")
            return await self._run_medal(amount - probed, results, spare_hearts,
                                         already=probed)

        if kind == PLAYER_LEVEL:
            target = int(self.params.get(PLAYER_LEVEL, player_level_max())
                         if value is None else value)
            return await self._run_player_level(max(0, min(target, player_level_max())),
                                                results)

        if kind == SCORE:
            target = int(self.params.get(SCORE, SCORE_MAX) if value is None else value)
            target = max(0, min(target, SCORE_MAX))
            before = int(self.info.userinfo.score or 0)
            if target <= before:
                # ハイスコアは下げられない。プレイを1回無駄にしないよう先に断る。
                return {"success": True, "warning": True,
                        "message": f"いまのスコア（{before:,}）のほうが高いため、"
                                   f"更新していません（指定 {target:,}）"}
            res = await self._play(results, score=target)
            if not self._play_ok(res):
                return {"success": False,
                        "message": self._play_failure("スコアの更新", res)}
            score = (res.get("userinfo", {}) or {}).get("score")
            shown = int(score) if isinstance(score, int) else target
            await self.refresh_info()
            return {"success": True, "message": f"スコアを更新しました（{shown:,}）"}

        if kind == TSUM_LEVEL:
            return await self._run_tsum_level(results)

        if kind == GACHA:
            return await self._run_gacha(value, results)

        self.trace.append(f"未対応の処理: {kind}")
        return {"success": False, "message": "この内容は処理できませんでした"}

    async def _run_player_level(self, target: int, results: list) -> dict:
        """プレイヤーレベルを指定のところまで上げる。

        レベルは経験値で決まるが、必要量の表は持っていない。上限まで上げるなら
        一度に大量の経験値を入れれば済む。途中のレベルを狙うときは、そのアカウント
        自身の「今までの経験値 ÷ 今のレベル」から1レベルぶんを見積もる。後半ほど
        1レベルが重くなるので、この見積もりは必ず少なめに出る = 行き過ぎない。
        足りなければもう一度、を何回か繰り返して寄せていく。
        """
        before = int(self.info.userinfo.lv or 0)
        if before >= target:
            return {"success": True, "warning": True,
                    "message": f"いまのレベル（{before}）のほうが高いため、"
                               f"上げていません（指定 {target}）"}

        # exp_cap: 1プレイで申告する経験値の上限。弾かれたら半分に落として「通る量」を探す。
        # boost: 見積もりが小さすぎて1レベルに届かないとき増やす倍率(通る上限で頭打ち)。
        exp_cap, boost = PLAYER_EXP, 1
        retries_left = PLAYER_EXP_RETRY
        points = []              # (総経験値, レベル) の実測
        rounds, stopped_by_heart, stop_reason, hit_cap = 0, False, "", False

        for _ in range(PLAYER_LEVEL_ROUNDS):
            now = int(self.info.userinfo.lv or 0)
            if now >= target:
                break
            if self.hearts() < HEART_PER_PLAY:
                stopped_by_heart = True
                break
            total = int(self.info.mydatainfo.totalexp or 0)
            # 同じレベルを2度入れない(2点が同レベルだと傾きが読めない)。
            if not points or points[-1][1] != now:
                points.append((total, now))
            # 指定へ届かせる追加経験値を必ず少なめに見積もり(飛び越えない)、
            # boost で足りないぶんを補い、通る上限(exp_cap)で頭打ちにする。
            need = self._exp_to_target(points, total, now, target)
            want = max(1, min(need * boost, exp_cap))
            played = await self._play(results, exp=want)
            if not self._play_ok(played):
                stopped_by_heart = self.hearts() < HEART_PER_PLAY
                if not stopped_by_heart:
                    stop_reason = self._play_failure("プレイヤーレベルの処理", played)
                break
            await self.refresh_info()
            rounds += 1
            after_lv = int(self.info.userinfo.lv or 0)
            after_total = int(self.info.mydatainfo.totalexp or 0)
            self.trace.append(
                f"{rounds}回目 目標Lv{target} 経験値+{want:,} → Lv{now} → {after_lv}"
                f"（総経験値 {total:,} → {after_total:,}）")
            if after_lv > now:
                boost = 1                # 進んだ。倍率は戻す(通る上限はそのまま)
                continue
            if after_total > total:
                # 経験値は入ったのにレベルが動かない=1レベルに足りない。次はもっと。
                if boost >= 64:
                    hit_cap = True       # 通る上限まで入れても動かない=ゲーム側の上限
                    break
                boost *= 4
                continue
            # 経験値が1も入らなかった=申告が大きすぎて弾かれた。いま送った量(want)の
            # 半分を上限にして「通る量」を探す(コインと同じ。ここが無くて「弾かれたら
            # 即あきらめ」だったのが未完了の原因)。exp_cap ではなく want を基準に半分へ
            # 落とすのは、申告が見積もり(want)で決まり exp_cap より小さいことがあるため。
            if retries_left <= 0 or want // 2 < 1000:
                break
            exp_cap = want // 2
            retries_left -= 1
            self.trace.append(f"弾かれたので 経験値{exp_cap:,} 以内で試し直します")

        after = int(self.info.userinfo.lv or 0)
        self.trace.append(f"プレイヤーレベル {before} → {after}（指定 {target} / "
                          f"プレイ {rounds}回）")
        text = f"プレイヤーレベル: {before} → {after}"
        if after >= target:
            if after > target:
                text += f"（ご指定の{target}以上になりました）"
            return {"success": True, "message": text}
        if hit_cap:
            return {"success": True, "warning": True,
                    "message": text + f"\nこれ以上は上がりませんでした"
                                      f"（レベル{after}がゲーム側の上限です）。"}
        if stopped_by_heart:
            return {"success": True, "warning": True,
                    "message": text + "\nハートが足りなくなったため途中で止めました。"}
        if stop_reason:
            return {"success": True, "warning": True,
                    "message": text + "\n" + stop_reason}
        return {"success": True, "warning": True,
                "message": text + f"\n指定の{target}には届きませんでした。"
                                  "残りは再度ご依頼ください。"}

    @staticmethod
    def _exp_to_target(points, total: int, now: int, target: int) -> int:
        """指定レベルへ届かせる追加経験値の見積もり。**必ず少なめに出す。**

        プレイヤーレベルの1レベルあたりの経験値は後半ほど重くなる(下に凸)。
        だから「直近の実測1区間の平均の傾き × 残りレベル」で先を延ばすと、
        次のレベルより軽い傾きを使うことになり、必ず指定の手前で止まる。
        これを1プレイぶんとして入れ、残りはまた測って寄せる。何回かに
        分かれるが、指定を飛び越えない(行き過ぎたレベルは下げられない)。

        実測2点が無いうちは、0からの平均(さらに平ら＝さらに安全)で見積もる。
        """
        remain = target - now
        if remain <= 0:
            return 0
        slope = 0.0
        if len(points) >= 2:
            (e0, n0), (e1, n1) = points[-2], points[-1]
            if n1 > n0 and e1 > e0:
                slope = (e1 - e0) / (n1 - n0)
        if slope <= 0:
            slope = total / max(now, 1)      # 0からの平均(実測が足りないとき)
        return max(1, int(slope * remain))

    async def _run_tsum_level(self, results: list) -> dict:
        """指定されたツムのレベルを上限まで上げる。

        1回のプレイで上がる分は決まっているので、上限に届くまで繰り返す。
        ハートが尽きるか、最小の申告でも経験値が入らなくなったら、そこまでの
        結果を伝えて終わる。回数では止めない。
        """
        tsum_id = int(self.params.get("tsum_id") or 0)
        if not tsum_id:
            # 注文の時点でマイツムを読んで入れてあるので、ここが空なのは異常。
            return {"success": False, "message": "対象のツムが分かりませんでした"}

        current = self.info.get_tsum(tsum_id)
        if current is None:
            return {"success": False,
                    "message": f"{tsum_name(tsum_id)} を持っていないため上げられません"}
        # ゲームは「いまのマイツム」でしかプレイできない。上げる1体(注文時の
        # マイツム)と今のマイツムが違っていれば(同じ注文のメダルでプラスツムに
        # 替えた直後・お客さんが替えた、など)、その1体へ替えてから回す(終わったら
        # 戻す)。替えずに回すと gameStart で弾かれて [失敗] になる。
        mine = self.mytsum()
        if (mine is None or int(mine.tsumid or 0) != tsum_id) \
                and not await self._switch_mytsum(tsum_id):
            return {"success": False,
                    "message": f"{tsum_name(tsum_id)} をマイツムにできなかったため上げられません"}
        # 目標はマスタが持つ上限(通常50)。limitlv はいまの上限で、
        # releaseTsumLv でこれを押し上げながらプレイでレベルを上げていく。
        master = load_tsum_master().get(tsum_id) or {}
        max_lv = int(master.get("maxlv") or 0) or 50
        before_lv = int(current.lv or 0)
        before_cnt = int(current.vanishcnt or 0)
        # レベルを動かしているのは exp のほう。実測では申告600個につき900 exp
        # 入り、レベルはその累計で決まっている。進んでいるかどうかも exp で
        # 見る。消去数は最後の1回が getInfo に出るのが遅れることがあり、
        # そのままだと「止まった」と誤解する。
        before_exp = last_exp = int(current.exp or 0)

        # 効きかたの設定は、走り出す前に1度だけ読む(途中で変わると
        # 申告した合計と記録が食い違う)。
        vanish = level_vanish()
        rounds, stopped_by_heart, stalled, stop_reason = 0, False, 0, ""
        declared = 0        # こちらが申告した消去数の合計
        # 回数(level_rounds)では止めない。上限(limitlv)に当たった回は入る
        # 経験値が頭打ちになる(Lv34→35 で +4,425 など)ので、決めた回数では
        # 足りずに Lv44/45 で [一部未完了] になっていた。止まるのは上限に
        # 届いた・ハートが尽きた・最小の申告でも増えない、のどれか。
        # LEVEL_PLAYS_GUARD はそれでも抜けられないときの歯止め。
        while rounds < LEVEL_PLAYS_GUARD:
            latest = self.info.get_tsum(tsum_id)
            if latest is not None and int(latest.lv or 0) >= max_lv:
                break
            if self.hearts() < HEART_PER_PLAY:
                stopped_by_heart = True
                break
            played = await self._play(results, tsum_id=tsum_id,
                                      vanish=vanish)
            if not self._play_ok(played):
                stopped_by_heart = self.hearts() < HEART_PER_PLAY
                if not stopped_by_heart:
                    # ここで黙って抜けると「プレイ1回」とだけ残って、
                    # なぜ続かなかったのかが後から追えない。
                    stop_reason = self._play_failure("途中のプレイ", played)
                break
            await self.refresh_info()
            rounds += 1
            # 投げられた回のぶんだけ数える。ハートが無くて投げていない回まで
            # 足すと、記録の「申告×回数 = 合計」が合わなくなる。
            declared += vanish

            now = self.info.get_tsum(tsum_id)
            now_exp = int(now.exp or 0) if now is not None else last_exp
            # 経験値はレベルの上限(limitlv)で頭打ちになる。そこで止まったまま
            # 次のプレイへ進むと、そのプレイは丸ごと無駄になる(実機で3回目に
            # +280で頭打ち、4回目が+0、解放後の5回目から+900に戻っていた)。
            # プレイの前ではなく、上限に当たったその場で解放する。
            # 上限がすでにレベル上限まで開いていれば、解放しても何も起きない。
            # 1回2,000コインかかるので、そこは呼ばない。
            released = ""
            wide_open = now is not None and now.limitlv \
                and int(now.limitlv) >= max_lv
            if now is not None and int(now.lv or 0) < max_lv and not wide_open \
                    and (now_exp <= last_exp
                         or (now.limitlv and int(now.lv or 0) >= int(now.limitlv))):
                self._touch()
                await self.client.release_tsum_lv(tsum_id)
                await self.refresh_info()
                now = self.info.get_tsum(tsum_id)
                now_exp = int(now.exp or 0) if now is not None else now_exp
                released = " ＋上限解放"
            # 1回ごとの入り方。申告した数と入った経験値がここで並ぶので、
            # ゲーム側が削っているのかどうかがそのまま見える。
            line = (f"{rounds}回目 申告{vanish:,} "
                    f"→ 経験値+{now_exp - last_exp:,} "
                    f"（累計 {now_exp:,} / 消去数 "
                    f"{int(now.vanishcnt or 0) if now is not None else '?'} / "
                    f"Lv{int(now.lv or 0) if now is not None else '?'}"
                    f"/{int(now.limitlv or 0) if now is not None else '?'}"
                    f"）{released}")
            print(f"[TSUM LV] {line}", flush=True)
            self.trace.append(line)
            if now_exp > last_exp:
                stalled = 0
            elif vanish > LEVEL_VANISH_SAFE:
                # 上限解放でも増えない = 申告数が大きすぎてゲーム側が弾いている
                # (実機でもLv45あたりから60,000が通らなくなり、そこで諦めていた)。
                # コイン付与と同じで、通る数まで下げて続ける。ここで止めない。
                vanish = max(LEVEL_VANISH_SAFE, vanish // 2)
                self.trace.append(f"通らなかったので消去数 {vanish:,} で試し直します")
            else:
                # 最小まで下げても増えない = ゲーム側が本当に受け付けない。
                # 繰り返してもハートを捨てるだけなので早めに止める。
                stalled += 1
                if stalled >= 2:
                    break
            last_exp = now_exp

        # 最後の1回ぶんが getInfo に出るまで少し遅れ、「10回まわして9回ぶん」に
        # なる。数えたものを正しく出すために、手元が新しくても取り直す。
        try:
            await self.refresh_info(force=True)
        except Exception as e:
            print(f"[TSUM] ツムレベルの最終確認に失敗: {type(e).__name__}: {e}",
                  flush=True)
        after = self.info.get_tsum(tsum_id)
        after_lv = int(after.lv or 0) if after is not None else before_lv
        after_cnt = int(after.vanishcnt or 0) if after is not None else before_cnt
        after_exp = int(after.exp or 0) if after is not None else before_exp
        # 申告・消去数・経験値はこちらの都合の数字。お客さんのDMには出さず、
        # 非公開ログのほうへ回す(何が起きたかを追うのに要るのはこちら側)。
        got = after_cnt - before_cnt
        self.trace.append(
            f"まとめ 申告合計 {declared:,}（{rounds}回）/ "
            f"消去数 {before_cnt:,} → {after_cnt:,}（+{got:,}） / "
            f"経験値 {before_exp:,} → {after_exp:,} / "
            f"Lv{before_lv} → {after_lv}")
        text = f"{tsum_name(tsum_id)} のレベル: {before_lv} → {after_lv}"
        if after_lv >= max_lv:
            return {"success": True, "message": text}
        if stopped_by_heart:
            return {"success": True, "warning": True,
                    "message": text + "\nハートが足りなくなったため途中で止めました。"
                                      "ハートを用意してから、残りをご依頼ください。"}
        if after_exp <= before_exp:
            # 1も入っていない。お渡しできていないので失敗として扱う。
            return {"success": False,
                    "message": text + "\nレベルを上げられませんでした。"}
        if stop_reason:
            return {"success": True, "warning": True,
                    "message": text + "\n途中で止まりました。"
                                      "残りは改めてご依頼ください。"}
        if after_lv > before_lv:
            # あと何回で上限か、は言わない。ゲーム側の必要数を持っていないので、
            # 出せるのは当てずっぽうの数字だけになる(実測どうしが同じ式に
            # 乗らないことを確かめてある)。上がったところまでを事実として出す。
            return {"success": True, "warning": True,
                    "message": text + f"\nレベル{max_lv}には届きませんでした。"
                                      "今回の分はそのまま残っていますので、"
                                      "続きは改めてご依頼ください。"}
        return {"success": True, "warning": True,
                "message": text + "\nレベルは上がりませんでした。"}

    @staticmethod
    def _gacha_cost(target: dict, name: str = "") -> tuple:
        """(完売までにかかる分, それが確定値か)。分からなければ (0, False)。

        マスタに中身の数(maxcnt)が入っていないボックス(プレミアムボックス+)は、
        前に回したときの実績から見積もる。実績が未完売どまりなら「最低でも」の
        下限として使う。0 を返すと歯止めが丸ごと効かないので、少しでも根拠が
        あるなら出す。
        """
        price = int(target.get("price") or 0)
        if price <= 0:
            return 0, False
        maxcnt = int(target.get("maxcnt") or 0)
        if maxcnt > 0:
            return price * maxcnt, True
        draws, exact = gacha_min_draws(name)
        return (price * draws, exact) if draws > 0 else (0, False)

    async def _run_gacha(self, name: str, results: list) -> dict:
        """完売系。開催中のガチャを特定してから、いまの手持ちで回す。

        完売はお客さんの手持ちで回すだけ。足りないからといって、こちらで
        通貨を増やしてから回すことはしない(頼まれたのは「完売」であって、
        通貨を増やすことではない)。足りなければ回さずにそう伝える。
        """
        kind = GACHA_KINDS.get(name) or {}
        label = kind.get("label", name)
        try:
            targets = await self._resolve_targets([name])
        except Exception as e:
            print(f"[TSUM GACHA] 開催中のガチャを特定できません: {type(e).__name__}: {e}",
                  flush=True)
            targets = {}
        target = targets.get(name)
        if not target:
            return {"success": True, "warning": True,
                    "message": f"開催中の{label}が見つかりませんでした"}
        if target.get("compflg") == 1:
            return {"success": True, "message": f"{label}はすでに完売しています"}

        balance, currency = self._balance_for_type(target["type"])
        tickets = self._ticket_count(target["type"])
        # 完売までにいくら要るかが分かるなら、足りないうちは1回も回さない。
        # 途中まで回して足りなくなると、完売しないままお客さんのコインだけが
        # 消える(1回の代行で1億コイン以上が飛ぶ)。
        need, exact = self._gacha_cost(target, name)
        if need and not tickets and balance < need:
            return {"success": True, "warning": True,
                    "message": (f"{label}：完売までに{currency}が"
                                f"{'' if exact else '最低でも'}{need:,}要ります"
                                f"（いま {balance:,}）。\n"
                                f"{currency}が足りないので、1回も回していません。")}

        self._touch()                   # ここから残高が動く
        if name == "pickup":
            # .so の SceneStore::purchaseProcedure では type=21/31 は
            # RequestPickupResult へ直接分岐する(通常のガチャ経路ではない)。
            gacha_res = await self.client.gacha_comp_pickup(
                gacha_id=target["gachaid"], gacha_type=target["type"],
                curr_price=target.get("price", 0), balance=balance,
                ticket_count=tickets, max_count=target.get("maxcnt") or 0,
                label=kind.get("api_label", "PICKUP"))
        else:
            gacha_res = await self.client.gacha_comp_store(
                gacha_id=target["gachaid"], gacha_type=target["type"],
                multi_allowed=(target["multiflg"] == 1 and kind.get("multi", True)),
                curr_price=target.get("price", 0), balance=balance,
                ticket_count=tickets, bonus_id=self._bonus_id(),
                label=kind.get("api_label", name.upper()),
                max_draws=int(target.get("maxcnt") or 0) or GACHA_MAX_DRAWS)
        draws_total = int((gacha_res or {}).get("_draws") or 0
                          if isinstance(gacha_res, dict) else 0)

        completed = await self._verify_completed(target["gachaid"])
        # 完売までに何回要るかを覚える。ボックスの中身の数(maxcnt)が
        # gachamst に入っていないボックスでは、これが唯一の手がかりになる。
        # 次の注文で「足りないなら1回も回さない」を効かせるのに使う。
        record_gacha_size(name, draws_total, completed,
                          int(target.get("price") or 0))
        if not completed:
            # どこで止まったかを非公開ログへ残す。
            if isinstance(gacha_res, dict):
                self.trace.append(
                    f"{label} 未完売（status={gacha_res.get('_status')} "
                    f"{gacha_res.get('_draws', '?')}回 / 残り{currency} "
                    f"{gacha_res.get('_balance', '?')}）")
            nonfatal = self._nonfatal_stop(label, gacha_res)
            if nonfatal:
                return nonfatal
            return {"success": False, "message": self._failure_message(label, gacha_res)}
        self.trace.append(f"{label} 完売（{draws_total:,}回）")
        return {"success": True, "message": f"{label}を完売しました"}

    async def _append_balance_diff(self, results: list, before_coin: int,
                                   before_medal: int, before_ruby: int, tasks: list):
        """最新の残高を取り直して、増えた分・減った分を書く。"""
        try:
            latest = await self.refresh_info()
        except Exception as e:
            print(f"[TSUM] 最終残高の取得に失敗: {type(e).__name__}: {e}", flush=True)
            return
        after_coin = int(latest.userinfo.coin_total or 0)
        after_medal = int(latest.userinfo.medal_total or 0)
        after_ruby = int(latest.userinfo.ruby_total or 0)

        results.append("────────────")
        coin_delta = after_coin - before_coin
        if coin_delta < 0:
            results.append(f"コイン: -{-coin_delta:,}（現在 {after_coin:,}）")
        elif coin_delta > 0:
            results.append(f"コイン: +{coin_delta:,}（現在 {after_coin:,}）")
        else:
            results.append(f"コイン: {after_coin:,}")

        medal_delta = after_medal - before_medal
        if medal_delta:
            sign = "+" if medal_delta > 0 else "-"
            results.append(f"メダル: {sign}{abs(medal_delta):,}（現在 {after_medal:,}）")

        ruby_delta = after_ruby - before_ruby
        if ruby_delta:
            sign = "+" if ruby_delta > 0 else "-"
            results.append(f"ルビー: {sign}{abs(ruby_delta):,}（現在 {after_ruby:,}）")


async def run_menus(refresh_token: str = None, keys=None, params: dict = None,
                    on_progress=None, guest_id: str = None,
                    guest_password: str = None) -> dict:
    """選ばれたメニューを順に流す。

    戻り値 {"ok": bool, "warning": bool, "account": str, "lines": [表示用の行]}。
    ok=False は1つ以上のメニューが通らなかったということ。ログインそのものが
    駄目だったときは TsumLoginError を投げる(やり直しても同じなので)。

    引き継ぎ番号(guest_id)で入ったときは、代行のあとに新しい引き継ぎ番号を
    発行して "guest_code": (番号, パスワード) を返す。これをお客さんに渡さないと
    垢を返せない(引き継ぎで移した時点で、お客さんの端末からは入れなくなる)。
    この番号は防犯ロックで、使えるのは発行から数時間〜24時間ほど後。
    """
    runner = TsumRunner(refresh_token, params=params,
                        guest_id=guest_id, guest_password=guest_password)
    # どこに時間がかかっているかを非公開ログに残す。「遅い」と言われたとき、
    # ログインなのか、プレイの間隔なのか、完売なのかが分からないと手が打てない。
    started = time.monotonic()
    timing = []
    try:
        # open() の途中で落ちても、そこまでに張った接続は手放す。
        await runner.open()
        timing.append(f"ログイン {time.monotonic() - started:.0f}秒")

        # 引き継ぎ(ゲスト)は支払い前にログインできない(番号を消費してしまう)
        # ので、マイツムを先に読めていない。入れ替えたあとのここで読んで補う。
        if (guest_id and needs_tsum(keys)
                and not runner.params.get("tsum_id")):
            mt = runner.mytsum()
            if mt is not None:
                runner.params["tsum_id"] = mt.tsumid

        lines, all_ok, any_warning = [], True, False
        # コイン(メダル)付与のメニューがこけたら、その通貨で回す「完売(GACHA)」
        # メニューは流さない。完売はお客さんの手持ちを使うので、増やせなかったのに
        # 回すと、元から持っていたぶんを削るだけになる(実際に、コイン付与失敗のあと
        # 完売が走って垢の手持ちコインが減った)。通貨は完売より前に処理される
        # (sort_keys = MENUS の並び順)ので、ここで見送れる。
        failed_pay = set()
        for key in sort_keys(keys):
            label = menu_label(key)
            tasks = menu_tasks(key)
            paid_kinds = {k for k, _ in tasks if k in (COIN, MEDAL)}
            blocked = {gacha_pay(v) for k, v in tasks if k == GACHA} & failed_pay
            if blocked:
                pay = task_label(sorted(blocked)[0])
                all_ok = False
                lines.append(f"[未実行] {label}\n{pay}を増やせなかったため実行して"
                             f"いません（お客さまの手持ち{pay}を減らさないよう見送りました）。")
                continue
            if on_progress is not None:
                await on_progress(key)
            menu_started = time.monotonic()
            result = await runner.run(key)
            timing.append(f"{label} {time.monotonic() - menu_started:.0f}秒")
            if not result.get("success"):
                all_ok = False
                failed_pay |= paid_kinds
                lines.append(f"[失敗] {label}\n{result.get('message', '')}")
            elif result.get("warning"):
                any_warning = True
                lines.append(f"[一部未完了] {label}\n{result.get('message', '')}")
            else:
                lines.append(f"[完了] {label}\n{result.get('message', '')}")

        runner.trace.append(
            f"所要 {time.monotonic() - started:.0f}秒（" + " / ".join(timing) + "）")
        out = {"ok": all_ok, "warning": any_warning,
               "account": runner.account_line(), "lines": lines,
               "trace": list(runner.trace)}
        if runner.debug is not None:
            out["debug"] = runner.debug
        # 引き継ぎで入ったときは、返却用の新しい番号を必ず出す。ここを落とすと
        # お客さんが自分の垢に戻れなくなるので、代行が一部こけていても発行する。
        if guest_id:
            try:
                mid, pw = await runner.client.issue_guest_code()
                out["guest_code"] = (mid, pw)
            except Exception as e:
                out["guest_code_error"] = f"{type(e).__name__}: {e}"
        return out
    finally:
        await runner.close()
