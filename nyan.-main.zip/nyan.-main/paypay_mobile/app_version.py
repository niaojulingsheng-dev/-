"""名乗るPayPayアプリのバージョンを決める。

PayPayは古いクライアントからの操作を弾くことがある(特に送金系)。古い版を
固定で名乗ると、送金リンクの作成だけが「Specific Error with half sheet
(S9999)」で失敗する。アプリからは同じ操作が通るので、アカウントではなく
クライアント側の問題。

そのため実際に配信されている最新バージョンに追従する。見に行くのは Google Play
(Android版)。_core.py は Client-OS-Type: ANDROID / User-Agent: PaypayApp/… Android10
と名乗っているので、追従先も Android でないと辻褄が合わない。

App Store(iOS版)を見てはいけない。iOS が先に出た日は Android にまだ存在
しないバージョンを名乗ることになり、古すぎたときと同じく送金リンクの作成
だけが S9999 で落ちる(受け取りは通るので気づきにくい)。

取得結果は24時間キャッシュし、取得できないときは FALLBACK_VERSION を使う
(ネットワークが不調でも動く)。環境変数 PAYPAY_APP_VERSION を入れておけば、
それが最優先される。
"""
import json
import os
import re
import threading
import time

import requests

# ストアから取得できなかったときに名乗るバージョン。
# 追従できているかは /paypay_status で確認できる。
FALLBACK_VERSION = "5.63.0"

LOOKUP_URL = ("https://play.google.com/store/apps/details"
              "?id=jp.ne.paypay.android.app&hl=ja&gl=JP")
# 配信中のバージョンは [[["5.63.0"]],… という形でページのデータに埋まっている。
# 説明文や関連アプリにも数字は出るので、この形以外は拾わない。
_PAGE_VERSION_RE = re.compile(r'\[\[\["(\d+(?:\.\d+){1,3})"\]\]')
# どのストアから取った値かをキャッシュに残す。参照先を変えたときに、前の参照先で
# 取った値(iOS版など)をそのまま使い続けないようにするため。
SOURCE_ID = "play"

CACHE_TTL = 24 * 3600      # 取得に成功したら1日は再取得しない
RETRY_AFTER = 600          # 失敗したら10分は再試行しない(操作のたびに外に出ない)
_VERSION_RE = re.compile(r"^\d+(\.\d+){1,3}$")

_lock = threading.Lock()
_state = {"version": None, "next_check": 0.0, "source": "fallback"}


def _cache_file() -> str:
    try:
        from datapath import data_path
        return data_path("paypay_app_version.json")
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "app_version.json")


def _load_cache():
    try:
        with open(_cache_file(), "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("source") != SOURCE_ID:
            return None, 0.0       # 参照先を変える前の値。取り直す
        v = data.get("version")
        if isinstance(v, str) and _VERSION_RE.match(v):
            return v, float(data.get("fetched_at") or 0)
    except (OSError, ValueError, TypeError):
        pass
    return None, 0.0


def _save_cache(version: str, fetched_at: float):
    try:
        with open(_cache_file(), "w", encoding="utf-8") as f:
            json.dump({"version": version, "fetched_at": fetched_at,
                       "source": SOURCE_ID}, f)
    except OSError:
        pass


def _fetch():
    try:
        res = requests.get(LOOKUP_URL, timeout=8,
                           headers={"Accept-Language": "ja"})
        if res.status_code != 200:
            return None
        m = _PAGE_VERSION_RE.search(res.text)
    except Exception:
        return None
    return m.group(1) if m else None


def get_app_version() -> str:
    """名乗るバージョンを返す。PayPay() を作るたびに呼ばれるので必ず即返す。"""
    env = (os.environ.get("PAYPAY_APP_VERSION") or "").strip()
    if env:
        return env

    now = time.time()
    with _lock:
        if _state["version"] and now < _state["next_check"]:
            return _state["version"]

        if _state["version"] is None:
            cached, fetched_at = _load_cache()
            if cached:
                _state["version"] = cached
                _state["next_check"] = fetched_at + CACHE_TTL
                _state["source"] = "cache"
                if now < _state["next_check"]:
                    return cached

        if _state["version"]:
            # 古くなっただけなら今の値ですぐ返し、取り直しは裏で1本だけ走らせる。
            # ここで取りに行くと、その間は支払い(受け取り)がストアの応答待ちで止まる
            # (取れないときは毎回タイムアウトまで待たされる)。
            if not _state.get("refreshing"):
                _state["refreshing"] = True
                threading.Thread(target=_refresh, daemon=True,
                                 name="app-version-refresh").start()
            return _state["version"]

        # 一度も値が無い(初めての起動でキャッシュも無い)ときだけ、その場で取りに行く
        _apply(_fetch(), now)
        return _state["version"]


def _apply(fetched, now: float):
    """取り直した結果を反映する(_lock を持った状態で呼ぶ)。"""
    if fetched:
        _state.update(version=fetched, next_check=now + CACHE_TTL, source=SOURCE_ID)
        _save_cache(fetched, now)
    else:
        # 取得できなくても止まらないように、古い値かフォールバックで続行する
        if not _state["version"]:
            _state["version"] = FALLBACK_VERSION
            _state["source"] = "fallback"
        _state["next_check"] = now + RETRY_AFTER


def _refresh():
    """裏での取り直し。ストアへの問い合わせ中は _lock を持たない(その間も PayPay() を作れる)。"""
    try:
        fetched = _fetch()
        with _lock:
            _apply(fetched, time.time())
    finally:
        _state["refreshing"] = False


def version_source() -> str:
    """今のバージョンをどこから得たか(play / cache / fallback / env)。

    play 以外が続くときはストアを見に行けていない。名乗る版が実際の配信版から
    離れるほど送金系が S9999 で落ちやすくなるので、/paypay_status で見える。
    """
    if (os.environ.get("PAYPAY_APP_VERSION") or "").strip():
        return "env"
    return _state["source"]
