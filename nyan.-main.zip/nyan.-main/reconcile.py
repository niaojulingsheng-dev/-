"""入金履歴とこちらの注文記録を突き合わせる(PayPay / Kyash)。

受け取りは通ったのにお渡しまで進まなかった注文は、こちらの記録に何も残らない。
残高が増えていても、それが渡せた分なのか渡せていない分なのか分からず、
お客さんが必ず問い合わせてくるとも限らない。

そこで決済側の履歴を正として、1件ずつ対応する記録を探す。
見つからない入金 = お金は入ったのにどの注文にも紐づいていない = 要対応。

突き合わせ先:
  sales.json / shop_sales.json … お渡しまで済んだ分
  link_orders.json             … まだ渡していない分
  payment_attempts             … 注文にすらならなかった分

確実に結ぶIDは取れないので、金額と時刻の近さで結ぶ。同額が並んだときに
1件の記録へ二重に紐づかないよう、使った記録は消し込む。件数は正確に出るが、
どの注文かの特定はあくまで目安。
"""
import os
import time
from datetime import datetime, timedelta, timezone
from typing import NamedTuple

import kyash_async
import link_orders
import payment_attempts
import payments
import paypay_async
from datapath import data_path, read_json, write_json

STATE_FILE = data_path("reconcile_state.json")

# 履歴を何件ぶん見に行くか。PayPayは新しい順に返す。
DEFAULT_SIZE = int(os.environ.get("RECONCILE_HISTORY_SIZE", "50"))
# 入金と注文を同じものとみなす時刻のずれ。保留が解けてから入るので広めに取る。
MATCH_WINDOW_SECONDS = int(os.environ.get("RECONCILE_WINDOW_SECONDS", str(6 * 3600)))
# これより古い入金は見ない。運用開始前の履歴まで拾って騒がないため。
MAX_AGE_SECONDS = int(os.environ.get("RECONCILE_MAX_AGE_SECONDS", str(7 * 86400)))

# 入金とみなす取引種別。種別は増えるので「RECEIVE を含む」で広く拾い、
# 判別できないものは黙って捨てずに別枠で報告する。
_INCOMING_HINT = "RECEIVE"
# 自分でチャージした分など、お客さんの支払いではない入り。
_SELF_TYPES = ("TOPUP", "CASHBACK", "AUTO_CHARGE")
# 送金の履歴。PayPayは送る側にも受け取る側にも同じ種別(P2PSEND)を付けるので、
# この種別に当たったら名前で向きを決めてはいけない。
_P2P_HINT = "P2P"

# 取引の向きは金額に付いた符号にしか出ない。amountPrefix は "+"/"-"、
# totalAmountLabel は "+400円" の形で返る。
_MINUS_HINTS = ("MINUS", "-", "−", "ー", "▲", "△")
_PLUS_HINTS = ("PLUS", "+", "＋")

# 残高が動かずに終わった取引。受け取りに失敗した送金がまさにこれで、
# 入金として突き合わせると、払われていないお金でお渡しまで走ってしまう。
# 状態は日本語のラベル(statusLabelString)でもコードでも返るので両方見る。
_DEAD_STATUS_HINTS = ("FAIL", "CANCEL", "REJECT", "DECLIN", "EXPIR", "RETURN",
                      "REVERS",
                      "失敗", "キャンセル", "取消", "取り消", "差し戻", "辞退",
                      "期限切れ")


class ReconcileError(Exception):
    """突合そのものができなかった(履歴が取れない等)。"""


# ---- PayPayの履歴 ----

# PayPayには Asia/Tokyo で問い合わせているので、タイムゾーンの付いていない
# 時刻は日本時間として読む。UTCとして読むと9時間ずれて時間窓から全部外れる。
_JST = timezone(timedelta(hours=9))


def _to_epoch(value) -> float:
    """日時をUNIX秒にする。読めなければ 0。

    PayPayはミリ秒の数値で返すことも、ISO8601や "YYYY/MM/DD HH:MM:SS" の
    文字列で返すこともある。どれも読めるようにしておく。
    """
    if not value or isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        # 13桁ならミリ秒
        return float(value) / 1000.0 if float(value) > 1e11 else float(value)

    text = str(value).strip()
    if not text:
        return 0.0
    if text.isdigit():
        return _to_epoch(int(text))

    normalized = text.replace("Z", "+00:00").replace("/", "-")
    if " " in normalized and "T" not in normalized:
        normalized = normalized.replace(" ", "T", 1)
    # 末尾に余計なものが付いていても、日付+時刻まで読めれば拾う
    for candidate in (normalized, normalized[:19], normalized[:16], normalized[:10]):
        try:
            parsed = datetime.fromisoformat(candidate)
        except ValueError:
            continue
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=_JST)
        return parsed.timestamp()
    return 0.0


# PayPayの履歴は階層もキー名もよく変わる。決め打ちすると名前が変わった瞬間に
# 「全部0円・時刻不明」になり、何も分かっていないのに警報だけが鳴る。
# 候補を並べて、上の階層から順に使える値を探す。
# 先頭は実物(bff/v3/getPaymentHistory)で確認済みのキー。
_AMOUNT_KEYS = ("totalAmount", "amount", "displayAmount", "orderAmount",
                "transactionAmount", "requestedAmount", "paidAmount")
_DATE_KEYS = ("dateTime", "orderDate", "transactionAt", "orderCreatedAt",
              "createdAt", "completedAt", "acceptedAt", "requestedAt",
              "updatedAt", "date")
_NAME_KEYS = ("displayName", "counterPartyDisplayName", "counterPartyName",
              "senderName", "nickName", "name")
_TYPE_KEYS = ("orderType", "displayTransactionType", "transactionType", "type")
# 表示専用。PayPay側の文言をそのまま見せたほうが分かりやすい。
_DESC_KEYS = ("description", "displayDescription", "summary")
_STATUS_KEYS = ("statusLabelString", "orderStatus", "status")
_LABEL_KEYS = ("totalAmountLabel", "amountLabel")
_PREFIX_KEYS = ("amountPrefix",)
_ID_KEYS = ("historyId", "orderId", "subOrderId", "transactionId", "paymentId", "id")

# 既定(PayPay)の候補キー。読み方——上から順に試し、駄目なら入れ子も見て、
# それでも読めなければ shape を出す——はサービス共通なので、
# normalize_entry には候補キーだけ差し替えて渡す。
PAYPAY_KEYS = {
    "date": _DATE_KEYS, "amount": _AMOUNT_KEYS, "type": _TYPE_KEYS,
    "name": _NAME_KEYS, "desc": _DESC_KEYS, "status": _STATUS_KEYS,
    "label": _LABEL_KEYS, "prefix": _PREFIX_KEYS, "id": _ID_KEYS,
}

# Kyashの候補キー。実物で確認できたものを含めつつ、名前が変わっても拾えるよう
# 広めに並べる。読めなかった行は伏せずに実際のキー名を出す。
KYASH_KEYS = {
    "date": ("createdAt", "created_at", "timestamp", "occurredAt", "date",
             "datetime", "dateTime", "updatedAt"),
    "amount": ("amount", "totalAmount", "price", "value", "displayAmount"),
    "type": ("type", "timelineType", "transactionType", "category", "kind",
             "resultType", "action"),
    "name": ("displayName", "userName", "username", "targetName", "originName",
             "counterpartyName", "title", "name"),
    "desc": ("message", "description", "subTitle", "subtitle", "memo", "text",
             "summary"),
    "status": ("status", "state", "resultStatus"),
    "label": ("amountLabel", "displayAmountLabel"),
    "prefix": ("amountPrefix", "sign"),
    # IDは入れ子の中にある(txUUIDAPI 等)。_entry_key が入れ子も探す。
    "id": ("uuid", "id", "transactionUuid", "timelineUuid",
           "txUUIDAPI", "txgUUIDAPI"),
}

# Kyashは金額に符号が付く(出ていく分がマイナス)ので、入り・出は符号で決める。
# 種別名は今後も増えるため、名前で見るのは「お客さんの支払いではない動き」を
# 除ける分だけにする。
#   (種別に含まれる語, 見出し, 突合での扱い / None なら符号で判断)
KYASH_KIND_RULES = (
    ("EXPIRY", "有効期限切れ", "self"),      # 期間限定バリューの失効
    ("CANCEL", "取り消し", "self"),          # 自分の送金が戻ってきた分
    ("REFUND", "返金", "self"),
    ("CHARGE", "チャージ", "self"),
    ("TOPUP", "チャージ", "self"),
    ("DEPOSIT", "入金", "self"),
    ("BANK", "銀行から", "self"),
    ("ATM", "ATMから", "self"),
    ("POINT", "ポイント", "self"),
    ("CASHBACK", "還元", "self"),
    ("BONUS", "還元", "self"),
    ("REQUEST", "請求", "self"),             # 請求を出しただけ。お金は動かない
    ("TRANSFER", "送金", None),              # 送金リンク。向きは符号で決まる
    ("RECEIVE", "受け取り", None),
    ("PAYMENT", "支払い", None),
    ("PURCHASE", "支払い", None),
    ("WITHDRAW", "出金", None),
    ("SEND", "送金", None),
)


def kyash_kind_rule(entry: dict):
    """(見出し, 突合での扱い) を返す。知らない種別なら None。

    扱いが None のときは呼び出し側が金額の符号で決める。
    """
    kind = (entry.get("type") or "").upper()
    for key, label, bucket in KYASH_KIND_RULES:
        if key in kind:
            return label, bucket
    return None

# 突合の解釈が変わったら上げる。読み方が違ったころの「通知済み」を引きずって、
# 直した後の入金まで握りつぶさないための世代番号。
PARSER_VERSION = "v2"

# 入れ子をどこまで潜って値を探すか。
_MAX_DEPTH = 3


def _walk(node, depth: int):
    """(キー, 値) を浅い階層から順に返す。"""
    if depth < 0 or not isinstance(node, dict):
        return
    for key, value in node.items():
        yield key, value
    for value in node.values():
        if isinstance(value, dict):
            yield from _walk(value, depth - 1)


def _as_amount(value):
    """金額として使える値なら int にする。{"amount": 1000, ...} の形も見る。"""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return int(value)
    if isinstance(value, str):
        # 符号は落とさない。捨てるとKyashの出金が入金に化ける。
        text = value.strip().replace(",", "").replace("+", "")
        sign = -1 if text.startswith("-") else 1
        text = text.lstrip("-")
        return sign * int(text) if text.isdigit() else None
    if isinstance(value, dict):
        for key in ("amount", "value", "total"):
            got = _as_amount(value.get(key))
            if got is not None:
                return got
    return None


def _pick(entry: dict, keys, convert):
    """候補のキー名を順に試す。まず一番上の階層、次に入れ子を見る。"""
    for key in keys:
        got = convert(entry.get(key))
        if got not in (None, "", 0):
            return got
    for key, value in _walk(entry, _MAX_DEPTH):
        if key in keys:
            got = convert(value)
            if got not in (None, "", 0):
                return got
    return None


def _as_text(value):
    return value.strip() if isinstance(value, str) and value.strip() else None


def entry_shape(entry: dict) -> str:
    """読めなかったときに、実際どんなキーが来ているかを見るための一覧。"""
    parts = []
    for key, value in (entry or {}).items():
        if isinstance(value, dict):
            parts.append(f"{key}{{{','.join(list(value)[:6])}}}")
        elif isinstance(value, list):
            parts.append(f"{key}[]")
        else:
            parts.append(key)
    return ", ".join(parts)


def _entry_key(entry: dict, normalized: dict, id_keys, source: str) -> str:
    """同じ入金を二度通知しないための鍵。サービス側のIDが取れればそれを使う。"""
    # PayPayの鍵は従来の文字列のまま。変えると「通知済み」の記録が読めなくなり、
    # 処理済みの入金でもう一度警報が鳴る。
    tag = "" if source in ("pp", payments.PAYPAY) else f"{source}:"
    for field in id_keys:
        value = entry.get(field)
        if isinstance(value, (str, int)) and str(value).strip():
            return f"{PARSER_VERSION}:{tag}{field}:{value}"
    # Kyashのように、IDが入れ子の中にしか無い形もある。時刻と金額だけの鍵は
    # 同額・同時刻で衝突する。
    for field, value in _walk(entry, _MAX_DEPTH):
        if field in id_keys and isinstance(value, (str, int)) and str(value).strip():
            return f"{PARSER_VERSION}:{tag}{field}:{value}"
    return (f"{PARSER_VERSION}:{tag}ts:{int(normalized['ts'])}"
            f":{normalized['amount'] if normalized['amount'] is not None else '?'}")


def _wrapper_type(entry: dict):
    """外側のキー名が種別を表している形に対応する。

    Kyashは {"transfer": {...}} のように種別がキー名で来る。type という項目は
    無いので、候補キーをいくら並べても「種別: 不明」のままになる。
    """
    if not isinstance(entry, dict) or len(entry) != 1:
        return None
    key = next(iter(entry))
    return key if isinstance(entry[key], (dict, list)) else None


def normalize_entry(entry: dict, keys: dict = None, source: str = "pp") -> dict:
    """履歴1件を、突合で使う形にそろえる。

    amount=None は「金額を読み取れなかった」の意味。突合できないので、
    紐づかない入金ではなく「読めていない」として別に扱う。

    keys に PAYPAY_KEYS と同じ形の辞書を渡すと候補キーを差し替えられる。
    source は鍵の頭に付ける印で、サービス間でIDが衝突しないようにする。
    """
    keys = keys or PAYPAY_KEYS
    normalized = {
        "ts": _pick(entry, keys["date"], _to_epoch) or 0.0,
        "amount": _pick(entry, keys["amount"], _as_amount),
        "type": (_pick(entry, keys["type"], _as_text)
                 or _wrapper_type(entry) or "").upper(),
        "name": _pick(entry, keys["name"], _as_text) or "",
        # ここから下は表示専用。突合の判定には使わない。
        "desc": _pick(entry, keys["desc"], _as_text) or "",
        "status": _pick(entry, keys["status"], _as_text) or "",
        "label": _pick(entry, keys["label"], _as_text) or "",
        "prefix": _pick(entry, keys["prefix"], _as_text) or "",
        "shape": entry_shape(entry),
    }
    normalized["key"] = _entry_key(entry, normalized, keys["id"], source)
    return normalized


def sign_direction(entry: dict):
    """金額に付いた符号から取引の向きを読む(PayPay)。読めなければ None。

    PayPayは送金の履歴を、送る側にも受け取る側にも同じ orderType(P2PSEND)で
    出す。向きが出るのは amountPrefix("+"/"-") と totalAmountLabel("+400円")
    だけで、種別名には出ない。
    """
    for text in (str(entry.get("prefix") or ""), str(entry.get("label") or "")):
        text = text.strip().upper()
        if not text:
            continue
        if text.startswith(_MINUS_HINTS) or "MINUS" in text:
            return "outgoing"
        if text.startswith(_PLUS_HINTS) or "PLUS" in text:
            return "incoming"
    amount = entry.get("amount")
    if isinstance(amount, int) and amount < 0:
        return "outgoing"
    return None


def looks_dead(entry: dict) -> bool:
    """失敗・取り消しで終わった取引か(残高は動いていない)。"""
    status = str(entry.get("status") or "").upper()
    return bool(status) and any(hint.upper() in status for hint in _DEAD_STATUS_HINTS)


def classify(entry: dict) -> str:
    """入金 / 自分の入り / 対象外 / 失敗 / 不明 に振り分ける(PayPay)。

    向きは符号を正とする。種別名では決められない。受け取りの履歴も
    orderType="P2PSEND" で返るので、種別で見るとお客さんからの入金が丸ごと
    「送金＝対象外」に落ち、取りこぼしを拾う最後の網が素通りになる。
    """
    order_type = entry["type"]
    if not order_type:
        return "unknown"
    if looks_dead(entry):
        # 入金として結ぶと、払われていないお金でお渡しまで走る
        return "dead"
    if any(t in order_type for t in _SELF_TYPES):
        return "self"
    direction = sign_direction(entry)
    if direction:
        return direction
    if _INCOMING_HINT in order_type:
        return "incoming"
    if _P2P_HINT in order_type:
        # 送金の履歴は送る側と受け取る側で同じ種別になる。符号が読めない以上
        # 向きは決められないので、「送金だから対象外」と落とさず報告へ回す。
        return "unknown"
    if "SEND" in order_type or "PAYMENT" in order_type or "MERCHANT" in order_type:
        return "outgoing"
    return "unknown"


def classify_kyash(entry: dict) -> str:
    """Kyashの取引を振り分ける。

    符号があるので入り・出はそれで決まる。名前を見るのはチャージ・失効・還元
    など「お客さんの支払いではない動き」を除ける分だけ。

    符号も種別も読めないものだけ unknown にする。「入金」に寄せると実在しない
    取りこぼしを騒ぎ、「対象外」に寄せると本物を見落とすため。
    """
    rule = kyash_kind_rule(entry)
    if rule and rule[1]:
        return rule[1]
    amount = entry.get("amount")
    if amount is None or amount == 0:
        return "unknown"
    return "incoming" if amount > 0 else "outgoing"


# ---- 突合の対象(サービスごとの違いはここにだけ持つ) ----

class Source(NamedTuple):
    """1つの決済サービスを突き合わせるのに要るもの一式。"""
    method: str          # payments.PAYPAY など。こちらの記録を絞るのに使う
    label: str           # 表示名
    keys: dict           # 履歴の候補キー
    classify: callable   # 正規化済みの1件を incoming/outgoing/self/unknown へ
    fetch: callable      # async (size) -> 生の履歴リスト
    registered: callable # そのアカウントが登録済みか
    interval: int        # 自動突合の最短間隔(秒)


async def _fetch_paypay_raw(size: int) -> list:
    try:
        raw = await paypay_async.run_owner_op(lambda pp: pp.get_history(size=size))
    except paypay_async.NotRegisteredError:
        raise ReconcileError("PayPayアカウントが登録されていません。")
    except Exception as e:
        raise ReconcileError(f"取引履歴を取得できませんでした: {str(e)[:200]}")
    return ((raw or {}).get("payload") or {}).get("paymentInfoList") or []


async def _fetch_kyash_raw(size: int) -> list:
    try:
        return await kyash_async.run_owner_op(lambda ky: ky.get_history(limit=size))
    except kyash_async.NotRegisteredError:
        raise ReconcileError("Kyashアカウントが登録されていません。")
    except Exception as e:
        raise ReconcileError(f"取引履歴を取得できませんでした: {str(e)[:200]}")


# PayPayは保留があり、履歴が「受け取れたか」の最終的な答えになる。お客さんの
# 待ち時間に直結するので短く回す。Kyashは受け取りがその場で確定するので、
# 履歴は取りこぼしを拾う保険でしかない。間隔を広げて足跡を減らす。
PAYPAY_SOURCE = Source(
    method=payments.PAYPAY, label="PayPay", keys=PAYPAY_KEYS,
    classify=classify, fetch=_fetch_paypay_raw,
    registered=lambda: bool(paypay_async.token_status().get("registered")),
    interval=0)

KYASH_SOURCE = Source(
    method=payments.KYASH, label="Kyash", keys=KYASH_KEYS,
    classify=classify_kyash, fetch=_fetch_kyash_raw,
    registered=kyash_async.is_registered,
    interval=int(os.environ.get("KYASH_RECONCILE_INTERVAL_SECONDS", str(30 * 60))))

SOURCES = (PAYPAY_SOURCE, KYASH_SOURCE)


def active_sources() -> list:
    """アカウントが登録されているサービスだけを返す。

    未登録のものまで叩くと「取得できませんでした」が定期的に鳴るだけになる。
    """
    available = []
    for source in SOURCES:
        try:
            if source.registered():
                available.append(source)
        except Exception:
            continue
    return available


async def fetch_history(size: int = DEFAULT_SIZE, source: Source = None) -> list:
    """取引履歴を取ってきて、突合で使う形のリストにして返す。"""
    source = source or PAYPAY_SOURCE
    entries = await source.fetch(size)
    return [normalize_entry(e, source.keys, source.method)
            for e in entries if isinstance(e, dict)]


# ---- こちらの記録 ----

def _order_ts(order: dict) -> float:
    """その注文のお金が動いたであろう時刻。"""
    return float(order.get("paid_at") or order.get("created_at") or 0)


def load_records(method: str = payments.PAYPAY) -> list:
    """突合先になるこちらの記録を、ひとつのリストにまとめる。

    delivered=True  お渡しまで終わっている(紐づけば何もしなくていい)
    delivered=False 入金はあるが、まだ渡していない

    支払い方法をまたいで混ぜないこと。同額の注文は日常的にあるので、混ざると
    本物の取りこぼしが「お渡し済み」に化けて消える。
    """
    records = []

    for sale in read_json(data_path("sales.json"), []):
        if str(sale.get("method") or "") != method:
            continue
        records.append({
            "ts": float(sale.get("ts") or 0),
            "amount": int(sale.get("amount") or 0),
            "label": "代行の売上",
            "detail": " / ".join(str(x) for x in (sale.get("items") or []))[:80],
            "user_id": sale.get("user_id"),
            "delivered": True,
            "source": "sale",
        })

    for sale in read_json(data_path("shop_sales.json"), []):
        if str(sale.get("method") or "") != method:
            continue
        records.append({
            "ts": float(sale.get("ts") or 0),
            "amount": int(sale.get("amount") or 0),
            "label": "自販機の売上",
            "detail": f"{sale.get('product_name') or ''} ×{sale.get('qty') or 1}"[:80],
            "user_id": sale.get("user_id"),
            "delivered": True,
            "source": "sale",
        })

    for order in link_orders.load_store()["orders"].values():
        status = order.get("status")
        if status in (link_orders.DONE,):
            # 完了した注文は上の売上記録で拾うので、ここでは飛ばす
            continue
        if str(order.get("method") or payments.PAYPAY) != method:
            continue
        # 受け取りを一度も投げていない(accepted=False)、またはリンクが差し戻された
        # (returned=キャンセル/期限切れ)注文は、このリンクからお金が入ることはない。
        # 突合の対象に残すと、別の人の同額入金がこの注文に当たって「渡し済み」に
        # 化けたり、お渡しまで走ったりする。入金が無い以上、突合からは外す。
        if order.get("returned") or not order.get("accepted"):
            continue
        records.append({
            "ts": _order_ts(order),
            "amount": int(order.get("paid_amount") or order.get("amount_jpy") or 0),
            "label": f"見張り中の注文（{status}）",
            "detail": f"`{order.get('id')}` {order.get('summary') or order.get('kind')}"[:80],
            "user_id": order.get("user_id"),
            "delivered": False,
            # 見張りがこれを見て、報告だけでなくお渡しまで進める
            "source": "order",
            "order_id": order.get("id"),
        })

    # 決着しなかった支払い試行。売上にも見張りにも載っていない入金の持ち主を
    # 突き止めるための層なので、必ず最後に足す。先に足すと、ちゃんと渡した
    # 売上よりこちらが先に紐づいてしまう。
    for attempt in payment_attempts.orphans(MAX_AGE_SECONDS):
        if str(attempt.get("method") or "") != method:
            continue
        records.append({
            "ts": float(attempt.get("ts") or 0),
            "amount": int(attempt.get("amount") or 0),
            "label": f"渡せていない注文（{attempt.get('kind')}）",
            "detail": f"`{attempt.get('id')}` {attempt.get('summary') or ''}"[:80],
            "user_id": attempt.get("user_id"),
            "delivered": False,
            "source": "attempt",
            "attempt_id": attempt.get("id"),
        })

    return records


# ---- 突合 ----

def match(entries: list, records: list, window: int = MATCH_WINDOW_SECONDS,
          classifier=None) -> dict:
    """入金1件ずつに、こちらの記録を割り当てる。

    matched     紐づいて、お渡しも済んでいる …… [(入金, 記録)]
    undelivered 紐づいたが、まだ渡していない
    unmatched   どの記録にも紐づかない = 残高だけ増えた分
    ignored     出金・自分のチャージ・失敗した取引など、突合の対象外
    unknown     種別を判別できなかった
    unreadable  金額を読み取れなかった = こちらの読み取りが壊れている
    undated     時刻を読み取れず、金額だけで突き合わせた分

    undated は突合の精度が落ちているという合図。時刻が読めないと古い記録と
    金額だけで結びつき、本物の取りこぼしが「お渡し済み」に化ける。
    黙って精度を落とさないよう件数を出す。
    """
    result = {"matched": [], "undelivered": [], "unmatched": [],
              "ignored": [], "unknown": [], "unreadable": [], "undated": []}
    remaining = list(records)
    now = time.time()
    classifier = classifier or classify

    for entry in sorted(entries, key=lambda e: e["ts"], reverse=True):
        if entry["amount"] is None or entry["amount"] == 0:
            # お金の問題ではなく、こちらが読めていないだけ。
            # 「紐づかない入金」に混ぜず、直すべき不具合として出す。
            result["unreadable"].append(entry)
            continue
        # 符号の有無はサービスによる。マイナスを読み取り失敗と決めつけず、
        # まず種別で振り分ける。
        kind = classifier(entry)
        if kind in ("outgoing", "self", "dead"):
            result["ignored"].append(entry)
            continue
        if kind == "unknown":
            result["unknown"].append(entry)
            continue
        if entry["amount"] < 0:
            # 入金なのにマイナス。辻褄が合わないので読み取りの不具合として出す
            result["unreadable"].append(entry)
            continue
        if entry["ts"] and now - entry["ts"] > MAX_AGE_SECONDS:
            result["ignored"].append(entry)
            continue
        if not entry["ts"]:
            # 時刻が読めないと下の突合が金額だけの一致になる。当たっている
            # 保証が無いので、精度が落ちていることを表に出す。
            result["undated"].append(entry)

        # 金額が同じで、いちばん時刻が近い記録に割り当てる。時刻が読めない
        # ときは金額だけで結ぶ。古い記録に当たることはあるが、警報を乱発する
        # よりはまし(件数は undated に出る)。
        best, best_gap = None, None
        for record in remaining:
            if record["amount"] != entry["amount"]:
                continue
            gap = abs(record["ts"] - entry["ts"]) if entry["ts"] and record["ts"] else window
            if gap > window:
                continue
            if best_gap is None or gap < best_gap:
                best, best_gap = record, gap

        if best is None:
            result["unmatched"].append(entry)
            continue
        remaining.remove(best)   # 同額が並んでも二重に紐づけない
        bucket = "matched" if best["delivered"] else "undelivered"
        result[bucket].append((entry, best))

    return result


async def run(size: int = DEFAULT_SIZE, window: int = MATCH_WINDOW_SECONDS,
              source: Source = None) -> dict:
    """履歴を取ってきて突合する。"""
    source = source or PAYPAY_SOURCE
    entries = await fetch_history(size, source)
    result = match(entries, load_records(source.method), window, source.classify)
    result["source"] = source
    return result


def understood(result: dict) -> bool:
    """その突合結果を「全部読めている」と言い切れるか。

    読めない行が残っているうちは「紐づかない入金 = 取りこぼし」と断定できない。
    今は未使用（見張り側は読めなかった件数をそのまま出している）。
    """
    return not result["unreadable"] and not result["unknown"] and not result["undated"]


# ---- 通知済みの記録(同じ入金で何度も騒がないため) ----

def _load_state() -> dict:
    state = read_json(STATE_FILE, None)
    if isinstance(state, dict):
        state.setdefault("reported", {})
        return state
    return {"reported": {}, "last_run": 0}


def mark_reported(entries: list):
    """通知済みとして記録する(古いものは落とす)。"""
    state = _load_state()
    now = time.time()
    for entry in entries:
        state["reported"][entry["key"]] = now
    limit = now - MAX_AGE_SECONDS * 2
    state["reported"] = {k: v for k, v in state["reported"].items() if v > limit}
    state["last_run"] = now
    write_json(STATE_FILE, state)


def unreported(entries: list) -> list:
    """まだ通知していない入金だけに絞る。"""
    reported = _load_state()["reported"]
    return [e for e in entries if e["key"] not in reported]


def last_run() -> float:
    return float(_load_state().get("last_run") or 0)
