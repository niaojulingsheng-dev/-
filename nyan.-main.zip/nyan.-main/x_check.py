"""X(旧Twitter)アカウントの凍結・年代のチェック。

在庫1行の先頭フィールド(id=ユーザー名)だけを使い、ログインせずにXの公開情報へ
問い合わせて「使える(生存) / 使えない(凍結・削除)」を判定する。パスワードは判定に
要らない(ログインするとXのbot対策=captcha等に当たりやすいので使わない)。

判定は guest token + UserByScreenName を使う。生存なら作成年(年代)も取れる。
X側が仕様を変えたら env(X_GQL_HOST / X_USER_QID)で差し替えられる。失敗は UNKNOWN に
して落とさず、理由をログに残す(ここもゲーム系と同じく、実運用のログを見て調整する)。
"""
import os
import re
import json
import random
import asyncio
import unicodedata
from collections import Counter

# 問い合わせ方法: Xの公開グラフAPI(ログイン不要のゲストトークン)。
# 旧 syndication(followbutton/info.json)は空の200を返すようになった(廃止)ので、
# ブラウザのログアウト時と同じ「guest token + UserByScreenName」で見分ける。
# いずれも X 側が変えたら env で差し替えられる。
GQL_HOST = os.getenv("X_GQL_HOST", "https://api.x.com")
GUEST_ACTIVATE = GQL_HOST + "/1.1/guest/activate.json"
# ログアウト時にブラウザが使う公開 Bearer(JSに埋まっている固定値)。
BEARER = os.getenv(
    "X_BEARER",
    "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs"
    "=1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA")
# UserByScreenName の queryId は数カ月ごとに変わる。既知の候補を順に試し、404でない
# (=そのパスが在る)ものを採用して以後使い回す。X_USER_QID で先頭に足せる(推奨)。
_DEFAULT_QIDS = [
    "G3KGOASz96M-Qu0nwmGXNg", "sLVLhk0bGj3MVFEKTdax1w", "xmU6X_CKVnQ5lSrCbAmJsg",
    "qW5u-DAuXpMEG0zA1F7UGQ", "hc-pka9A7gyS3xODIafnrQ", "7mjxD3-C6BxitPMVQ6w0-Q",
]
QID_CANDIDATES = [q for q in ([os.getenv("X_USER_QID")] + _DEFAULT_QIDS) if q]
# UserByScreenName に必須の features(足りないと400でキー名が返るので自己補完する)。
_BASE_FEATURES = {
    "hidden_profile_subscriptions_enabled": True,
    "rweb_tipjar_consumption_enabled": True,
    "responsive_web_graphql_exclude_directive_enabled": True,
    "verified_phone_label_enabled": False,
    "subscriptions_verification_info_is_identity_verified_enabled": True,
    "subscriptions_verification_info_verified_since_enabled": True,
    "highlights_tweets_tab_ui_enabled": True,
    "responsive_web_twitter_article_notes_tab_enabled": True,
    "subscriptions_feature_can_gift_premium": True,
    "creator_subscriptions_tweet_preview_api_enabled": True,
    "responsive_web_graphql_skip_user_profile_image_extensions_enabled": False,
    "responsive_web_graphql_timeline_navigation_enabled": True,
}
# 同時に走らせる件数。1件ずつ順番に待つと遅いので、この数だけ並行して問い合わせる。
# 多いほど速いが、データセンターIPから一気に叩くとレート制限/ブロック(=⚠️判定不可)が
# 増える。既定は控えめ。結果がきれいなら X_CHECK_CONCURRENCY で上げ、⚠️が増えたら下げる。
CHECK_CONCURRENCY = max(1, int(os.getenv("X_CHECK_CONCURRENCY", "5")))
# 1件ごとに入れる“ばらつき”の上限(秒)。並行でも足並みが揃って一斉に飛ばないよう、
# 0〜この値の範囲でランダムに待つ。連打対策。X_CHECK_DELAY で調整。
CHECK_DELAY = float(os.getenv("X_CHECK_DELAY", "0.8"))
# 1回のチェックで見る最大件数(暴走と Discord の応答期限切れを避ける枠)。
CHECK_MAX = int(os.getenv("X_CHECK_MAX", "500"))
# curl_cffi でなりすます本物ブラウザの指紋(ブロック回避)。
IMPERSONATE = os.getenv("X_IMPERSONATE", "chrome")
# 1件ごとの結果をログに出す(なぜ判定不可かの調査用)。
DEBUG = os.getenv("X_CHECK_DEBUG", "1") not in ("0", "", "false")

# 判定の種類。
ACTIVE = "active"          # 生きている(公開/非公開どちらも)
FROZEN = "frozen"          # 凍結・削除・存在しない(=販売できない)
NO_USERNAME = "no_username"  # 先頭からユーザー名を取れない(メール等)
UNKNOWN = "unknown"        # X側に問い合わせできなかった(ブロック/通信エラー)

STATUS_LABEL = {ACTIVE: "生存", FROZEN: "凍結/削除(使用不可)",
                NO_USERNAME: "ユーザー名を取れません", UNKNOWN: "判定不可"}
STATUS_MARK = {ACTIVE: "🟢", FROZEN: "🧊", NO_USERNAME: "❓", UNKNOWN: "⚠️"}




def extract_username(record: str) -> str:
    """在庫1レコードのユーザー名(id)を取り出す。

    ふつうは先頭の値がユーザー名(仕入れは `id----password----…` や `user:pass:…`)。
    「ID: xxx」のような項目名つきの行や、Cookie が先に来る形も読めるよう、まず形式確認と
    同じ読み分け(label_fields)でユーザーIDを探す。先頭の @ は外す。Xのプロフィール
    URL(https://x.com/xxx)ならそこから取る。

    見つからなければ、先頭の区切りまでを見る。Xのユーザー名は英数と _ だけ(ハイフンは
    使えない)なので、ハイフン1つで区切られたファイルでも、先頭の英数_の並びを取れば
    ユーザー名になる。先頭がメールアドレスのときは、そのまま返して「ユーザー名を
    取れない」扱いにする。
    """
    for label, value in label_fields(record):
        if label == L_URL:
            m = re.match(r"https?://(?:www\.|mobile\.)?(?:x|twitter)\.com/(\w{1,15})/?$", value)
            if m and _usable_handle(m.group(1)):
                return m.group(1)
        if label == L_USER:
            handle = value.strip().lstrip("@")
            if _usable_handle(handle):
                return handle
            break
    line = next((ln for ln in (record or "").splitlines() if ln.strip()), "")
    line = line.strip().lstrip("@")
    if not line:
        return ""
    token = re.split(r"[:|\t,;\s]|-{2,}|[—–―]+", line, 1)[0].strip()
    if _usable_handle(token) or "@" in token:
        return token
    # 区切りがハイフン1つ等: 先頭の英数_の並びがユーザー名。
    m = re.match(r"[A-Za-z0-9_]+", token)
    return m.group(0) if m else token


def _usable_handle(s: str) -> bool:
    """Xのユーザー名として問い合わせられる形か(英数と _、1〜15文字)。"""
    return bool(re.fullmatch(r"[A-Za-z0-9_]{1,15}", s or ""))


# ---------- 形式確認(アカウント情報を項目ごとに分ける) ----------
#
# 仕入れ先ごとに並びも区切りも違う。実際に来ている形は例えば
#   user:pass:authtoken:2fa:email|mailpassword|refresh_token|client_id    (: と | が混ざる)
#   Username----Password----Email----mailpassword----Email token----Email ID----2FA----AUTH_TOKEN
# 1行を区切りで値に分け、値の中身(メール・40桁hex・GUID・Outlookのトークン 等)と
# 並び(先頭はユーザーID、2番目はパスワード、メールの次はメールパスワード)から項目名を
# 決める。「ID: xxx」のような項目名つきの行、Cookie(auth_token=…; ct0=… / JSON /
# Netscape形式)、1行に1項目ずつのものも読む。上の2行のような見出し(形式の説明)が
# 付いていれば、その並びに従う。

L_USER = "ユーザーID"
L_LOGIN_MAIL = "メールアドレス（ログインID）"
L_LOGIN_PHONE = "電話番号（ログインID）"
L_PASS = "パスワード"
L_MAIL = "メールアドレス"
L_MAIL_PASS = "メールパスワード"
L_SUB_MAIL = "予備メールアドレス"
L_SUB_MAIL_PASS = "予備メールのパスワード"
L_TOKEN = "auth_token"
L_CT0 = "ct0"
L_COOKIE = "Cookie"
L_2FA = "2段階認証キー"
L_BACKUP = "バックアップコード"
L_REFRESH = "メールのリフレッシュトークン"
L_CLIENT = "メールのクライアントID"
L_PHONE = "電話番号"
L_UID = "XのユーザーID（数字）"
L_DATE = "作成日"
L_YEAR = "作成年"
L_URL = "URL"
L_UA = "ユーザーエージェント"
L_IP = "IPアドレス"
L_TOKEN_UNKNOWN = "トークン（種類不明）"
_MAILS = (L_MAIL, L_LOGIN_MAIL, L_SUB_MAIL)

# 見出し・項目名に使われる語 → 項目名。語は _norm_name をかけた形(小文字・記号や
# 空白を除いたもの)で書く。英語・日本語・中国語(仕入れ先に多い)。
_NAME_GROUPS = (
    (L_USER, "id user username userid login loginid loginname account acc handle screenname "
             "name twitter twitterid xid ユーザーid ユーザー ユーザー名 ユーザーネーム ログインid "
             "ログイン アカウント アカウント名 账号 帐号 账户 用户名"),
    (L_PASS, "pass password pw pwd passwd パスワード パス 密码"),
    (L_MAIL, "email mail emailaddress mailaddress メール メールアドレス メアド 邮箱 邮件"),
    (L_MAIL_PASS, "emailpassword mailpassword emailpass mailpass emailpw mailpw emailpwd "
                  "mailpwd メールパスワード メールパス メアドパス 邮箱密码"),
    (L_SUB_MAIL, "recoveryemail recoverymail backupemail backupmail 予備メール 予備メールアドレス "
                 "辅助邮箱 备用邮箱"),
    (L_SUB_MAIL_PASS, "recoveryemailpassword recoverymailpassword recoverypassword "
                      "予備メールパスワード"),
    (L_PHONE, "phone phonenumber tel mobile 電話 電話番号 手机 手机号"),
    (L_2FA, "2fa 2fakey 2fasecret 2facode twofa totp otp mfa secret 2段階認証 二段階認証 "
            "2段階認証キー 二段階認証キー 二次验证 2fa密钥"),
    (L_BACKUP, "backupcode backupcodes backup recoverycode バックアップコード 备份码"),
    (L_TOKEN, "authtoken token auth xtoken twittertoken 認証トークン"),
    (L_CT0, "ct0 csrf csrftoken"),
    (L_COOKIE, "cookie cookies クッキー"),
    (L_REFRESH, "refreshtoken emailtoken mailtoken refresh oauth oauth2 oauthtoken "
                "メールトークン 邮箱令牌"),
    (L_CLIENT, "clientid emailid mailid client appid クライアントid"),
    (L_UID, "uid twid numericid restid"),
    (L_DATE, "created createdat creationdate date regdate registered registrationdate "
             "作成日 登録日 注册时间 注册日期"),
    (L_YEAR, "year 作成年 年代 年"),
    (L_IP, "ip ipaddress"),
    ("プロキシ", "proxy プロキシ 代理"),
    (L_UA, "useragent ua"),
    ("表示名", "displayname nickname 表示名 名前 昵称"),
    ("フォロワー数", "followers follower フォロワー フォロワー数 粉丝"),
    ("国", "country region geo 国 国家 地区"),
)
_FIELD_NAMES = {n: label for label, names in _NAME_GROUPS for n in names.split()}

_HEX40 = re.compile(r"^[0-9a-f]{40}$", re.I)       # auth_token
_HEXLONG = re.compile(r"^[0-9a-f]{100,}$", re.I)   # ct0(ログイン中のものは160桁)
_GUID = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I)
# メールの OAuth リフレッシュトークン。Outlook/Hotmail(M.C5xx_BAY.0.U.-… / M.R3_BAY.-…)、
# Google(1//…)、Microsoft の組織アカウント(0.A…)。
_REFRESH = re.compile(r"^(?:M\.[A-Z][A-Za-z0-9]*_[A-Za-z0-9]+\.\S{40,}|1//[\w-]{20,}"
                      r"|0\.A[\w.-]{100,})$")
_EMAIL = re.compile(r"^[^@\s:|,;<>()\[\]\\\"]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}$")
_BASE32 = re.compile(r"^[A-Z2-7]{16,64}=*$")                    # 2段階認証の秘密鍵
_BASE32_LOWER = re.compile(r"^[a-z2-7]{16,64}=*$")
_BASE32_GROUPED = re.compile(r"^[A-Za-z2-7]{4}(?: [A-Za-z2-7]{4}){3,15}$")   # ABCD EFGH …
_BACKUP = re.compile(r"^(?=.*[a-z])(?=.*\d)[a-z0-9]{12}$")      # Xのバックアップコード(12桁)
# 0 1 8 9 が混ざった(base32 ではない)大文字英数の16/32桁。2段階認証キーとして渡されることがある
_KEY_UPPER = re.compile(r"^(?=(?:[^A-Z]*[A-Z]){8})(?:[A-Z0-9]{16}|[A-Z0-9]{32})$")
_PHONE_PLUS = re.compile(r"^\+\d[\d ()-]{6,18}\d$")
_DATE = re.compile(r"^(?:\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|\d{1,2}[-/.]\d{1,2}[-/.]\d{4}"
                   r"|\d{4}年(?:\d{1,2}月(?:\d{1,2}日)?)?"
                   r"|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.? \d{4})$", re.I)
_IP = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")

_X_COOKIE_NAMES = ("auth_token", "ct0", "twid", "kdt", "att", "guest_id", "personalization_id")
_COOKIE_PAIRS = re.compile(r"^[\w.-]+=[^;]*(?:;\s*[\w.-]+=[^;]*)*;?$")
_KV = re.compile(r"^([^\s:：=|]{1,30}(?:[ \t][^\s:：=|]{1,30}){0,2})\s*([:：=])(\s*)(.+)$")
_DASH = re.compile(r"-{3,}|[—–―]+")     # ----(仕入れ先に多い)。値の中の - や -- では切らない
_MINOR = re.compile(r"[,;]|[:：](?!//)")   # 片の中の区切り(: , ;)。URL の :// では切らない
_JSON_START = re.compile(r"[\[{]\s*[{\"]")


def _norm_name(s: str) -> str:
    """項目名の語をそろえる(全角→半角・小文字・記号や空白を除く)。"""
    return re.sub(r"[\W_]+", "", unicodedata.normalize("NFKC", s or "").lower())


def _name_label(s: str):
    return _FIELD_NAMES.get(_norm_name(s))


def _cookie_label(name: str) -> str:
    n = (name or "").strip()
    return {"auth_token": L_TOKEN, "ct0": L_CT0, "twid": L_UID}.get(n.lower(), f"{L_COOKIE}（{n}）")


def _json_items(s: str):
    """JSON なら [(項目名, 値), …]。Cookie の書き出し([{name, value}, …])でも、1垢を
    {"username": …, "password": …} のように書いたものでもよい。JSON でなければ None。"""
    try:
        data = json.loads(s)
    except Exception:
        return None
    items = []
    for row in (data if isinstance(data, list) else [data]):
        if not isinstance(row, dict):
            continue
        if "name" in row and "value" in row:        # Cookie 1つ分
            items.append((_cookie_label(str(row["name"])), str(row["value"])))
            continue
        for k, val in row.items():
            if isinstance(val, (dict, list)):
                val = json.dumps(val, ensure_ascii=False)
            label = _name_label(k) or (_cookie_label(k) if k.lower() in _X_COOKIE_NAMES else k)
            items.append((label, str(val)))
    return items or None


def _cookie_items(s: str):
    """Cookie や JSON なら [(項目名, 値), …]。どちらでもなければ None。
    「auth_token=…; ct0=…」・JSON・Netscape形式(タブ区切り7列の1行)を読む。"""
    s = s.strip()
    if s[:1] in ("[", "{"):
        items = _json_items(s)
        if items is not None:
            return items
        # 途中で切れた JSON などは、まとめて Cookie として見せる
        return [(f"{L_COOKIE}（JSON）", s)] if re.search(r'"(?:name|value|domain)"', s) else None
    cols = s.split("\t")
    if len(cols) == 7 and re.search(r"(?:^|\.)(?:x|twitter)\.com$", cols[0].strip()):
        return [(_cookie_label(cols[5]), cols[6].strip())]
    if _COOKIE_PAIRS.match(s) and any(re.search(rf"(?:^|;)\s*{n}=", s, re.I)
                                      for n in _X_COOKIE_NAMES):
        return [(_cookie_label(k), v.strip()) for k, v in
                (p.split("=", 1) for p in s.split(";") if "=" in p)]
    return None


def _kv(s: str, loose: bool = False):
    """「ID: xxx」「パスワード：xxx」「auth_token=xxx」のように項目名が付いた値なら
    [(項目名, 値)]。知らない語のもの・値にまだ区切りが残るもの(user:pass:… の先頭が
    たまたま項目名に見えた等)は None。

    半角の : で空白も無い「user_name:pass」は、ユーザー名がたまたま項目名に見える
    データの行かもしれない。項目名つきとみなすのは = ・ ：・「: 」(空白つき)・複数語の
    項目名のとき、または1行に1項目ずつ書いた記録(loose)のときだけ。
    """
    m = _KV.match(s.strip())
    if not m:
        return None
    key, sep, gap, value = m.group(1), m.group(2), m.group(3), m.group(4).strip()
    label = _name_label(key)
    if not label or not value or re.search(r"\||-{3,}|[:：](?!//)", value):
        return None
    if sep == ":" and not gap and " " not in key and not loose:
        return None
    if label == L_COOKIE:
        return _cookie_items(value) or [(label, value)]
    return [(label, value)]


def _segments(line: str):
    """1行を区切りで分ける → (片のリスト, 片をさらに分ける区切り or None)。

    大きな区切り ----(3つ以上) > タブ > | で片に分ける。| の片と、大きな区切りの無い行は
    : , ; でさらに分ける。old垢は user,pass,authtoken,2fa,email|mailpassword|… のように
    | の前が , や : で区切られて混ざるため。---- とタブの行は、値に : , ; | -- があっても
    切らない。どれも無ければ -- 、最後は空白。
    """
    if _DASH.search(line):
        return _DASH.split(line), None
    if "\t" in line:
        return line.split("\t"), None
    if "|" in line:
        return line.split("|"), _MINOR
    if _MINOR.search(line):
        return [line], _MINOR
    if "--" in line:
        return re.split(r"-{2,}", line), None
    return line.split(), None


def _clean(v: str) -> str:
    return v.strip().strip("'\"").strip()


def _split_values(line: str) -> list:
    """1行を区切りだけで値に分ける(見出しの行を読むのに使う)。"""
    segs, sub = _segments(line)
    vals = [p for seg in segs for p in (sub.split(seg) if sub else [seg])]
    return [_clean(v) for v in vals if _clean(v)]


def _line_items(line: str, loose: bool = False) -> list:
    """1行を [(項目名 or None, 値), …] にする。None の値は、あとで中身と並びから決める。
    loose は複数行の記録の1行(「ID:xxx」のような項目名つきの行として読みやすくする)。"""
    line = line.strip()
    if not re.search(r"[^\W_]", line):
        return []                               # ------ や ==== だけの区切り線
    found = _cookie_items(line)
    if found is None:
        found = _kv(line, loose)
    if found is not None:
        return found
    tail = None
    m = _JSON_START.search(line)
    if m and m.start() > 0:                     # 行の途中から JSON(Cookie 等)。中の : , で切らない
        tail, line = line[m.start():], line[:m.start()]
    segs, sub = _segments(line)
    items = []
    for seg in segs:
        seg = _clean(seg)
        if not seg:
            continue
        found = _cookie_items(seg)
        if found is None:
            found = _kv(seg)
        if found is not None:
            items += found
        elif sub:
            for p in map(_clean, sub.split(seg)):
                if p:       # user:pass:auth_token=…; ct0=… のように : の先に Cookie が来ることもある
                    items += _cookie_items(p) or _kv(p) or [(None, p)]
        else:
            items.append((None, seg))
    if tail:
        items += _cookie_items(tail) or [(L_COOKIE, tail.strip())]
    return items


def _guess(v: str):
    """値の中身から (項目名, 確かさ) を推す。確かさは "A"=ほかの値と取り違えない形、
    "B"=ほぼ確か、"C"=形は合うがパスワード等でもあり得る。分からなければ (None, None)。"""
    s = v.strip()
    if re.match(r"https?://", s):
        return L_URL, "A"
    if s.startswith("Mozilla/"):
        return L_UA, "A"
    if _EMAIL.match(s):
        return L_MAIL, "A"
    if _HEX40.match(s):
        return L_TOKEN, "A"
    if _HEXLONG.match(s):
        return L_CT0, "A"
    if _GUID.match(s):
        return L_CLIENT, "A"
    if _REFRESH.match(s):
        return L_REFRESH, "A"
    if _BASE32.match(s) or (_BASE32_GROUPED.match(s) and re.search(r"[A-Z2-7]", s)):
        return L_2FA, "B"
    if _PHONE_PLUS.match(s):
        return L_PHONE, "B"
    if ((_BASE32_LOWER.match(s) and re.search(r"[2-7]", s)) or _BASE32_GROUPED.match(s)
            or _KEY_UPPER.match(s)):
        return L_2FA, "C"      # 小文字だけの4文字区切りは Gmail のアプリパスワードもこの形
    if _BACKUP.match(s):
        return L_BACKUP, "C"
    if _DATE.match(s):
        return L_DATE, "C"
    if _IP.match(s):
        return L_IP, "C"
    if s.isdigit():
        if len(s) == 4 and 2006 <= int(s) <= 2100:
            return L_YEAR, "C"
        if len(s) >= 16:
            return L_UID, "C"      # 2013年ごろ以降の垢の数字IDは18〜19桁
        if len(s) >= 10:
            return L_PHONE, "C"
        if len(s) >= 5:
            return L_UID, "C"      # 古い垢の数字IDは短い
    return None, None


def _classify(items: list) -> list:
    """項目名の無い値(None)に名前を付けて [(項目名, 値), …] にする。

    中身ではっきり分かるもの(メール・40桁hex・GUID 等)を優先し、次に並び(先頭は
    ユーザーID、2番目はパスワード、メールの次はメールパスワード)、それでも決まらない
    ものは前後の値から決める(リフレッシュトークンの次はクライアントID 等)。
    """
    out, seen, pos = [], set(), 0
    for label, v in items:
        prev = out[-1][0] if out else None
        if label is None:
            guess, sure = _guess(v)
            if pos == 0:
                label = (L_LOGIN_MAIL if guess == L_MAIL
                         else L_LOGIN_PHONE if guess == L_PHONE and sure == "B"
                         else guess if sure == "A" else L_USER)
            elif pos == 1 and sure != "A":
                label = L_PASS
            elif sure == "A":
                label = guess
            elif prev in (L_MAIL, L_SUB_MAIL) and sure != "B":
                label = L_MAIL_PASS if prev == L_MAIL else L_SUB_MAIL_PASS
            else:
                label = guess
            pos += 1
        elif label == L_PASS and prev in (L_MAIL, L_SUB_MAIL) and seen & {L_USER, L_PASS}:
            # 「ID / パスワード / メール / パスワード」の2つ目はメールのパスワード
            label = L_MAIL_PASS if prev == L_MAIL else L_SUB_MAIL_PASS
        if label == L_MAIL and L_MAIL in seen:
            label = L_SUB_MAIL                  # 2つ目のメールは予備
        seen.add(label)
        out.append([label, v])
    for i, row in enumerate(out):
        if row[0]:
            continue
        v = row[1]
        prev = out[i - 1][0] if i else None
        nxt = out[i + 1][0] if i + 1 < len(out) else None
        if prev == L_REFRESH:
            row[0] = L_CLIENT                   # リフレッシュトークンの次はクライアントID
        elif nxt == L_CLIENT or (prev in (L_MAIL, L_MAIL_PASS) and len(v) >= 30):
            row[0] = L_REFRESH
        elif L_LOGIN_MAIL in seen and L_MAIL_PASS not in seen and len(v) <= 64 and " " not in v:
            row[0] = L_MAIL_PASS                # メールでログインする垢の、メール側のパスワード
            seen.add(L_MAIL_PASS)
        elif len(v) >= 30 and " " not in v:
            row[0] = L_TOKEN_UNKNOWN
        else:
            row[0] = f"その他{i + 1}"
    return [tuple(r) for r in out]


def header_labels(record: str):
    """「Username----Password----Email----…」「user:pass:authtoken:2fa:email|…」のような
    見出し(形式の説明)の行なら、その並びの項目名のリスト。見出しでなければ None。

    値がすべて項目名として知っている語のときだけ見出しとみなす(実データの行を
    取り違えないように)。
    """
    lines = [ln for ln in (record or "").splitlines() if ln.strip()]
    if len(lines) != 1:
        return None
    labels = [_name_label(v) for v in _split_values(lines[0].strip())]
    if len(labels) < 2 or not all(labels):
        return None
    out = []
    for lab in labels:
        prev = out[-1] if out else None
        if lab == L_PASS and prev in (L_MAIL, L_SUB_MAIL) and len(out) > 1:
            lab = L_MAIL_PASS if prev == L_MAIL else L_SUB_MAIL_PASS
        elif lab == L_MAIL and L_MAIL in out:
            lab = L_SUB_MAIL
        out.append(lab)
    if out[0] == L_MAIL:
        out[0] = L_LOGIN_MAIL
    return out


def _header_fits(header: list, items: list) -> bool:
    """見出しの並びが値と合っているか(中身ではっきり分かる値が見出しと食い違わないか)。"""
    for label, (_, v) in zip(header, items):
        guess, sure = _guess(v)
        if sure == "A" and guess != label and not (guess in _MAILS and label in _MAILS):
            return False
    return True


def label_fields(record: str, header: list = None) -> list:
    """[(項目名, 値), …]。header(header_labels の結果)を渡すと、値の数と中身が合えば
    その並びに従う。合わなければ・無ければ、中身と並びから決める。"""
    lines = [ln for ln in (record or "").splitlines() if ln.strip()]
    items = [it for ln in lines for it in _line_items(ln, loose=len(lines) > 1)]
    if (header and len(items) == len(header) and all(lab is None for lab, _ in items)
            and _header_fits(header, items)):
        return [(label, v) for label, (_, v) in zip(header, items)]
    return _classify(items)


def extract_auth_token(record: str) -> str | None:
    """レコードから auth_token(40桁の16進)を取り出す。無ければ None。

    位置に頼らず、形式確認と同じ読み分けで auth_token の値を拾う(old垢の
    user:pass:authtoken:… も new垢の …----AUTH_TOKEN も、Cookie や JSON の中のものも)。
    """
    for label, value in label_fields(record):
        if label == L_TOKEN and _HEX40.match(value.strip()):
            return value.strip()
    m = re.search(r"auth_token.{1,24}?\b([0-9a-f]{40})\b", record or "", re.I | re.S)
    return m.group(1) if m else None


class _XClient:
    """ゲストトークンと queryId を覚えて、UserByScreenName で1件ずつ見分ける。"""

    def __init__(self, session):
        self.s = session
        self.gt = None                       # guest token
        self.qid = None                      # 採用した queryId
        self.features = dict(_BASE_FEATURES)  # 400で足りないと言われたら補完
        self._actlock = asyncio.Lock()       # guest取り直しを1本化(並行時の二重取得防止)

    def _headers(self) -> dict:
        h = {"Authorization": f"Bearer {BEARER}", "x-twitter-active-user": "yes",
             "Accept": "*/*", "Accept-Encoding": "gzip",
             "Content-Type": "application/json"}
        if self.gt:
            h["x-guest-token"] = self.gt
        return h

    async def activate_guest(self):
        r = await self.s.post(GUEST_ACTIVATE, headers=self._headers(), timeout=15)
        try:
            self.gt = (r.json() or {}).get("guest_token")
        except Exception:
            self.gt = None
        if DEBUG:
            print(f"[XCHECK] guest activate http{r.status_code} "
                  f"token={'ok' if self.gt else 'none'} body={(r.text or '')[:120]!r}",
                  flush=True)
        return self.gt

    async def _call(self, username: str):
        variables = {"screen_name": username, "withSafetyModeUserFields": True}
        params = {"variables": json.dumps(variables, separators=(",", ":")),
                  "features": json.dumps(self.features, separators=(",", ":")),
                  "fieldToggles": json.dumps({"withAuxiliaryUserLabels": False},
                                             separators=(",", ":"))}
        url = f"{GQL_HOST}/graphql/{self.qid}/UserByScreenName"
        return await self.s.get(url, params=params, headers=self._headers(), timeout=15)

    async def _pick_qid(self, username):
        """候補の queryId を順に試して、404でない(=パスが在る)ものを採用。"""
        for qid in QID_CANDIDATES:
            self.qid = qid
            r = await self._call(username)
            if DEBUG:
                print(f"[XCHECK] qid試行 {qid}: http{r.status_code} "
                      f"body={(r.text or '')[:100]!r}", flush=True)
            if r.status_code != 404:
                return r
        self.qid = None
        return None

    async def warmup(self, username: str):
        """本番の並行実行に入る前に、guest token・queryId・features を1件で確定させる。

        これをやっておくと、並行で走る各タスクは確定済みの gt/qid を使うだけになり、
        初期化が重ならない(queryId探しを全タスクが別々にやる、を防ぐ)。
        """
        if self.gt is None:
            await self.activate_guest()
        if self.qid is None and username:
            await self._pick_qid(username)

    async def _reactivate(self, old_gt: str):
        """ゲストトークンを取り直す。並行時に何本も同時に取り直さないようロックで1本化。
        既に別のタスクが取り直していたら(gtが変わっていたら)何もしない。"""
        async with self._actlock:
            if self.gt == old_gt:
                await self.activate_guest()

    async def check(self, username: str) -> tuple:
        """(status, 詳細, 作成年|None)。"""
        if self.gt is None and await self.activate_guest() is None:
            return UNKNOWN, "guest取得失敗", None
        if self.qid is None:
            r = await self._pick_qid(username)
            if r is None:
                return UNKNOWN, "queryId全滅(X_USER_QIDで指定を)", None
        else:
            r = await self._call(username)
        # ゲストトークン切れ等 → 1回だけ取り直して再試行(並行時は1本化)。
        if r.status_code in (401, 403, 429):
            await self._reactivate(self.gt)
            r = await self._call(username)
        return await self._interpret(r, username, heal=True)

    async def _interpret(self, r, username, heal: bool) -> tuple:
        """(status, 詳細, 作成年|None)。作成年は生存垢の created_at から。"""
        status = r.status_code
        text = r.text or ""
        if not text:
            try:
                text = (r.content or b"").decode("utf-8", "replace")
            except Exception:
                text = ""
        if DEBUG:
            print(f"[XCHECK] {username}: http{status} len={len(text)} "
                  f"body={text[:200]!r}", flush=True)
        try:
            data = json.loads(text) if text.strip() else {}
        except Exception:
            data = None
        if data is None:
            return UNKNOWN, f"非JSON(http{status} len{len(text)})", None
        errs = data.get("errors") if isinstance(data, dict) else None
        # features 不足の400 → キー名を拾って false で足し、1回だけやり直す。
        if status == 400 and errs and heal:
            msg = " ".join(str(e.get("message", "")) for e in errs)
            m = re.search(r"features cannot be null:\s*([A-Za-z0-9_,\s]+)", msg)
            added = []
            if m:
                for name in re.split(r"[,\s]+", m.group(1)):
                    name = name.strip()
                    if name and name not in self.features:
                        self.features[name] = False
                        added.append(name)
            if added:
                if DEBUG:
                    print(f"[XCHECK] features自己補完 +{added}", flush=True)
                return await self._interpret(await self._call(username), username, heal=False)
            return UNKNOWN, f"400:{msg[:80]}", None
        user = (((data or {}).get("data") or {}).get("user") or {}) if isinstance(data, dict) else {}
        result = user.get("result") or {}
        tn = result.get("__typename")
        if tn == "User":
            return ACTIVE, "", _year_of(result)
        if tn == "UserUnavailable":
            reason = str(result.get("reason") or "")
            return FROZEN, ("凍結" if "suspend" in reason.lower() else (reason or "利用不可")), None
        if isinstance(data, dict) and "data" in data and not user:
            return FROZEN, "存在しない", None
        if errs:
            em = " ".join(str(e.get("message", "")) for e in errs).lower()
            if "suspend" in em:
                return FROZEN, "凍結", None
            if "not found" in em or "could not" in em or "does not exist" in em:
                return FROZEN, "存在しない", None
            return UNKNOWN, f"errors:{em[:60]}", None
        return UNKNOWN, f"想定外(http{status}):{text[:60]}", None


async def _run_bounded(targets: list, worker, progress_cb, total: int) -> list:
    """targets を worker(index, item) で処理する。CHECK_CONCURRENCY 件まで同時に走らせ、
    結果は入力と同じ順のリストで返す。

    worker は1件を処理して結果タプルを返す async 関数。並行で足並みが揃わないよう、
    各タスクの最初に 0〜CHECK_DELAY 秒のばらつきを入れる。progress_cb(done, total,
    これまでの結果) は 10件ごと(と最後)に、終わった順の件数で呼ぶ。
    """
    results = [None] * total
    sem = asyncio.Semaphore(CHECK_CONCURRENCY)
    done = 0
    done_lock = asyncio.Lock()

    async def run(idx, item):
        nonlocal done
        async with sem:
            # 一斉スタートを避けるための軽いばらつき(枠を持ったまま少しだけ待つ)。
            await asyncio.sleep(random.uniform(0, CHECK_DELAY))
            res = await worker(idx, item)
        results[idx] = res
        async with done_lock:
            done += 1
            cur = done
        if progress_cb and (cur % 10 == 0 or cur == total):
            try:
                await progress_cb(cur, total, [r for r in results if r is not None])
            except Exception:
                pass

    await asyncio.gather(*(run(i, it) for i, it in enumerate(targets)))
    return results


async def check_records(records: list, progress_cb=None) -> list:
    """在庫レコードのリストをチェックする(CHECK_CONCURRENCY 件ずつ並行)。

    戻り値は [(record, username, status, detail, year), ...]。CHECK_MAX を超える分は
    見ない(truncated は呼び出し側が len で分かる)。progress_cb(done, total, results)
    があれば 10件ごと(と最後)に呼ぶ。
    """
    targets = records[:CHECK_MAX]
    total = len(targets)
    if not total:
        return []
    # curl_cffi はチェックを実行するときだけ要る。import をここに置いておくと、
    # 読み込むだけ(shop cog のロード)では curl_cffi に依存しない。
    from curl_cffi.requests import AsyncSession
    async with AsyncSession(impersonate=IMPERSONATE) as session:
        client = _XClient(session)
        # 並行に入る前に、使える最初のユーザー名で guest/qid/features を確定させる。
        first = next((u for u in (extract_username(r) for r in targets)
                      if _usable_handle(u)), None)
        await client.warmup(first)

        async def worker(idx, rec):
            username = ""
            try:
                username = extract_username(rec)
                year = None
                if not username:
                    status, detail = NO_USERNAME, "空"
                elif not _usable_handle(username):
                    status, detail = NO_USERNAME, f"handle不可:{username[:30]}"
                else:
                    try:
                        status, detail, year = await client.check(username)
                    except Exception as e:
                        status, detail = UNKNOWN, f"{type(e).__name__}:{str(e)[:50]}"
                if DEBUG:
                    print(f"[XCHECK] {idx + 1}/{total} @{username} -> {status} {detail}"
                          + (f" {year}年" if year else ""), flush=True)
                return (rec, username, status, detail, year)
            except Exception as e:
                # 想定外でも1件のために全体を止めない。
                return (rec, username, UNKNOWN, f"worker:{type(e).__name__}:{str(e)[:40]}", None)

        return await _run_bounded(targets, worker, progress_cb, total)


def parse_year(created_at) -> int | None:
    """Xの created_at("Wed Mar 10 12:34:56 +0000 2021" / ISO)から作成年だけ取る。"""
    s = str(created_at or "").strip()
    m = re.search(r"(\d{4})\s*$", s) or re.match(r"(\d{4})-\d{2}-\d{2}", s)
    return int(m.group(1)) if m else None


def _year_of(result: dict) -> int | None:
    """UserByScreenName の result から作成年。legacy と(新しい形の)core の両方を見る。"""
    for sect in ("legacy", "core"):
        created = ((result or {}).get(sect) or {}).get("created_at")
        if created:
            return parse_year(created)
    return None


def summarize(results: list) -> dict:
    """結果の内訳。"""
    c = Counter(st for _, _, st, _, _ in results)
    return {"active": c.get(ACTIVE, 0), "frozen": c.get(FROZEN, 0),
            "no_username": c.get(NO_USERNAME, 0), "unknown": c.get(UNKNOWN, 0),
            "total": len(results)}


def age_line(results: list, total_records: int = None) -> str:
    """年代(作成年)の内訳を年だけで。凍結や判定不可は年代モードでは出さない。"""
    s = summarize(results)
    years = Counter(y for _, _, st, _, y in results if st == ACTIVE and y)
    parts = [f"{y}年 {n}件" for y, n in sorted(years.items())]
    line = "年代の内訳: " + (" / ".join(parts) if parts else "（年代を取れたアカウントなし）")
    line += f"\n合計 {s['total']}件"
    if total_records is not None and total_records > s["total"]:
        line += (f"\n※ 1回で見られるのは{CHECK_MAX}件まで。残り{total_records - s['total']}件は"
                 "もう一度実行してください（`X_CHECK_MAX` で増やせます）。")
    return line


def summary_line(results: list, total_records: int = None) -> str:
    """内訳を1〜2行で。total_records を渡すと CHECK_MAX で切った分も伝える。"""
    s = summarize(results)
    line = (f"合計 {s['total']}件 ／ 🟢生存 {s['active']} ／ 🧊凍結・削除 {s['frozen']}"
            f" ／ ❓名前取れず {s['no_username']} ／ ⚠️判定不可 {s['unknown']}")
    if total_records is not None and total_records > s['total']:
        line += (f"\n※ 1回で見られるのは{CHECK_MAX}件まで。残り{total_records - s['total']}件は"
                 "もう一度実行してください（`X_CHECK_MAX` で増やせます）。")
    return line


def removable_records(results: list) -> list:
    """チェック結果から、取り除く(使えない)レコードだけを返す。

    凍結・削除(存在しない)は使えないので取り除く。生存・判定不可・ユーザー名を取れない
    ものは「確実に使えない」と言えないので残す(誤って捨てない)。check_records の
    5つ組 (rec, username, status, detail, year) を受け取る。
    """
    return [r[0] for r in results if len(r) > 2 and r[2] == FROZEN]


def newer_records(results: list, max_year: int = None) -> list:
    """チェック結果から、max_year より後に作られた(生きている)垢のレコードを返す。

    「2007〜2018年」のように年代で売る商品に、それより新しい垢が混ざっていたら
    取り除くのに使う。作成年を取れたものだけが対象。判定不可・作成年不明のものは
    年代が分からないので残す(誤って捨てない)。max_year が無ければ空。
    """
    if not max_year:
        return []
    return [r[0] for r in results
            if len(r) > 4 and r[2] == ACTIVE and r[4] and r[4] > max_year]
