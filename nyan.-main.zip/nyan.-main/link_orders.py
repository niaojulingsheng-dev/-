"""すぐに受け取れなかった送金リンク(PayPay)を後追いで見張って、必ず受け取って渡す。

受け取りのリクエストは一度で通るとは限らない。支払い画面はインタラクションが
生きている数分しか待てないので、そこで捨てると、後から通った分のお金だけが
こちらに入り、代行もお渡しも走らずログにも残らない。

そこで決着していないリンクをディスクに残し、受け取れ次第そのまま渡す。
見張りループ(Cogs/linkwatch.py)が定期的に poll_once() を呼び、受け取れた
注文を種類ごとのハンドラへ渡す。
"""
import asyncio
import os
import random
import re
import time
import uuid

import paypay_async
import payments
import support
from crosslock import LockTimeout, cross_process_lock
from datapath import data_path, read_json, write_json

ORDER_FILE = data_path("link_orders.json")
STORE_LOCK_FILE = data_path("link_orders.lock")
FILE_LOCK_TIMEOUT = 30

# どれだけ粘るか(分)。支払い画面での待ち時間(3分)を過ぎた注文を、
# ここまで見張り続ける。長すぎると「忘れた頃に引き落とされる」ことになるので、
# 気が変わってリンクをキャンセルする余地を残しつつ1時間を既定にする。
WATCH_MINUTES = int(os.environ.get("LINK_WATCH_MINUTES", "60"))
# ただし受け取りを投げた後は別。投げた時点でお金は動きうるし、投げ直して
# 通ることもある。ここで見張りをやめると「お金だけ入って何も来ない」が
# 再発するので、うんと長く粘る。
ACCEPTED_WATCH_HOURS = float(os.environ.get("LINK_WATCH_ACCEPTED_HOURS", "12"))
# 見張りの巡回間隔(秒)。承認から受け取りまでの待たせ時間になる。
POLL_INTERVAL_SECONDS = int(os.environ.get("LINK_WATCH_POLL_SECONDS", "20"))
# 1件ごとの確認間隔。承認は「支払い直後」に集中するので最初は細かく見て、
# 時間が経つにつれて間隔を空ける。同じリンクを何時間も等間隔で叩き続けると
# 機械的で目立つため、毎回ゆらぎも入れる。(経過秒, 次までの間隔秒)
CHECK_STEPS = ((300, 20), (900, 60), (3600, 180), (None, 600))
# ただし保留中の注文だけは間隔を空けない。保留は「お客さんのアプリに承認ボタンが
# 出ている」状態で、押されるのは何時間か後のこともある。古い注文だからと10分に
# 1回まで落とすと、押してから完了するまでの待ち時間がそのまま「承認したのに
# 来ない」になる。押された直後に拾えるところまでは詰める。
HELD_CHECK_SECONDS = 30
# 受け取りを投げ直す間隔(秒)。前から順に使い、尽きたら最後の値を使い続ける。
#
# 「承認されたら拾う」を、承認を読み取って作ることはできない。PayPayのリンクの
# 状態(orderStatus)は承認の前も後も PENDING のままで、承認だけを見分ける手段が
# 無いため。「短い間隔で投げ直して、通った回が承認後」という形にしかならず、
# 承認から完了までの待ち時間は投げ直しの間隔そのものになる。
#
# 一方で、投げるたびに送金者のアプリへ承認の催促が出る。立て続けに出すと
# どれを押せばいいのか分からなくなってキャンセルを選ばれる。
#
# 承認は案内を見た直後に集中するので、最初だけ詰めて、あとは間隔を空ける。
# 支払い画面が開いている間の投げ直し(45秒→90秒)と同じ考え方。
#
# 間隔を倍々(2分→4分→8分…)に伸ばすと催促は減るが、承認から完了までが最大
# 30分になり、そのあいだ画面には何も起きない。お客さんから見れば「承認したのに
# 通らない」なので、後半でも5分より空けない。
ACCEPT_RETRY_STEPS = (30, 45, 60, 90, 120, 300)
# 投げ直しの総数。見張りの時間いっぱい(既定60分)を、上の間隔で使い切る量。
MAX_ACCEPT_ATTEMPTS = 14
# 片付いた注文を残しておく日数(後から調べられるように少し置いておく)。
KEEP_DAYS = 14
# 支払い画面が受け取りに入っているリンクを、その画面に握らせておく時間(秒)。
# 画面は保留を3分待つので、それより長く持たせる。途中で落ちて札が残っても、
# ここを過ぎれば見張りが引き取れる。
HOLD_SECONDS = int(os.environ.get("LINK_HOLD_SECONDS", "600"))

WATCHING = "watching"
PAID = "paid"
DONE = "done"
FAILED = "failed"
EXPIRED = "expired"
CANCELED = "canceled"

# もう受け取れないと分かった注文につける理由(お客さんへの案内に使う)。
GONE_NOTE = "リンクが受け取れない状態になりました"
# PayPayが保留にしている(送金者の承認待ち)注文につける理由。
HELD_NOTE = "PayPayが保留にしています（お客さんの「承認する」待ち）"
# 支払い画面がその場で受け取ったので、見張りの出番が無くなった注文につける理由。
SCREEN_NOTE = "同じリンクを支払い画面が受け取ったため、こちらでのお渡しは行いません"


class LinkOrderError(Exception):
    """見張りの保存に失敗した。"""


class LinkBusy(Exception):
    """そのリンクは別の受け取りが握っている(二重お渡し防止)。

    入金1回に対してお渡しは1回だけ。同じリンクを支払い画面と見張り、あるいは
    支払い画面どうしが同時に受け取ると、ゲームの残高を2回動かしてしまう。

    メッセージはそのままお客さんに出せる文言にしてある。**絶対に「もう一度
    支払ってください」とは言わない**(お金は1回しか要らない)。
    order は握っている注文(あれば)。
    """

    def __init__(self, message: str, order: dict = None):
        super().__init__(message)
        self.order = order


class NeedsCustomerInput(Exception):
    """お客さんに入れ直してもらわないと先へ進めない。

    代表例は代行の引き継ぎコード。承認を待つ間にお客さんがゲームを起動すると
    そのコードは使えなくなり、何度やり直しても同じ結果にしかならない。
    見張りの再試行を止めて本人に新しいコードを頼む。

    prompt はお客さんへ出す説明。
    """

    def __init__(self, message: str, prompt: str = ""):
        super().__init__(message)
        self.prompt = prompt or str(message)


def watch_span_label(order: dict) -> str:
    """「あとどれくらい見張るか」の表示用文言(45分 / 約12時間)。"""
    remaining = float(order.get("expires_at") or 0) - time.time()
    if remaining < 60:
        return "まもなく終了"
    if remaining < 3600:
        return f"約{int(remaining // 60)}分"
    return f"約{int(remaining // 3600)}時間"


# 貼られた文章の中からリンクを拾うための形。お客さんはURLだけでなく、
# 「[PayPay] 受け取りリンクが届きました。…… https://pay.paypay.ne.jp/XXXX」の
# ように案内文ごと貼ってくる。文中から拾えないと、同じリンクなのに鍵が変わり、
# 二重の見張り・二重のお渡しを止められない(入金1回でコインを2回渡すことになる)。
# PayPay は pay.paypay.ne.jp/<コード> でホスト直後の段がコード。Kyash は
# kyash.me/payments/<コード> で、ホスト直後の段は全リンク共通の "payments"。以前は
# 両方とも「ホスト直後の段」を鍵にしていたため、Kyash は全リンクの鍵が "payments" に
# なり、1件お渡しが済むと別の Kyash リンクまで「このリンクは受け取り済みです」で弾いて
# いた(2回目以降払えない)。Kyash は最後の段をコードとして取る。
_LINK_IN_TEXT = re.compile(
    r"pay\.paypay\.ne\.jp/([0-9A-Za-z_-]+)"
    r"|kyash\.me/(?:[0-9A-Za-z_-]+/)*([0-9A-Za-z_-]+)",
    re.IGNORECASE)


def normalize_code(url: str) -> str:
    """同じリンクを二重に見張らないための鍵(末尾の受け取りコード)。

    URLそのままでも、案内文ごと貼られても、同じリンクなら同じ鍵になる。
    """
    text = (url or "").strip()
    found = _LINK_IN_TEXT.search(text)
    if found:
        return (found.group(1) or found.group(2)).lower()
    # URLとして読めない(コードだけ貼られた等)。空白で切って最後のかたまりを
    # 見る。文章の途中に混ざっていても、コードそのものは拾えるようにする。
    code = text.split()[-1] if text.split() else ""
    if "?" in code:
        code = code.split("?", 1)[0]
    code = code.rstrip("/")
    return code.rsplit("/", 1)[-1].lower()


# ---- 保存 ----

def _empty_store() -> dict:
    return {"orders": {}, "holds": {}}


def load_store() -> dict:
    data = read_json(ORDER_FILE, None)
    if isinstance(data, dict):
        data.setdefault("orders", {})
        data.setdefault("holds", {})
        return data
    return _empty_store()


def _save_store(store: dict):
    write_json(ORDER_FILE, store)


_store_lock = asyncio.Lock()


def _update_store_sync(mutate):
    try:
        with cross_process_lock(STORE_LOCK_FILE, FILE_LOCK_TIMEOUT):
            store = load_store()
            result = mutate(store)
            _save_store(store)
            return result
    except LockTimeout as e:
        raise LinkOrderError(str(e))


async def update_store(mutate):
    async with _store_lock:
        return await asyncio.to_thread(_update_store_sync, mutate)


def get_order(order_id: str) -> dict:
    return load_store()["orders"].get(order_id)


def list_orders(status: str = None) -> list:
    out = [o for o in load_store()["orders"].values()
           if status is None or o.get("status") == status]
    out.sort(key=lambda x: x.get("created_at", 0), reverse=True)
    return out


def watching_orders() -> list:
    return list_orders(WATCHING)


def _same_link(order: dict, code: str) -> bool:
    """その注文が同じリンクのものか。

    注文に残っている鍵と、リンクから引き直した鍵の両方で見る。鍵の作り方を
    直す前に保存された注文も、同じリンクなら同じものとして扱うため。
    """
    if not code:
        return False
    return (order.get("code") == code
            or normalize_code(order.get("link") or "") == code)


def find_live_order(url: str) -> dict:
    """同じリンクでまだ決着していない注文があれば返す(二重見張り・二重お渡し防止)。"""
    code = normalize_code(url)
    for o in load_store()["orders"].values():
        if _same_link(o, code) and o.get("status") in (WATCHING, PAID):
            return o
    return None


def find_any_order(url: str) -> dict:
    """そのリンクの注文を状態を問わず探す。

    決着済み(DONE)も含めて見るのが find_live_order との違い。入金だけを頼りに
    注文を作り直すときは、渡し終わった注文をもう一度作ってしまうと二重お渡しに
    なるので、こちらで確かめる。
    """
    code = normalize_code(url)
    for o in load_store()["orders"].values():
        if _same_link(o, code):
            return o
    return None


# ---- リンクの札(同じリンクを2か所で受け取らない) ----

def _prune_holds(store: dict, now: float):
    for code, hold in list(store.get("holds", {}).items()):
        if float(hold.get("expires_at") or 0) <= now:
            del store["holds"][code]


def _live_hold(holds: dict, code: str, now: float) -> dict:
    hold = holds.get((code or "").lower())
    return hold if hold and float(hold.get("expires_at") or 0) > now else None


def held_link(url: str) -> dict:
    """そのリンクを今どこかの支払い画面が握っていれば、その札を返す。"""
    return _live_hold(load_store().get("holds", {}), normalize_code(url), time.time())


def held_order(order: dict) -> dict:
    """その注文のリンクを支払い画面が握っていれば、その札を返す。

    注文に残っている鍵と、リンクから引き直した鍵の両方を見る。鍵の作り方を
    直した後も、古い注文が札をすり抜けないようにするため。
    """
    holds = load_store().get("holds", {})
    now = time.time()
    for code in (order.get("code"), normalize_code(order.get("link") or "")):
        hold = _live_hold(holds, code, now)
        if hold:
            return hold
    return None


def _busy_for_order(order: dict, user_id) -> str:
    """既にその注文が持っているリンクを、また貼られたときの文言。"""
    if str(order.get("user_id")) != str(user_id):
        # 他人の注文のリンク。注文番号は出さない(その人のものではない)。
        return ("このリンクは別のご注文で受付済みです。"
                "ご自身のお支払いリンクを貼り直してください。")
    if order.get("status") == PAID:
        return ("このお支払いは受け取り済みです。今こちらで処理しています。"
                "**もう一度支払わないでください。**\n"
                f"注文番号: `{order.get('id')}`")
    return ("このお支払いは受付済みです（承認をお待ちしています）。"
            "確認でき次第そのまま自動で進めて、DMでお知らせします。\n"
            "**もう一度支払う必要はありません。**\n"
            f"注文番号: `{order.get('id')}`")


async def hold_link(url: str, *, kind: str, user_id, seconds: int = None) -> str:
    """このリンクの受け取りを、今の支払い画面だけに握らせる。控え番号を返す。

    受け取りを投げる前に必ず通す。同じリンクを見張りが持っている・別の画面が
    受け取っている・もう受け取り済みなら LinkBusy を投げるので、呼び出し側は
    その文言をそのままお客さんへ出して引き下がる(お金は動かない)。

    これを通さないと、保留のまま見張りへ移した注文と、同じリンクを貼り直した
    支払い画面が別々にお渡しまで走り、入金1回でコインを2回渡すことになる。

    握った札は release_link() で必ず返すこと(呼び出し側の finally から)。
    """
    code = normalize_code(url)
    if not code:
        raise LinkBusy("リンクを読み取れませんでした。もう一度貼り直してください。")
    token = f"HL-{uuid.uuid4().hex[:8].upper()}"
    now = time.time()
    ttl = HOLD_SECONDS if seconds is None else seconds

    def mutate(store):
        _prune_holds(store, now)
        for order in store["orders"].values():
            if not _same_link(order, code):
                continue
            if order.get("status") in (WATCHING, PAID):
                raise LinkBusy(_busy_for_order(order, user_id), order)
            if order.get("status") == DONE:
                raise LinkBusy(
                    "このリンクは受け取り済みです。**もう一度支払わないでください。**\n"
                    "お届けできていないものがあれば、" + support.contact_line(), order)
        if code in store["holds"]:
            raise LinkBusy(
                "このお支払いは今こちらで処理しています。そのままお待ちください。\n"
                "**もう一度支払わないでください。**")
        store["holds"][code] = {"id": token, "code": code, "kind": kind,
                                "user_id": str(user_id), "created_at": now,
                                "expires_at": now + ttl}
        return token

    return await update_store(mutate)


async def release_link(token: str):
    """握った札を返す。見張りがそのリンクを引き取れるようにする。"""
    if not token:
        return

    def mutate(store):
        for code, hold in list(store.get("holds", {}).items()):
            if hold.get("id") == token:
                del store["holds"][code]
                return True
        return False

    try:
        return await update_store(mutate)
    except LinkOrderError:
        # 返せなくても期限で消える。ここで例外を上げると、お渡しが済んだ後の
        # 後始末だけで支払い処理を失敗扱いにしてしまう。
        return False


# 支払い画面で受け取った注文につけるメモ。お渡しの前後で言い分ける。
SCREEN_DONE_NOTE = "支払い画面でその場で受け取り、お渡しまで完了しました"
SCREEN_DELIVERING_NOTE = "支払い画面でその場で受け取りました。お渡し中です"


async def settle_on_screen(kind: str, user_id, url: str, *, paid: int,
                           method: str = payments.PAYPAY, summary: str = "",
                           guild_id=None, channel_id=None,
                           note: str = None, delivered: bool = True,
                           own_record: bool = False) -> dict:
    """支払い画面がその場で受け取ったリンクを、決着済みとして残す。

    リンクの受け取りは1回きり。そのお金でのお渡しはもう済んでいる(または
    いまから済ませる)ので、同じリンクを持っている注文をここで畳む。畳まないと、
    見張りが同じリンクを「受け取れた」と読んでもう一度お渡ししてしまう。
    打ち切った注文まで畳むのは、そちらが入金履歴との突合で拾い直されて動き出すため。

    そのリンクの注文がまだ無ければ、決着済みの注文として1件書く。あとから入金
    だけを頼りに注文を起こし直す道(突合)から、同じリンクをもう一度拾わせない。

    戻り値は {"record": このリンクを表す決着済みの注文, "closed": 畳んだ注文の一覧}。
    record の id が、その購入の注文番号になる(お客さんへの案内・販売ログ・
    売上の記録で同じ番号を使い、あとから1本で突き合わせられるようにする)。

    own_record=True なら、畳んだ注文を番号に使い回さず、この購入のための記録を
    必ず新しく書く。期限切れになった前の注文を同じリンクで買い直されたとき、
    その古い注文(別の商品・別の人のこともある)の番号をお客さんに渡さないため。

    delivered=False は「受け取ったがお渡しはこれから」。お渡しの前に書く側
    (自販機)はこれで書き、渡し終えたら mark_screen_delivery で立てる。
    渡す前に落ちた注文は delivered が立たないまま残るので、入金突合が
    「渡していない」と見分けて渡し直せる(DONE として書いてしまうと、受け取った
    お金だけが残って誰にも拾われない)。
    """
    code = normalize_code(url)
    if not code:
        return {"record": None, "closed": []}
    now = time.time()
    fresh_note = note or (SCREEN_DONE_NOTE if delivered else SCREEN_DELIVERING_NOTE)

    def mutate(store):
        closed = []
        record = None
        for order in store["orders"].values():
            if not _same_link(order, code):
                continue
            if record is None and not own_record:
                record = order
            if order.get("status") == DONE:
                continue
            order.update(status=DONE, accepted=True, note=SCREEN_NOTE,
                         paid_amount=int(paid or order.get("paid_amount") or 0),
                         paid_at=order.get("paid_at") or now, updated_at=now,
                         settled_by="screen")
            closed.append(order)
        if record is None:
            record_id = f"LP-{uuid.uuid4().hex[:8].upper()}"
            record = store["orders"][record_id] = {
                "id": record_id,
                "source": "link",
                "kind": kind,
                "method": method,
                "user_id": str(user_id),
                "guild_id": str(guild_id) if guild_id else None,
                "channel_id": str(channel_id) if channel_id else None,
                "link": url,
                "code": code,
                "amount_jpy": int(paid or 0),
                "paid_amount": int(paid or 0),
                "payload": {},
                "summary": summary,
                "status": DONE,
                "accepted": True,
                "created_at": now,
                "paid_at": now,
                "expires_at": now,
                "settled_by": "screen",
                "note": fresh_note,
            }
        record["delivered"] = bool(delivered)
        # 畳んだ注文は、このリンクについては record に席を譲る(渡したかどうかは
        # record の delivered で見る)。
        for order in closed:
            if order is not record:
                order["superseded_by"] = record["id"]
        return {"record": dict(record), "closed": [dict(o) for o in closed]}

    return await update_store(mutate)


async def mark_screen_delivery(order_id: str, delivered: bool, note: str = None,
                               **fields) -> dict:
    """支払い画面で受け取った注文の「渡したか」を書く。

    渡し終えたら delivered=True。在庫不足などで渡せなかったときは False のまま、
    理由をメモに残す(入金突合の見張りと、管理者の一覧の両方から分かるように)。
    fields は同じ書き込みで一緒に残す項目(渡した中身・記録が済んだかの印など)。
    """
    if not order_id:
        return None
    if note is None:
        note = SCREEN_DONE_NOTE if delivered else SCREEN_DELIVERING_NOTE
    return await mark_order(order_id, DONE, delivered=bool(delivered), note=note,
                            updated_at=time.time(), **fields)


def undelivered_screen_records(url: str) -> list:
    """支払い画面が受け取りはしたが、渡した印が無いまま残っている記録。"""
    code = normalize_code(url)
    if not code:
        return []
    return [dict(o) for o in load_store()["orders"].values()
            if _same_link(o, code) and o.get("status") == DONE
            and o.get("settled_by") == "screen" and o.get("delivered") is False
            and not o.get("superseded_by")]


def link_blocks_revival(url: str) -> bool:
    """そのリンクの注文を、入金だけを頼りに起こし直してはいけないか。

    見張り中・受け取り済みでお渡し待ち(WATCHING / PAID)の注文があれば、その
    注文が渡す。決着済み(DONE)の注文も、渡し終えていれば起こし直すと二重の
    お渡しになる。例外は、支払い画面が受け取りはしたものの渡す前に止まった
    記録(delivered が False のまま)。これだけは「お金は入ったのに何も渡って
    いない」ので、突合から渡し直してよい。
    畳まれた注文(superseded_by つき)は、そのリンクの判断を record に譲る。
    古い記録(delivered の無いもの)は、渡し終えたものとして扱う。
    """
    code = normalize_code(url)
    if not code:
        return True
    for order in load_store()["orders"].values():
        if not _same_link(order, code):
            continue
        status = order.get("status")
        if status in (WATCHING, PAID):
            return True
        if status != DONE:
            continue
        if order.get("superseded_by"):
            continue
        if order.get("delivered") is False and order.get("settled_by") == "screen":
            continue
        return True
    return False


async def record_screen_receipt(kind: str, user_id, url: str, *, paid: int,
                                method: str = payments.PAYPAY, summary: str = "",
                                guild_id=None, channel_id=None) -> list:
    """settle_on_screen の、畳んだ注文の一覧だけを返す形(代行の画面が使う)。"""
    result = await settle_on_screen(kind, user_id, url, paid=paid, method=method,
                                    summary=summary, guild_id=guild_id,
                                    channel_id=channel_id)
    return result["closed"]


def _accepted_deadline(order: dict) -> float:
    """受け取りを投げた注文の見張り期限。

    投げた後はお金が動きうるので、呼び出し側が指定した短い見張り時間
    (watch_minutes)よりも必ず長く粘る。ここを「指定があればそれに従う」に
    していたせいで、自販機の注文(120分指定)だけ承認待ちの延長が効かず、
    PayPayの保留が解けた頃には打ち切られていた(=入金だけ残る)。
    """
    created = float(order.get("created_at") or time.time())
    return max(float(order.get("expires_at") or 0),
               created + ACCEPTED_WATCH_HOURS * 3600)


async def create_order(kind: str, user_id, url: str, *, amount_jpy: int, payload: dict,
                       method: str = payments.PAYPAY, passcode: str = None,
                       accepted: bool = False, summary: str = "",
                       guild_id=None, channel_id=None, minutes: int = None) -> dict:
    """決着していないリンクを見張りに登録する。同じリンクの先客がいればそれを返す。"""
    now = time.time()
    order = {
        "id": f"LP-{uuid.uuid4().hex[:8].upper()}",
        "source": "link",
        "kind": kind,
        "method": method,
        "user_id": str(user_id),
        "guild_id": str(guild_id) if guild_id else None,
        "channel_id": str(channel_id) if channel_id else None,
        "link": url,
        "code": normalize_code(url),
        "passcode": passcode or None,
        "amount_jpy": int(amount_jpy),
        "paid_amount": 0,
        "payload": payload or {},
        "summary": summary,
        "status": WATCHING,
        "accepted": bool(accepted),
        "created_at": now,
        "expires_at": now + (minutes if minutes is not None else WATCH_MINUTES) * 60,
        "watch_minutes": minutes,
        "accept_attempts": 1 if accepted else 0,
        "last_accept_at": now if accepted else 0,
        "deliver_attempts": 0,
        "last_attempt_at": 0,
        "note": "",
    }
    if accepted:
        order["expires_at"] = _accepted_deadline(order)

    def mutate(store):
        for existing in store["orders"].values():
            if _same_link(existing, order["code"]) and existing.get("status") in (WATCHING, PAID):
                # 受け取りを投げた事実だけは強いほうに寄せる(取りこぼし防止)。
                # reused は呼び出し側への合図で、保存はしない(コピーに付ける)。
                if order["accepted"] and not existing.get("accepted"):
                    existing["accepted"] = True
                    existing["accept_attempts"] = int(existing.get("accept_attempts") or 0) + 1
                    existing["last_accept_at"] = now
                    existing["expires_at"] = _accepted_deadline(existing)
                return dict(existing, reused=True)
        store["orders"][order["id"]] = order
        return dict(order)

    return await update_store(mutate)


async def create_settled_order(kind: str, user_id, url: str, *, paid: int, payload: dict,
                               method: str = payments.PAYPAY, passcode: str = None,
                               summary: str = "", guild_id=None, channel_id=None,
                               note: str = "", status: str = None) -> dict:
    """支払い画面でその場で受け取った注文を、受け取り済みの注文として台帳に書く。

    既定(status=PAID)は「その場でお渡しを始められなかった注文を見張りに預ける」用で、
    見張りの巡回が次からお渡しを再試行する。status=DONE を渡すと「画面でその場で
    流している注文の記録」になる(走り出した印つきで残しておけば、途中で落ちたときに
    起動時の点検が拾える)。

    受け取りは済んでいるので WATCHING は経ない(経ると、見張りが同じリンクをもう一度
    受け取ろうとする)。同じリンクの決着済みの記録(record_screen_receipt が書いたもの)は
    そのまま残す(入金履歴との突合から同じリンクを拾い直させない役目があるため)。
    """
    now = time.time()
    order = {
        "id": f"LP-{uuid.uuid4().hex[:8].upper()}",
        "source": "link",
        "kind": kind,
        "method": method,
        "user_id": str(user_id),
        "guild_id": str(guild_id) if guild_id else None,
        "channel_id": str(channel_id) if channel_id else None,
        "link": url,
        "code": normalize_code(url),
        "passcode": passcode or None,
        "amount_jpy": int(paid or 0),
        "paid_amount": int(paid or 0),
        "payload": payload or {},
        "summary": summary,
        "status": status or PAID,
        "accepted": True,
        "created_at": now,
        "paid_at": now,
        "expires_at": now,
        "settled_by": "screen",
        "accept_attempts": 1,
        "last_accept_at": now,
        "deliver_attempts": 0,
        "last_attempt_at": 0,
        "note": str(note or "")[:300],
    }

    def mutate(store):
        store["orders"][order["id"]] = order
        return dict(order)

    return await update_store(mutate)


async def mark_order(order_id: str, status: str, **fields) -> dict:
    def mutate(store):
        order = store["orders"].get(order_id)
        if not order:
            return None
        order["status"] = status
        order.update(fields)
        return order

    return await update_store(mutate)


async def settle_from_history(order_id: str, paid: int, history_key: str) -> dict:
    """入金履歴で受け取りが確認できた注文を決着させる。決着したら注文を返す。

    受け取り済みのリンクは問い合わせ自体が失敗することがあり、リンクの状態
    からは「まだ保留」と見分けが付かない。放っておくと、入金済みの注文が
    watching のまま期限切れになる。

    入ったかどうかの最終的な答えは入金履歴にあるので、リンクが読めないときは
    そちらを正とする。決着済みの注文には触らない。同じ入金で2件を決着させない
    よう、使った履歴の番号を注文に残す。
    """
    def mutate(store):
        order = store["orders"].get(order_id)
        if not order or order.get("status") not in (WATCHING, EXPIRED):
            return None
        if order.get("returned"):
            # リンクが差し戻されている(キャンセル/期限切れで送り主に戻った)。
            # この注文に入るお金は無いので、同額というだけの入金で決着させない。
            # ここを通すと、払っていない人に別の人の入金で商品が渡る。
            return None
        if not order.get("accepted"):
            # 受け取りを一度も投げていない = このリンクからお金は入らない。
            # 同額の入金はこの注文のものではないので決着させない。
            return None
        for other in store["orders"].values():
            if other.get("history_key") == history_key and other.get("id") != order_id:
                return None      # その入金は別の注文で使い済み
        order.update(status=PAID, accepted=True, paid_amount=int(paid),
                     paid_at=time.time(), history_key=history_key,
                     note="入金履歴で受け取りを確認しました")
        return order

    return await update_store(mutate)


async def deposit_belongs_to_order(order: dict) -> bool:
    """入金履歴の1件でこの注文を決着させてよいか、リンクの今の状態で確かめる。

    入金履歴は「同額」というだけで、この注文のものとは限らない。商品が同じ値段
    で何件も並ぶので、別の人の入金がこの注文に当たってしまう。リンクの状態を
    その場で読み直して、本当にこの注文にお金が入っているときだけ True を返す。

      RECEIVED      … こちらが受け取れている。この注文のお金。 → True
      ERROR/UNSURE  … リンクが読めない(受け取り済みのリンクはこう見えやすい)。
                      受け取りを投げた注文に限り、入金履歴を最後の拠り所にする。
      GONE          … 差し戻し(キャンセル/期限切れ)。お金は入っていない。 → False
      PENDING       … まだ未承認。お金はまだ入っていない。 → False
      TAKEN         … こちらが投げていないのに受領済み。別口なので触らない。 → False

    受け取りは投げない(accept=False)。状態を読むだけ。
    """
    link = order.get("link") or ""
    if not link:
        return False
    out = await paypay_async.collect_link(
        link, passcode=order.get("passcode"),
        min_amount=int(order.get("amount_jpy") or 0),
        accepted_before=bool(order.get("accepted")), accept=False)
    if out.state == paypay_async.RECEIVED:
        return True
    if out.state in (paypay_async.ERROR, paypay_async.UNSURE):
        return bool(order.get("accepted"))
    return False


async def cancel_superseded(user_id, kind: str, amount: int, keep_id: str = None) -> list:
    """買い直しで置き去りになった見張りを畳む。畳んだ注文を返す。

    支払いに一度失敗した人が、そのまま同じ内容で買い直すことがある。すると
    前回の注文が見張りに残り、渡し終わっているのに「保留中」に並び続ける。

    畳むのは**受け取りを一度も投げていない**注文だけ。投げた注文は、あとから
    承認されて入金する可能性があるので絶対に手を離さない(離すと、お金だけ
    入って誰にも紐づかない状態が生まれる)。
    """
    def mutate(store):
        closed = []
        for oid, order in store["orders"].items():
            if oid == keep_id or order.get("status") != WATCHING:
                continue
            if order.get("accepted"):
                continue            # 受け取り送信済み = まだ入金しうる
            if str(order.get("user_id")) != str(user_id):
                continue
            if order.get("kind") != kind or int(order.get("amount_jpy") or 0) != int(amount):
                continue
            order["status"] = CANCELED
            order["note"] = "同じ内容で買い直されたため見張りを終了しました"
            order["superseded"] = True   # 買い直しで畳んだ印(在庫は戻すがログは出さない)
            order["updated_at"] = time.time()
            closed.append(order)
        return closed

    return await update_store(mutate)


async def purge_old(days: int = KEEP_DAYS) -> int:
    limit = time.time() - days * 86400

    def mutate(store):
        _prune_holds(store, time.time())
        gone = [oid for oid, o in store["orders"].items()
                if o.get("status") in (DONE, EXPIRED, CANCELED, FAILED)
                and float(o.get("created_at", 0)) < limit]
        for oid in gone:
            del store["orders"][oid]
        return len(gone)

    return await update_store(mutate)


# ---- 見張り ----

def _may_accept(order: dict, now: float) -> bool:
    """この回に受け取りを投げてよいか(投げない回は状態を見るだけ)。

    毎回投げると送金者への承認の催促が乱発されるので、間隔を倍々に空けていく。
    それでも投げ続けるのは、承認された後にもう一度投げないと受け取れない場合が
    あるため。上限まで来たら以降は状態の確認だけにする。

    ただし accept_now が立っているときは、間隔も上限も見ずに投げる。これは
    名指しで確認しに来たときだけ立つ印なので、
    間隔を待たせる理由がない。
    """
    if order.get("accept_now"):
        return True
    attempts = int(order.get("accept_attempts") or 0)
    if attempts == 0:
        return True
    if attempts >= MAX_ACCEPT_ATTEMPTS:
        return False
    wait = ACCEPT_RETRY_STEPS[min(attempts - 1, len(ACCEPT_RETRY_STEPS) - 1)]
    return now - float(order.get("last_accept_at") or 0) >= wait


async def request_recheck(order_id: str) -> dict:
    """その注文を、間隔を待たずに次の巡回で投げ直す。見張り中の注文だけ。

    管理者が名指しで確認しに来たときに使う。ふだんの投げ直しは催促を
    乱発しないよう間隔を空けているが、人が見に来ている場面で待たせる
    理由がない。

    決着済みの注文には何もしない(お渡し済みのものを蒸し返さない)。
    """
    def mutate(store):
        order = store["orders"].get(order_id)
        if not order or order.get("status") != WATCHING:
            return None
        order.update(next_check_at=0, accept_now=True, updated_at=time.time())
        return dict(order)

    return await update_store(mutate)


def _next_check(order: dict, now: float) -> float:
    """次にこの注文を確認する時刻。古い注文ほど間隔を空ける(ゆらぎ付き)。"""
    age = now - float(order.get("created_at") or now)
    interval = CHECK_STEPS[-1][1]
    for limit, seconds in CHECK_STEPS:
        if limit is None or age < limit:
            interval = seconds
            break
    return now + interval * random.uniform(0.85, 1.15)


_poll_lock = asyncio.Lock()


async def poll_once() -> dict:
    """見張り中の注文をひと通り確認する。

    戻り値 {"settled": [...], "expired": [...], "unsure": [...], "unreadable": [...]}
      settled … 受け取れた注文(呼び出し側でお渡しする)
      expired … 期限切れ・受け取れなくなった注文(後始末が要る)
      unsure  … 受け取りを投げたが結果が確認できない注文(手動確認が要る)
      unreadable … 受け取りは投げたのにリンクの状態が読めない注文。入金済みでも
                   同じ見え方になるので、入金履歴との突合を急がせる合図に使う
    """
    async with _poll_lock:
        return await _poll_once()


async def _poll_once() -> dict:
    result = {"settled": [], "expired": [], "unsure": [], "unreadable": []}
    orders = watching_orders()
    if not orders:
        return result

    now = time.time()
    orders.sort(key=lambda x: x.get("created_at", 0))
    for order in orders:
        if now < float(order.get("next_check_at") or 0):
            continue
        if held_order(order):
            # そのリンクは支払い画面が受け取っている最中。横から投げると、
            # 同じ入金で2回お渡しすることになる。札が返るまで手を出さない。
            continue
        order = await mark_order(order["id"], WATCHING,
                                 next_check_at=_next_check(order, now)) or order

        if order.get("method") != payments.PAYPAY:
            # 保留になるのは今のところPayPayだけ。他は見張っても意味がない。
            expired = await mark_order(order["id"], EXPIRED, note="対応していない支払い方法です")
            result["expired"].append(expired or order)
            continue

        out = await paypay_async.collect_link(
            order.get("link") or "", passcode=order.get("passcode"),
            min_amount=int(order.get("amount_jpy") or 0),
            accepted_before=bool(order.get("accepted")),
            accept=_may_accept(order, now),
        )

        # 何を措いても先に「受け取りを投げた」事実を残す。以降の分岐がこれを
        # 見て、打ち切るときに管理者へ知らせるかどうかを決める。
        fields = {}
        if out.attempted:
            fields["accept_attempts"] = int(order.get("accept_attempts") or 0) + 1
            fields["last_accept_at"] = now
            # 「承認しました」の印は1回投げたら下ろす。残すと、押した1回が
            # 以降ずっと間隔なしの投げ直しに化けて催促を乱発する。
            fields["accept_now"] = False
        if out.accepted:
            # 投げた後はお金が動きうる。承認は数十分〜数時間後のこともあるので、
            # 短い見張り期限のまま切らないように必ず延ばす。
            fields["accepted"] = True
            fields["expires_at"] = _accepted_deadline(dict(order, **fields))
        if fields:
            order = await mark_order(order["id"], WATCHING, **fields) or order

        if out.state == paypay_async.RECEIVED:
            paid = int(out.amount or order.get("amount_jpy") or 0)
            settled = await mark_order(order["id"], PAID, accepted=True, paid_amount=paid,
                                       paid_at=time.time(), note="")
            result["settled"].append(settled or order)
            continue

        if out.state == paypay_async.UNSURE:
            # 受け取りは投げた。入金の有無が読めないので見張りは続けつつ、
            # 一度だけ管理者に知らせる(放置すると誰にも気付かれない)。
            report = not order.get("unsure_reported")
            updated = await mark_order(order["id"], WATCHING, unsure_reported=True,
                                       note=out.detail or "")
            if report:
                result["unsure"].append(updated or order)
            continue

        if out.state == paypay_async.TAKEN:
            # 誰かが受け取った後だった。こちらの受け取りが記録される前に落ちた
            # 可能性もあるので、入金済み扱いで管理者に確認してもらう。
            taken = await mark_order(
                order["id"], EXPIRED, accepted=True,
                note=(out.detail or "受け取り済みのリンクでした")
                     + "（こちらで受け取っている可能性があります）")
            result["expired"].append(taken or order)
            continue

        if out.state == paypay_async.GONE:
            # returned なら、PayPayがリンクを閉じている = お金は送り主に戻った。
            # 受け取りを投げた後でも入金はしないので、後始末で「入金されている
            # 可能性があります」と言わないよう印を残す。
            gone = await mark_order(order["id"], EXPIRED, returned=bool(out.returned),
                                    note=out.detail or GONE_NOTE)
            result["expired"].append(gone or order)
            continue

        # held / pending / error … まだ決着していない。期限が来たら打ち切る。
        if out.state == paypay_async.HELD:
            # 保留にされた理由(PayPayが受け取りを弾いたときの文言)は、後から
            # 原因を追う唯一の手掛かりになる。決まり文句で塗り潰さない。
            note = f"{HELD_NOTE}: {out.detail}" if out.detail else HELD_NOTE
            # 承認ボタンが押された直後に拾えるよう、確認の間隔を詰め直す。
            # (すでにもっと近い時刻が入っているならそちらを残す)
            soon = now + HELD_CHECK_SECONDS
            order = await mark_order(
                order["id"], WATCHING, note=note,
                next_check_at=min(float(order.get("next_check_at") or 0) or soon,
                                  soon)) or order
        elif out.unreadable and order.get("accepted"):
            # 受け取りは投げてあるのにリンクが読めない。受け取り済みのリンクは
            # 問い合わせ自体が失敗することがあるので、入金済みでもこう見える。
            # リンクからは答えが出ないので、入金履歴との突合を急いでもらう。
            result["unreadable"].append(order)
        if now >= float(order.get("expires_at", 0)):
            # リンクがまだ開いたまま打ち切るのなら、そのお金は送り主のリンクの
            # 中にある。受け取りを投げた後でも、こちらには入っていないと言える。
            # ここを見分けないと「入金しているかもしれない」の一点張りになり、
            # 取り消せば戻るお金について二重払いの心配をさせることになる。
            open_link = out.state in (paypay_async.HELD, paypay_async.PENDING)
            expired = await mark_order(
                order["id"], EXPIRED, link_open=open_link,
                note=out.detail or "受け取れないまま期限が来ました")
            result["expired"].append(expired or order)

    return result


# ---- 受け取り後のお渡し ----

_handlers = {}
_expire_handlers = {}
_retry_views = {}


def register_handler(kind: str, handler, on_expire=None, retry_view=None):
    """受け取りが確認できた後に呼ばれる処理を登録する。

    handler(order) -> bool（True=お渡し完了）。False や例外は失敗扱いで、
    見張りループが数回まで再試行する。on_expire(order) は打ち切り時の後始末。

    retry_view(order_id) -> discord.ui.View は、お客さんに入れ直してもらう
    ときに出す画面。何を入れ直してもらうかは注文の種類で違う(にゃんこ代行は
    引き継ぎコード、ツムツムはLINEのログイン)ので、種類ごとに預かる。
    省略した種類は見張り側の既定(引き継ぎコード)になる。
    """
    _handlers[kind] = handler
    if on_expire is not None:
        _expire_handlers[kind] = on_expire
    if retry_view is not None:
        _retry_views[kind] = retry_view


def get_handler(kind: str):
    return _handlers.get(kind)


def get_expire_handler(kind: str):
    return _expire_handlers.get(kind)


def get_retry_view(kind: str):
    return _retry_views.get(kind)
