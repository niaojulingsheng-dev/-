"""Telegram の販売窓口。Discord と同じ在庫(vending_data.json)をそのまま売る。

方針(ユーザー確認済み):
  ・商品や在庫の管理は Discord 側の既存コマンドで行う。こちらは「お客さんの購入」と
    「お渡し」専用。Telegram に管理コマンドは置かない。
  ・在庫は Discord と共有(同じ vending_data.json・同じ在庫ファイル)。どちらで売れても
    同じ在庫から引く。
  ・支払い(PayPay / Kyash の送金リンク)、取り置き(保留)、入金突合は Discord と
    まったく同じ共通処理(payments / link_orders / reconcile)を使う。なので #436/#437 の
    支払い安全対策もそのまま効く。
  ・Discord で在庫を足すと、Telegram に出している商品なら、この Bot の利用者全員へ
    お知らせする(Discord の `/tg restock_notify` でオン/オフ)。

起動:
  環境変数 TELEGRAM_BOT_TOKEN に BotFather のトークンを入れる。未設定なら起動しない
  (Discord だけ動く)。main.py の setup_hook から start(bot) を呼ぶ。

実装は Telegram Bot API を素の HTTP(ロングポーリング)で叩く。PayPay / Kyash / ゲームAPI
と同じく、ライブラリは足さない(requests を to_thread で回す)。
"""
import asyncio
import hashlib
import io
import json
import logging
import os
import re
import secrets
import time

import requests
from requests.adapters import HTTPAdapter

import link_orders
import payment_attempts
import payments
from datapath import data_path, read_json, write_json
from Cogs import shop

log = logging.getLogger(__name__)

TOKEN = (os.getenv("TELEGRAM_BOT_TOKEN") or os.getenv("TELEGRAM_TOKEN") or "").strip()
API_BASE = "https://api.telegram.org/bot{token}/{method}"
FILE_BASE = "https://api.telegram.org/file/bot{token}/{path}"
# ロングポーリング1回の待ち時間(秒)。Telegram 側の timeout。HTTP の読み取り待ちは
# これより長くする(途中で切ると毎回タイムアウト扱いになる)。
POLL_TIMEOUT = int(os.getenv("TELEGRAM_POLL_TIMEOUT", "30"))
# Telegram の本文上限は 4096 文字。これを超えそうな在庫は .txt で送る。
TG_TEXT_LIMIT = 3500
# この kind で注文・支払い試行・見張りを記録する(Discord の "shop" と分ける。
# 分けないと、保留から遅れて届いた入金のお渡しが Discord 側へ飛んでしまう)。
KIND = "tgshop"

# お渡しに使う Telegram API と Discord bot(管理者通知・販売ログ用)。start() で入れる。
_api = None
_bot = None
# callback_data 用の短いトークン -> (machine_id, product_id)。カタログを描くたびに作る。
# 再起動で消えても、トークンは機械的に作る(md5)ので、押されたときに作り直せる。
_catalog_index = {}
# chat_id -> 選択中の商品 {"mid","pid","name","qty","msg"}。個数・リンク待ち。
# msg は個数入力の画面に書き換えたパネルのメッセージID(戻る・買い終わりで一覧に戻す)。
_selecting = {}
# 出したパネルを覚えておき、在庫などが変わったら編集して最新にする(リアルタイム更新)。
# {str(chat_id): message_id} … チャットごとに最新の1枚。再起動後も続くよう保存する。
_panels = {}
# 直近に描いた内容の指紋。変わったときだけ編集する(無駄な編集とレート制限を避ける)。
_last_sig = None
# パネルを編集し直す間隔(秒)。Discord側の購入・在庫追加もこの周期で反映される。
REFRESH_SECONDS = max(5, int(os.getenv("TELEGRAM_REFRESH_SECONDS", "12")))


# ====================== 純粋なヘルパー(通信なし・テストしやすい) ======================

def configured() -> bool:
    return bool(TOKEN)


def _token_for(mid: str, pid: str) -> str:
    """商品を指す短いトークン(callback_data は 64 バイトまで)。"""
    return hashlib.md5(f"{mid}\x00{pid}".encode("utf-8")).hexdigest()[:12]


def stock_count(product: dict) -> int | None:
    """在庫数。無限在庫は None(=∞)。"""
    if product.get("infinite"):
        return None
    try:
        return len(shop.read_stock_records(product.get("stock_file")))
    except Exception:
        return 0


def shown_stock(product: dict) -> int | None:
    """お客さんに見せる在庫数(手元の在庫＋保留で取り置き中の分)。無限在庫は None(=∞)。

    取り置き・戻しで数が動いて見えないように、Discord の表示と同じ数を出す
    (shop.shown_stock)。買える個数の上限(_qty_cap)は手元の在庫のまま。"""
    if product.get("infinite"):
        return None
    try:
        return shop.shown_stock(product)
    except Exception:
        return stock_count(product)


def _sold_out_text(product: dict) -> str:
    """買える在庫が無いときの文。取り置き中の分があるなら、入荷待ちではなくそう言う。"""
    held = shop.reserved_count(product)
    if held:
        return (f"「{product.get('name')}」は現在、在庫 {held}個すべてが別のお客様の支払い確認中です。"
                "少し時間をおいてお試しください。")
    return f"「{product.get('name')}」は現在入荷待ちです。"


def _price(product: dict) -> int:
    try:
        return int(product.get("price") or 0)
    except (TypeError, ValueError):
        return 0


def build_catalog(vending: dict) -> list:
    """[(token, machine, product, 在庫数|None)] を、Telegramで売る商品だけ返す。

    Telegram に並べるのは product["telegram"] が真の商品だけ(Discord 側の
    `/tg products` で選ぶ)。在庫は Discord と共有だが、どれを Telegram に出すかは
    ここで絞る。0円商品は送金リンクで買えないので出さない。
    """
    out = []
    for mid, machine in (vending or {}).items():
        if not isinstance(machine, dict):
            continue
        for product in machine.get("products", []):
            if not isinstance(product, dict) or not product.get("product_id"):
                continue
            if not product.get("telegram"):
                continue
            if _price(product) <= 0:
                continue
            token = _token_for(mid, product["product_id"])
            _catalog_index[token] = (mid, product["product_id"])
            out.append((token, machine, product, shown_stock(product)))
    return out


def resolve_token(token: str):
    """トークンから (machine_id, machine, product) を引く。未知なら今の在庫から作り直す。"""
    hit = _catalog_index.get(token)
    vending = shop.load_vending()
    if not hit:
        build_catalog(vending)          # 作り直してから引き直す(再起動後など)
        hit = _catalog_index.get(token)
    if not hit:
        return None, None, None
    mid, pid = hit
    machine = vending.get(mid) or {}
    product = shop._find_product(machine, pid)
    return mid, machine, product


def _avail_label(product: dict, count) -> str:
    if product.get("infinite"):
        return "在庫あり"
    return f"残り{count}" if count and count > 0 else "入荷待ち"


def _num(i: int) -> str:
    """1→① … 20→⑳。それ以上は「21.」のように数字で。"""
    return chr(0x245F + i) if 1 <= i <= 20 else f"{i}."


def product_button_label(num: str, product: dict, count) -> str:
    """ボタンは短く「番号 値段／在庫」だけ。商品名はボタンに入れない。

    ボタンは1行に収まる幅しか無く、長い商品名を入れると値段・在庫が切れて見えなく
    なる。商品名はメッセージ本文(折り返すので全部見える)に番号付きで出し、ボタンは
    その番号＋値段＋在庫にする。これで名前も値段も在庫も全部見える。
    """
    return f"{num} ¥{_price(product):,}／{_avail_label(product, count)}"


def catalog_text(intro: str, catalog: list) -> str:
    """本文には商品名だけを番号付きで出す。値段・在庫はボタンに出るので重ねない。"""
    lines = [intro, ""]
    for i, (_token, _m, product, _count) in enumerate(catalog, 1):
        lines.append(f"{_num(i)} {product.get('name') or '商品'}")
    lines.append("")
    lines.append("▼ 下の番号ボタンから選んでください。")
    return "\n".join(lines)


def render_catalog():
    """いまの在庫で (本文, ボタン, 指紋) を作る。

    指紋は本文とボタンから作る文字列。前回と同じなら編集しない(無駄打ちしない)ため。
    在庫・値段・名前・出す商品のどれかが変われば指紋が変わる。
    """
    catalog = build_catalog(shop.load_vending())
    if not catalog:
        text = "現在購入できる商品がありません。"
        rows = []
    else:
        text = catalog_text(get_intro(), catalog)
        rows = [[{"text": product_button_label(_num(i), p, c),
                  "callback_data": f"b:{token}"}]
                for i, (token, _m, p, c) in enumerate(catalog, 1)]
    if support_configured():
        # 窓口のグループが結び付いているときだけ出す(押しても繋がらないボタンを出さない)
        rows.append([{"text": "💬 サポート", "callback_data": "support"}])
    buttons = rows or None
    sig = text + "||" + "|".join(row[0]["text"] + row[0]["callback_data"] for row in rows)
    return text, buttons, sig


def detect_method(url: str) -> str | None:
    """リンクが PayPay か Kyash か(どちらでもなければ None)。"""
    if payments.looks_like_link(payments.PAYPAY, url):
        return payments.PAYPAY
    if payments.looks_like_link(payments.KYASH, url):
        return payments.KYASH
    return None


def parse_link_and_pass(text: str):
    """お客さんのメッセージから (リンク, パスワード|None) を取り出す。

    「<リンク> <パスワード>」のように後ろに付けても拾えるようにする(PayPayの
    パスワード付きリンク用)。見つからなければ (None, None)。
    """
    tokens = (text or "").split()
    link = None
    rest = []
    for t in tokens:
        if link is None and detect_method(t):
            link = t
        else:
            rest.append(t)
    passcode = rest[0] if (link and rest) else None
    return link, passcode


# 個数の入力。「3」「３」「3個」「 5 個 」を受ける(\d は全角数字にも当たる)。
_QTY_RE = re.compile(r"^\s*(\d{1,4})\s*個?\s*$")


def parse_qty(text: str):
    """お客さんが送った個数を int で返す。個数の形でなければ None。"""
    m = _QTY_RE.match(text or "")
    return int(m.group(1)) if m else None


# /start で出す説明文の既定。運営者が Discord の `/tg intro` で差し替えられる
# (差し替えた文は telegram_config.json に入る)。説明文はそのまま文字として送る
# (Markdown 記法は使わない)ので、運営者が書いた通りに表示される。
INTRO = (
    "🛒 自販機\n\n"
    "・買いたい商品を下のボタンから選んでください。\n"
    "・選ぶと支払い方法(PayPay / Kyash)の送金リンクを送ってもらいます。\n"
    "・受け取りが確認でき次第、自動でこのチャットにお渡しします。\n"
    "・保留(承認待ち)になったら、承認いただければそのまま自動でお渡しします。"
)

CONFIG_FILE = "telegram_config.json"


def get_intro() -> str:
    """/start で出す説明文。運営者が設定していればそれ、無ければ既定。"""
    try:
        cfg = read_json(data_path(CONFIG_FILE), {})
    except Exception:
        cfg = {}
    text = cfg.get("intro") if isinstance(cfg, dict) else None
    return text.strip() if isinstance(text, str) and text.strip() else INTRO


def set_intro(text: str):
    """説明文を保存する(Discord の `/tg intro` から呼ぶ)。"""
    path = data_path(CONFIG_FILE)
    cfg = read_json(path, {})
    if not isinstance(cfg, dict):
        cfg = {}
    cfg["intro"] = (text or "").strip()
    write_json(path, cfg)


# ====================== Telegram API(素の HTTP・to_thread) ======================

class TelegramAPI:
    def __init__(self, token: str):
        self.token = token
        # 接続を使い回す。requests.post をそのまま呼ぶと、呼ぶたびに api.telegram.org との
        # 接続(TCP と TLS)を作り直すので、ボタン1回の返事でも往復が何回ぶんも増える。
        # 受信待ち(長く待つ)と送信がいくつも同時に走るので、接続は多めに持てるようにする。
        self.http = requests.Session()
        self.http.mount("https://", HTTPAdapter(pool_connections=2, pool_maxsize=32))

    def _url(self, method: str) -> str:
        return API_BASE.format(token=self.token, method=method)

    def _post(self, url: str, build) -> requests.Response:
        """POST する(送る中身は build() で作る)。使い回していた接続が向こうで切られて
        いた等で繋がらなかったときは、中身を作り直して1回だけ送り直す。"""
        try:
            return self.http.post(url, **build())
        except requests.exceptions.ConnectionError:
            return self.http.post(url, **build())

    async def call(self, method: str, timeout: int = 20, **params) -> dict:
        def do():
            r = self._post(self._url(method), lambda: {"json": params, "timeout": timeout})
            return r.json()
        try:
            return await asyncio.to_thread(do)
        except Exception as e:
            log.warning("telegram %s 失敗: %s", method, e)
            return {"ok": False, "error": str(e)}

    async def get_updates(self, offset: int) -> list:
        def do():
            r = self.http.get(self._url("getUpdates"),
                              params={"offset": offset, "timeout": POLL_TIMEOUT},
                              timeout=POLL_TIMEOUT + 15)
            return r.json()
        data = await asyncio.to_thread(do)
        return data.get("result") or [] if isinstance(data, dict) else []

    async def send_message(self, chat_id, text: str, buttons: list = None,
                           markdown: bool = True, thread_id: int = None) -> dict:
        params = {"chat_id": chat_id, "text": text,
                  "disable_web_page_preview": True}
        if markdown:
            params["parse_mode"] = "Markdown"
        if buttons is not None:
            params["reply_markup"] = {"inline_keyboard": buttons}
        if thread_id:
            params["message_thread_id"] = thread_id   # フォーラムのトピックへ出す
        return await self.call("sendMessage", **params)

    async def copy_message(self, chat_id, from_chat_id, message_id: int,
                           thread_id: int = None) -> dict:
        """メッセージを中身ごと複製する(文字・写真・ファイル等なんでも)。"""
        params = {"chat_id": chat_id, "from_chat_id": from_chat_id,
                  "message_id": message_id}
        if thread_id:
            params["message_thread_id"] = thread_id
        return await self.call("copyMessage", **params)

    async def edit_message(self, chat_id, message_id, text: str, buttons: list = None,
                           markdown: bool = True) -> dict:
        params = {"chat_id": chat_id, "message_id": message_id, "text": text,
                  "disable_web_page_preview": True}
        if markdown:
            params["parse_mode"] = "Markdown"
        # buttons を省いた編集はキーボードを残す。空にしたいときは [] を渡す。
        if buttons is not None:
            params["reply_markup"] = {"inline_keyboard": buttons}
        return await self.call("editMessageText", **params)

    async def answer_callback(self, callback_id: str, text: str = None):
        params = {"callback_query_id": callback_id}
        if text:
            params["text"] = text
        return await self.call("answerCallbackQuery", **params)

    async def download_file(self, file_id: str):
        """送られてきたファイルの中身(bytes)。取れなければ None。"""
        res = await self.call("getFile", file_id=file_id)
        path = (res.get("result") or {}).get("file_path") if res.get("ok") else None
        if not path:
            return None

        def do():
            r = self.http.get(FILE_BASE.format(token=self.token, path=path), timeout=60)
            return r.content if r.status_code == 200 else None
        try:
            return await asyncio.to_thread(do)
        except Exception as e:
            log.warning("telegram ファイルの取得に失敗: %s", e)
            return None

    async def send_document(self, chat_id, filename: str, data: bytes,
                            caption: str = None, buttons: list = None) -> dict:
        def do():
            payload = {"chat_id": str(chat_id)}
            if caption:
                payload["caption"] = caption
            if buttons is not None:
                # ファイル送信(multipart)では、ボタンは JSON の文字列で渡す
                payload["reply_markup"] = json.dumps({"inline_keyboard": buttons})
            # 送り直すときはファイルを読み直せるよう、中身は毎回作る
            r = self._post(self._url("sendDocument"), lambda: {
                "data": payload, "files": {"document": (filename, io.BytesIO(data))},
                "timeout": 60})
            return r.json()
        try:
            return await asyncio.to_thread(do)
        except Exception as e:
            log.warning("telegram sendDocument 失敗: %s", e)
            return {"ok": False, "error": str(e)}


async def _deliver_text(chat_id, stock_text: str, header: str) -> bool:
    """在庫(コードなど)をチャットに渡す。長ければ .txt で送る。送れたら True。"""
    body = f"{header}\n```\n{stock_text}\n```"
    if len(body) <= TG_TEXT_LIMIT:
        res = await _api.send_message(chat_id, body)
    else:
        res = await _api.send_document(
            chat_id, "stock.txt", stock_text.encode("utf-8"), caption=header[:1000])
    return bool(res.get("ok"))


# ====================== お渡し(同期ぶん・共通の後始末) ======================

def _sale_header(product_name: str, qty: int, paid: int, method: str, order_id) -> str:
    lines = ["✅ *ご購入ありがとうございます*",
             f"商品: {product_name}",
             f"個数: {qty}",
             f"金額: ¥{int(paid):,}",
             f"支払い: {payments.method_label(method)}"]
    if order_id:
        lines.append(f"注文番号: `{order_id}`（お問い合わせの際はこの番号を）")
    return "\n".join(lines)


async def _record_tg_sale(machine_id, machine, product, qty, paid, tg_uid, method, order_id,
                          stock_text=""):
    """売上を shop_sales.json に残す(入金突合が『お渡し済み』として扱えるように)。

    これが無いと、Telegram で受け取った入金が『持ち主のいない入金』に見えて、
    #436/#437 の突合が別の注文へ回してしまう。必ず残す。
    stock_text は実際に渡した在庫の中身(アカウント情報など)。非公開ログに載せる。
    """
    try:
        await shop.record_shop_sale_async(
            machine_id, machine, product, qty, int(paid), f"tg:{tg_uid}",
            method=method, order_id=order_id)
    except Exception as e:
        log.warning("Telegram 売上の記録に失敗 (%s): %s", order_id, e)
    await _post_discord_log(machine, product, qty, paid, tg_uid, method, order_id,
                            stock_text=stock_text)


class _TGBuyer:
    """Telegram の購入者を Discord の販売ログ embed に載せるための最小の形。

    purchase_log_embeds が使う .mention / .id を持つ。Discord のアバターは無いので
    .display_avatar は持たない(公開ログのサムネ取得は embed 側の try/except で無視される)。
    """

    def __init__(self, uid):
        self.id = uid
        self.mention = "Telegramユーザー"


async def _post_discord_log(machine, product, qty, paid, tg_uid, method, order_id,
                            stock_text=""):
    """Discord の非公開販売ログに、Telegram の売上を Discord と同じ形で出す。

    経路=Telegram を入れるので、Discord 購入と Telegram 購入を同じログで見分けられる。
    渡した在庫の中身(stock_text。アカウント情報など)があれば、Discord 購入のログと
    同じように一緒に載せる(短ければコードブロック、長ければ .txt 添付)。
    best-effort。非公開ログのチャンネルが無ければ何もしない。"""
    if _bot is None:
        return
    ch_id = machine.get("private_log_channel_id") or machine.get("log_channel_id")
    if not ch_id:
        return
    try:
        ch = _bot.get_channel(int(ch_id)) or await _bot.fetch_channel(int(ch_id))
        _pub, prv = shop.purchase_log_embeds(
            _TGBuyer(tg_uid), str(product.get("name")), int(qty), int(paid), method,
            order_id=order_id, route="Telegram")
        extra = shop.stock_payload(stock_text) if stock_text else {}
        await ch.send(embed=prv, **extra)
    except Exception as e:
        log.warning("Telegram 販売の Discord ログ送信に失敗: %s", e)


# ====================== 見張りからのお渡し(保留が後から承認されたとき) ======================

async def tg_deliver(order: dict) -> bool:
    """入金が確認できた Telegram の注文を、取り置いた在庫でお渡しする。

    送れなければ False(監視ループが少し間をおいて再試行する)。Discord の
    offline_deliver の Telegram 版。
    """
    if _api is None:
        return False
    payload = order.get("payload") or {}
    chat_id = payload.get("tg_chat_id")
    if not chat_id:
        log.warning("Telegram 注文に chat_id がありません: %s", order.get("id"))
        return False
    records = payload.get("records") or []
    qty = int(payload.get("qty") or len(records) or 1)
    paid = int(order.get("paid_amount") or order.get("amount_jpy") or 0)
    method = order.get("method") or payments.PAYPAY
    product_name = payload.get("product_name") or "商品"
    machine_id = payload.get("machine_id")
    machine = shop.load_vending().get(machine_id, {}) or {}
    product = shop._find_product(machine, payload.get("product_id"))

    if payload.get("released"):
        # 期限切れで在庫を戻した後に遅れて届いた入金。取り置き直してから渡す。
        if product is None:
            raise RuntimeError("商品が削除されているため渡せません")
        fresh = await shop.take_stock_async(product, qty)
        if fresh is None:
            raise RuntimeError(f"在庫が足りません（{product_name} ×{qty}個）")
        records = fresh
        await link_orders.mark_order(order["id"], order.get("status", "paid"),
                                     payload={**payload, "records": fresh, "released": False})

    ok = await _deliver_text(chat_id, "\n\n".join(records),
                             _sale_header(product_name, qty, paid, method, order.get("id")))
    if not ok:
        return False
    # ここから先は手元に届いている。記録で失敗しても False を返さない
    # (返すと見張りが再試行して同じ在庫を二重に送る)。
    try:
        await _record_tg_sale(machine_id, machine,
                              product or {"product_id": payload.get("product_id"),
                                          "name": product_name},
                              qty, paid, order.get("user_id"), method, order.get("id"),
                              stock_text="\n\n".join(records))
    except Exception as e:
        log.exception("Telegram お渡し後の記録に失敗 (%s): %s", order.get("id"), e)
    _kick_refresh()      # 在庫が動いた可能性があるのでパネルを更新
    return True


async def tg_release(order: dict):
    """期限切れ・キャンセルの Telegram 注文の取り置き在庫を戻す。"""
    payload = order.get("payload") or {}
    if payload.get("released"):
        return
    records = payload.get("records") or []
    machine = shop.load_vending().get(payload.get("machine_id"), {}) or {}
    product = shop._find_product(machine, payload.get("product_id"))
    if product is not None and records:
        try:
            await shop.return_stock_async(product, records)
        except Exception as e:
            log.warning("Telegram 取り置きの戻しに失敗 (%s): %s", order.get("id"), e)
    try:
        await link_orders.mark_order(order["id"], order.get("status", "expired"),
                                     payload={**payload, "released": True})
    except Exception:
        pass
    chat_id = payload.get("tg_chat_id")
    if chat_id and _api is not None:
        await _api.send_message(
            chat_id,
            "⌛ 期限までに支払いの承認が確認できなかったため、取り置きを終了しました。\n"
            "もう一度購入し直してください。（お代はいただいていません）")
    _kick_refresh()      # 取り置きを戻した＝在庫が増えたのでパネルを更新


# ====================== お客さんの購入フロー ======================

async def _watch_pending(chat_id, tg_uid, machine, machine_id, product, qty, total,
                         method, url, passcode, error, told: bool = False) -> bool:
    """決着しなかった支払いを見張りに引き継ぐ。引き継げたら True(Discord の shop と同じ流れ)。

    told は、保留の案内(承認を押してください)をすでに送ってあるか。送ってあれば
    同じ説明を繰り返さず、引き続き待つことと注文番号だけを伝える。"""
    if method != payments.PAYPAY:
        return False       # 保留があるのは PayPay だけ
    accepted = bool(getattr(error, "accepted", False))
    reserved = await shop.take_stock_async(product, qty)
    if reserved is None:
        return False
    payload = {
        "machine_id": machine_id,
        "product_id": product["product_id"],
        "product_name": product["name"],
        "qty": qty,
        "records": reserved,
        "tg_chat_id": chat_id,
    }
    try:
        order = await link_orders.create_order(
            KIND, tg_uid, url, amount_jpy=int(total), payload=payload, method=method,
            minutes=shop.WATCH_MINUTES, passcode=passcode, accepted=accepted,
            summary=f"{product['name']} ×{qty}個")
    except Exception as e:
        await shop.return_stock_async(product, reserved)
        log.warning("Telegram 見張り登録に失敗: %s", e)
        return False
    if not order:
        await shop.return_stock_async(product, reserved)
        return False
    if order.get("reused"):
        await shop.return_stock_async(product, reserved)
    if told:
        text = ("⏳ まだ承認を確認できていません。引き続き自動で確認を続け、承認が確認でき次第"
                "このチャットにお渡しします。支払い直す必要はありません。\n"
                f"注文番号: `{order['id']}`（お問い合わせの際はこの番号を）")
    else:
        text = ("⏳ 支払いが保留(承認待ち)です。PayPayアプリで *「承認する」* を押してください。\n"
                "⚠️ 「キャンセル」を押すと送金が戻り、お渡しできません。\n"
                "承認が確認でき次第、自動でこのチャットにお渡しします。支払い直す必要はありません。\n"
                f"注文番号: `{order['id']}`")
    await _api.send_message(chat_id, text)
    return True


async def _deliver_now(chat_id, tg_uid, machine, machine_id, product, qty, paid, method, url):
    """その場で受け取れたぶんを、在庫を取ってお渡しする(Discord の _hand_over 相当)。"""
    order_id = None
    try:
        settled = await link_orders.settle_on_screen(
            KIND, tg_uid, url, paid=paid, method=method,
            summary=f"{product.get('name')} ×{qty}個",
            delivered=False, own_record=True)
        order_id = (settled.get("record") or {}).get("id")
        for closed in settled.get("closed") or []:
            try:
                await shop.release_closed_order(_bot, closed)
            except Exception as e:
                log.warning("Telegram: 同じリンクの見張りの後始末に失敗: %s", e)
    except Exception as e:
        log.warning("Telegram: 受け取り記録に失敗: %s", e)

    records = await shop.take_stock_async(product, qty)
    if records is None:
        # 支払い済みなのに在庫切れ。必ず記録と通知を残す。
        await _record_tg_sale(machine_id, machine, product, qty, paid, tg_uid, method, order_id)
        await _api.send_message(
            chat_id,
            "⚠️ お支払いは受け取りましたが、在庫が不足していてお渡しできませんでした。\n"
            "確認して対応します。もう一度支払わないでください。\n"
            + (f"注文番号: `{order_id}`" if order_id else ""))
        if order_id:
            try:
                await link_orders.mark_screen_delivery(
                    order_id, False, "在庫不足でお渡しできませんでした（手渡しか返金が必要）")
            except Exception:
                pass
        return

    ok = await _deliver_text(chat_id, "\n\n".join(records),
                             _sale_header(product["name"], qty, paid, method, order_id))
    if order_id:
        try:
            await link_orders.mark_screen_delivery(order_id, bool(ok))
        except Exception:
            pass
    await _record_tg_sale(machine_id, machine, product, qty, paid, tg_uid, method, order_id,
                          stock_text="\n\n".join(records))
    if not ok:
        await _api.send_message(
            chat_id, "⚠️ お渡しの送信に失敗しました。確認して対応します。"
            + (f"\n注文番号: `{order_id}`" if order_id else ""))


async def _purchase(chat_id, tg_uid, url, passcode):
    sel = _selecting.get(chat_id)
    if not sel:
        await _api.send_message(
            chat_id, "先に下のボタンから商品を選んでください。/start で一覧を出せます。")
        return
    method = detect_method(url)
    if not method:
        await _api.send_message(
            chat_id, "PayPay または Kyash の送金リンクを送ってください。")
        return
    # 共有・コピーで前後に付いた案内文やスペースを落とし、正規のリンクだけにする
    # (余分な文字ごと受け取りコードにすると保留・エラーになる)。以降の受け取り・
    # 取り置き・記録はすべてこの整えたリンクを使う。
    url = payments.clean_link(method, url)

    vending = shop.load_vending()
    machine = vending.get(sel["mid"]) or {}
    product = shop._find_product(machine, sel["pid"])
    if not product:
        _end_selection(chat_id)
        await _api.send_message(chat_id, "商品が見つかりませんでした。/start でやり直してください。")
        return
    if not sel.get("qty"):
        # 個数を入れる前にリンクが来た。1個分で受け取ると、複数個ぶんのリンクを
        # 送られたときに多く受け取って1個しか渡さないことになる。先に個数を聞く。
        return await _api.send_message(
            chat_id, f"先に購入する個数を数字で送ってください（1〜{_qty_cap(product)}）。例: 3",
            markdown=False)
    qty = int(sel["qty"])
    if not product.get("infinite"):
        avail = stock_count(product) or 0
        if avail < qty:
            _end_selection(chat_id)
            note = shop.availability_note(product)
            await _api.send_message(
                chat_id,
                (f"在庫が不足しています（ご希望 {qty}個）。{note}" if note
                 else f"在庫が不足しています（在庫 {avail}個 / ご希望 {qty}個）。")
                + "/start でやり直してください。", markdown=False)
            return
    # 金額は Discord と同じ product_total(まとめ買い値下げを含む)で出す。
    total = shop.product_total(product, qty)[0]

    attempt = await payment_attempts.record_async(
        KIND, tg_uid, amount=int(total), method=method, link=url,
        summary=f"{product.get('name')} ×{qty}個",
        payload={"machine_id": sel["mid"], "product_id": product["product_id"],
                 "product_name": product["name"], "qty": qty, "records": [],
                 "released": True, "tg_chat_id": chat_id})

    # 同じリンクを見張り(または別の画面)が持っていないか先に確かめる。
    try:
        hold = await link_orders.hold_link(url, kind=KIND, user_id=tg_uid)
    except link_orders.LinkBusy as e:
        await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e)[:300])
        await payment_attempts.finish_async(attempt)
        await _api.send_message(chat_id, f"{e}")
        return
    except link_orders.LinkOrderError as e:
        await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e)[:300])
        await payment_attempts.finish_async(attempt)
        await _api.send_message(
            chat_id, "ただいま混み合っています。少し時間をおいてからお試しください。"
            "（お代はいただいていません）")
        return

    try:
        state = {}
        told = {"pending": False}

        async def notify_pending(deadline: float):
            # 保留(送金者の承認待ち)になったら、その場で承認を頼む(Discord と同じ)。
            # 黙って待つと、お客さんは「確認しています」のまま3分待たされ、承認を
            # 押すきっかけが無いまま見張りに回ってしまう。
            told["pending"] = True
            await _api.send_message(
                chat_id,
                "⏳ 支払いが保留(承認待ち)になっています。PayPayアプリに\n"
                "「◯◯さんへの送金が保留になっています」と出ているので、*「承認する」* を押してください。\n"
                "⚠️ 「キャンセル」を押すと送金が戻り、お渡しできません。\n"
                "承認が確認でき次第、自動でこのチャットにお渡しします。支払い直す必要はありません。")

        try:
            # 「確認しています」の送信を待たずに受け取りを始める(並べて走らせる)。
            # 両方そろってから先へ進むので、このあとの返事がこれより先に届くことはない。
            _, paid = await asyncio.gather(
                _api.send_message(chat_id, "支払いを確認しています。少々お待ちください…"),
                payments.receive_link_payment(
                    method, url, passcode=passcode, min_amount=total,
                    on_pending=notify_pending, client=_bot, state=state, buyer=None,
                    kind="Telegram自販機"),
                return_exceptions=True)
            if isinstance(paid, BaseException):
                raise paid
        except payments.PaymentNotRegistered as e:
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await _api.send_message(chat_id, str(e))
        except payments.PaymentError as e:
            if getattr(e, "watchable", False) and await _watch_pending(
                    chat_id, tg_uid, machine, sel["mid"], product, qty, total,
                    method, url, passcode, e, told=told["pending"]):
                _end_selection(chat_id, sel)
                await payment_attempts.resolve_async(attempt, payment_attempts.WATCHING, str(e))
                return
            if getattr(e, "accepted", False):
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.DROPPED,
                    f"受け取り送信済みだが見張りに載せられず: {getattr(e, 'watch_note', '') or e}")
                return await _api.send_message(
                    chat_id,
                    "受け取りのリクエストは送信済みですが、処理を完了できませんでした。\n"
                    "お代をいただいている可能性があります。もう一度支払わないでください。"
                    "確認して対応します。")
            if isinstance(e, payments.PaymentPending):
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.REJECTED, "承認されませんでした")
                return await _api.send_message(
                    chat_id,
                    "支払いがまだ承認されていません。PayPayアプリで「承認する」を押してから、"
                    "もう一度リンクを送ってください。（お代はいただいていません）")
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await _api.send_message(
                chat_id, f"支払いを確認できませんでした。\n{e}\n"
                "お代はいただいていません。もう一度お試しください。")

        # 受け取れた。
        _end_selection(chat_id, sel)
        await payment_attempts.resolve_async(attempt, payment_attempts.DELIVERED, f"{paid:,}円")
        await _deliver_now(chat_id, tg_uid, machine, sel["mid"], product, qty, paid, method, url)
        try:
            for closed in await link_orders.cancel_superseded(tg_uid, KIND, int(total)):
                await shop.release_closed_order(_bot, closed)
        except Exception as e:
            log.warning("Telegram: 買い直しの後始末に失敗: %s", e)
    finally:
        await payment_attempts.finish_async(attempt)
        await link_orders.release_link(hold)
        _kick_refresh()      # 在庫が動いたのでパネルをすぐ更新


# ====================== パネルのリアルタイム更新 ======================

def _load_panels():
    global _panels
    try:
        cfg = read_json(data_path(CONFIG_FILE), {})
        saved = cfg.get("panels") if isinstance(cfg, dict) else None
        _panels = {str(k): int(v) for k, v in saved.items()} if isinstance(saved, dict) else {}
    except Exception:
        _panels = {}


def _save_panels():
    try:
        path = data_path(CONFIG_FILE)
        cfg = read_json(path, {})
        if not isinstance(cfg, dict):
            cfg = {}
        cfg["panels"] = {str(k): int(v) for k, v in _panels.items()}
        write_json(path, cfg)
    except Exception as e:
        log.warning("Telegram パネルの保存に失敗: %s", e)


async def refresh_panels(force: bool = False):
    """出してあるパネルを、いまの在庫で編集し直す。内容が変わったときだけ編集する。

    Discord側の購入・在庫追加・在庫取り出し・商品の出し入れも、ここで反映される
    (在庫ファイルや vending を読み直して描くだけなので、変更元を問わない)。
    """
    global _last_sig
    if _api is None or not _panels:
        return
    text, buttons, sig = render_catalog()
    if sig == _last_sig and not force:
        return
    _last_sig = sig
    dead = []
    for chat_id, msg_id in list(_panels.items()):
        if _showing_prompt(chat_id, msg_id):
            continue                   # いまは個数入力の画面(選び終わったら一覧に戻す)
        try:
            res = await _api.edit_message(chat_id, msg_id, text,
                                          buttons=buttons if buttons is not None else [],
                                          markdown=False)
        except Exception:
            continue
        if not res.get("ok"):
            desc = str(res.get("description") or res.get("error") or "").lower()
            if "not modified" in desc:
                continue
            if any(s in desc for s in ("not found", "blocked", "deactivated",
                                       "chat not found", "can't be edited",
                                       "message to edit not found", "kicked")):
                dead.append(chat_id)   # 消された/ブロックされたパネルは追わない
        await asyncio.sleep(0.05)      # レート制限を避けて少しずつ
    if dead:
        for c in dead:
            _panels.pop(c, None)
        _save_panels()


def _kick_refresh():
    """在庫が動いたときに、すぐ1回だけパネルを更新する(待たせない)。"""
    if _api is None:
        return
    try:
        asyncio.create_task(refresh_panels())
    except RuntimeError:
        pass


async def _refresh_loop():
    while True:
        try:
            await asyncio.sleep(REFRESH_SECONDS)
            await refresh_panels()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("Telegram パネル更新でエラー: %s", e)


# ====================== 在庫追加のお知らせ(利用者全員へ) ======================
#
# Discord で在庫を足したら、Telegram に出している商品なら、この Bot と個別チャットで
# 話したことのある全員へ知らせる。Bot は一度も話しかけてこない人には送れないので、
# 話しかけてきた人を送り先として覚えておく。ブロックした人は送り先から外す。
# Discord の `/tg restock_notify` でオン/オフできる(既定はオン)。

_users = set()                  # 送り先(個別チャットの chat_id を str で)
_users_loaded = False
_bg_tasks = set()               # 裏で送っているタスク(途中で GC に消されないよう持っておく)
_broadcast_lock = asyncio.Lock()
# 1通ごとの間隔(秒)。Telegram は相手が別々でも毎秒30通ほどが上限。
BROADCAST_INTERVAL = 0.05
# もう届かない相手(ブロック・退会・存在しない)の返答
_UNREACHABLE = ("blocked", "deactivated", "chat not found", "user not found",
                "can't initiate conversation")


def _load_users():
    global _users, _users_loaded
    try:
        cfg = read_json(data_path(CONFIG_FILE), {})
        cfg = cfg if isinstance(cfg, dict) else {}
    except Exception:
        cfg = {}
    if isinstance(cfg.get("users"), list):
        _users = {str(x) for x in cfg["users"]}
    else:
        # この仕組みより前から使っている人も漏らさないよう、初回だけ、パネルを出した人と
        # サポートを使った人から作る。
        panels = cfg.get("panels") if isinstance(cfg.get("panels"), dict) else {}
        sup = cfg.get("support") if isinstance(cfg.get("support"), dict) else {}
        topics = sup.get("topics") if isinstance(sup.get("topics"), dict) else {}
        _users = {str(k) for k in panels} | {str(k) for k in topics}
        if _users:
            _save_users()
    _users_loaded = True


def _save_users():
    try:
        path = data_path(CONFIG_FILE)
        cfg = read_json(path, {})
        if not isinstance(cfg, dict):
            cfg = {}
        cfg["users"] = sorted(_users)
        write_json(path, cfg)
    except Exception as e:
        log.warning("Telegram 利用者一覧の保存に失敗: %s", e)


def _remember_user(chat_id):
    """個別チャットで話しかけてきた人を、お知らせの送り先として覚える。"""
    if not _users_loaded:
        _load_users()
    key = str(chat_id)
    if key not in _users:
        _users.add(key)
        _save_users()


def subscriber_count() -> int:
    if not _users_loaded:
        _load_users()
    return len(_users)


def restock_notify_enabled() -> bool:
    try:
        cfg = read_json(data_path(CONFIG_FILE), {})
    except Exception:
        cfg = {}
    return not (isinstance(cfg, dict) and cfg.get("restock_notify") is False)


def set_restock_notify(on: bool):
    """お知らせのオン/オフを保存する(Discord の `/tg restock_notify` から呼ぶ)。"""
    path = data_path(CONFIG_FILE)
    cfg = read_json(path, {})
    if not isinstance(cfg, dict):
        cfg = {}
    cfg["restock_notify"] = bool(on)
    write_json(path, cfg)


def restock_text(product: dict, added: int) -> str:
    """Discord の在庫追加通知と同じく、商品と足した数を出す。"""
    return f"📦 在庫追加\n・{product.get('name') or '商品'} {int(added)}個"


def _menu_button():
    return [[{"text": "🛒 商品一覧を見る", "callback_data": "menu"}]]


def _spawn(coro):
    try:
        task = asyncio.create_task(coro)
    except RuntimeError:
        coro.close()
        return None
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)
    return task


def notify_restock(product: dict, added) -> int:
    """Discord で在庫を足したときに呼ぶ。Telegram に出している商品なら全員へ知らせる。

    送るのは裏で行う(人数が多くても Discord の操作を待たせない)。知らせる人数を返す
    (知らせないときは 0)。"""
    if _api is None or not isinstance(product, dict) or not product.get("telegram"):
        return 0
    if _price(product) <= 0:
        return 0       # 0円商品は Telegram に並ばない
    try:
        added = int(added)
    except (TypeError, ValueError):
        return 0
    if added <= 0:
        return 0
    if not _users_loaded:
        _load_users()
    count = len(_users) if restock_notify_enabled() else 0
    task = _spawn(_after_restock(restock_text(product, added) if count else None))
    return count if task else 0


async def _after_restock(text):
    """先にパネルの在庫を増やしてから知らせる(お知らせを見て開いた人が古い在庫を見ないように)。"""
    try:
        await refresh_panels()
        if text:
            await _broadcast(text, _menu_button())
    except Exception as e:
        log.exception("Telegram 在庫追加のお知らせでエラー: %s", e)


async def _send_with_retry(chat_id, text, buttons) -> dict:
    """1人に送る。混雑(429)のときは言われた秒数だけ待って送り直す。"""
    res = {}
    for _ in range(3):
        res = await _api.send_message(chat_id, text, buttons=buttons, markdown=False)
        if res.get("ok") or res.get("error_code") != 429:
            return res
        wait = (res.get("parameters") or {}).get("retry_after") or 1
        await asyncio.sleep(min(float(wait), 60) + 0.5)
    return res


async def _broadcast(text, buttons=None) -> int:
    """覚えている全員へ1通ずつ送る。届かなくなった人(ブロック等)は送り先から外す。"""
    async with _broadcast_lock:      # 続けて足されても、同時に送って混雑させない
        sent = 0
        gone = []
        for cid in sorted(_users):
            res = await _send_with_retry(int(cid), text, buttons)
            if res.get("ok"):
                sent += 1
            else:
                desc = str(res.get("description") or "").lower()
                if res.get("error_code") == 403 or any(s in desc for s in _UNREACHABLE):
                    gone.append(cid)
            await asyncio.sleep(BROADCAST_INTERVAL)
        if gone:
            for cid in gone:
                _users.discard(cid)
            _save_users()
        log.info("Telegram 在庫追加のお知らせ: %d人に送信 / 届かないため外した %d人",
                 sent, len(gone))
        return sent


# ====================== サポート(お客さんごとの専用トピック) ======================
#
# Bot は Telegram で新しいグループを作れない。そこで運営者のスーパーグループ
# (トピック機能オン・Botを管理者に)を1つ「サポート窓口」にして、お客さんごとに
# トピックを1つ作る。お客さんの発言はそのトピックへ、トピックに運営が書いた発言は
# そのお客さんへ、Bot が中継する。これで「運営とそのお客さんだけの専用チャンネル」になる。
#
# 窓口のグループは、Discord の `/tg support` で出す使い捨てコードを、
# そのグループで `/setsupport コード` と送って結び付ける。第三者が自分のグループを
# 窓口にして、お客さんの相談を横取りするのを防ぐため。

_support = {"chat_id": None, "topics": {}, "open": set()}   # topics: {客chat_id: thread_id}
_thread_to_cust = {}            # thread_id -> 客chat_id(str)
_support_loaded = False
_link_code = {"code": None, "expires": 0.0}
LINK_CODE_MINUTES = 10
_me = {}                        # getMe の結果(Bot自身のID)

# トピックが消された / 閉じられているときの Telegram の返答
_THREAD_GONE = ("thread not found", "message thread not found", "topic_deleted", "topic deleted")
_THREAD_CLOSED = ("topic_closed", "topic closed")
# 中継しないサービスメッセージ(トピック作成の通知など)
_SERVICE_KEYS = ("forum_topic_created", "forum_topic_closed", "forum_topic_reopened",
                 "forum_topic_edited", "general_forum_topic_hidden",
                 "general_forum_topic_unhidden", "new_chat_members", "left_chat_member",
                 "pinned_message", "new_chat_title", "new_chat_photo", "delete_chat_photo",
                 "group_chat_created", "supergroup_chat_created", "migrate_to_chat_id",
                 "migrate_from_chat_id", "video_chat_started", "video_chat_ended")


def _load_support():
    global _support_loaded
    try:
        cfg = read_json(data_path(CONFIG_FILE), {})
        sup = cfg.get("support") if isinstance(cfg, dict) else None
        sup = sup if isinstance(sup, dict) else {}
    except Exception:
        sup = {}
    chat_id = sup.get("chat_id")
    _support["chat_id"] = int(chat_id) if chat_id not in (None, "") else None
    topics = sup.get("topics") if isinstance(sup.get("topics"), dict) else {}
    _support["topics"] = {str(k): int(v) for k, v in topics.items()}
    _support["open"] = {str(x) for x in (sup.get("open") or [])}
    _thread_to_cust.clear()
    _thread_to_cust.update({t: c for c, t in _support["topics"].items()})
    _support_loaded = True


def _save_support():
    try:
        path = data_path(CONFIG_FILE)
        cfg = read_json(path, {})
        if not isinstance(cfg, dict):
            cfg = {}
        cfg["support"] = {"chat_id": _support["chat_id"],
                          "topics": dict(_support["topics"]),
                          "open": sorted(_support["open"])}
        write_json(path, cfg)
    except Exception as e:
        log.warning("Telegram サポート設定の保存に失敗: %s", e)


def _ensure_support_loaded():
    if not _support_loaded:
        _load_support()


def support_configured() -> bool:
    _ensure_support_loaded()
    return bool(_support["chat_id"])


def create_support_link_code() -> str:
    """窓口グループを結び付ける使い捨てコード(Discord の管理者にだけ見せる)。"""
    code = secrets.token_hex(3).upper()     # 6文字
    _link_code.update(code=code, expires=time.time() + LINK_CODE_MINUTES * 60)
    return code


def disable_support():
    """窓口を解除する(パネルの💬サポートも消える)。"""
    _ensure_support_loaded()
    _support.update(chat_id=None, topics={}, open=set())
    _thread_to_cust.clear()
    _save_support()
    _kick_refresh()


def _forget_topic(cust: str):
    thread = _support["topics"].pop(cust, None)
    if thread is not None:
        _thread_to_cust.pop(thread, None)
    _save_support()


def _user_label(user: dict) -> str:
    user = user or {}
    name = " ".join(x for x in (user.get("first_name"), user.get("last_name")) if x)
    return name or "お客様"


async def _ensure_topic(cust: str, user: dict = None):
    """このお客さんのトピックを返す。無ければ作る。作れなければ None。"""
    thread = _support["topics"].get(cust)
    if thread:
        return thread
    sup = _support["chat_id"]
    label = _user_label(user)
    username = (user or {}).get("username")
    name = f"👤 {label}" + (f" @{username}" if username else "") + f" | {cust}"
    res = await _api.call("createForumTopic", chat_id=sup, name=name[:128])
    if not res.get("ok"):
        log.warning("Telegram サポートのトピックを作れませんでした: %s", res.get("description"))
        return None
    thread = int(res["result"]["message_thread_id"])
    _support["topics"][cust] = thread
    _thread_to_cust[thread] = cust
    _save_support()
    await _api.send_message(
        sup,
        f"🆕 サポート\nお客様: {label}" + (f"（@{username}）" if username else "")
        + f"\nTelegram ID: {cust}\n\nこのトピックに書いた内容は、このお客様だけに届きます。\n"
        "対応が終わったら、このトピックで /close と送ってください"
        "（お客様に終了を伝えて、このトピックを削除します）。",
        markdown=False, thread_id=thread)
    return thread


async def _with_topic(cust: str, user: dict, op):
    """op(thread_id) を実行する。トピックが閉じていれば開け直し、消されていれば
    作り直して、1回だけやり直す。"""
    thread = await _ensure_topic(cust, user)
    if not thread:
        return {"ok": False, "description": "no topic"}
    res = await op(thread)
    if res.get("ok"):
        return res
    desc = str(res.get("description") or "").lower()
    if any(s in desc for s in _THREAD_CLOSED):
        await _api.call("reopenForumTopic", chat_id=_support["chat_id"],
                        message_thread_id=thread)
        return await op(thread)
    if any(s in desc for s in _THREAD_GONE):
        _forget_topic(cust)
        thread = await _ensure_topic(cust, user)
        if thread:
            return await op(thread)
    return res


def _end_button():
    return [[{"text": "サポートを終える", "callback_data": "support_end"}]]


async def _start_support(chat_id, user: dict):
    if not support_configured():
        await _api.send_message(chat_id, "現在サポート窓口は準備中です。時間をおいてお試しください。",
                                markdown=False)
        return
    _formatting.pop(chat_id, None)       # サポートを開いたら、次の発言はサポートへ(形式確認にしない)
    cust = str(chat_id)
    sup = _support["chat_id"]
    existing = _support["topics"].get(cust)
    if existing:
        # 閉じたままのトピック(/close で消せずに閉じた等)を開け直す(開いていれば何も
        # 起きない)。Bot は管理者なので閉じたトピックにも書けてしまい、一覧で「閉じた」の
        # まま対応が続くのを防ぐ。
        await _api.call("reopenForumTopic", chat_id=sup, message_thread_id=existing)
    res = await _with_topic(cust, user, lambda t: _api.send_message(
        sup, "📩 お客様がサポートを開きました。", markdown=False, thread_id=t))
    if not res.get("ok"):
        await _api.send_message(
            chat_id, "サポート窓口に接続できませんでした。時間をおいてもう一度お試しください。",
            markdown=False)
        return
    _end_selection(chat_id)
    _support["open"].add(cust)
    _save_support()
    await _api.send_message(
        chat_id,
        "💬 サポートにつながりました。\n"
        "ご用件をこのチャットに送ってください（写真やファイルも送れます）。担当者が返信します。\n\n"
        "購入に戻るときは「サポートを終える」を押すか、パネルから商品を選んでください。",
        buttons=_end_button(), markdown=False)


async def _relay_to_support(chat_id, msg: dict):
    """サポート中のお客さんの発言を、その人のトピックへ中身ごと複製する。"""
    cust = str(chat_id)
    sup = _support["chat_id"]
    res = await _with_topic(cust, msg.get("from") or {}, lambda t: _api.copy_message(
        sup, chat_id, msg["message_id"], thread_id=t))
    if not res.get("ok"):
        await _api.send_message(
            chat_id, "⚠️ サポートへの送信に失敗しました。時間をおいてもう一度送ってください。",
            markdown=False)


async def _end_support(cust: str, by_admin: bool = False):
    was_open = cust in _support["open"]
    _support["open"].discard(cust)
    _save_support()
    thread = _support["topics"].get(cust)
    sup = _support["chat_id"]
    if by_admin:
        r = await _api.send_message(
            int(cust), "✅ サポートを終了しました。ご利用ありがとうございました。\n"
            "またいつでもパネルの「💬 サポート」からどうぞ。", markdown=False)
        if sup and thread:
            # 終わった対応のトピックは消す(次に押されたら新しく作る)。消すには Bot に
            # 「メッセージの削除」の権限が要る。消せなければ、これまでどおり閉じておく。
            res = await _api.call("deleteForumTopic", chat_id=sup, message_thread_id=thread)
            if res.get("ok"):
                _forget_topic(cust)
                return
            note = ("✅ 対応を終了しました（お客様に通知済み）。" if r.get("ok")
                    else "✅ 対応を終了しました（お客様への通知は届きませんでした）。")
            await _api.send_message(
                sup, note + "\n⚠️ トピックを削除できなかったので、閉じておきました"
                "（Botに「メッセージの削除」の権限があるか確認してください）。",
                markdown=False, thread_id=thread)
            await _api.call("closeForumTopic", chat_id=sup, message_thread_id=thread)
        return
    await _api.send_message(
        int(cust), "サポートを終了しました。またいつでもパネルの「💬 サポート」からどうぞ。",
        markdown=False)
    if was_open and sup and thread:
        await _api.send_message(sup, "ℹ️ お客様がサポートを終了しました。",
                                markdown=False, thread_id=thread)


async def _bot_can_manage_topics(chat_id) -> bool:
    if not _me.get("id"):
        res = await _api.call("getMe")
        if res.get("ok"):
            _me.update(res.get("result") or {})
    if not _me.get("id"):
        return False
    res = await _api.call("getChatMember", chat_id=chat_id, user_id=_me["id"])
    member = res.get("result") or {}
    return member.get("status") == "administrator" and bool(member.get("can_manage_topics"))


def _command(text: str) -> str:
    """'/close@BotName あいう' → '/close'。コマンドでなければ ''。"""
    if not (text or "").startswith("/"):
        return ""
    return text.split()[0].split("@")[0].lower()


async def _try_link_support(msg: dict):
    """グループで `/setsupport コード` を受けたら、そのグループを窓口にする。"""
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    parts = (msg.get("text") or "").split()
    code = parts[1].strip().upper() if len(parts) > 1 else ""
    thread = msg.get("message_thread_id") if msg.get("is_topic_message") else None

    async def reply(text):
        await _api.send_message(chat_id, text, markdown=False, thread_id=thread)

    if not (_link_code["code"] and code == _link_code["code"]
            and time.time() < _link_code["expires"]):
        return await reply("コードが違うか、期限切れです。Discord の /tg support で"
                           "コードを出し直してください。")
    if chat.get("type") != "supergroup" or not chat.get("is_forum"):
        return await reply("このグループは「トピック」がオフです。グループの設定でトピックを"
                           "オンにしてから、もう一度送ってください。")
    if not await _bot_can_manage_topics(chat_id):
        return await reply("このBotをグループの管理者にして、「トピックの管理」を許可してから、"
                           "もう一度送ってください。")
    _ensure_support_loaded()
    _link_code.update(code=None, expires=0.0)
    if _support["chat_id"] != chat_id:
        # 別のグループへ付け替えるときは、前のグループのトピックは使えない
        _support.update(topics={}, open=set())
        _thread_to_cust.clear()
    _support["chat_id"] = chat_id
    _save_support()
    await reply("✅ このグループをサポート窓口にしました。\n"
                "お客様がパネルの「💬 サポート」を押すと、お客様ごとにトピックができます。"
                "そのトピックに書いた内容は、そのお客様だけに届きます。\n"
                "対応が終わったら、そのトピックで /close と送ってください（トピックは削除されます）。")
    _kick_refresh()      # 出ているパネルに💬サポートボタンを付ける


async def _on_support_group_message(msg: dict):
    """窓口グループでの発言。お客さんのトピックに書かれたものを、そのお客さんへ届ける。"""
    sup = _support["chat_id"]
    # Bot の発言は中継しない。ただし「匿名のままにする」をオンにした管理者の発言は
    # グループ名義(from が GroupAnonymousBot)で届くので、運営の発言として通す。
    if (msg.get("from") or {}).get("is_bot") and (msg.get("sender_chat") or {}).get("id") != sup:
        return
    text = msg.get("text") or ""
    cmd = _command(text)
    if cmd == "/setsupport":
        return await _try_link_support(msg)
    if any(k in msg for k in _SERVICE_KEYS):
        return
    # どのお客さんのトピックかは、トピック番号(message_thread_id)だけで決める。
    # is_topic_message は条件にしない(付いていないときに、トピック内でそのまま
    # 書いた発言まで捨ててしまわないように)。トピック番号はトピックを作ったときの
    # メッセージIDなので、General の返信に付く番号と重なることはない。
    thread = msg.get("message_thread_id")
    cust = _thread_to_cust.get(int(thread)) if thread is not None else None
    if not cust:
        if text and not msg.get("is_topic_message"):
            # General(全体)に書かれた発言は、どのお客さんにも届かない。黙って捨てると
            # 届いたと思われてしまうので、届いていないことを知らせる。
            await _api.send_message(
                sup, "⚠️ General に送られたので、お客様には届いていません。\n"
                "お客様のトピックを開いてその中で送るか、お客様のメッセージにリプライしてください。",
                markdown=False)
        return                       # General か、お客さんに結び付いていないトピック
    if cmd == "/close":
        return await _end_support(cust, by_admin=True)
    if cmd:
        return                       # ほかのコマンドは中継しない
    if text:
        res = await _api.send_message(int(cust), "💬 サポートより:\n" + text, markdown=False)
    else:
        await _api.send_message(int(cust), "💬 サポートより:", markdown=False)
        res = await _api.copy_message(int(cust), sup, msg["message_id"])
    if not res.get("ok"):
        await _api.send_message(
            sup, "⚠️ お客様に届けられませんでした（Botがブロックされている可能性があります）。",
            markdown=False, thread_id=thread)


# ====================== 形式確認(/format) ======================
#
# 購入したX垢の情報(届いたメッセージ・まとめ買いの stock.txt)を送ってもらい、項目ごとに
# 分けて返す。読み分けは Discord の形式確認パネルと同じ(shop.format_breakdown)。
# /format で受け付けを始め、「形式確認を終える」・/start・商品を選ぶ・10分何も送らない、
# のどれかで終わる。長い貼り付けは Telegram が何通かに分けて送るので、受け付け中は
# 何通でも読む。受け付け中に送金リンクが来たら、形式確認ではなく購入として扱う。

FORMAT_IDLE_SECONDS = 600
_formatting = {}                # chat_id -> 最後に受け付けた時刻
# お渡しのメッセージ(_sale_header)の先頭の案内。そのまま貼られたら垢として数えない
_DELIVERY_HEADER = re.compile(
    r"^\s*(?:✅\s*\*?ご購入ありがとうございます|(?:商品|個数|金額|支払い|注文番号)\s*[:：])")


def _format_buttons():
    return [[{"text": "形式確認を終える", "callback_data": "format_end"}]]


def _format_waiting(chat_id) -> bool:
    """形式確認の受け付け中か(10分何も送られなければ終わり)。"""
    at = _formatting.get(chat_id)
    if at is not None and time.time() - at > FORMAT_IDLE_SECONDS:
        _formatting.pop(chat_id, None)
        at = None
    return at is not None


async def _start_format(chat_id):
    _end_selection(chat_id)          # 個数待ちの数字などを、形式確認として読まないように
    _formatting[chat_id] = time.time()
    await _api.send_message(
        chat_id,
        "🔍 X垢の形式確認\n"
        "購入したアカウント情報をこのチャットに貼り付けるか、まとめ買いで届いたファイル"
        "（stock.txt）を送ってください。項目ごとに分けて返します。\n"
        "届いたメッセージをそのまま転送しても大丈夫です。",
        buttons=_format_buttons(), markdown=False)


async def _end_format(chat_id):
    if _formatting.pop(chat_id, None) is not None:
        await _api.send_message(chat_id, "形式確認を終えました。/start で商品一覧に戻れます。",
                                markdown=False)


def _code_blocks(text: str, entities) -> list:
    """メッセージの中のコードブロック(pre)の中身。お渡しを転送・コピーされたとき、在庫は
    コードブロックに入っているので、そこだけを読む(見出しの「ご購入ありがとう…」や
    注文番号を垢として数えない)。entities の位置は UTF-16 の単位で数える。"""
    raw = (text or "").encode("utf-16-le")
    out = []
    for e in entities or []:
        if e.get("type") == "pre":
            start, size = int(e.get("offset", 0)) * 2, int(e.get("length", 0)) * 2
            out.append(raw[start:start + size].decode("utf-16-le", errors="replace"))
    return out


def _has_payment_url(text: str) -> bool:
    """URL の形の送金リンク(PayPay・kyash.me)が入っているか。

    Kyash はコードだけでも受け取れるので、購入の判定(parse_link_and_pass)は / の無い
    文字列もリンク扱いにする。それだとアカウント情報まで購入に回ってしまうので、
    形式確認の受け付け中は URL の形のものだけを送金リンクとみなす。
    """
    return any("/" in t and detect_method(t) for t in (text or "").split())


def _drop_delivery_header(text: str) -> str:
    """お渡しのメッセージを文字だけで貼られたときの、先頭の案内(商品・個数・金額…)を外す。"""
    lines = (text or "").splitlines()
    while lines and (not lines[0].strip() or _DELIVERY_HEADER.match(lines[0])):
        lines.pop(0)
    return "\n".join(lines)


async def _check_format(chat_id, msg: dict):
    """受け付け中に届いた文字・ファイルを、項目ごとに分けて返す。"""
    _formatting[chat_id] = time.time()
    sources, notes = [], []
    text = msg.get("text") or ""
    if text:
        sources += _code_blocks(text, msg.get("entities")) or [_drop_delivery_header(text)]
    doc = msg.get("document")
    if doc:
        name = doc.get("file_name") or "ファイル"
        data = None
        if int(doc.get("file_size") or 0) > shop.FORMAT_MAX_FILE_BYTES:
            notes.append(f"⚠️「{name}」は大きすぎるため読みませんでした。")
        elif (data := await _api.download_file(doc.get("file_id"))) is None:
            notes.append(f"⚠️「{name}」を読み込めませんでした。")
        elif (content := shop.decode_format_file(data)) is None:
            notes.append(f"⚠️「{name}」はテキストファイルではないため読みませんでした。")
        else:
            sources.append(content)
    result = shop.format_breakdown(*sources)
    note = "".join(f"{n}\n" for n in notes)
    if not result:
        return await _api.send_message(
            chat_id, note + "読み取れませんでした。購入時に届いた内容を貼り付けるか、"
            "届いたファイルを送ってください。", buttons=_format_buttons(), markdown=False)
    count = result.count("件目】")
    head = "🔍 形式確認の結果" + (f"（{count}件）" if count else "") + "\n" + note
    body = f"{head}\n{result}"
    if len(body) <= TG_TEXT_LIMIT:
        # 値に * や _ が入る(トークン等)ので、Markdown にせずそのまま出す
        await _api.send_message(chat_id, body, buttons=_format_buttons(), markdown=False)
    else:
        await _api.send_document(chat_id, "x_format.txt", result.encode("utf-8"),
                                 caption=(head + "長いので、結果をファイルにまとめました。")[:1000],
                                 buttons=_format_buttons())


# ====================== 受信の振り分け ======================

async def _show_catalog(chat_id):
    text, buttons, _sig = render_catalog()
    # 本文に商品名を全部出し(折り返すので切れない)、ボタンは番号＋値段＋在庫。
    # 説明文は運営者が設定した文をそのまま(Markdownにしない)。記号で崩れないように。
    res = await _api.send_message(chat_id, text, buttons=buttons, markdown=False)
    msg = res.get("result") if isinstance(res, dict) else None
    if msg and msg.get("message_id"):
        # このチャットの最新パネルとして覚える(以後、在庫が動いたら編集して更新する)。
        _panels[str(chat_id)] = int(msg["message_id"])
        _save_panels()
    # _last_sig はここでは変えない。変えると、在庫が動いてから次の更新までの間に
    # 誰かが一覧を開いただけで「もう反映済み」扱いになり、ほかの人のパネルが古いまま残る。


async def _edit_to_catalog(chat_id, message_id) -> bool:
    """そのメッセージを、いまの商品一覧に書き換える。書き換えられたら True。"""
    text, buttons, _sig = render_catalog()
    res = await _api.edit_message(chat_id, message_id, text,
                                  buttons=buttons if buttons is not None else [],
                                  markdown=False)
    return bool(res.get("ok")) or "not modified" in str(res.get("description") or "").lower()


def _track_panel(chat_id, message_id):
    """このチャットで使っているパネルとして覚える(以後、在庫が動いたらこれを更新する)。"""
    if _panels.get(str(chat_id)) != int(message_id):
        _panels[str(chat_id)] = int(message_id)
        _save_panels()


def _showing_prompt(chat_key, message_id) -> bool:
    """そのパネルが、いま個数入力の画面になっているか(なっていれば自動更新で上書きしない)。"""
    try:
        sel = _selecting.get(int(chat_key))
    except (TypeError, ValueError):
        return False
    return bool(sel) and sel.get("msg") == message_id


async def _restore_panel(chat_id, message_id):
    """個数入力の画面にしていたパネルを、商品一覧に戻す。"""
    for _ in range(3):
        if (_selecting.get(chat_id) or {}).get("msg") == message_id:
            return      # その間に、同じパネルでまた商品が選ばれた
        sig = render_catalog()[2]
        await _edit_to_catalog(chat_id, message_id)
        if render_catalog()[2] == sig:
            return      # 書き換えている間に在庫が動いていなければ、これで最新
        # 動いていたら書き直す(自動更新の編集より後に届いて、古い在庫が残らないように)


def _end_selection(chat_id, sel=None):
    """選んでいた商品をやめる(買い終わった・やめた等)。パネルを個数入力の画面に
    していたら、一覧に戻す。

    sel を渡したときは、それがまだ選択中のときだけやめる(支払いの確認中に別の商品が
    選ばれていたら、そちらは残す)。"""
    if sel is not None and _selecting.get(chat_id) is not sel:
        return
    sel = _selecting.pop(chat_id, None)
    if sel and sel.get("msg"):
        _spawn(_restore_panel(chat_id, sel["msg"]))


async def _back_to_menu(chat_id, message_id=None):
    """「◀ 商品一覧に戻る」。選んでいた商品をやめて、元のパネルに戻す(新しく出さない)。

    ふつうはパネルそのものを個数入力の画面にしているので、同じメッセージを一覧に
    書き戻す。パネルとは別に送った個数の案内(パネルを書き換えられなかったときや、
    前の版で送ったもの)なら、その案内を消す。上にある元のパネルがそのまま残る。
    """
    sel = _selecting.pop(chat_id, None)
    prompt = (sel or {}).get("msg")
    if prompt and prompt != message_id:
        _spawn(_restore_panel(chat_id, prompt))   # 別のパネルを個数入力にしていたら、それも戻す
    if message_id:
        if message_id == prompt or _panels.get(str(chat_id)) == message_id:
            if await _edit_to_catalog(chat_id, message_id):
                _track_panel(chat_id, message_id)
                return
        else:
            res = await _api.call("deleteMessage", chat_id=chat_id, message_id=message_id)
            if res.get("ok"):
                return
            if await _edit_to_catalog(chat_id, message_id):    # 消せない(古すぎる)ときは一覧に変える
                _track_panel(chat_id, message_id)
                return
    await _show_catalog(chat_id)


def _qty_cap(product: dict) -> int:
    """1回に買える上限。Discord と同じ MAX_QTY と、今の在庫のうち小さいほう。"""
    if product.get("infinite"):
        return int(shop.MAX_QTY)
    return max(0, min(int(shop.MAX_QTY), stock_count(product) or 0))


def _back_button():
    return [[{"text": "◀ 商品一覧に戻る", "callback_data": "back"}]]


async def _send_qty_prompt(chat_id, product, cap: int, message_id=None):
    """個数は入力してもらう(個数のボタンは出さない)。一覧に戻るボタンだけ付ける。

    押されたパネルそのものを個数入力の画面に書き換える(戻ると同じパネルが一覧に戻る)。
    書き換えられなければ、案内を別に送る。"""
    note = shop.availability_note(product) if not product.get("infinite") else ""
    text = (f"「{product.get('name')}」\n"
            f"購入する個数を数字で送ってください（1〜{cap}）。例: 3" + (f"\n{note}" if note else ""))
    sel = _selecting.get(chat_id)
    if message_id and sel is not None:
        # 書き換えの途中で、パネルの自動更新に一覧へ戻されないよう先に印を付ける
        sel["msg"] = int(message_id)
        _track_panel(chat_id, message_id)
        res = await _api.edit_message(chat_id, message_id, text,
                                      buttons=_back_button(), markdown=False)
        if res.get("ok"):
            return
        sel["msg"] = None
    await _api.send_message(chat_id, text, buttons=_back_button(), markdown=False)


async def _on_select(chat_id, token, message_id=None):
    mid, machine, product = resolve_token(token)
    if not product:
        await _api.send_message(chat_id, "商品が見つかりませんでした。/start でやり直してください。")
        return
    cap = _qty_cap(product)
    if cap <= 0:
        await _api.send_message(chat_id, _sold_out_text(product), markdown=False)
        return
    _formatting.pop(chat_id, None)       # 商品を選んだ＝購入に戻った(個数を形式確認として読まない)
    prev = _selecting.get(chat_id)
    # qty は入力されるまで決めない(入れずにリンクを送ると、1個分の金額で多く払う等が起きる)
    _selecting[chat_id] = {"mid": mid, "pid": product["product_id"],
                           "name": product.get("name"), "qty": None, "msg": None}
    if prev and prev.get("msg") and prev["msg"] != message_id:
        _spawn(_restore_panel(chat_id, prev["msg"]))   # 前に個数入力にしたパネルは一覧に戻す
    if str(chat_id) in _support["open"]:
        # 商品を選んだ＝購入に戻った。以後の送金リンクはサポートへ回さず購入として扱う。
        _support["open"].discard(str(chat_id))
        _save_support()
    await _send_qty_prompt(chat_id, product, cap, message_id)


async def _choose_qty(chat_id, n_str: str):
    """個数を決める(ボタン or 数字入力)。決まったら金額(まとめ買い反映済み)を出して
    送金リンクを促す。まとめ買い値下げが効いた個数なら、Discord と同じく1個あたり
    いくら引いたかを合計の下に添える(効いているか分かるように)。"""
    sel = _selecting.get(chat_id)
    if not sel:
        return await _show_catalog(chat_id)
    try:
        n = int(n_str)
    except (TypeError, ValueError):
        return
    product = shop._find_product(shop.load_vending().get(sel["mid"]) or {}, sel["pid"])
    if not product:
        _end_selection(chat_id)
        return await _api.send_message(chat_id, "商品が見つかりませんでした。/start でやり直してください。")
    cap = _qty_cap(product)
    if cap <= 0:
        _end_selection(chat_id)
        return await _api.send_message(chat_id, _sold_out_text(product), markdown=False)
    if not 1 <= n <= cap:
        # Discord と同じく範囲外は断る(勝手に丸めると、パスワードの数字などを
        # 個数と取り違えたときに上限個数で買わせてしまう)。
        stock_note = (f"（在庫 {cap}個）"
                      if not product.get("infinite") and cap < int(shop.MAX_QTY) else "")
        # 一覧の在庫数(取り置き中を含む)より買える数が少ないときは、その理由も添える
        note = shop.availability_note(product) if not product.get("infinite") else ""
        return await _api.send_message(
            chat_id, f"個数は1〜{cap}の数字で送ってください{stock_note}。" + (f"\n{note}" if note else ""),
            markdown=False)
    sel["qty"] = n
    total, regular, off = shop.product_total(product, n)
    # まとめ買い値下げが効いていれば、Discord と同じ文言で内訳を添える。
    discount = (f"まとめ買い値下げで1個あたり {off:,}円引き（通常 ¥{regular:,}）\n"
                if off else "")
    await _api.send_message(
        chat_id,
        f"「{product.get('name')}」 ×{n}個\n"
        f"合計: ¥{total:,}\n"
        f"{discount}\n"
        "この金額の PayPay または Kyash の送金リンクをこのチャットに送ってください。\n"
        "（PayPayでパスワード付きのときは「リンク パスワード」のように続けて送ってください）",
        markdown=False)


DM_ONLY_TEXT = "このBotとの個別チャット（DM）でご利用ください。"


async def _handle_update(update: dict):
    _ensure_support_loaded()
    cq = update.get("callback_query")
    if cq:
        data = cq.get("data") or ""
        chat = (cq.get("message") or {}).get("chat") or {}
        chat_id = chat.get("id")
        # ボタンの読み込み表示を止める返事。待つと、その1往復ぶん次の処理が遅れる
        _spawn(_api.answer_callback(cq.get("id")))
        if chat_id is None:
            return
        if chat.get("type") != "private":
            # 購入もサポートも個別チャットだけ。グループで買わせると、お渡しする在庫
            # (アカウント情報)や送金リンクがグループ全員に見えてしまう。
            await _api.send_message(chat_id, DM_ONLY_TEXT, markdown=False)
            return
        _remember_user(chat_id)
        if data.startswith("b:"):
            await _on_select(chat_id, data[2:], (cq.get("message") or {}).get("message_id"))
        elif data.startswith("q:"):
            await _choose_qty(chat_id, data[2:])
        elif data == "back":
            await _back_to_menu(chat_id, (cq.get("message") or {}).get("message_id"))
        elif data == "menu":
            await _show_catalog(chat_id)
        elif data == "support":
            await _start_support(chat_id, cq.get("from") or {})
        elif data == "support_end":
            await _end_support(str(chat_id))
        elif data == "format":
            await _start_format(chat_id)
        elif data == "format_end":
            await _end_format(chat_id)
        return

    # 編集されたメッセージは扱わない(送金リンクの貼り直しで購入が二重に走らないように)
    msg = update.get("message")
    if not msg:
        return
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    if chat_id is None:
        return
    if _support["chat_id"] and chat_id == _support["chat_id"]:
        return await _on_support_group_message(msg)
    text = (msg.get("text") or "").strip()
    if chat.get("type") != "private":
        cmd = _command(text)
        if cmd == "/setsupport":
            return await _try_link_support(msg)
        if cmd in ("/start", "/shop", "/format"):
            await _api.send_message(chat_id, DM_ONLY_TEXT, markdown=False)
        return

    # ---- 個別チャット(お客さん) ----
    _remember_user(chat_id)          # 在庫追加のお知らせの送り先として覚える
    frm = msg.get("from") or {}
    tg_uid = frm.get("id")
    if text.startswith("/start") or text.startswith("/shop") or text in ("メニュー", "menu"):
        _formatting.pop(chat_id, None)
        return await _show_catalog(chat_id)
    if _command(text) == "/format":
        return await _start_format(chat_id)
    if _format_waiting(chat_id):
        if not _has_payment_url(text):
            return await _check_format(chat_id, msg)
        _formatting.pop(chat_id, None)   # 送金リンクは形式確認でなく、購入として扱う
    if str(chat_id) in _support["open"]:
        # サポート中は、送金リンクも含めて全部サポートへ回す(購入としては扱わない)
        return await _relay_to_support(chat_id, msg)
    if not text:
        return
    # 商品を選んでいるときに個数(「3」「３」「3個」)を送ったら、それを個数として扱う。
    if chat_id in _selecting:
        q = parse_qty(text)
        if q is not None:
            return await _choose_qty(chat_id, str(q))
    link, passcode = parse_link_and_pass(text)
    if link:
        return await _purchase(chat_id, tg_uid, link, passcode)
    # それ以外の文章。選択中なら次にすることを促し、そうでなければ一覧を出す。
    sel = _selecting.get(chat_id)
    if sel and not sel.get("qty"):
        await _api.send_message(
            chat_id, "購入する個数を数字で送ってください（例: 3）。/start で一覧に戻れます。",
            markdown=False)
    elif sel:
        await _api.send_message(
            chat_id, "PayPay または Kyash の送金リンクを送ってください。"
            "個数を変えるときは数字を送り直してください。/start で一覧に戻れます。",
            markdown=False)
    else:
        await _show_catalog(chat_id)


# ====================== 起動 ======================

async def _safe_handle(up: dict):
    try:
        await _handle_update(up)
    except Exception as e:
        log.exception("Telegram update 処理でエラー: %s", e)


async def _poll_loop():
    offset = 0
    log.info("Telegram 自販機を開始しました。")
    while True:
        try:
            updates = await _api.get_updates(offset)
            for up in updates:
                offset = max(offset, int(up.get("update_id", 0)) + 1)
                # 1件ずつ別タスクで処理する。支払いの受け取りは保留で最大数分
                # 待つことがあり、順番に await するとその間ポーリングが止まって
                # 他のお客さんをさばけなくなる(Discord と違い自前ループのため)。
                asyncio.create_task(_safe_handle(up))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            log.warning("Telegram ロングポーリングでエラー: %s", e)
            await asyncio.sleep(3)


def start(bot) -> bool:
    """Telegram 自販機を起動する。トークンが無ければ False(Discord だけ動く)。

    main.py の setup_hook から呼ぶ。見張りからのお渡し用に link_orders へ
    ハンドラを登録し、ロングポーリングのタスクを立てる。
    """
    global _api, _bot
    if not configured():
        log.info("TELEGRAM_BOT_TOKEN が未設定のため、Telegram 自販機は起動しません。")
        return False
    _bot = bot
    _api = TelegramAPI(TOKEN)
    _load_panels()      # 再起動前に出したパネルを引き継いで、引き続き更新する
    _load_support()     # サポート窓口とお客さんごとのトピックも引き継ぐ
    _load_users()       # 在庫追加のお知らせの送り先
    # 保留から遅れて承認された入金で、取り置いた在庫を Telegram へお渡し(期限切れは戻す)。
    link_orders.register_handler(KIND, tg_deliver, on_expire=tg_release)
    asyncio.create_task(_poll_loop())
    asyncio.create_task(_refresh_loop())   # 在庫などの変化をパネルに反映し続ける
    return True
