"""取引履歴を月ごとに足して、入出金の合計を出す。

history_view は1件ずつ並べるだけなので、「今月いくら出て、いくら入ったか」
はこちらで出す。数字が合っていないレポートは無いより悪いので、

  - 残高が動いていない取引(失敗・取り消し)は足さない
  - 金額を読めなかった行は0円として足さず、件数で出す
  - 入りか出か決められない取引は、どちらにも寄せず合計から外す
  - 履歴が月の頭まで届いていなければ、そう書く

内訳の合計は必ず総額と一致する(余りは「その他」に入れる)。

PayPay・Kyash・LTCで違うのは種別の呼び方だけなので、振り分けは
呼び出し側から bucket(entry) -> (向き, 見出し) で渡してもらう。
"""
from datetime import datetime, timedelta, timezone

import discord

JST = timezone(timedelta(hours=9))

IN, OUT = "in", "out"
UNKNOWN = "unknown"       # 合計に入れず、脚注で出す

# コードブロックの等幅で崩れない文字だけ使う。
BAR_FULL = "█"
BAR_WIDTH = 12
MONTHS = 6                # グラフに並べる月の数


def yen(amount) -> str:
    return f"{int(amount):,}円"


def month_key(ts: float) -> str:
    return datetime.fromtimestamp(ts, tz=JST).strftime("%Y-%m")


def month_label(key: str) -> str:
    year, month = key.split("-")
    return f"{year}年 {int(month)}月"


def month_start(key: str) -> float:
    """その月の1日0時(JST)。"""
    year, month = (int(v) for v in key.split("-"))
    return datetime(year, month, 1, tzinfo=JST).timestamp()


def month_shift(key: str, delta: int) -> str:
    year, month = (int(v) for v in key.split("-"))
    index = year * 12 + (month - 1) + delta
    return f"{index // 12:04d}-{index % 12 + 1:02d}"


def recent_months(latest: str, count: int = MONTHS) -> list:
    """latest で終わる連続した月。取引の無い月も飛ばさずに並べる。"""
    return [month_shift(latest, -i) for i in range(count - 1, -1, -1)]


def summarize(entries: list, bucket) -> dict:
    """月ごと・向きごとに足す。{月: {"in": {見出し: 金額}, "out": ..., ...}}"""
    months = {}
    for entry in entries:
        ts = entry.get("ts") or 0
        if not ts:
            continue                # いつの取引か分からないものは月に足せない
        month = months.setdefault(month_key(ts), _empty_month())
        amount = entry.get("amount")
        if amount is None:
            # 0円として足すと総額が静かにずれる。件数だけ数える。
            month["unreadable"] += 1
            continue
        way, label = bucket(entry)
        if way not in (IN, OUT, UNKNOWN):
            continue                # 残高が動いていない(失敗・取り消し・請求)
        side = month[way]
        side[label] = side.get(label, 0) + abs(int(amount))
    return months


def _empty_month() -> dict:
    return {IN: {}, OUT: {}, UNKNOWN: {}, "unreadable": 0}


def _total(side: dict) -> int:
    return sum(side.values())


def _bar(value: int, top: int) -> str:
    if top <= 0 or value <= 0:
        return ""
    return BAR_FULL * max(1, round(value / top * BAR_WIDTH))


def chart_lines(months: dict, keys: list, way: str, money=yen) -> list:
    """月次の棒グラフ。実額も添えるので目分量にならない。"""
    values = [_total(months.get(k, {}).get(way, {})) for k in keys]
    top = max(values) if values else 0
    lines = []
    for key, value in zip(keys, values):
        year, month = key.split("-")
        lines.append(f"{int(month):>2}月 |{_bar(value, top):<{BAR_WIDTH}}| "
                     + (money(value) if value else "－"))
    return lines


def breakdown_lines(side: dict, money=yen) -> list:
    """内訳を多い順に。合計は必ず総額と一致する。"""
    total = _total(side)
    if not total:
        return []
    lines = []
    for label, value in sorted(side.items(), key=lambda kv: -kv[1]):
        share = value / total * 100
        lines.append(f"{label}　**{money(value)}**（{share:.0f}%）")
    return lines


def render(entries: list, *, bucket, month: str = None, way: str = OUT,
           title: str = "利用レポート", money=yen, note: str = "",
           fetched: int = 0, oldest_ts: float = 0.0) -> discord.Embed:
    """1か月ぶんのレポート。

    bucket     entry -> (IN / OUT / UNKNOWN / None, 見出し)
    month      "2026-08"。省略すると取引のあった最新の月
    way        主役にする側(IN / OUT)
    note       いちばん下に添える但し書き(レートなど)
    oldest_ts  取ってきた中で最古の取引時刻。月頭より新しければその旨を書く
    """
    months = summarize(entries, bucket)
    now_month = month_key(datetime.now(tz=JST).timestamp())
    month = month or (max(months) if months else now_month)
    data = months.get(month) or _empty_month()

    out_total, in_total = _total(data[OUT]), _total(data[IN])
    side_name = "出金" if way == OUT else "入金"
    other_name = "入金" if way == OUT else "出金"
    other_total = in_total if way == OUT else out_total

    embed = discord.Embed(
        title=f"{title}　{month_label(month)}",
        color=0xff5a7a if way == OUT else 0x2fb87a,
        timestamp=discord.utils.utcnow())

    keys = recent_months(month)
    embed.add_field(
        name=f"月次（{side_name}）",
        value="```\n" + "\n".join(chart_lines(months, keys, way, money)) + "\n```",
        inline=False)

    lines = breakdown_lines(data[way], money)
    embed.add_field(
        name=f"{side_name}　合計 {money(_total(data[way]))}",
        value="\n".join(lines) if lines else f"この月の{side_name}はありません。",
        inline=False)
    embed.add_field(name=f"同じ月の{other_name}", value=money(other_total),
                    inline=True)
    embed.add_field(name="収支", value=money(in_total - out_total), inline=True)

    # 合計に入らなかった分は脚注1行。大きく出すと毎回そちらに目が行く。
    notes = []
    if data[UNKNOWN]:
        notes.append(f"入出金を判別できない取引 {_total(data[UNKNOWN]):,}円")
    if data["unreadable"]:
        notes.append(f"金額を読めない取引 {data['unreadable']}件")
    if oldest_ts and oldest_ts > month_start(month):
        oldest = datetime.fromtimestamp(oldest_ts, tz=JST)
        notes.append(f"集計は {oldest.month}/{oldest.day} {oldest:%H:%M} 以降のぶんだけ")
    if notes:
        embed.add_field(name="合計に入れていないもの", value=" ／ ".join(notes),
                        inline=False)
    if note:
        embed.add_field(name="補足", value=note, inline=False)

    embed.set_footer(text=f"直近{fetched}件の履歴から集計"
                          if fetched else "取引履歴から集計")
    return embed


def months_with_data(entries: list, bucket) -> list:
    """取引のあった月を新しい順に。月を送るボタンの行き先に使う。"""
    return sorted(summarize(entries, bucket), reverse=True)


class ReportView(discord.ui.View):
    """出金/入金の切り替えと月送り。履歴は持っている分で切り替える。"""

    def __init__(self, entries: list, *, bucket, title: str = "利用レポート",
                 money=yen, note: str = "", fetched: int = 0,
                 oldest_ts: float = 0.0, month: str = None, way: str = OUT,
                 timeout: float = 300):
        super().__init__(timeout=timeout)
        self.entries = entries
        self.bucket = bucket
        self.title = title
        self.money = money
        self.note = note
        self.fetched = fetched
        self.oldest_ts = oldest_ts
        self.way = way
        self.months = months_with_data(entries, bucket) or [
            month_key(datetime.now(tz=JST).timestamp())]
        self.month = month or self.months[0]
        self._sync()

    def embed(self) -> discord.Embed:
        return render(self.entries, bucket=self.bucket, month=self.month,
                      way=self.way, title=self.title, money=self.money,
                      note=self.note, fetched=self.fetched,
                      oldest_ts=self.oldest_ts)

    def older(self):
        """1つ前の「取引のある」月。無ければ None。"""
        found = [m for m in self.months if m < self.month]
        return max(found) if found else None

    def newer(self):
        found = [m for m in self.months if m > self.month]
        return min(found) if found else None

    def _sync(self):
        """ボタンの見た目と可否を今の月・向きに合わせる。

        行き先は取引のある月。ボタンにもその月を書く(暦の前月を書くと、
        取引が無い月を指したまま別の月へ飛ぶ)。
        """
        older, newer = self.older(), self.newer()
        self.prev_month.disabled = older is None
        self.next_month.disabled = newer is None
        self.prev_month.label = f"◀ {month_label(older)}" if older else "◀ これ以前は無し"
        self.next_month.label = f"{month_label(newer)} ▶" if newer else "これ以降は無し ▶"
        self.toggle.label = "入金を見る" if self.way == OUT else "出金を見る"
        self.toggle.style = (discord.ButtonStyle.success if self.way == OUT
                             else discord.ButtonStyle.danger)

    async def _show(self, interaction: discord.Interaction):
        await interaction.response.edit_message(embed=self.embed(), view=self)

    @discord.ui.button(label="◀", style=discord.ButtonStyle.secondary)
    async def prev_month(self, interaction: discord.Interaction, button):
        older = self.older()
        if older:
            self.month = older
            self._sync()
        await self._show(interaction)

    @discord.ui.button(label="▶", style=discord.ButtonStyle.secondary)
    async def next_month(self, interaction: discord.Interaction, button):
        newer = self.newer()
        if newer:
            self.month = newer
            self._sync()
        await self._show(interaction)

    @discord.ui.button(label="入金を見る", style=discord.ButtonStyle.success)
    async def toggle(self, interaction: discord.Interaction, button):
        self.way = IN if self.way == OUT else OUT
        self._sync()
        await self._show(interaction)
