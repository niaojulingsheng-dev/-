# 動かしている場所と、ふだんの操作

Bot は **XServer VPS クラウド**(4GB、Ubuntu 24.04)の上で、**Coolify** という管理画面から動かしている。

| もの | 場所 |
|---|---|
| Coolify の管理画面 | https://coolify.bbtwi.com(2段階認証あり) |
| Bot の公開 URL(認証パネルのコールバック) | https://auth.bbtwi.com → コンテナの 8080 番 |
| 永続データ(`DATA_DIR=/data`) | サーバーの `/srv/nyan/data` をコンテナの `/data` に割り当て |
| サーバーの操作 | XServer の VPS パネル → コンソール(シリアルコンソール)、または Coolify の Terminal |
| DNS | XServer の VPS パネル → DNS設定(`bbtwi.com`) |
| 通り道(ファイアウォール) | VPS パネル → パケットフィルター `coolify`(80・443・8000・6001・6002) |

## ふだんの操作

| やりたいこと | どこで |
|---|---|
| コードを反映 | `main` に push(マージ)すると Coolify が自動でビルドして入れ替える。新旧のコンテナは同時に動かない(Consistent container name) |
| 環境変数を変える | Coolify → アプリ → Environment Variables → Save → Redeploy |
| ログを見る | Coolify → アプリ → Logs |
| 再起動 | Coolify → アプリ → Restart |
| コンテナの中で何か実行 | Coolify → アプリ → Terminal(または VPS のコンソールで `docker exec -it <コンテナ名> …`) |
| データを見る | VPS のコンソールで `/srv/nyan/data` |

環境変数は `DATA_DIR`・`DISCORD_CLIENT_ID`・`DISCORD_TOKEN`・`DISCORD_CLIENT_SECRET`・`OAUTH_REDIRECT_URI`・`TELEGRAM_BOT_TOKEN`。
Bot を止めたいときは Coolify → アプリ → **Stop**(データはそのまま残る)。

## バックアップ

- VPS クラウドの自動バックアップ(毎日・7日分)で、サーバーごと戻せる(VPS パネル → バックアップ)。
- データだけ手で取るなら、コンソールで `tar czf /srv/nyan/backup-$(date +%F).tgz -C /srv/nyan data`。

## 気をつけること

- Coolify は自動アップデートが ON(Settings → Updates)。重大な脆弱性が直されることがあるので切らない。
- Coolify の管理者パスワードと 2 段階認証の回復コードは、なくすと入れなくなる。
- 月額の支払いは XServer アカウントの「料金支払い」。更新日の前にカードの残高を確かめる。
