"""永続データの保存先を1か所(DATA_DIR)に集約するためのヘルパー。

ホスティング先でこのディレクトリを永続ストレージに割り当てれば、
再デプロイ後もデータ(自販機・PayPay登録・NGワード等)が保持される。

- 環境変数 DATA_DIR で保存先を指定(未設定なら ./data)。
- JSONの読み書きは read_json / write_json を使う(壊れたファイルを作らない・
  壊れたファイルを黙って空データとして上書きしない)。
"""
import json
import os
import tempfile
import time

DATA_DIR = os.environ.get("DATA_DIR", "data")
os.makedirs(DATA_DIR, exist_ok=True)


def data_path(name: str) -> str:
    """DATA_DIR 配下のパスを返す。"""
    return os.path.join(DATA_DIR, name)


def write_json(path: str, obj):
    """書き切ってから差し替える(途中で落ちても壊れたファイルを残さない)。

    再デプロイやOOMで書き込みの最中に殺されると、`open(path,"w")` は先に中身を
    消してしまっているので、中途半端なJSONがディスクに残る。読み手はそれを
    「空データ」として扱うため、次の保存でその空データがそのまま書き戻され、
    設定(ログ送信先・購入時ロール・自販機の中身など)が消える。
    テンポラリに書き切ってから os.replace で差し替えれば、どの瞬間に落ちても
    新旧どちらかの完全なファイルが必ず残る。

    一時ファイルは書き込みごとにユニークな名前にする。固定名(`path.tmp`)だと、
    同じファイルへ同時に書く処理(例: にゃんことツムツムのバージョン監視)が
    互いのテンポラリを奪い合い、差し替えのときに「.tmpが無い」で片方が失敗する。
    同じディレクトリに作るので os.replace は変わらずアトミック。
    """
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(
        prefix=os.path.basename(path) + ".", suffix=".tmp", dir=directory)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=4, ensure_ascii=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        # 差し替え前に失敗したら中途半端なテンポラリを残さない
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise


def read_json(path: str, default):
    """JSONを読む。無ければ default、壊れていれば退避してから default。

    壊れたファイルをそのまま置いておくと、次の保存で「空データ」に上書きされて
    中身が永久に失われる。読めなかったファイルは `.broken-<時刻>` に改名して
    残し、目に見えるログを出す(後から手で救出できるようにする)。
    default が dict/list のときは、型が違う中身も default として扱う。
    """
    fallback = default
    if not os.path.exists(path):
        return fallback
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as e:
        broken = f"{path}.broken-{int(time.time())}"
        try:
            os.replace(path, broken)
        except OSError:
            broken = "(退避できず)"
        print(f"[DATA ERROR] {path} を読めませんでした({e})。{broken} に退避しました。", flush=True)
        return fallback
    except OSError as e:
        # 読み込み自体に失敗(一時的な可能性)。ファイルには触らない。
        print(f"[DATA ERROR] {path} を開けませんでした: {e}", flush=True)
        return fallback

    if fallback is not None and not isinstance(data, type(fallback)):
        print(f"[DATA ERROR] {path} の形式が想定と違います({type(data).__name__})。", flush=True)
        return fallback
    return data
