"""ぷにぷにのステージIDに名前を付ける(表示用)。

ステージIDは <系統><エリア3桁><ステージ3桁> の7〜8桁で、上の桁で系統が分かる。

    1001001 … メイン(日本編) エリア1(さくら住宅街) ステージ1
    1002001 … メイン エリア2(おおもり山) の1つ目(=通しのステージ16)
    1901001 … 19xx 系(うらルートと推定)
    5001001 … 5xxx 系(サブ)
    2880001 / 2890001 … 強敵      2900001 … 夜叉
    29701001 … イベント(8桁)。297 がイベント、01 がブロック(会場)、001 がステージ

メインのエリア名・ステージ数・かくしステージ数は game8 の全ステージ一覧
(https://game8.jp/punipuni/43447 と各エリアの詳細ページ)から取り、
puni_stage_names.json に持つ。エリア内は「通常ステージ → かくしステージ」の順で
IDが振られている(実データ: さくら住宅街は 15+かくし1 = 1001001〜1001016)。

周回するステージはお客さんに選ばせず、ログイン後に垢のデータから決める
(puni_daiko.PuniRunner.pick_farm_stage)。ここは確認画面・DM・ログで
「1002001（おおもり山 ステージ16）」のように読める名前を添えるためだけにある。
イベントのステージ名はゲームのマスタから取れていないので、IDの位置から
「イベント297 会場1 ステージ13」と表す。
"""
import json
import os

NAMES_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "puni_stage_names.json")

# 系統。
CAT_MAIN = "main"        # メインステージ(日本編・USA編)
CAT_URA = "ura"          # 19xx 系(うらルートと推定)
CAT_WORLD2 = "world2"    # 20xx 系(未確認。USA編の可能性)
CAT_SUB = "sub"          # 5xxx 系
CAT_STRONG = "strong"    # 強敵 2880/2890
CAT_YASHA = "yasha"      # 夜叉 2900
CAT_EVENT = "event"      # イベント(8桁)
CAT_OTHER = "other"

CATEGORY_LABELS = {
    CAT_MAIN: "メインステージ",
    CAT_EVENT: "イベントステージ",
    CAT_URA: "うらルート（19xx系）",
    CAT_SUB: "サブステージ（5xxx系）",
    CAT_STRONG: "強敵ステージ",
    CAT_YASHA: "夜叉ステージ",
    CAT_WORLD2: "20xx系（USA編？）",
    CAT_OTHER: "その他",
}

EVENT_ID_MIN = 10_000_000

_NAMES = None


def _names() -> dict:
    global _NAMES
    if _NAMES is None:
        try:
            with open(NAMES_FILE, encoding="utf-8") as f:
                _NAMES = json.load(f)
        except Exception:
            _NAMES = {"areas": []}
    return _NAMES


def areas() -> list:
    """メインのエリア一覧(番号順)。各要素 {no,name,world,boss,stages,hidden,prefix}。"""
    out = []
    for a in _names().get("areas") or []:
        item = dict(a)
        item["prefix"] = 1000 + int(a["no"])       # 1001, 1002, …
        out.append(item)
    return out


def area_stage_ids(area: dict) -> list:
    """そのエリアの全ステージID(通常 → かくし の順)。"""
    p = int(area["prefix"]) * 1000
    n = len(area.get("stages") or [])
    h = len(area.get("hidden") or [])
    return [p + i for i in range(1, n + h + 1)]


def main_stage_id(global_no: int):
    """通しのステージ番号(1〜425)からメインのステージIDを引く。無ければ None。"""
    try:
        g = int(global_no)
    except (TypeError, ValueError):
        return None
    for a in areas():
        for idx, (no, _enemies) in enumerate(a.get("stages") or [], 1):
            if int(no) == g:
                return int(a["prefix"]) * 1000 + idx
    return None


def main_stage_count() -> int:
    return sum(len(a.get("stages") or []) for a in areas())


def _main_entry(sid: int):
    """メインのIDを (エリア, 種別, 表示番号, 出現妖怪) に分解する。該当なしは None。"""
    area_prefix, idx = divmod(int(sid), 1000)
    for a in areas():
        if a["prefix"] != area_prefix:
            continue
        stages = a.get("stages") or []
        hidden = a.get("hidden") or []
        if 1 <= idx <= len(stages):
            no, enemies = stages[idx - 1]
            return a, "stage", int(no), enemies
        if len(stages) < idx <= len(stages) + len(hidden):
            no, enemies = hidden[idx - len(stages) - 1]
            return a, "hidden", int(no), enemies
        return a, "unknown", idx, ""
    return None


def category_of(sid) -> str:
    try:
        n = int(sid)
    except (TypeError, ValueError):
        return CAT_OTHER
    if n >= EVENT_ID_MIN:
        return CAT_EVENT
    if 2_880_000 <= n < 2_900_000:          # 2880xxx / 2890xxx
        return CAT_STRONG
    if 2_900_000 <= n < 2_901_000:          # 2900xxx
        return CAT_YASHA
    if 1_000_000 <= n < 1_900_000:
        return CAT_MAIN
    if 1_900_000 <= n < 2_000_000:
        return CAT_URA
    if 2_000_000 <= n < 2_100_000:
        return CAT_WORLD2
    if 5_000_000 <= n < 6_000_000:
        return CAT_SUB
    return CAT_OTHER


def stage_label(sid) -> str:
    """お客さんに見せる短い名前。分からなければ系統とIDの位置で表す。"""
    try:
        n = int(sid)
    except (TypeError, ValueError):
        return str(sid)
    cat = category_of(n)
    if cat == CAT_MAIN:
        e = _main_entry(n)
        if e is not None:
            a, kind, no, _enemies = e
            if kind == "stage":
                return f"{a['name']} ステージ{no}"
            if kind == "hidden":
                return f"{a['name']} かくしステージ{no}"
            return f"{a['name']} {n % 1000}番目"
        return f"メイン {n // 1000}系 {n % 1000}"
    if cat == CAT_EVENT:
        ev, rest = divmod(n, 100_000)
        block, no = divmod(rest, 1000)
        return f"イベント{ev} 会場{block} ステージ{no}"
    if cat == CAT_URA:
        return f"うらルート {n // 1000 - 1900}-{n % 1000}"
    if cat == CAT_SUB:
        return f"サブ {n // 1000}-{n % 1000}"
    if cat == CAT_STRONG:
        return f"強敵 {n // 1000}-{n % 1000}"
    if cat == CAT_YASHA:
        return f"夜叉 {n // 1000}-{n % 1000}"
    if cat == CAT_WORLD2:
        return f"20xx系 {n // 1000}-{n % 1000}"
    return str(n)


def describe(sid) -> str:
    """注文確認などに添える「ID（名前）」の1行。名前が分からなければIDだけ。"""
    label = stage_label(sid)
    if label == str(sid):
        return str(sid)
    return f"{sid}（{label}）"
