import sys, os, re, json, asyncio, secrets, time, hmac, hashlib, requests, threading, http.server, shutil, typing, uuid, traceback
from pathlib import Path
from datetime import datetime, timezone, timedelta

try:
    local_core_data = Path("./core_data")
    if local_core_data.exists():
        home = Path(os.environ.get("HOME") or Path.home())
        target_dirs = []
        if os.name == "nt":
            target_dirs.append(Path(os.environ.get("USERPROFILE", str(home))) / "Documents" / "bcsfe")
        else:
            xdg = os.environ.get("XDG_DATA_HOME")
            target_dirs.append((Path(xdg) if xdg else home / ".local" / "share") / "bcsfe")
            target_dirs.append(home / "Documents" / "bcsfe")

        for target in target_dirs:
            try:
                target.mkdir(parents=True, exist_ok=True)
                shutil.copytree(local_core_data, target, dirs_exist_ok=True)
                # 「取得済み」の印は同梱のバージョンにだけ付ける。置き場の全部に付けると、
                # 途中で止まった取り寄せ(未完成のディレクトリ)まで取得済みに見えてしまう。
                for ver_dir in (local_core_data / "game_data").glob("*/*"):
                    if ver_dir.is_dir():
                        mirrored = target / "game_data" / ver_dir.parent.name / ver_dir.name
                        if mirrored.is_dir():
                            (mirrored / "downloaded").touch(exist_ok=True)
                print(f"🔥 [SUCCESS] bcsfe読込前に core_data を配置しました: {target}", flush=True)
            except Exception:
                pass
except Exception as e:
    print(f"❌ [ERROR] core_data 物理コピーの全体エラー: {e}", flush=True)

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks
from dotenv import load_dotenv

from datapath import data_path, read_json, write_json
from utils import notify_payment_pending

# 統合版 /profit で自販機の売上データも参照する
from Cogs.shop import (
    load_shop_sales as shop_load_sales,
    load_vending as shop_load_vending,
    machine_autocomplete as shop_machine_autocomplete,
)

from bcsfe import core

# bcsfe のゲームデータ(キャラ名・図鑑・unitbuy)の置き場を、永続ディレクトリ(DATA_DIR)の
# 下にする。既定の置き場(~/.local/share/bcsfe)はコンテナの再起動で消えるので、取り寄せた
# 新しいデータが起動のたびに無くなり、毎回取り寄せ直していた(その都度「更新しました」
# の通知も飛んでいた)。同梱のバージョンもここへ写しておく(bcsfe は置き場に無い
# バージョンを配布所へ取りに行こうとする)。
GAME_DATA_DIR = data_path("bcsfe_game_data")


def _prepare_game_data_dir():
    try:
        os.makedirs(GAME_DATA_DIR, exist_ok=True)
        core.set_game_data_path(core.Path(GAME_DATA_DIR))
        for ver_dir in Path("./core_data/game_data").glob("*/*"):
            if not ver_dir.is_dir():
                continue
            mirrored = Path(GAME_DATA_DIR) / ver_dir.parent.name / ver_dir.name
            if (mirrored / "downloaded").exists():
                continue          # 写し済み(毎回 40MB を写し直さない)
            shutil.copytree(ver_dir, mirrored, dirs_exist_ok=True)
            (mirrored / "downloaded").touch()
            print(f"[gdata] 同梱のゲームデータ {ver_dir.name} を {mirrored} に写しました", flush=True)
    except Exception as e:
        print(f"❌ [gdata] ゲームデータの置き場を用意できません: {e}", flush=True)


_prepare_game_data_dir()

from bcsfe.core.game.catbase.cat import Talent
from bcsfe.core.game.gamoto.base_materials import Material
from bcsfe.core.game.gamoto.gamatoto import Helper, Helpers
from bcsfe.core.game.catbase.playtime import PlayTime
from bcsfe.core.game.catbase.nyanko_club import NyankoClub
from bcsfe.core.game.battle.enemy import EnemyDictionary

sys.stdout.reconfigure(line_buffering=True); sys.stderr.reconfigure(line_buffering=True)
sys.modules['audioop'] = type('audioop', (object,), {'mul': lambda *a: None, 'max': lambda *a: None})

try:
    core.core_data.init_data()
except Exception as e:
    print(f"❌ [ERROR] bcsfe core_data 初期化失敗: {e}", flush=True)

try:
    core.core_data.config.set(core.ConfigKey.MAX_BACKUPS, 0)
except:
    pass
try:
    core.core_data.config.set(core.ConfigKey.UNLOCK_CAT_ON_EDIT, False)
except:
    pass

import link_orders
import payment_attempts
import payments
import panels
import risk
import support

load_dotenv()

# ツムツム代行の売上を /profit で見るためだけに読む(実体は Cogs/tsum.py)。
# ゲームのバージョンを .env から取るので、必ず load_dotenv の後に読む。
import tsum_daiko

TKN = os.getenv("DISCORD_TOKEN") or os.getenv("TOKEN")
GV = "15.5.0"
# 代行代金を受け取るアカウントのキー(本垢)。受取先は支払い方法ごとに1つへ固定する。
MY_USER_ID = 1421704357983813744
# 管理者コマンドを使えるユーザー(本垢・サブ垢)。
ADMIN_IDS = {MY_USER_ID, 1483116477698539670, 1525688835751809216}

def is_admin(uid: int) -> bool:
    return uid in ADMIN_IDS

# 商品ごとの価格が未設定のときのデフォルト料金(円)。
DAIKO_PRICE = int(os.getenv("DAIKO_PRICE", "50"))

# 商品(項目)ごとの価格を保存するファイル。 {item_key: price}
PRICES_FILE = data_path("prices.json")

def load_prices() -> dict:
    return read_json(PRICES_FILE, {})

def save_prices(data: dict):
    write_json(PRICES_FILE, data)

def get_price(key: str) -> int:
    """商品1つの価格。未設定ならデフォルト(DAIKO_PRICE)。"""
    return int(load_prices().get(key, DAIKO_PRICE))

def get_total_price(keys: list[str]) -> int:
    """選択された全商品の合計金額。"""
    prices = load_prices()
    return sum(int(prices.get(k, DAIKO_PRICE)) for k in keys)

def compute_total(opts: list[str], spec_ids=None) -> int:
    """合計金額。指定キャラ系は指定したキャラの体数分を課金する。"""
    return sum(compute_item_prices(opts, spec_ids).values())

def compute_item_prices(opts: list[str], spec_ids=None) -> dict:
    """商品ごとの課金額 {key: 円}。指定キャラ系は体数分(最低1体)。"""
    prices = load_prices()
    n = len(spec_ids) if spec_ids else 0
    out = {}
    for k in opts:
        price = int(prices.get(k, DAIKO_PRICE))
        out[k] = price * max(n, 1) if k in CAT_ID_OPTS else price
    return out

# --- セット商品(複数の代行項目を1つの固定価格でまとめ売り) -----------------
# 客単価を上げるための束売り。中身(opts)と価格を管理者が決め、最大5個まで置ける。
# 買われたら通常の代行と同じ流れ(ログイン→前提判定→支払い→セーブ編集)に乗せ、
# 売上は「1件=1セット」で記録する(個別項目の単価には割らない)ので、/profit に
# セットが1行で出て客単価が見える。
SETS_FILE = data_path("daiko_sets.json")
SET_MAX = 5                       # 置けるセットの数の上限

def load_sets() -> list:
    data = read_json(SETS_FILE, [])
    return data if isinstance(data, list) else []

def save_sets(sets: list):
    write_json(SETS_FILE, sets)

def get_set(set_id: str):
    return next((s for s in load_sets() if s.get("id") == set_id), None)

def set_sale_key(name: str) -> str:
    """売上台帳・/profit で1行にまとめるためのキー(名前で見えるようにする)。"""
    return f"セット:{name}"

def set_selectable_opts() -> list:
    """セットに入れられる項目 [(cat_key, opt_key, label), ...]。

    指定キャラ系(unlock/upgrade/true_form の specific)は体数で課金するため、
    固定価格のセットには入れられない。ここで最初から除いておく。
    """
    out = []
    excluded = set(CAT_ID_OPTS) | set(ACCOUNT_RESET_OPTS)   # 体数課金・新コード発行系は除く
    for cat_key, (emoji, name, desc, opts) in CATEGORIES.items():
        for k, l in opts:
            if k not in excluded:
                out.append((cat_key, k, l))
    return out

def set_price_reference(opts: list[str]) -> int:
    """セットの中身を個別に買ったときの合計(値付けの目安として見せる)。"""
    prices = load_prices()
    return sum(int(prices.get(k, DAIKO_PRICE)) for k in opts if k not in CAT_ID_OPTS)

# 各種設定(代行ログの送信先チャンネルなど)を保存するファイル。
CONFIG_FILE = data_path("config.json")

def load_config() -> dict:
    return read_json(CONFIG_FILE, {})

def save_config(data: dict):
    write_json(CONFIG_FILE, data)

# Botのステータス(プレイ中表示)。on_ready/on_resumed の両方でこの値を使い、
# 再接続のたびに固定文言へ戻ってしまう問題を防ぐ。/status で実行時変更・永続化できる。
DEFAULT_STATUS_TEXT = os.getenv("BOT_STATUS", "仕事中")
STATUS_TYPES = {
    "playing": discord.ActivityType.playing,
    "watching": discord.ActivityType.watching,
    "listening": discord.ActivityType.listening,
    "competing": discord.ActivityType.competing,
}

def get_status() -> dict:
    """現在のステータス設定 {"text","type"}。config優先→既定。"""
    cfg = load_config()
    return {
        "text": cfg.get("status_text", DEFAULT_STATUS_TEXT),
        "type": cfg.get("status_type", "playing"),
    }

def set_status(text: str = None, type_: str = None):
    cfg = load_config()
    if text is not None:
        cfg["status_text"] = text
    if type_ is not None:
        cfg["status_type"] = type_
    save_config(cfg)

def build_activity() -> discord.Activity:
    st = get_status()
    atype = STATUS_TYPES.get(st["type"], discord.ActivityType.playing)
    return discord.Activity(type=atype, name=st["text"])

async def apply_presence():
    """設定に基づいてBotのプレゼンスをセットする。全ての設定箇所はこれを使う。"""
    try:
        await bot.change_presence(status=discord.Status.online, activity=build_activity())
    except Exception as e:
        print(f"[PRESENCE ERROR] {e}", flush=True)

# にゃんこ大戦争のゲームバージョン。ゲーム更新でPONOSのセーブ転送APIが弾くように
# なっても、再デプロイ不要で追従できるようにする。
# 通常はバックグラウンドの自動チェック(VERSION_CHECK_INTERVAL_HOURS間隔)が
# App Storeの最新版を検知して自動更新し、/nyanko_version で手動確認・上書きもできる。
NYANKO_APPSTORE_ID = os.getenv("NYANKO_APPSTORE_ID", "547145938")  # にゃんこ大戦争(JP)
VERSION_CHECK_INTERVAL_HOURS = float(os.getenv("VERSION_CHECK_INTERVAL_HOURS", "1"))

def get_game_version() -> str:
    """使用するゲームバージョン。config優先→環境変数→既定(GV)。"""
    v = load_config().get("nyanko_version")
    if v:
        return str(v)
    return os.getenv("NYANKO_VERSION", GV)

def set_game_version(version: str):
    cfg = load_config()
    cfg["nyanko_version"] = str(version)
    save_config(cfg)

def version_tuple(v: str):
    """'15.6.0' → (15, 6, 0)。比較用。数字以外が混じる場合は0扱い。"""
    parts = []
    for p in str(v).split("."):
        m = re.match(r"\d+", p.strip())
        parts.append(int(m.group()) if m else 0)
    return tuple(parts)

def is_newer_version(candidate: str, current: str) -> bool:
    """candidate が current より新しいなら True(桁数違いは0埋めで比較)。"""
    a, b = version_tuple(candidate), version_tuple(current)
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)) > b + (0,) * (n - len(b))

def get_version_check_state() -> dict:
    """自動チェックの記録(最終チェック時刻・最終更新の内容)を返す。"""
    return load_config().get("nyanko_version_check", {}) or {}

def _record_version_check(latest, updated_from=None, updated_to=None):
    cfg = load_config()
    st = cfg.setdefault("nyanko_version_check", {})
    st["last_checked_at"] = time.time()
    st["last_seen_latest"] = latest
    if updated_to:
        st["last_updated_at"] = time.time()
        st["last_updated_from"] = updated_from
        st["last_updated_to"] = updated_to
    save_config(cfg)

def fetch_latest_game_version():
    """App Storeから最新のゲームバージョンを取得する(ブロッキング/失敗時None)。"""
    try:
        r = requests.get("https://itunes.apple.com/lookup",
                         params={"id": NYANKO_APPSTORE_ID, "country": "jp"}, timeout=15)
        j = r.json()
        if j.get("resultCount"):
            return j["results"][0].get("version")
    except Exception as e:
        print(f"[VERSION FETCH ERROR] {e}", flush=True)
    return None

def check_and_update_game_version() -> dict:
    """最新版を取得し、現在より新しければ自動でバージョンを切り替える(ブロッキング)。

    戻り値: {"latest", "current", "updated"(bool), "before"}
    latest が None のときは取得失敗(何もしない)。
    古いバージョンへは下げない(手動で新しめに設定した場合を尊重するため)。
    """
    current = get_game_version()
    latest = fetch_latest_game_version()
    if not latest:
        return {"latest": None, "current": current, "updated": False, "before": current}
    if is_newer_version(latest, current):
        set_game_version(latest)
        _record_version_check(latest, updated_from=current, updated_to=latest)
        print(f"[VERSION] auto-updated {current} -> {latest}", flush=True)
        return {"latest": latest, "current": latest, "updated": True, "before": current}
    _record_version_check(latest)
    return {"latest": latest, "current": current, "updated": False, "before": current}


# --- ゲームデータ(キャラ名・図鑑・unitbuy)の自動更新 ------------------------
# 同梱の core_data は 15.5.0(871体)。新しいコラボのキャラはそれより後のIDなので、
# 同梱のままだと「キャラID検索」に出ず、解放でも「図鑑に無いキャラ」として扱われて
# いた(指定しても解放されず、全キャラ解放ではエラーキャラ扱いで消していた)。
# bcsfe が使う配布所(BCData の metadata.json)にある、いちばん新しい jp のデータを
# 取り寄せて bcsfe のデータ置き場に入れる(起動後すぐと、バージョン確認の周期ごと)。
# セーブごとに、そのセーブのバージョンに合うデータを bcsfe に使わせる
# (ensure_game_data_for。bcsfe は最初に読んだセーブのバージョンのまま使い続ける)。
GAME_DATA_CC = "jp"
GAME_DATA_STATE_KEY = "nyanko_game_data"
# 直近の取り寄せ確認の結果(表示用。設定ファイルには取り寄せたときだけ書く)。
GAME_DATA_LAST_CHECK = {}
# セーブの編集は1件ずつ。bcsfe のゲームデータ(図鑑・unitbuy・ドロップの表)は
# プロセスで1つを共有していて、別のセーブ(別バージョン)の編集や取り寄せが途中で
# 差し替えると、図鑑の範囲が食い違う(新しいキャラを「データ未対応」と見誤る)。
EDIT_LOCK = threading.RLock()
# bcsfe が「最初に読んだセーブ」に結びつけて持つ表。ドロップの表(CharaDrop)は
# そのセーブへ書き込む(unlock_drops_from_cat_id)ので、別のお客さんのセーブに
# 書いてしまっていた。セーブごとに作り直す。
BCSFE_SAVE_CACHES = ("gatya_item_names", "gatya_item_buy", "chara_drop",
                     "gamatoto_levels", "gamatoto_members_name", "localizable", "abilty_data",
                     "enemy_names", "rank_gift_descriptions", "rank_gifts", "treasure_text",
                     "cat_shrine_levels", "medal_names", "mission_names", "mission_conditions")


def _bcsfe_cc():
    return core.CountryCode.from_code(GAME_DATA_CC)


def downloaded_game_data_versions() -> list:
    """bcsfe のデータ置き場にある jp のバージョン(文字列・古い順)。"""
    try:
        versions = core.GameDataGetter.get_downloaded_versions_region(_bcsfe_cc())
    except Exception as e:
        print(f"[gdata] 取得済みのバージョンを読めません: {e}", flush=True)
        return []
    versions.sort()
    return [v.to_string() for v in versions]


def newest_downloaded_game_data():
    versions = downloaded_game_data_versions()
    return versions[-1] if versions else None


def fetch_game_data_metadata():
    """配布所の一覧 (書庫の置き場のURL, {jpのバージョン: 書庫のパス})。届かなければ None。"""
    try:
        # show_alt=False: 届かないときに bcsfe が端末で「別の配布所を使うか」と聞くのを止める
        meta = core.GameDataGetter.get_metadata(show_alt=False)
    except Exception as e:
        print(f"[gdata] 配布所の一覧を読めません: {e}", flush=True)
        return None
    if not meta:
        return None
    base_url = str(meta.get("base_url") or "")
    cc_versions = core.GameDataGetter.get_versions(meta).get(GAME_DATA_CC) or {}
    if not base_url or not cc_versions:
        return None
    return base_url, dict(cc_versions)


def available_game_data_versions():
    """配布所にある jp のバージョン(文字列・古い順)。届かなければ None。"""
    meta = fetch_game_data_metadata()
    return sorted(meta[1], key=version_tuple) if meta else None


def reset_bcsfe_save_caches():
    """bcsfe がセーブに結びつけて持つ表(BCSFE_SAVE_CACHES)を捨てる。次のセーブで作り直す。"""
    cd = getattr(core, "core_data", None)
    for name in BCSFE_SAVE_CACHES:
        if cd is not None and hasattr(cd, name):
            setattr(cd, name, None)


def reset_bcsfe_game_data_caches(names: bool = True):
    """bcsfe が持っている読み込み済みのゲームデータ(最初に読んだセーブのバージョン)を捨てる。

    次に使うときに、いま手元にあるいちばん合うバージョンで読み直される。
    names=True ならキャラ名の索引も作り直す(新しいデータを取り寄せたとき)。
    """
    cd = getattr(core, "core_data", None)
    if cd is not None and hasattr(cd, "game_data_getter"):
        cd.game_data_getter = None
    reset_bcsfe_save_caches()
    if names:
        global CAT_NAME_INDEX
        CAT_NAME_INDEX = None


def _download_game_data(base_url: str, filepath: str, version: str):
    """書庫を取り寄せて bcsfe のデータ置き場に入れる。失敗の理由を返す(成功なら None)。

    bcsfe の download_version_data と同じ置き方(game_data/jp/<版>/ に展開して
    downloaded の印)だが、
      ・手元に無いバージョンを bcsfe の GameDataGetter で開くと、配布所にもう一度
        問い合わせ、それが落ちると端末で「別の配布所を使うか」と聞いて止まる。
        ここでは取ってある一覧のURLをそのまま使い、対話に入らない
      ・いったん隣の仮ディレクトリに展開し、要の表が揃っているのを確かめてから
        差し替える(途中で止まっても未完成のものが「取得済み」にならない)
    """
    import io
    import tarfile
    import tempfile
    url = base_url + filepath
    try:
        resp = requests.get(url, timeout=120)
    except Exception as e:
        return f"取り寄せに失敗: {type(e).__name__}: {e}"
    if resp.status_code != 200 or not resp.content:
        return f"取り寄せに失敗: HTTP {resp.status_code}"
    cc_dir = Path(core.GameDataGetter.get_game_data_dir().path) / GAME_DATA_CC
    cc_dir.mkdir(parents=True, exist_ok=True)
    final = cc_dir / version
    tmp = Path(tempfile.mkdtemp(prefix=f".{version}.", dir=cc_dir))
    try:
        with tarfile.open(mode="r:xz", fileobj=io.BytesIO(resp.content)) as archive:
            try:
                archive.extractall(tmp, filter="data")
            except TypeError:
                archive.extractall(tmp)
        for must in ("DataLocal/nyankoPictureBookData.csv", "DataLocal/unitbuy.csv"):
            if not (tmp / must).exists():
                raise RuntimeError(f"{must} が書庫にありません")
        if final.exists():
            shutil.rmtree(final)
        os.replace(tmp, final)
        (final / "downloaded").touch()
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        return f"展開に失敗: {type(e).__name__}: {e}"
    return None


# 取り寄せたゲームデータを新しい順にいくつ残すか。置き場は永続領域なので、
# 残し続けると更新のたびに 40MB ほど増える。同梱のバージョンは数えず、消さない。
GAME_DATA_KEEP = 2


def _prune_game_data(keep: int = GAME_DATA_KEEP):
    """取り寄せた古いバージョンを消す。EDIT_LOCK の中で呼ぶ(編集の途中で消さない)。"""
    bundled = {d.name for d in Path("./core_data/game_data").glob(f"{GAME_DATA_CC}/*") if d.is_dir()}
    fetched = [v for v in downloaded_game_data_versions() if v not in bundled]   # 古い順
    stale = fetched[:-keep] if keep > 0 else fetched
    base = Path(core.GameDataGetter.get_game_data_dir().path) / GAME_DATA_CC
    for v in stale:
        try:
            shutil.rmtree(base / v)
            print(f"[gdata] 古いゲームデータ {v} を消しました", flush=True)
        except Exception as e:
            print(f"[gdata] 古いゲームデータ {v} を消せません: {e}", flush=True)


def _record_game_data_check(remote, local, updated_from=None):
    cfg = load_config()
    st = cfg.setdefault(GAME_DATA_STATE_KEY, {})
    st["last_checked_at"] = time.time()
    st["remote"] = remote
    st["local"] = local
    if updated_from is not None:
        st["last_updated_at"] = time.time()
        st["updated_from"] = updated_from
        st["updated_to"] = local
    save_config(cfg)


def sync_game_data() -> dict:
    """配布所にいちばん新しい jp のデータがあれば取り寄せる(ブロッキング)。

    戻り値 {"remote": 配布所の最新, "local": 手元の最新, "downloaded": 取り寄せたか, "error": 文}
    """
    local = downloaded_game_data_versions()
    before = local[-1] if local else None
    meta = fetch_game_data_metadata()
    if not meta:
        GAME_DATA_LAST_CHECK.update(at=time.time(), remote=None, error="配布所に届きませんでした")
        return {"remote": None, "local": before, "downloaded": False,
                "error": "配布所に届きませんでした"}
    base_url, remote_versions = meta
    newest = max(remote_versions, key=version_tuple)
    if newest in local:
        GAME_DATA_LAST_CHECK.update(at=time.time(), remote=newest, error=None)
        return {"remote": newest, "local": before, "downloaded": False, "error": None}
    error = _download_game_data(base_url, remote_versions[newest], newest)
    if error is None and newest not in downloaded_game_data_versions():
        error = "取り寄せたはずのデータが見つかりません"
    if error:
        print(f"[gdata] {newest} の{error}", flush=True)
        GAME_DATA_LAST_CHECK.update(at=time.time(), remote=newest, error=error)
        return {"remote": newest, "local": before, "downloaded": False, "error": error}
    # 編集の途中で差し替えない(編集は EDIT_LOCK の中で動く)。
    with EDIT_LOCK:
        reset_bcsfe_game_data_caches()
        _prune_game_data()
    _record_game_data_check(newest, newest, updated_from=before)
    GAME_DATA_LAST_CHECK.update(at=time.time(), remote=newest, error=None)
    print(f"[gdata] ゲームデータを更新: {before} → {newest}", flush=True)
    return {"remote": newest, "local": newest, "downloaded": True, "error": None}


def ensure_game_data_for(save_file):
    """このセーブのバージョンに合う手元のゲームデータを bcsfe に使わせる(ネットは使わない)。

    bcsfe は最初に読んだセーブのバージョンのデータを持ち続けるので、古いセーブの
    あとに新しいセーブが来ると、新しいキャラが「図鑑に無い」ことになっていた。
    手元にそのバージョン以上があればいちばん近いもの、無ければ手元の最新を使う。
    戻り値は使うデータのバージョン(手元に何も無ければ None)。
    """
    local = downloaded_game_data_versions()
    if not local:
        return None
    gv = getattr(save_file, "game_version", None)
    pick = local[-1]
    try:
        if gv is not None:
            for v in local:
                if core.GameVersion.from_string(v) >= gv:
                    pick = v
                    break
    except Exception as e:
        print(f"[gdata] セーブのバージョン比較に失敗: {e}", flush=True)
    getter = getattr(core.core_data, "game_data_getter", None)
    if getter is not None and getattr(getter, "version", None) == pick:
        reset_bcsfe_save_caches()          # 表はこのセーブで作り直す(ドロップの表はセーブに書く)
        return pick
    reset_bcsfe_game_data_caches(names=False)
    try:
        core.core_data.game_data_getter = core.GameDataGetter(
            _bcsfe_cc(), core.GameVersion.from_string(pick), do_print=False)
    except Exception as e:
        print(f"[gdata] {pick} を使えません: {e}", flush=True)
        return None
    return pick


def get_daiko_role_id(guild_id):
    """代行の購入時付与ロールID(ギルドごと)。未設定なら None。"""
    roles = load_config().get("daiko_purchase_roles", {})
    rid = roles.get(str(guild_id))
    return int(rid) if rid else None

def set_daiko_role_id(guild_id, role_id):
    cfg = load_config()
    roles = cfg.setdefault("daiko_purchase_roles", {})
    if role_id:
        roles[str(guild_id)] = int(role_id)
    else:
        roles.pop(str(guild_id), None)
    save_config(cfg)

async def grant_daiko_purchase_role(interaction, paid_amount) -> bool:
    """代行の購入時ロールを付与する。0円(無料券含む)は付与しない=必ず支払いがあった時のみ。"""
    return await grant_daiko_purchase_role_in(interaction.guild, interaction.user.id, paid_amount)

async def grant_daiko_purchase_role_in(guild, user_id, paid_amount) -> bool:
    """ロール付与の本体。LTCのように後から(Interaction無しで)実行する場合もここを使う。"""
    if int(paid_amount or 0) <= 0:
        return False
    if guild is None:
        return False
    role_id = get_daiko_role_id(guild.id)
    if not role_id:
        return False
    # get_member はキャッシュ頼りで、再起動直後やLTCのように後から処理する場面では
    # None になりやすい。そのまま諦めるとロールが「たまに付かない」挙動になる。
    member = guild.get_member(int(user_id))
    if member is None:
        try:
            member = await guild.fetch_member(int(user_id))
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            member = None
    role = guild.get_role(int(role_id))
    if member is None or role is None:
        print(f"[DAIKO ROLE] 付与できません(member={member is not None} / "
              f"role={role is not None} / role_id={role_id})", flush=True)
        return False
    if role in member.roles:
        return True
    try:
        await member.add_roles(role, reason="代行購入(有料)による自動付与")
        return True
    except (discord.Forbidden, discord.HTTPException) as e:
        # Botのロールが対象より下・権限不足など。黙って落とすと原因が追えない。
        print(f"[DAIKO ROLE] 付与に失敗({role.name} → {member}): {e}", flush=True)
        return False

# 無料利用券 {user_id: 有効期限(epoch秒)}。期限内は全代行が無料。
FREE_TICKET_FILE = data_path("free_tickets.json")

# 付与できる日数の幅。ここを1か所にしておけば、コマンドの入力欄(Discord側の
# 制限)・検算・案内文がずれない。
FREE_TICKET_MIN_DAYS = 1
FREE_TICKET_MAX_DAYS = 30
FREE_TICKET_DEFAULT_DAYS = 2

def load_free_tickets() -> dict:
    return read_json(FREE_TICKET_FILE, {})

def save_free_tickets(data: dict):
    write_json(FREE_TICKET_FILE, data)

def grant_free_ticket(user_id, days: int = FREE_TICKET_DEFAULT_DAYS) -> float:
    """指定ユーザーに days 日間の無料券を付与し、有効期限(epoch秒)を返す。"""
    data = load_free_tickets()
    expiry = time.time() + days * 86400
    data[str(user_id)] = expiry
    save_free_tickets(data)
    return expiry

def free_ticket_expiry(user_id) -> float:
    """有効な無料券の期限(epoch秒)。無ければ 0。"""
    exp = load_free_tickets().get(str(user_id), 0)
    try:
        exp = float(exp)
    except (TypeError, ValueError):
        return 0
    return exp if exp > time.time() else 0

def has_free_ticket(user_id) -> bool:
    return free_ticket_expiry(user_id) > 0

def revoke_free_ticket(user_id) -> bool:
    """指定ユーザーの無料券を剥奪する。存在したら True。"""
    data = load_free_tickets()
    if str(user_id) in data:
        del data[str(user_id)]
        save_free_tickets(data)
        return True
    return False

def list_active_free_tickets() -> list:
    """有効な無料券のリスト [(user_id, 期限epoch), ...] を期限順で返す。"""
    now = time.time()
    out = []
    for uid, exp in load_free_tickets().items():
        try:
            exp = float(exp)
        except (TypeError, ValueError):
            continue
        if exp > now:
            out.append((uid, exp))
    out.sort(key=lambda x: x[1])
    return out

# 売上記録 [{"ts": epoch, "amount": int, "user_id": str, "items": [key,...]}]
SALES_FILE = data_path("sales.json")

def load_sales() -> list:
    return read_json(SALES_FILE, [])

def record_sale(amount: int, user_id, items: list, item_prices: dict = None,
                method: str = payments.PAYPAY):
    """代行の売上を1件記録する(実際に受け取った金額のみ)。item_pricesは商品別の単価。"""
    if amount <= 0:
        return
    data = load_sales()
    entry = {"ts": time.time(), "amount": int(amount), "method": method,
             "user_id": str(user_id), "items": list(items)}
    if item_prices:
        entry["item_prices"] = {k: int(v) for k, v in item_prices.items()}
    data.append(entry)
    write_json(SALES_FILE, data)

def sale_item_amounts(sale: dict) -> dict:
    """1件の売上を商品ごとの金額に配分する {key: 円}。
    単価記録(item_prices)があれば実受取額をその比率で配分し、
    無い古い記録は商品数で均等割する(合計は必ず実受取額と一致)。"""
    items = list(sale.get("items") or [])
    amount = int(sale.get("amount", 0))
    if not items or amount <= 0:
        return {}
    weights_src = sale.get("item_prices") or {}
    weights = [max(int(weights_src.get(k, 0)), 0) for k in items]
    if sum(weights) <= 0:
        weights = [1] * len(items)
    total_w = sum(weights)
    out, allocated = {}, 0
    for idx, k in enumerate(items):
        amt = amount - allocated if idx == len(items) - 1 else amount * weights[idx] // total_w
        allocated += amt
        out[k] = out.get(k, 0) + amt
    return out

def force_clear_map_group(map_group, mod, max_stages=12):
    if not map_group: return
    for ch_stars in getattr(map_group, "chapters", []):
        for sub_ch in getattr(ch_stars, "chapters", [ch_stars]):
            stgs = getattr(sub_ch, "stages", [])
            if not stgs:
                StageCls = getattr(mod, "EventStage", getattr(mod, "Stage", None))
                if StageCls: sub_ch.stages = [StageCls(1) for _ in range(max_stages)]
            else:
                for st in stgs:
                    if hasattr(st, "clear_amount"): st.clear_amount = 1
                    elif hasattr(st, "clear_times"): st.clear_times = 1
                    if hasattr(st, "clear_stage"): 
                        try: st.clear_stage(1)
                        except: pass
            l = len(getattr(sub_ch, "stages", []))
            for attr in ["progress", "clear_progress"]:
                if hasattr(sub_ch, attr): setattr(sub_ch, attr, l)
            for attr in ["chapter_unlock_state", "unlock_state"]:
                if hasattr(sub_ch, attr): setattr(sub_ch, attr, 3)

# にゃんにゃん
class Nyanko:
    def __init__(self, data: bytes, country_code="jp", version="15.5.0"):
        self.cc = core.CountryCode.from_code(country_code)
        self.gv = core.GameVersion.from_string(version)
        self.save_file = core.SaveFile(core.Data(data), cc=self.cc)
        # このセーブのバージョンに合うゲームデータ(図鑑・unitbuy・ドロップ)を使う。
        self.data_version = ensure_game_data_for(self.save_file)

    def get_raw_data(self) -> bytes:
        return self.save_file.to_data().to_bytes()

    def edit_xp(self, amount: int = 99999999): self.save_file.xp = amount
    def edit_np(self, amount: int = 9999): self.save_file.np = amount
    def edit_catfood(self, amount: int = 58000): self.save_file.catfood = amount
    def edit_leadership(self, amount: int = 999): self.save_file.leadership = amount
    def edit_normal_tickets(self, amount: int = 999): self.save_file.normal_tickets = amount
    def edit_rare_tickets(self, amount: int = 999): self.save_file.rare_tickets = amount
    def edit_platinum_tickets(self, amount: int = 29): self.save_file.platinum_tickets = amount
    def edit_legend_tickets(self, amount: int = 29): self.save_file.legend_tickets = amount

    def edit_event_tickets(self, amount: int = 999):
        if hasattr(self.save_file, "event_capsules"):
            for i in range(len(self.save_file.event_capsules)):
                try: self.save_file.event_capsules[i] = amount
                except:
                    if hasattr(self.save_file.event_capsules[i], "amount"):
                        self.save_file.event_capsules[i].amount = amount

    def edit_battle_items(self, amount: int = 999):
        if hasattr(self.save_file, "battle_items") and hasattr(self.save_file.battle_items, "items"):
            for item in self.save_file.battle_items.items:
                if hasattr(item, "amount"): item.amount = amount

    def edit_catamins(self, amount: int = 999):
        if hasattr(self.save_file, "catamins") and isinstance(self.save_file.catamins, list):
            self.save_file.catamins = [amount] * len(self.save_file.catamins)

    def edit_base_materials(self, amount: int = 999):
        bm = getattr(self.save_file, "base_materials", None) or getattr(getattr(self.save_file, "ototo", None), "base_materials", None)
        if bm and hasattr(bm, "materials") and isinstance(bm.materials, list):
            bm.materials = [Material(amount) for _ in bm.materials]

    def edit_catseyes(self, amount: int = 999):
        if hasattr(self.save_file, "catseyes") and isinstance(self.save_file.catseyes, list):
            self.save_file.catseyes = [amount] * len(self.save_file.catseyes)

    def edit_matatabi(self, amount: int = 998):
        if hasattr(self.save_file, "catfruit") and isinstance(self.save_file.catfruit, list):
            self.save_file.catfruit = [amount] * len(self.save_file.catfruit)

    @staticmethod
    def max_talent_orb_value(default: int = 998) -> int:
        """本能玉1種あたりの上限。bcsfe の設定値があればそれに従う。"""
        try:
            v = int(core.core_data.max_value_manager.talent_orbs)
        except Exception:
            return default
        return v if v > 0 else default

    def edit_talent_orbs(self, amount: int = 99) -> str:
        """所持している本能玉を99にする。

        対象は「所持しているもののみ」(#にゃんこ代行-注意点 の告知どおり)。
        持っていない種類は増やさないので、玉が1個も無い垢では何も起きない。

        bcsfe の TalentOrb が持っているのは .value で、.amount ではない。
        属性名を外しても例外は出ず、1個も書き換わらないまま「完了」とだけ
        出る。書き換えた後に読み直して、効いたことを確かめる。

        既に指定数より多く持っている玉は減らさない。
        """
        holder = getattr(self.save_file, "talent_orbs", None)
        orbs = getattr(holder, "orbs", None)
        if not isinstance(orbs, dict):
            raise RuntimeError("talent_orbs構造が見つからない")

        amount = max(0, min(int(amount), self.max_talent_orb_value()))
        set_orb = getattr(holder, "set_orb", None)
        raised = 0
        for orb_id, orb in list(orbs.items()):
            if int(getattr(orb, "value", 0) or 0) >= amount:
                continue
            if callable(set_orb):
                set_orb(orb_id, amount)
            else:
                orb.value = amount
            if int(getattr(orbs.get(orb_id), "value", 0) or 0) != amount:
                raise RuntimeError("本能玉の個数を書き換えられない(bcsfeの構造が変わった可能性)")
            raised += 1
        return f"所持{len(orbs)}種 → {raised}種を x{amount} に"


    ERROR_CAT_THRESHOLD = 806  

    @staticmethod
    def find_bcsfe_class(name: str):
        cls = getattr(core, name, None)
        if isinstance(cls, type):
            return cls
        for mod_name, mod in list(sys.modules.items()):
            if not mod_name.startswith("bcsfe") or mod is None:
                continue
            cls = getattr(mod, name, None)
            if isinstance(cls, type) and cls.__name__ == name:
                return cls
        return None

    @staticmethod
    def _to_text(obj):
        if obj is None: return None
        if isinstance(obj, str): return obj
        if isinstance(obj, (bytes, bytearray)):
            return bytes(obj).decode("utf-8", errors="replace")
        for attr in ("to_str", "to_string"):
            f = getattr(obj, attr, None)
            if callable(f):
                try: return str(f())
                except Exception: pass
        f = getattr(obj, "to_bytes", None)
        if callable(f):
            try: return f().decode("utf-8", errors="replace")
            except Exception: pass
        d = getattr(obj, "data", None)
        if isinstance(d, (bytes, bytearray)):
            return bytes(d).decode("utf-8", errors="replace")
        return None

    def get_game_data_file(self, file_name: str):
        getters = []
        ccd = getattr(core, "core_data", None)
        for fn_name in ("get_game_data_getter",):
            fn = getattr(ccd, fn_name, None) if ccd else None
            if callable(fn):
                try: getters.append(fn(self.save_file))
                except Exception as e: print(f"[gdata] getter作成失敗: {e}", flush=True)
        GDG = self.find_bcsfe_class("GameDataGetter")
        if GDG is not None:
            try: getters.append(GDG(self.save_file))
            except Exception: pass
        for g in getters:
            for meth in ("download", "get_file", "download_file", "get"):
                f = getattr(g, meth, None)
                if not callable(f): continue
                for args in (("DataLocal", file_name), (file_name,), (f"DataLocal/{file_name}",)):
                    try:
                        res = f(*args)
                    except Exception:
                        continue
                    if isinstance(res, tuple):
                        res = res[-1]
                    txt = self._to_text(res)
                    if txt and len(txt) > 10:
                        print(f"[gdata] {file_name} を取得 ({type(g).__name__}.{meth})", flush=True)
                        return txt
        print(f"[gdata] {file_name} の取得に失敗", flush=True)
        return None

    def get_picture_book(self):
        try:
            pb = self.save_file.cats.read_nyanko_picture_book(self.save_file)
            if pb is not None and pb.cats:
                return pb
        except Exception as e:
            print(f"[pb] 図鑑データ取得失敗: {e}", flush=True)
        return None

    def get_valid_cat_count(self) -> int:
        pb = self.get_picture_book()
        if pb is not None and pb.cats:
            return len(pb.cats)
        return self.ERROR_CAT_THRESHOLD

    def get_obtainable_ids(self):
        pb = self.get_picture_book()
        if pb is None or not pb.cats:
            return None
        return {c.cat_id for c in pb.cats if c.is_displayed_in_catguide}

    def _unlock_cat(self, cat):
        try:
            cat.unlocked = 1
            cat.gatya_seen = 1
            core.core_data.get_chara_drop(self.save_file).unlock_drops_from_cat_id(cat.id)
        except Exception:
            pass
        try:
            self.save_file.unlock_equip_menu()
        except Exception:
            pass

    def _reset_cat(self, cat):
        try:
            cat.remove(reset=True, save_file=self.save_file)
        except Exception:
            try: cat.reset()
            except Exception: cat.unlocked = 0

    # --- 全キャラ解放 ＋ エラーキャラ削除 / 指定キャラ解放 ---
    def unlock_cats(self, cat_ids: list[int] = None) -> str:
        """cat_ids=None なら全キャラ解放(図鑑に出ないエラーキャラは消す)。
        cat_ids があれば、そのキャラだけ解放する(ほかのキャラには触らない)。

        図鑑(nyankoPictureBookData.csv)は手元のゲームデータのもの。セーブのほうが
        新しい(新コラボのキャラがある)と、そのIDは図鑑に載っていない。以前はそれを
        エラーキャラと見なしてリセットしていたので、新キャラを指定しても解放されず、
        全キャラ解放では消えていた。手元のデータより新しいIDは、
          ・指定されたなら解放する(IDはお客さん・運営が調べたもの)
          ・全キャラ解放では触らない(エラーキャラかどうか判断できないため)
        図鑑そのものが読めないときは何も消さない(消すのは根拠があるときだけ)。
        """
        cats_obj = getattr(self.save_file, "cats", None)
        if not cats_obj or not hasattr(cats_obj, "cats"):
            return
        all_cats = cats_obj.cats
        pb = self.get_picture_book()
        if pb is not None and pb.cats:
            obtainable = {c.cat_id for c in pb.cats if c.is_displayed_in_catguide}
            known_max = max(c.cat_id for c in pb.cats)
        else:
            # 図鑑が読めない。セーブにある枠は全部解放し、消すほうは根拠が無いので
            # 何もしない(以前は806体目から先を一律にエラーキャラ扱いで消していた)。
            obtainable = None
            known_max = max((cat.id for cat in all_cats), default=-1)
        wanted = set(cat_ids) if cat_ids is not None else None
        total = len(all_cats)
        print(f"[unlock] セーブ内キャラ数={total} / 図鑑表示キャラ数="
              f"{len(obtainable) if obtainable is not None else '?'} / データ {self.data_version}",
              flush=True)

        unlocked_n = removed_n = newer_n = 0
        skipped = []            # 指定されたが図鑑に無い(エラーキャラ)ので解放しなかったID
        for cat in all_cats:
            if wanted is not None and cat.id not in wanted:
                continue
            if cat.id > known_max:
                # 手元のゲームデータより新しいキャラ(新コラボなど)
                if wanted is not None:
                    self._unlock_cat(cat)
                    unlocked_n += 1
                else:
                    newer_n += 1
                continue
            if obtainable is None or cat.id in obtainable:
                self._unlock_cat(cat)
                unlocked_n += 1
            elif wanted is None:
                if getattr(cat, "unlocked", 0):
                    removed_n += 1
                self._reset_cat(cat)
            else:
                skipped.append(cat.id + 1)

        if hasattr(self.save_file, "rank_up_sale_value"):
            self.save_file.rank_up_sale_value = 0x7FFFFFFF
        if wanted is not None:
            info = f"解放{unlocked_n}体"
            if skipped:
                info += f" / 図鑑に無いため解放せず: ID {', '.join(str(x) for x in skipped)}"
            missing = sorted(wanted - {cat.id for cat in all_cats})
            if missing:
                # セーブにその枠が無い(お客さんのアプリがまだ古い・番号の打ち間違い)
                info += (f" / セーブに無いID: {', '.join(str(x + 1) for x in missing)}"
                         "（アプリの更新前か、番号違い）")
        elif obtainable is None:
            info = f"解放{unlocked_n}体 / 図鑑データが読めないためエラーキャラの削除はしていません"
        else:
            info = f"解放{unlocked_n}体 / エラーキャラ{removed_n}体削除 (図鑑表示{len(obtainable)}体)"
            if newer_n:
                info += f" / データ未対応の新キャラ{newer_n}体は触っていません"
        return info + f" [データ {self.data_version or '不明'}]"

    def upgrade_cats(self, cat_ids: list[int] = None):
        cats_obj = getattr(self.save_file, "cats", None)
        if not cats_obj or not hasattr(cats_obj, "cats"):
            return
        unit_buy = None
        try:
            unit_buy = cats_obj.read_unitbuy(self.save_file)
        except Exception as e:
            print(f"[upgrade] unitbuy取得失敗: {e}", flush=True)
        for cat in cats_obj.cats:
            if not getattr(cat, "unlocked", False): continue
            if cat_ids is not None and cat.id not in cat_ids: continue
            ub = unit_buy.get_unit_buy(cat.id) if unit_buy else None
            if ub is not None and ub.max_upgrade_level_catseye > 0:
                # upgrade.base は 0始まり (レベル = base + 1)
                cat.upgrade.base = ub.max_upgrade_level_catseye - 1
                cat.upgrade.plus = max(0, ub.max_plus_upgrade_level)
            else:
                cat.upgrade.base = 49
                cat.upgrade.plus = 80
        self.save_file.rank_up_sale_value = 0x7FFFFFFF

    def _set_max_form(self, cat, total_forms: int):
        try:
            cat.set_form_true(self.save_file, total_forms, set_current_form=True, fourth_form=True)
        except Exception:
            cat.unlocked_forms = 3
            cat.current_form = max(2, getattr(cat, "current_form", 0))

    # --- 最大形態 (第3/第4形態) の完全解放 ---
    def true_form_cats(self, cat_ids: list[int] = None) -> str:
        """最大形態にした体数を文で返す。

        手元のゲームデータより新しいキャラ(図鑑に無い)は、形態の数が分からないので
        触らない(当てずっぽうで第3形態を開けると、2形態しか無いキャラを壊す)。
        指定されていたら、そのIDを「見送り」として返す(✅ だけ出して黙らない)。
        """
        cats_obj = getattr(self.save_file, "cats", None)
        if not cats_obj or not hasattr(cats_obj, "cats"):
            return "0体"
        pb = self.get_picture_book()
        obtainable = self.get_obtainable_ids()
        known_max = max((c.cat_id for c in pb.cats), default=-1) if (pb is not None and pb.cats) else -1
        done, newer = 0, []
        for cat in cats_obj.cats:
            if not getattr(cat, "unlocked", False): continue
            if cat_ids is not None and cat.id not in cat_ids: continue
            if known_max >= 0 and cat.id > known_max:
                newer.append(cat.id + 1)
                continue
            if obtainable is not None and cat.id not in obtainable: continue
            total_forms = 3
            if pb is not None:
                pb_cat = pb.get_cat(cat.id)
                if pb_cat is not None:
                    total_forms = pb_cat.total_forms
            self._set_max_form(cat, total_forms)
            done += 1
        info = f"{done}体"
        if newer and cat_ids is not None:
            info += (f" / データ未対応のため見送り: ID {', '.join(str(x) for x in newer)}"
                     "（データが更新されたら改めて）")
        elif newer:
            info += f" / データ未対応の新キャラ{len(newer)}体は見送り"
        return info

    
    # --- 本能(Talent)MAX: SkillAcquisition.csv 準拠 ---
    def upgrade_talents_max(self, cat_ids: list[int] = None) -> str:
        cats_obj = getattr(self.save_file, "cats", None)
        if not cats_obj or not hasattr(cats_obj, "cats"):
            return
        talent_data = None
        try:
            talent_data = cats_obj.read_talent_data(self.save_file)
        except Exception as e:
            print(f"[talent] TalentData取得失敗: {e}", flush=True)
        if talent_data is None:
            return "⚠️ ゲームデータ取得失敗のため変更せず"

        pb = self.get_picture_book()
        obtainable = self.get_obtainable_ids()

        made, cleaned = 0, 0
        for cat in cats_obj.cats:
            if not getattr(cat, "unlocked", 0):
                continue
            if cat_ids is not None and cat.id not in cat_ids:
                continue
            if obtainable is not None and cat.id not in obtainable:
                continue

            cat_skill = talent_data.get_cat_skill(cat.id)
            if cat_skill is None or not cat_skill.skills:
                if cat.talents:
                    for t in cat.talents:
                        t.level = 0
                    cleaned += 1
                continue

            total_forms = 3
            if pb is not None:
                pb_cat = pb.get_cat(cat.id)
                if pb_cat is not None:
                    total_forms = pb_cat.total_forms
            self._set_max_form(cat, total_forms)

            
            new_talents = []
            for skill in cat_skill.skills:
                if skill.ability_id <= 0:
                    continue
                lv = skill.max_lv if skill.max_lv > 0 else 1
                new_talents.append(Talent(skill.ability_id, lv))
            if new_talents:
                cat.talents = new_talents
                made += 1

        return f"SkillAcquisition準拠 / 付与{made}体・不正データ修復{cleaned}体"


    # 施設・ステージ系
    def upgrade_facilities(self):
        if hasattr(self.save_file, "special_skills"):
            skills = getattr(self.save_file.special_skills, "skills", self.save_file.special_skills)
            if hasattr(skills, "get_valid_skills"): skills = skills.get_valid_skills()
            if isinstance(skills, list):
                for skill in skills:
                    if hasattr(skill, "upgrade"):
                        skill.upgrade.base = 29
                        skill.upgrade.plus = 10
            self.save_file.rank_up_sale_value = 0x7FFFFFFF

   
    def edit_gamatoto_level(self) -> str:
        gm = getattr(self.save_file, "gamatoto", None)
        if gm is None:
            return "gamatoto構造が見つからない"
        xp = None
        max_level = None
        try:
            levels = core.core_data.get_gamatoto_levels(self.save_file)
            max_level = levels.get_max_level()
            if max_level:
                xp = levels.get_xp_from_level(max_level)
        except Exception as e:
            print(f"[gamatoto] レベルデータ取得失敗: {e}", flush=True)
        if not xp or xp <= 0:
            # Lv130 には 102193300 XP 要る。99999999 では Lv129 で止まる
            xp, max_level = self.GAMATOTO_MAX_XP_FALLBACK, 130
        gm.xp = xp
        return f"Lv{max_level} (XP {xp})"

    # --- ガマトト助手 全レジェンド (隊員データ準拠) ---
    def edit_gamatoto_helpers(self, count: int = 10) -> str:
        gm = getattr(self.save_file, "gamatoto", None)
        if gm is None or not hasattr(gm, "helpers"):
            return "gamatoto構造が見つからない"

       
        try:
            members_name = core.core_data.get_gamatoto_members_name(self.save_file)
            members = members_name.members
        except Exception as e:
            print(f"[gamatoto] 隊員データ取得失敗: {e}", flush=True)
            members = None
        if not members:
            return "⚠️ 隊員データ取得失敗のため変更せず(ログ参照)"

        max_rarity = max(m.rarity for m in members)
        legends = [m for m in members if m.rarity == max_rarity]
        if not legends:
            return "⚠️ レジェンド隊員が見つからない"

        
        try:
            total = core.core_data.get_gamatoto_levels(self.save_file).get_total_helpers() or count
        except Exception:
            total = count
        total = min(total, len(legends))

        new_helpers = [Helper(m.member_id) for m in legends[:total]]
        holder = gm.helpers
        if isinstance(holder, list):
            gm.helpers = new_helpers
        elif hasattr(holder, "helpers"):
            holder.helpers = new_helpers
        else:
            gm.helpers = Helpers(new_helpers)
        names = ", ".join(m.name for m in legends[:total])
        return f"{legends[0].rarity_name}隊員{total}体: {names}"
                
    # --- 地底迷宮メダル全種 ---
    def edit_labyrinth_medals(self, amount: int = 99) -> str:
        s = self.save_file
        if not hasattr(s, "labyrinth_medals") or not isinstance(s.labyrinth_medals, list):
            return "このセーブは地底迷宮に非対応"
        maxv = amount
        n = len(s.labyrinth_medals)
        try:
            items = core.core_data.get_gatya_item_buy(s).get_by_category(11)
            if items:
                n = max(n, len(items))
        except Exception as e:
            print(f"[labyrinth] メダル種数取得失敗: {e}", flush=True)
        s.labyrinth_medals = [maxv] * n
        return f"{n}種 x{maxv}"

    # --- ゴールド会員化 (にゃんこクラブ ゴールドパス) ---
    def edit_gold_pass(self) -> str:
        op = getattr(self.save_file, "officer_pass", None)
        gp = getattr(op, "gold_pass", None)
        if gp is None:
            return "officer_pass構造が見つからない"
        officer_id = NyankoClub.get_random_officer_id()
        gp.get_gold_pass(officer_id, 30, self.save_file)
        return f"会員ID {officer_id} / 30日"

    # --- 編成スロット最大拡張 ---
    def edit_lineup_slots(self) -> str:
        lu = getattr(self.save_file, "lineups", None)
        if lu is None or not hasattr(lu, "unlocked_slots"):
            return "lineups構造が見つからない"
        total = getattr(lu, "slot_names_length", 15) or 15
        try:
            from bcsfe.core.game.battle.slots import EquipSlots
            while len(lu.slots) < total:
                lu.slots.append(EquipSlots.init())
        except Exception:
            total = min(total, len(getattr(lu, "slots", []) or [total]))
        lu.unlocked_slots = total
        try:
            self.save_file.unlock_equip_menu()
        except Exception:
            pass
        return f"{total}スロット解放"

    # --- にゃんこメダル全解放 (medalname.tsv 準拠) ---
    def unlock_all_medals(self) -> str:
        medals = getattr(self.save_file, "medals", None)
        if medals is None or not hasattr(medals, "add_medal"):
            return "medals構造が見つからない"
        try:
            rows = core.core_data.get_medal_names(self.save_file).medal_names
        except Exception as e:
            print(f"[medals] メダル名取得失敗: {e}", flush=True)
            rows = None
        if not rows:
            return "⚠️ メダルデータ取得失敗のため変更せず"
        n = 0
        for i, row in enumerate(rows):
            if not row or not any(str(x).strip() for x in row):
                continue
            medals.add_medal(i)
            n += 1
        return f"{n}種のメダルを取得済みに"

    # --- 敵キャラ図鑑全解放 (enemy_dictionary_list.csv 準拠) ---
    def unlock_enemy_guide_all(self) -> str:
        s = self.save_file
        eg = getattr(s, "enemy_guide", None)
        if not isinstance(eg, list) or not eg:
            return "enemy_guide構造が見つからない"
        try:
            valid = EnemyDictionary(s).get_valid_enemies()
        except Exception as e:
            print(f"[enemy] 敵図鑑データ取得失敗: {e}", flush=True)
            valid = None
        if valid is None:
            return "⚠️ 敵図鑑データ取得失敗のため変更せず"
        valid_set = set(valid)
        n = 0
        for i in range(len(eg)):
            if i in valid_set:
                eg[i] = 1
                n += 1
            else:
                eg[i] = 0
        if hasattr(s, "unlock_enemy_guide"):
            s.unlock_enemy_guide = 1
        return f"{n}体を図鑑に登録"

    # --- ユーザーランク報酬全受取 ---
    def claim_user_rank_rewards(self) -> str:
        s = self.save_file
        urr = getattr(s, "user_rank_rewards", None)
        if urr is None or not hasattr(urr, "rewards"):
            return "user_rank_rewards構造が見つからない"
        try:
            gifts = core.core_data.get_rank_gifts(s).rank_gift
        except Exception as e:
            print(f"[rank] rankGift取得失敗: {e}", flush=True)
            gifts = None
        if gifts is None:
            return "⚠️ ランク報酬データ取得失敗のため変更せず"
        try:
            rank = s.calculate_user_rank()
        except Exception:
            rank = 0
        try:
            from bcsfe.core.game.catbase.user_rank_rewards import Reward
        except Exception:
            Reward = None
        n = 0
        for gift in gifts:
            if gift.threshold > rank:
                continue
            if gift.index >= len(urr.rewards):
                if Reward is None:
                    continue
                while len(urr.rewards) <= gift.index:
                    urr.rewards.append(Reward(False))
            if not urr.rewards[gift.index].claimed:
                n += 1
            urr.rewards[gift.index].claimed = True
        return f"ランク{rank}までの{n}件を受取済みに"

    # --- プレイ時間カンスト (9999:59:59) ---
    def edit_playtime(self) -> str:
        op = getattr(self.save_file, "officer_pass", None)
        if op is None or not hasattr(op, "play_time"):
            return "officer_pass構造が見つからない"
        pt = PlayTime.from_hours_mins_secs(9999, 59, 59)
        op.play_time = pt.frames
        return "9999時間59分59秒"

    # --- 全ミッションクリア (報酬受取可能状態) ---
    def clear_all_missions(self) -> str:
        ms = getattr(self.save_file, "missions", None)
        if ms is None or not hasattr(ms, "clear_states"):
            return "missions構造が見つからない"
        conds = None
        try:
            conds = core.core_data.get_mission_conditions(self.save_file).conditions
        except Exception as e:
            print(f"[missions] 条件データ取得失敗: {e}", flush=True)
        n = 0
        for mid in list(ms.clear_states.keys()):
            ms.clear_states[mid] = 2  # クリア済み・報酬受取可能
            if conds and mid in conds:
                ms.requirements[mid] = conds[mid].progress_count
            n += 1
        return f"{n}件をクリア済み(報酬受取可)に"

    # --- 開放テロップ削除 (未再生の解放演出を既読化) ---
    def remove_unlock_popups(self) -> str:
        up = getattr(self.save_file, "unlock_popups", None)
        if up is None or not hasattr(up, "popups"):
            return "unlock_popups構造が見つからない"
        n = 0
        for p in up.popups.values():
            if not p.seen:
                n += 1
            p.seen = True
        return f"{n}件のテロップを既読化 (登録済み{len(up.popups)}件)"

    # --- 広告非表示 ---
    def hide_ads(self) -> str:
        gm = getattr(self.save_file, "gamatoto", None)
        if gm is not None and hasattr(gm, "is_ad_present"):
            gm.is_ad_present = False
        return "ガマトト広告枠OFF (ゴールド会員化と併用推奨)"

    def edit_ototo_cannons(self):
        if hasattr(self.save_file, "ototo") and self.save_file.ototo and hasattr(self.save_file.ototo, "cannons") and self.save_file.ototo.cannons:
            cc = getattr(self.save_file.ototo.cannons, "cannons", self.save_file.ototo.cannons)
            if isinstance(cc, dict):
                for c_id, cannon in cc.items():
                    if hasattr(cannon, "development"): cannon.development = 3
                    if hasattr(cannon, "levels") and isinstance(cannon.levels, list):
                        for p_id in range(len(cannon.levels)): cannon.levels[p_id] = 29 if p_id == 0 else 30
            elif isinstance(cc, list):
                for cannon in cc:
                    if hasattr(cannon, "development"): cannon.development = 3
                    if hasattr(cannon, "levels") and isinstance(cannon.levels, list):
                        for p_id in range(len(cannon.levels)): cannon.levels[p_id] = 29 if p_id == 0 else 30

# 通信
class NSig:
    def __init__(self, iq, d): self.iq, self.d = iq, d
    def s(self, h, d, algo): return h + hmac.HMAC((self.iq + h).encode(), d.encode(), algo).hexdigest()
    def g1(self): return self.s(secrets.token_hex(32), self.d, hashlib.sha256)
    def g2(self): return self.s(secrets.token_hex(20), self.d * 2, hashlib.sha1)

class CEd:
    def __init__(self, tc, pin):
        self.pin = pin
        self.tc = tc
        self.s = requests.Session()
        self.sf, self.pw, self.err = None, "", ""
        self.auth_failed = False   # 認証が通らない=預かった情報では進めない
        self.pw_note = ""          # パスワード取り直しの結果(失敗理由の表示用)
        self.cred_source = "新規ダウンロード"   # 認証材料が新品か預かりか
        self.raw = None        # ダウンロードした元セーブのバイト列(再シリアライズ回避用)
        self.mod_bytes = None  # 編集後セーブのバイト列(up時の再シリアライズ回避用)

    def hdrs(self, iq, d): return {"Content-Type": "application/json", "Nyanko-Signature": NSig(iq, d).g1(), "Nyanko-Timestamp": str(int(time.time())), "Nyanko-Signature-Version": "1", "Nyanko-Signature-Algorithm": "HMACSHA256", "User-Agent": "Dalvik/2.1.0"}

    def dl(self):
        b = json.dumps({"clientInfo": {"client": {"version": get_game_version(), "countryCode": "ja"}, "os": {"type": "android", "version": "13"}, "device": {"model": "SM-S918B"}}, "pin": self.pin, "nonce": secrets.token_hex(16)}, separators=(",", ":"))
        try:
            r = self.s.post(f"https://nyanko-save.ponosgames.com/v2/transfers/{self.tc}/reception", headers={"Content-Type": "application/json"}, data=b, timeout=15)
            if r.status_code == 200:
                self.raw = r.content  # 元セーブのバイト列を保持(run側の再シリアライズを省略)
                self.sf = core.SaveFile(core.Data(r.content), cc=core.CountryCode("jp"))
                self.pw = r.headers.get("Nyanko-Password", "")
                return True
            self.err = r.text
        except Exception as e: self.err = str(e)
        return False

    def _refresh_password(self):
        """パスワードを取り直す。取れなければ None。

        1. セーブの中の更新用トークンで更新する(refresh_password)
        2. 問い合わせコードと作成時刻で発行し直す(get_password_new)
        1が拒否されても2が通ることがあるので、両方当たる。

        bcsfe の get_password() は使わないこと。両方失敗すると最後に
        create_new_account() まで行き、お客さんのアカウントが別物になる。
        """
        self.pw_note = ""
        try:
            sh = core.ServerHandler(self.sf, print=False)
        except Exception as e:
            self.pw_note = f"取り直しの準備に失敗: {e}"
            print(f"[UP PW REFRESH ERROR] {e}", flush=True)
            return None

        for label, get in (("更新用トークン", sh.refresh_password),
                           ("新規発行", sh.get_password_new)):
            try:
                pw = get()
            except Exception as e:
                self.pw_note += f" / {label}: 例外 {type(e).__name__}"
                print(f"[UP PW REFRESH ERROR] {label}: {e}", flush=True)
                continue
            if pw:
                self.pw_note = f"{label}で取り直せました"
                return pw
            self.pw_note += f" / {label}: 拒否"
        return None

    def up(self):
        """編集したセーブを保存して、新しい引き継ぎコードを発行する。

        失敗しても理由を捨てない。どの段階で落ちても「保存に失敗しました」しか
        出ないと、認証切れなのか、アップロードを弾かれたのか、アカウントの状態が
        悪いのかが区別できない。入金は済んでいるので、原因が読めないと手が打てない。
        """
        self.err = ""
        self.auth_failed = False
        if not self.sf:
            self.err = "セーブが読み込まれていません"
            return None, None

        def account_code() -> str:
            """今この瞬間の問い合わせコード(アカウントコード)。

            パスワードを取り直すと、Ponosが別のアカウントコードを割り当てて
            返してくることがあり、bcsfe はそれをセーブに書き込む。最初に1度
            読んで使い回すと、やり直しが「新しいパスワード + 古いコード」に
            なって statusCode=101 で弾かれる(署名の鍵でもあるので本文と署名の
            両方が食い違う)。毎回引き直す。
            """
            return getattr(self.sf, "inquiry_code", "0") or "0"

        def fail(step: str, resp=None, hint: str = ""):
            detail = ""
            if resp is not None:
                body = (resp.text or "")[:200].replace("\n", " ")
                detail = f"(HTTP {resp.status_code}) {body}"
            self.err = f"{step}に失敗 {detail}{hint}".strip()
            print(f"[UP ERROR] {self.err}", flush=True)
            return None, None

        def ponos_payload(resp):
            """Ponosの応答から payload を取り出す。取れなければ (None, 理由)。

            Ponos は失敗でも HTTP 200 を返し、本文の statusCode で成否を伝える
            (1 が成功)。HTTPステータスだけで判断すると、失敗応答のまま先へ進んで
            payload が None のまま添字を引くことになる。
            """
            try:
                body = resp.json()
            except Exception:
                text = (resp.text or "")[:150].replace("\n", " ")
                return None, f"(HTTP {resp.status_code}) 応答をJSONとして読めません: {text}"
            if not isinstance(body, dict):
                return None, f"(HTTP {resp.status_code}) 想定外の応答形式"
            status = body.get("statusCode")
            payload = body.get("payload")
            if status != 1 or not isinstance(payload, dict):
                dump = json.dumps(body, ensure_ascii=False)[:200]
                return None, f"(HTTP {resp.status_code}) statusCode={status} {dump}"
            return payload, ""

        def token_request():
            iq = account_code()
            body = json.dumps({"accountCode": iq, "password": self.pw, "clientInfo": {"client": {"version": get_game_version(), "countryCode": "ja"}, "os": {"type": "android", "version": "9"}, "device": {"model": "SM-G955F"}}, "nonce": secrets.token_hex(16)}, separators=(",", ":"))
            return self.s.post("https://nyanko-auth.ponosgames.com/v1/tokens",
                               headers=self.hdrs(iq, body), data=body, timeout=15)

        try:
            r1 = token_request()
            p1, why = ponos_payload(r1)
            if not p1 or not p1.get("token"):
                # 保留の承認待ちで時間が空くと、預かったパスワードは古くなる。
                # セーブが更新用トークンを持っているので、お客さんの手を借りずに
                # 取り直して一度だけやり直す。
                before = account_code()
                fresh = self._refresh_password()
                if not fresh:
                    self.auth_failed = True
                    return fail("認証(トークン取得)",
                                hint=f"\n{why}\n※パスワードの取り直しもできませんでした"
                                     f"（預かったパスワード: {'空' if not self.pw else '有り'}"
                                     f" / 更新用トークン: {'無し' if not getattr(self.sf, 'password_refresh_token', None) else '有り'}）"
                                     f"\n取り直しの内訳: {getattr(self, 'pw_note', '') or '不明'}"
                                     f"\n認証材料: {getattr(self, 'cred_source', '不明')}"
                                     f" / ゲームver: {get_game_version()}")
                self.pw = fresh
                if account_code() != before:
                    # 編集後のバイト列は変わる前のものなので、そのまま上げると
                    # セーブの中身(古いコード)とアカウント(新しいコード)が
                    # 食い違う。取り直した認証材料ごと作り直して上げる。
                    self.mod_bytes = None
                    self.pw_note += " / アカウントコードが変わったので保存し直します"
                    print(f"[UP PW REFRESH] account code changed: {before} -> {account_code()}",
                          flush=True)
                r1 = token_request()
                p1, why = ponos_payload(r1)
                if not p1 or not p1.get("token"):
                    self.auth_failed = True
                    return fail("認証(パスワード取り直し後のトークン取得)",
                                hint=f"\n{why}\n取り直しの内訳: "
                                     f"{getattr(self, 'pw_note', '') or '不明'}")
            tk = p1["token"]
            iq = account_code()
            h2 = self.hdrs(iq, ""); h2["Authorization"] = f"Bearer {tk}"
            r2 = self.s.get(f"https://nyanko-save.ponosgames.com/v2/save/key?nonce={secrets.token_hex(16)}", headers=h2, timeout=15)
            aw, why = ponos_payload(r2)
            if not aw or not aw.get("url") or not aw.get("key"):
                return fail("保存キーの取得", hint=f"\n{why}")
            up_bytes = self.mod_bytes if self.mod_bytes is not None else self.sf.to_data().to_bytes()
            # 結果を見ないと、弾かれても気付かないまま次へ進んで、
            # 最後に理由の分からない失敗になる
            r3 = requests.post(aw["url"], data={k: v for k, v in aw.items() if k != "url"}, files={"file": ("f.sav", up_bytes, "application/octet-stream")}, timeout=20)
            if r3.status_code not in (200, 201, 204):
                return fail("セーブ本体のアップロード", r3)
            rk = self.sf.calculate_user_rank() if hasattr(self.sf, 'calculate_user_rank') else 6000
            # 追跡アイテム(猫缶・チケット類)の増減を、アップロードと一緒に申告する。
            # セーブの数字だけ増やして空の申告([])を送ると、PONOS側の台帳と
            # 食い違う「出どころのない増加」になり、BANの種になる。申告の中身は
            # apply_modifications が編集時にセーブへ記録したもの(bcsfe本体の
            # アップロードと同じ作法)。編集していないアップロードでは空のまま。
            try:
                mi = [i.to_dict()
                      for i in core.BackupMetaData(self.sf).get_managed_items()]
            except Exception as e:
                print(f"[UP] 増分申告を読めません: {type(e).__name__}: {e}", flush=True)
                mi = []
            mi_str = json.dumps(mi, separators=(",", ":"))
            bm = json.dumps({"managedItemDetails": mi, "nonce": secrets.token_hex(16), "playTime": getattr(self.sf.officer_pass, "play_time", 0), "rank": rk, "receiptLogIds": [], "saveKey": aw["key"], "signature_v1": NSig(iq, mi_str).g2()}, separators=(",", ":"))
            h4 = self.hdrs(iq, bm); h4["Authorization"] = f"Bearer {tk}"
            r4 = self.s.post("https://nyanko-save.ponosgames.com/v2/transfers", headers=h4, data=bm, timeout=15)
            out, why = ponos_payload(r4)
            if not out:
                return fail("引き継ぎコードの発行", hint=f"\n{why}")
            code, pin = out.get("transferCode"), out.get("pin")
            if not code:
                return fail("引き継ぎコードの発行", hint="\n※応答にコードが入っていません")
            return code, pin
        except Exception as e:
            self.err = f"{type(e).__name__}: {e}"
            print(f"[UP ERROR] {self.err}", flush=True)
        return None, None

    def restore(self, raw: bytes, pw: str) -> bool:
        """ダウンロード済みのセーブから状態を組み直す(再ダウンロードしない)。

        dl() は引き継ぎコードを消費する。だから up() は新しいコードを発行して
        返す。つまり同じコードで dl() は2回呼べない。保留になった注文を後から
        代行するときに dl() をやり直すと、お客さんがゲームを起動したかどうかに
        関係なく必ず失敗する(こちらが使い切っているため)。
        そこで注文時に落としたセーブを取っておき、ここから復元する。
        """
        try:
            self.raw = raw
            self.sf = core.SaveFile(core.Data(raw), cc=core.CountryCode("jp"))
            self.pw = pw or ""
            self.cred_source = "預かり(注文時のもの)"
            return True
        except Exception as e:
            self.err = f"預かったセーブを読み込めませんでした: {e}"
            return False

    def up_new_account(self):
        """新しい問い合わせコード(アカウントID)を発行してからアップロードする。
        - 垢複製: 元アカウントと独立した新規アカウントのコピーを作成
        - バン解除: 新IDでバン対象から外れる
        bcsfeのServerHandlerを使い、パスワード/トークン/セーブキーを再取得する。"""
        if not self.sf:
            return None, None
        try:
            sh = core.ServerHandler(self.sf, print=False)
            if not sh.create_new_account():
                self.err = "アカウント再発行に失敗しました (通信または旧IDの状態を確認してください)"
                return None, None
            codes = sh.get_codes()
            if codes:
                return codes  # (transferCode, pin)
            self.err = "新アカウントのアップロードに失敗しました"
        except Exception as e:
            print(f"[UP_NEW ERROR] {e}", flush=True)
            self.err = str(e)
        return None, None




# 保留中の注文のために、ダウンロード済みのセーブを置いておく場所。
PENDING_SAVE_DIR = data_path("pending_saves")
# 置きっぱなしにしない日数(見張りの上限より少し長く持つ)。
PENDING_SAVE_KEEP_DAYS = 3


def stash_save(ed: "CEd") -> dict:
    """落としたセーブをディスクに退避して、復元に要る情報を返す。

    引き継ぎコードは消費済みなので、これを取っておかないと保留になった注文は
    二度と代行できない。失敗しても支払いは止めない(戻り値が空になるだけ)。
    """
    if not getattr(ed, "raw", None):
        # ここに来ると、保留になった時点でその注文は詰む(お客さんの入れ直し待ち)。
        # 黙って進むと原因が分からなくなるので、必ず声を出す。
        print("[SAVE STASH SKIP] セーブの元データが無いので預けられません", flush=True)
        return {}
    try:
        os.makedirs(PENDING_SAVE_DIR, exist_ok=True)
        name = f"{uuid.uuid4().hex}.sav"
        path = os.path.join(PENDING_SAVE_DIR, name)
        with open(path, "wb") as f:
            f.write(ed.raw)
            f.flush()
            os.fsync(f.fileno())   # 落ちても中身が残るようにしてから返す
        return {"save_file": path, "save_pw": getattr(ed, "pw", "") or ""}
    except Exception as e:
        print(f"[SAVE STASH ERROR] {e}", flush=True)
        return {}


def stash_reason(payload: dict) -> str:
    """預かりセーブを使えなかった理由。使えるなら空文字。

    「無い」「消えた」「読めない」は原因も打つ手も別物なので、まとめて
    「引き継ぎに失敗しました」にはしない。
    """
    path = (payload or {}).get("save_file")
    if not path:
        return "預かりセーブが作られていません（注文時の保存に失敗した可能性）"
    if not os.path.exists(path):
        return "預かりセーブが見つかりません（掃除で消えた可能性）"
    return ""


async def stash_save_async(ed: "CEd") -> dict:
    """stash_save をスレッドで回す。

    セーブは数百KBあり、書き込みと fsync のあいだイベントループが止まる。
    その間は他の人の購入も見張りも全部待たされるので、必ず逃がす。
    """
    return await asyncio.to_thread(stash_save, ed)


def load_stashed(payload: dict) -> "CEd":
    """退避しておいたセーブから CEd を組み直す。無ければ None。"""
    path = (payload or {}).get("save_file")
    if not path or not os.path.exists(path):
        return None
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except OSError as e:
        print(f"[SAVE STASH READ ERROR] {e}", flush=True)
        return None
    ed = CEd(payload.get("tc", ""), payload.get("pin", ""))
    if ed.restore(raw, payload.get("save_pw", "")):
        return ed
    print(f"[SAVE STASH PARSE ERROR] {path}: {getattr(ed, 'err', '')}", flush=True)
    return None


def drop_stashed(payload: dict):
    """使い終わった(または不要になった)退避セーブを消す。"""
    path = (payload or {}).get("save_file")
    if path and os.path.exists(path):
        try:
            os.remove(path)
        except OSError:
            pass


def stashed_in_use() -> set:
    """まだ決着していない注文が抱えている預かりセーブのパス。

    これを消してしまうと、承認済みの注文でも代行し直せなくなり、
    お客さんに引き継ぎコードを入れ直してもらうしかなくなる。
    読めない記録があっても「使っていない」と決めつけない(消すのは危険側)。
    """
    paths = set()

    def keep(payload):
        path = (payload or {}).get("save_file")
        if path:
            paths.add(path)

    try:
        for order in link_orders.load_store()["orders"].values():
            if order.get("status") not in (link_orders.DONE, link_orders.CANCELED):
                keep(order.get("payload"))
    except Exception as e:
        print(f"[SAVE STASH SCAN ERROR] link_orders: {e}", flush=True)
        raise
    try:
        for attempt in payment_attempts.orphans():
            keep(attempt.get("payload"))
    except Exception as e:
        print(f"[SAVE STASH SCAN ERROR] attempts: {e}", flush=True)
        raise
    return paths


def purge_stashed_saves(days: int = PENDING_SAVE_KEEP_DAYS) -> int:
    """置き去りになった退避セーブを片付ける。

    古さだけで消していたため、承認待ちが長引いた注文の預かりセーブが
    まだ必要なうちに消えていた。日数に関係なく、生きている注文が
    抱えているものは残す。
    どの注文が何を使っているか読めなかったときは、1件も消さない。
    """
    if not os.path.isdir(PENDING_SAVE_DIR):
        return 0
    try:
        in_use = stashed_in_use()
    except Exception:
        print("[SAVE STASH PURGE] 使用中の判定ができないので今回は消しません", flush=True)
        return 0

    limit = time.time() - days * 86400
    gone = 0
    for name in os.listdir(PENDING_SAVE_DIR):
        path = os.path.join(PENDING_SAVE_DIR, name)
        if path in in_use:
            continue
        try:
            if os.path.isfile(path) and os.path.getmtime(path) < limit:
                os.remove(path)
                gone += 1
        except OSError:
            continue
    return gone



CAT_ITEM = [
    ("xp", "XP"), ("np", "NP"), ("catfood", "猫缶"), ("leadership", "リーダーシップ"),
    ("normal_ticket", "にゃんチケ"), ("rare_ticket", "レアチケ"), ("platinum_tickets", "プラチケ"), ("legend_tickets", "レジェチケ"),
    ("event_tickets", "イベチケ"), ("battle_items", "バトルアイテム全種"), ("catseyes", "キャッツアイ全種"), ("matatabi", "マタタビ+獣石全種"),
    ("edit_talent_or_bs", "本能玉"), ("base_materials", "城素材全種"), ("catamins", "ネコビタン全種"), ("labyrinth_medals", "地底迷宮メダル全種"),
]
CAT_STAGE = [
    ("main_stages", "メイン全クリア＋金お宝"), ("clear_all_sol", "旧レジェ全クリア"), ("true_legend", "真レジェ全クリア"),
    ("zero_legend", "零レジェ全クリア"), ("makai", "魔界編全クリア"), ("zombie_stages", "ゾンビ全クリア"), ("event_stages", "イベステ全クリア"),
]
CAT_CHAR = [
    ("unlock_cats_all", "全キャラ解放+エラーキャラ削除"), ("unlock_cats_specific", "指定キャラ解放"),
    ("upgrade_cats_all", "全キャラLvMAX"), ("upgrade_cats_specific", "指定キャラLvMAX"),
    ("true_form_cats_all", "全キャラ最大形態"), ("true_form_cats_specific", "指定キャラ最大形態"),
    ("upgrade_talents_all", "全キャラ本能MAX"),
]
CAT_GAMATOTO = [
    ("gamatoto_level", "ガマトトLvMAX"), ("gamatoto_legend", "ガマトト助手全レジェンド"),
    ("ototo_cannons", "オトート全城LvMAX"), ("upgrade_facilities", "施設LvMAX"), ("shrine_max", "神社LvMAX"),
]
CAT_SYSTEM = [
    ("gold_pass", "ゴールド会員化"), ("lineup_slots", "編成スロット最大拡張"),
    ("cat_medals", "にゃんこメダル全解放"), ("enemy_guide", "敵キャラ図鑑全解放"), ("rank_rewards", "ユーザーランク報酬全受取"),
    ("playtime_max", "プレイ時間カンスト"), ("all_missions", "全ミッションクリア"), ("remove_popups", "開放テロップ削除"),
    ("hide_ads", "広告非表示"), ("account_dup", "垢複製"), ("unban", "バン解除"),
    ("all_apply", "代行全適用垢"),
]

CATEGORIES = {
    "item":     ("🔑", "アイテム系", "資源・チケット・素材など (個数指定可 / 未入力でMAX)", CAT_ITEM),
    "stage":    ("🔑", "ステージ系", "各種ステージの全クリア", CAT_STAGE),
    "char":     ("🔑", "キャラ系", "キャラ解放・レベル・形態・本能", CAT_CHAR),
    "gamatoto": ("🔑", "ガマトト系", "ガマトト・オトート・施設・神社", CAT_GAMATOTO),
    "system":   ("🔑", "システム系", "会員・スロット・図鑑・報酬・その他", CAT_SYSTEM),
}

QUANTITY_ITEMS = {
    "xp": ("XP", 99999999),
    "np": ("NP", 9999),
    "catfood": ("猫缶", 58000),
    "leadership": ("リーダーシップ", 999),
    "normal_ticket": ("にゃんチケ", 999),
    "rare_ticket": ("レアチケ", 999),
    "platinum_tickets": ("プラチケ", 29),
    "legend_tickets": ("レジェチケ", 29),
    "event_tickets": ("イベチケ", 999),
    # 「全種」系: 指定した個数がセット内の各アイテムに入る(未指定はカンスト)
    "battle_items": ("バトルアイテム全種", 999),
    "catseyes": ("キャッツアイ全種", 999),
    "matatabi": ("マタタビ+獣石全種", 998),
    # 本能玉は所持しているものだけが対象なので「全種」ではない
    "edit_talent_or_bs": ("本能玉", 99),
    "base_materials": ("城素材全種", 999),
    "catamins": ("ネコビタン全種", 999),
    "labyrinth_medals": ("地底迷宮メダル全種", 99),
}

# 「全種」系アイテム。個数を指定するとセット内の各アイテムに同じ個数が入るため、
# 表示・入力時に「各」を付けて1種あたりの個数だとわかるようにする。
# 本能玉は所持しているものだけが対象で「全種」ではないため、ここには入れない
# (「各」も「全種」の案内も付かない)。
FULL_SET_ITEMS = {
    "battle_items", "catseyes", "matatabi",
    "base_materials", "catamins", "labyrinth_medals",
}


CAT_ID_OPTS = {"unlock_cats_specific", "upgrade_cats_specific", "true_form_cats_specific"}

ACCOUNT_RESET_OPTS = {"account_dup", "unban"}

# メインストーリーの章(StoryChapters.get_real_chapters のインデックス順)。
# 「メイン全クリア＋金お宝」で章を個別選択できるようにする。未選択なら全章。
MAIN_CHAPTER_NAMES = [
    "日本編1章", "日本編2章", "日本編3章",
    "未来編1章", "未来編2章", "未来編3章",
    "宇宙編1章", "宇宙編2章", "宇宙編3章",
]

def main_chapter_label(indices) -> str:
    """選択された章インデックスを『日本編1章、未来編2章』のような表示にする。空なら全章。"""
    if not indices:
        return "全章"
    return "、".join(MAIN_CHAPTER_NAMES[i] for i in sorted(indices)
                    if 0 <= i < len(MAIN_CHAPTER_NAMES))

def current_cleared_chapters(sf) -> set:
    """セーブ上で既にクリア済みのメイン章(実インデックス)の集合を返す。
    章の解放判定(前の章がクリア済みか)に使う。"""
    out = set()
    story = getattr(sf, "story", None)
    if story is None:
        return out
    try:
        real = story.get_real_chapters()
    except Exception:
        return out
    for idx, ch in enumerate(real):
        if int(getattr(ch, "progress", 0) or 0) >= 48:
            out.add(idx)
    return out

def chapter_unlocked(idx: int, cleared: set, selected) -> bool:
    """章idxが解放済みか。最初の章か、前の章が(既クリア or 今回選択済み)なら解放。"""
    if idx <= 0:
        return True
    return (idx - 1) in cleared or (idx - 1) in set(selected or [])


def _count_node_stages(top):
    """ノード(chapters→(sub)→stages のネスト)を走査してクリア数(cleared,total)を返す。
    ステージが1つも見つからない/エラーなら None。実セーブ(SAVE_DATA)で検証済み。"""
    try:
        cleared = total = 0
        stack = [top]
        seen_stage = False
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                node = list(node.values())
            if isinstance(node, (list, tuple)):
                stack.extend(node)
                continue
            stages = getattr(node, "stages", None)
            if stages is not None:
                seen_stage = True
                stlist = stages.values() if isinstance(stages, dict) else stages
                for st in stlist:
                    total += 1
                    for v in (getattr(st, "clear_amount", None), getattr(st, "clear_times", None)):
                        if isinstance(v, int) and v > 0:
                            cleared += 1
                            break
                        if isinstance(v, (list, tuple)) and any(int(z) > 0 for z in v):
                            cleared += 1
                            break
            sub = getattr(node, "chapters", None)
            if sub is not None:
                stack.append(sub.chapters if hasattr(sub, "chapters") else sub)
        if not seen_stage or total == 0:
            return None
        return cleared, total
    except Exception:
        return None


def _map_group_clear_ratio(group):
    """トップに .chapters を持つステージ群のクリア数(cleared,total)。判定不能は None。"""
    chapters = getattr(group, "chapters", None)
    if chapters is None:
        return None
    top = chapters.chapters if hasattr(chapters, "chapters") else chapters
    return _count_node_stages(top)


def is_fully_cleared(group):
    """ステージ群が完全クリア済みか。True/False/None(判定不能)。"""
    r = _map_group_clear_ratio(group)
    if r is None:
        return None
    cleared, total = r
    return cleared >= total and total > 0


# ステージ系の解放依存。key=商品, value=(前提商品 or None, 前提の説明, セーブ判定関数名)
# 前提が「同じ注文で一緒に選ばれている」か「アカウントで既にクリア済み」なら通す。
# セーブ判定は実データ未検証のため fail-open(判定不能=Noneで通す)。誤ブロックを避ける。
def _group_unlocked_incomplete(group):
    """解放済み(chapter_unlock_state>0)なのに手つかず(clear_progress==0)のマップ数。
    ステージ構造が読めなければ None。実セーブで検証済み。
    ※ 各マップの枠(len(stages))は未使用スロットを含み実ステージ数と一致しないため、
      枠数比較ではなく「clear_progress==0(=1つもクリアしていない)」で未完判定する。
    ・0  → 解放済みマップは全て着手/クリア済み = そのモードは完了(前提を満たす)
    ・>0 → 解放されたのに手つかずのマップがある = 未完了(前提を満たさない)
    """
    chapters = getattr(group, "chapters", None)
    if chapters is None:
        return None
    top = chapters.chapters if hasattr(chapters, "chapters") else chapters
    try:
        inc = 0
        seen = False
        stack = [top]
        while stack:
            node = stack.pop()
            if isinstance(node, dict):
                node = list(node.values())
            if isinstance(node, (list, tuple)):
                stack.extend(node)
                continue
            us = getattr(node, "chapter_unlock_state", None)
            cp = getattr(node, "clear_progress", None)
            stg = getattr(node, "stages", None)
            if us is not None and cp is not None and stg is not None:
                seen = True
                if int(us or 0) > 0 and int(cp or 0) == 0:
                    inc += 1
            sub = getattr(node, "chapters", None)
            if sub is not None:
                stack.append(sub.chapters if hasattr(sub, "chapters") else sub)
        return inc if seen else None
    except Exception:
        return None


def _sol_complete(sf):
    """旧レジェ(SoL=event_stages種別0)が完了しているか。True/False/None。"""
    es = getattr(sf, "event_stages", None)
    if es is None:
        return None
    try:
        inner = es.chapters.chapters if hasattr(es.chapters, "chapters") else es.chapters
        inc = _group_unlocked_incomplete(inner[0])
        return None if inc is None else (inc == 0)
    except Exception:
        return None

def _uncanny_complete(sf):
    """真レジェ(uncanny)が完了しているか。True/False/None。"""
    inc = _group_unlocked_incomplete(getattr(sf, "uncanny", None))
    return None if inc is None else (inc == 0)

def _chapter_progress_pos(sf, idx):
    """メイン章idxに少しでも進行があるか。進行0だけ False、読めなければ None。"""
    story = getattr(sf, "story", None)
    if story is None:
        return None
    try:
        real = story.get_real_chapters()
    except Exception:
        return None
    if not real or idx >= len(real):
        return None
    return int(getattr(real[idx], "progress", 0) or 0) > 0

# 福岡県は日本編1章のステージインデックス39(StageName_ja.csv 40行目)。
# 旧レジェ・イベステはここをクリアすると解放されるため、進行>=40 を前提とする。
FUKUOKA_PROGRESS = 40

def _chapter_progress_at_least(sf, idx, min_progress):
    """メイン章idxの進行が min_progress 以上か。読めなければ None。"""
    story = getattr(sf, "story", None)
    if story is None:
        return None
    try:
        real = story.get_real_chapters()
    except Exception:
        return None
    if not real or idx >= len(real):
        return None
    return int(getattr(real[idx], "progress", 0) or 0) >= min_progress

def _eoc1_fukuoka(sf):
    # 旧レジェは日本編1章の福岡県クリアで解放
    return _chapter_progress_at_least(sf, 0, FUKUOKA_PROGRESS)

# key=商品, value=(前提商品 or None, 前提の表示名, 判定関数)
# prereq_opt を同じ注文で一緒に選べば通す(Noneならバイパス無し=必ず判定)。
# そうでなければ判定関数で確認し、「確実に未達(False)」のときだけブロックする。
# ※ 魔界・イベステはセーブから解放判定を確実に読めないため依存チェックしない。
STAGE_PREREQS = {
    "true_legend": ("clear_all_sol", "旧レジェ", _sol_complete),
    "zero_legend": ("true_legend", "真レジェ", _uncanny_complete),
    "clear_all_sol": ("main_stages", "日本編1章 福岡県", _eoc1_fukuoka),
}

def validate_stage_prereqs(sf, opts):
    """選択したステージ系の解放依存を検証する。戻り値 (ok, メッセージ)。
    前提を同じ注文で一緒に選んでいれば通す。そうでなければ判定関数で確認し、
    確実に未達(False)のときだけブロックする。"""
    opts_set = set(opts)
    for item, (prereq_opt, prereq_name, detector) in STAGE_PREREQS.items():
        if item not in opts_set:
            continue
        if prereq_opt and prereq_opt in opts_set:
            continue  # 同じ注文で前提も一緒にクリアされる
        try:
            state = detector(sf)
        except Exception:
            state = None
        if state is False:  # 確実に前提未達=未解放
            item_name = LABELS.get(item, item)
            return False, (
                f"「{item_name}」はまだ解放されていません。"
                f"先に「{prereq_name}」を完了させるか、同じ注文で「{prereq_name}」も一緒に選んでください。")
    return True, ""

LABELS = {k: l for _, _, _, opts in CATEGORIES.values() for k, l in opts}

def all_apply_opts() -> list:
    """「代行全適用垢」で適用する全項目(指定キャラ系・垢複製/バン解除・自身は除く)。"""
    return [k for k in LABELS
            if k not in CAT_ID_OPTS and k not in ACCOUNT_RESET_OPTS and k != "all_apply"]

def expand_all_apply(opts: list) -> list:
    """opts に all_apply が含まれていたら全項目に展開する。"""
    if "all_apply" not in opts:
        return opts
    full = all_apply_opts()
    extra = [k for k in opts if k != "all_apply" and k not in full]
    return full + extra

def item_cap(key: str):
    """商品のカンスト値(最大数)。無いものは None。"""
    if key in QUANTITY_ITEMS:
        return QUANTITY_ITEMS[key][1]
    return None

def qty_prefix(key: str) -> str:
    """個数表示の接頭辞。「全種」系は1種あたりの個数なので「各」を付ける。"""
    return "各" if key in FULL_SET_ITEMS else ""

def item_display_name(key: str) -> str:
    """パネル等に表示する商品名。カンスト値があれば「猫缶 50,000」のように付ける。"""
    label = LABELS.get(key, key)
    cap = item_cap(key)
    return f"{label} {cap:,}" if cap is not None else label


CAT_NAME_INDEX = None
CAT_NAME_INDEX_VERSION = None      # 索引に使ったいちばん新しいデータのバージョン


def game_data_version_dirs() -> list:
    """キャラ名を読むディレクトリ(古い順)。同梱の core_data と、bcsfe のデータ置き場
    (自動で取り寄せた新しいバージョンはこちらに入る)。同じバージョンは置き場を優先。"""
    roots = [Path("./core_data/game_data")]
    try:
        roots.append(Path(core.GameDataGetter.get_game_data_dir().path))
    except Exception as e:
        print(f"[search] bcsfe のデータ置き場を読めません: {e}", flush=True)
    found = {}
    for root in roots:
        try:
            for d in root.glob(f"{GAME_DATA_CC}/*"):
                if d.is_dir() and (d / "resLocal").is_dir():
                    found[d.name] = d
        except Exception:
            continue
    return [found[v] for v in sorted(found, key=version_tuple)]


def load_cat_name_index() -> dict:
    """キャラID → 形態名の一覧。手元にあるデータを古い順に読み、新しいもので上書きする
    (新しいバージョンにだけあるキャラが増え、名前が変わったものは新しい名前になる)。"""
    global CAT_NAME_INDEX, CAT_NAME_INDEX_VERSION
    if CAT_NAME_INDEX is not None:
        return CAT_NAME_INDEX
    idx = {}
    newest = None
    try:
        for d in game_data_version_dirs():
            for f in sorted((d / "resLocal").glob("Unit_Explanation*_ja.csv")):
                m = re.match(r"Unit_Explanation(\d+)_", f.name)
                if not m:
                    continue
                cat_id = int(m.group(1)) - 1
                names = []
                try:
                    text = f.read_text(encoding="utf-8", errors="replace")
                except Exception:
                    continue
                for line in text.splitlines():
                    nm = line.split(",")[0].strip().strip("　")
                    if nm:
                        names.append(nm)
                if names:
                    idx[cat_id] = names
            newest = d.name
    except Exception as e:
        print(f"[search] キャラ名インデックス作成失敗: {e}", flush=True)
    print(f"[search] キャラ名インデックス: {len(idx)}体 (データ {newest})", flush=True)
    CAT_NAME_INDEX = idx
    CAT_NAME_INDEX_VERSION = newest
    return idx


def known_cat_max_id() -> int:
    """索引に載っているいちばん大きいキャラID(0始まり)。無ければ -1。"""
    idx = load_cat_name_index()
    return max(idx) if idx else -1

def cat_name(spec_id: int) -> str:
    """指定キャラID(検索で表示される1始まりの番号)から基本形態のキャラ名を返す。"""
    idx = load_cat_name_index()
    names = idx.get(spec_id - 1)
    if names and names[0]:
        return names[0]
    return f"ID{spec_id}"

def spec_cat_names(spec_ids: list) -> str:
    """指定キャラIDのリストを「名前(ID:xxx), 名前(ID:xxx)」の文字列にする。"""
    if not spec_ids:
        return "未指定"
    return ", ".join(f"{cat_name(x)}(ID:{x})" for x in spec_ids)

def search_cat_ids(query: str) -> list:
    """キャラ名(部分一致)またはIDで検索し [(cat_id, [形態名...]), ...] を返す。"""
    idx = load_cat_name_index()
    q = query.strip().lower()
    if not q:
        return []
    results = []
    if q.isdigit():
        cid = int(q) - 1
        if cid in idx:
            results.append((cid, idx[cid]))
    for cid, names in idx.items():
        if any(q in n.lower() for n in names) and all(cid != r[0] for r in results):
            results.append((cid, names))
    results.sort(key=lambda r: r[0])
    return results

def apply_modifications(save_bytes: bytes, opts: list[str], amounts: dict, spec_c_ids: list[int],
                        main_chapters: list[int] = None):
    """セーブの編集(ブロッキング)。1件ずつ流す(EDIT_LOCK の説明を参照)。"""
    with EDIT_LOCK:
        return _apply_modifications(save_bytes, opts, amounts, spec_c_ids, main_chapters)


def _apply_modifications(save_bytes: bytes, opts: list[str], amounts: dict, spec_c_ids: list[int],
                         main_chapters: list[int] = None):
    opts = expand_all_apply(opts)  # 「代行全適用垢」なら全項目に展開
    nyanko = Nyanko(save_bytes)
    s = nyanko.save_file
    lg = []
    
    try:
        core.StoryChapters.clear_tutorial(nyanko.save_file)
        if hasattr(nyanko.save_file, "unlock_equip_menu"): nyanko.save_file.unlock_equip_menu()
    except: pass

    def get_val(k, lim):
        val = amounts.get(k)
        if val is None or val == "": return lim
        try: return min(int(val), lim)
        except: return lim

    # 追跡アイテム(猫缶・レアチケ・プラチケ・レジェチケ)は、PONOSがサーバ側の
    # 台帳で増減を照合している。セーブの数字だけ書き換えて増分を申告しないと
    # 「出どころのない増加」として照合に落ち、BANの種になる。bcsfe本体の編集と
    # 同じに、増減を ManagedItem としてセーブへ記録しておき、アップロード時に
    # managedItemDetails として申告する(CEd.up を参照)。XP・NP・統率力・
    # にゃんチケなどは台帳の対象外(bcsfe の ManagedItemType はこの4つだけ)。
    try:
        # 前の代行の記録が残っていると、同じ増分を二重に申告してしまう。
        core.BackupMetaData(s).remove_managed_items()
    except Exception:
        pass

    def edit_tracked(kind, getter, do_edit):
        before = getter()
        do_edit()
        try:
            core.BackupMetaData(s).add_managed_item(
                core.ManagedItem.from_change(getter() - before, kind))
        except Exception as e:
            print(f"[NYANKO] 増分申告を記録できません({kind}): {e}", flush=True)

    # ① 資源・アイテム系
    if "xp" in opts: nyanko.edit_xp(get_val("xp", 99999999)); lg.append(f"✅ XP {nyanko.save_file.xp}")
    if "np" in opts: nyanko.edit_np(get_val("np", 9999)); lg.append(f"✅ NP {nyanko.save_file.np}")
    if "catfood" in opts:
        edit_tracked(core.ManagedItemType.CATFOOD, lambda: s.catfood,
                     lambda: nyanko.edit_catfood(get_val("catfood", 58000)))
        lg.append(f"✅ 猫缶 {nyanko.save_file.catfood}")
    if "leadership" in opts: nyanko.edit_leadership(get_val("leadership", 999)); lg.append(f"✅ 統率力 {nyanko.save_file.leadership}")
    if "normal_ticket" in opts: nyanko.edit_normal_tickets(get_val("normal_ticket", 999)); lg.append(f"✅ にゃんチケ {nyanko.save_file.normal_tickets}")
    if "rare_ticket" in opts:
        edit_tracked(core.ManagedItemType.RARE_TICKET, lambda: s.rare_tickets,
                     lambda: nyanko.edit_rare_tickets(get_val("rare_ticket", 999)))
        lg.append(f"✅ レアチケ {nyanko.save_file.rare_tickets}")
    if "platinum_tickets" in opts:
        edit_tracked(core.ManagedItemType.PLATINUM_TICKET, lambda: s.platinum_tickets,
                     lambda: nyanko.edit_platinum_tickets(get_val("platinum_tickets", 29)))
        lg.append(f"✅ プラチケ {nyanko.save_file.platinum_tickets}")
    if "legend_tickets" in opts:
        edit_tracked(core.ManagedItemType.LEGEND_TICKET, lambda: s.legend_tickets,
                     lambda: nyanko.edit_legend_tickets(get_val("legend_tickets", 29)))
        lg.append(f"✅ レジェチケ {nyanko.save_file.legend_tickets}")
    if "event_tickets" in opts:
        v = get_val("event_tickets", 999)
        nyanko.edit_event_tickets(v)
        lg.append(f"✅ イベチケ 各{v:,}")

    # 「全種」系アイテム。個数指定があればセット内の各アイテムにその個数を入れる(未指定はカンスト)。
    for key, fn in (
        ("battle_items", nyanko.edit_battle_items),
        ("catseyes", nyanko.edit_catseyes),
        ("matatabi", nyanko.edit_matatabi),
        ("base_materials", nyanko.edit_base_materials),
        ("catamins", nyanko.edit_catamins),
    ):
        if key not in opts:
            continue
        v = get_val(key, QUANTITY_ITEMS[key][1])
        fn(v)
        lg.append(f"✅ {LABELS.get(key, key)} 各{v:,}")
    # 本能玉は「所持しているもののみ」が対象なので、入った種類数をログに残す。
    # 一括ループに混ぜると失敗しても ✅ と出てしまうため、ここで分けて扱う。
    if "edit_talent_or_bs" in opts:
        try:
            info = nyanko.edit_talent_orbs(get_val("edit_talent_or_bs", QUANTITY_ITEMS["edit_talent_or_bs"][1]))
            lg.append(f"✅ 本能玉 [{info}]")
        except Exception as e:
            lg.append(f"❌ 本能玉 エラー: {e}")
    if "labyrinth_medals" in opts:
        try:
            info = nyanko.edit_labyrinth_medals(get_val("labyrinth_medals", QUANTITY_ITEMS["labyrinth_medals"][1]))
            lg.append(f"✅ 地底迷宮メダル全種 [{info}]")
        except Exception as e:
            lg.append(f"❌ 地底迷宮メダル全種 エラー: {e}")

    # ② キャラ系
    real_c_ids = [max(0, int(i) - 1) for i in spec_c_ids if str(i).strip().isdigit()]
    if "unlock_cats_all" in opts:
        info = nyanko.unlock_cats()
        lg.append(f"✅ 全キャラ解放+エラーキャラ削除 [{info}]")
    if "unlock_cats_specific" in opts and real_c_ids:
        info = nyanko.unlock_cats(real_c_ids)
        # 1体も解放できていないのに ✅ を出さない(番号違い・アプリが古い など)。
        mark = "⚠️" if str(info).startswith("解放0体") else "✅"
        lg.append(f"{mark} 指定キャラ解放 [{info}]")
    if "upgrade_cats_all" in opts: nyanko.upgrade_cats(); lg.append("✅ 全キャラLvMAX")
    if "upgrade_cats_specific" in opts and real_c_ids: nyanko.upgrade_cats(real_c_ids); lg.append("✅ 指定キャラLvMAX")
    if "true_form_cats_all" in opts:
        info = nyanko.true_form_cats()
        lg.append(f"✅ 全キャラ最大形態化 [{info}]")
    if "true_form_cats_specific" in opts and real_c_ids:
        info = nyanko.true_form_cats(real_c_ids)
        mark = "⚠️" if str(info).startswith("0体") else "✅"
        lg.append(f"{mark} 指定キャラ最大形態化 [{info}]")
    if "upgrade_talents_all" in opts:
        info = nyanko.upgrade_talents_max()
        lg.append(f"✅ 全キャラ本能MAX [{info}]")

    # ③ 施設・ステージ系
    if "upgrade_facilities" in opts: nyanko.upgrade_facilities(); lg.append("✅ 施設LvMAX")
    if "gamatoto_level" in opts:
        info = nyanko.edit_gamatoto_level()
        lg.append(f"✅ ガマトトLvMAX [{info}]")
        
    if "gamatoto_legend" in opts:
        try:
            info = nyanko.edit_gamatoto_helpers()
            lg.append(f"✅ ガマトト助手全レジェンド [{info}]")
        except Exception as e:
            lg.append(f"❌ ガマトト助手エラー: {e}")

    # ③-2 収集・アカウント系 (bcsfeゲームデータ準拠)
    new_edits = [
        ("gold_pass", "ゴールド会員化", nyanko.edit_gold_pass),
        ("lineup_slots", "編成スロット最大拡張", nyanko.edit_lineup_slots),
        ("cat_medals", "にゃんこメダル全解放", nyanko.unlock_all_medals),
        ("enemy_guide", "敵キャラ図鑑全解放", nyanko.unlock_enemy_guide_all),
        ("rank_rewards", "ユーザーランク報酬全受取", nyanko.claim_user_rank_rewards),
        ("playtime_max", "プレイ時間カンスト", nyanko.edit_playtime),
        ("all_missions", "全ミッションクリア", nyanko.clear_all_missions),
        ("remove_popups", "開放テロップ削除", nyanko.remove_unlock_popups),
        ("hide_ads", "広告非表示", nyanko.hide_ads),
    ]
    for key, label, fn in new_edits:
        if key not in opts:
            continue
        try:
            info = fn()
            lg.append(f"✅ {label} [{info}]")
        except Exception as e:
            lg.append(f"❌ {label} エラー: {e}")

    if "ototo_cannons" in opts: nyanko.edit_ototo_cannons(); lg.append("✅ オトート全城LvMAX")
    if "shrine_max" in opts:
        try:
            data = core.core_data.get_cat_shrine_levels(nyanko.save_file)
            max_xp = data.get_max_xp()
            max_level = data.get_max_level()
            if max_xp is not None:
                nyanko.save_file.cat_shrine.xp_offering = max_xp
                if max_level is not None:
                    nyanko.save_file.cat_shrine.dialogs = max_level - 1
                lg.append("✅ 神社LvMAX")
            else:
                lg.append("❌ 神社Lv: レベルデータ取得失敗")
        except Exception as e:
            lg.append(f"❌ 神社Lv エラー: {e}")

    if "main_stages" in opts and hasattr(s, "story"):
        real = s.story.get_real_chapters()
        # 選んだ章だけをクリアする(自動穴埋めしない)。未選択なら全章。
        # 解放依存(前の章がクリア済みか)はUI側でブロック済みなのでここでは選択通りに適用。
        explicit = bool([i for i in (main_chapters or []) if 0 <= i < len(real)])
        sel = [i for i in main_chapters if 0 <= i < len(real)] if explicit else list(range(len(real)))
        for idx in sel:
            ch = real[idx]
            ch.apply_progress(48, [1]*48)
            for i in range(48): ch.set_treasure(i, 3)
        # チュートリアルは常にクリア扱いにしてプレイ可能にする。
        # メイン=日本編1章〜宇宙編3章の9章のみ。魔界編・フィリバスターには手を付けない。
        for attr in ["tutorial_cleared"]:
            if hasattr(s, attr): setattr(s, attr, True)
            if hasattr(s, "story") and hasattr(s.story, attr): setattr(s.story, attr, True)
        if not explicit:
            lg.append("✅ メイン全クリア(9章)+48個金お宝")
        else:
            lg.append(f"✅ メインクリア+金お宝（{main_chapter_label(sel)}）")

    if "clear_all_sol" in opts and hasattr(s, "event_stages"):
        for m in range(50):
            for star in range(4):
                for st in range(8):
                    try: s.event_stages.clear_stage(0, m, star, st, overwrite_clear_progress=True, ensure_cleared_only=True)
                    except: pass
        lg.append("✅ 旧レジェ全クリア")
        
    if "true_legend" in opts and hasattr(s, "uncanny"):
        force_clear_map_group(s.uncanny.chapters, sys.modules[s.uncanny.chapters.__module__])
        lg.append("✅ 真レジェ全クリア")
        
    if "zero_legend" in opts and hasattr(s, "zero_legends"):
        force_clear_map_group(s.zero_legends, sys.modules[s.zero_legends.__module__])
        lg.append("✅ 零レジェ全クリア")

    if "makai" in opts and hasattr(s, "aku"):
        force_clear_map_group(s.aku, sys.modules[s.aku.__module__])
        if hasattr(s, "aku_unlocked"): s.aku_unlocked = True
        lg.append("✅ 魔界編全クリア")
    
    if "zombie_stages" in opts and hasattr(s, "outbreaks"):
        try:
            mod = sys.modules[s.outbreaks.__module__]
            Outbreak = getattr(mod, "Outbreak")
            OutbreakChapter = getattr(mod, "Chapter")
            # メインでクリア済みの段階(=ゾンビが解放されている章・ステージ)だけをクリアする。
            # 未クリアの章のゾンビには手を付けない(歯抜けの不整合を避ける)。
            story_chapters = getattr(getattr(s, "story", None), "chapters", None)
            done = 0
            for cid in [0, 1, 2, 4, 5, 6, 7, 8, 9]:
                prog = 0
                if story_chapters is not None and cid < len(story_chapters):
                    prog = int(getattr(story_chapters[cid], "progress", 0) or 0)
                if prog <= 0:
                    continue  # メイン未クリアの章はゾンビも触らない
                if cid not in s.outbreaks.chapters:
                    s.outbreaks.chapters[cid] = OutbreakChapter(cid, {})
                for j in range(min(prog, 48)):
                    if j not in s.outbreaks.chapters[cid].outbreaks:
                        s.outbreaks.chapters[cid].outbreaks[j] = Outbreak(True)
                    else:
                        s.outbreaks.chapters[cid].outbreaks[j].cleared = True
                done += 1
            if hasattr(s.outbreaks, "current_outbreaks"): s.outbreaks.current_outbreaks.clear()
            if done:
                lg.append("✅ ゾンビクリア(クリア済みの章のみ)")
            else:
                lg.append("⚠️ ゾンビ: クリア済みのメイン章が無いため対象なし")
        except Exception as e: lg.append(f"❌ ゾンビクリア失敗: {e}")

    if "event_stages" in opts and hasattr(s, "event_stages"):
        chaps = getattr(s.event_stages, "chapters", [])
        if len(chaps) > 1:
            for cg in (chaps[1:] if isinstance(chaps, list) else list(chaps.values())[1:]):
                force_clear_map_group(cg, sys.modules[s.event_stages.__module__])
        # 塔・強襲・獣石・コラボ強襲も一緒にクリア(別オブジェクトのため個別処理)
        for name in ("gauntlets", "collab_gauntlets", "behemoth_culling"):
            g = getattr(s, name, None)
            if g is not None:
                try:
                    force_clear_map_group(g, sys.modules[g.__module__])
                except Exception as e:
                    lg.append(f"❌ {name}: {e}")
        # 塔(tower)は構造が異なるので clear_stage(map,star,stage) で総当り
        tw = getattr(s, "tower", None)
        tch = getattr(tw, "chapters", None) if tw is not None else None
        if tch is not None and hasattr(tch, "clear_stage"):
            try:
                for mi, mp in enumerate(getattr(tch, "chapters", []) or []):
                    for si, star in enumerate(getattr(mp, "chapters", []) or []):
                        for sti in range(len(getattr(star, "stages", []) or [])):
                            try:
                                tch.clear_stage(mi, si, sti)
                            except Exception:
                                pass
            except Exception as e:
                lg.append(f"❌ 塔: {e}")
        lg.append("✅ イベステ全クリア(塔・強襲・獣石含む)")

    for f in ["ban_flag", "is_banned", "cheat_flag", "hacked", "show_ban_message", "fraud_flag", "suspicious"]:
        if hasattr(s, f): setattr(s, f, False)
    try:
        s.write_to_file()
    except:
        pass
    
    try:
        nyanko.bypass_ban()
    except:
        pass
    # 編集後のセーブそのものも返す。呼び出し側が使うので、バイト列から
    # 読み直す必要がない(セーブのパースは重いうえ、代行のたびに走る)。
    return nyanko.get_raw_data(), lg, nyanko.save_file


class CatSearchModal(ui.Modal):
    def __init__(self):
        super().__init__(title="キャラID検索")
        self.add_item(ui.TextInput(label="キャラ名 (一部でもOK) または ID", placeholder="例: キャスリィ", required=True))

    async def on_submit(self, i: discord.Interaction):
        q = self.children[0].value.strip()
        results = await asyncio.to_thread(search_cat_ids, q)
        db_link = "[キャラ一覧 (battlecats-db)](https://battlecats-db.com/unit/index_status.html)"
        data_ver = CAT_NAME_INDEX_VERSION or "不明"
        if not results:
            hint = ""
            top = known_cat_max_id() + 1
            if q.isdigit() and int(q) > top:
                # 手元のデータより新しいID(新コラボなど)。名前は出せないが、IDを
                # そのまま入れれば解放はできる(unlock_cats が新しいIDを解放する)。
                hint = (f"\nこのIDは手元のゲームデータ（{data_ver} / ID {top} まで）にまだ"
                        "載っていません。新しいデータは配布され次第、自動で取り寄せます。\n"
                        "battlecats-db で確かめたIDなら、そのまま「指定キャラID入力」に"
                        "入れれば解放できます（名前は表示されません）。")
            return await i.response.send_message(
                f"❌ 「{q}」に一致するキャラが見つかりませんでした。{hint}\n{db_link}", ephemeral=True)
        lines = [f"`{cid + 1:>3}` : {' → '.join(names[:4])}" for cid, names in results[:20]]
        more = f"\n…他 {len(results) - 20} 件 (キーワードを絞ってください)" if len(results) > 20 else ""
        embed = discord.Embed(
            title=f"🔍 キャラID検索: {q}",
            description="\n".join(lines) + more +
                        f"\n\n左の数字を「指定キャラID入力」にカンマ区切りで入力してください。\n{db_link}",
            color=0x00aaff
        )
        embed.set_footer(text=f"キャラデータ {data_ver}（ID {known_cat_max_id() + 1} まで）")
        await i.response.send_message(embed=embed, ephemeral=True)


# --- ① 個数入力モーダル (1品目1フィールド) ---
class QuantityModal(ui.Modal):
    def __init__(self, cfg: "ConfigView", key: str, label: str, maxv: int):
        super().__init__(title=f"{label} の個数")
        self.cfg = cfg
        self.key = key
        cur = cfg.amounts.get(key)
        per = qty_prefix(key)  # 「全種」系は1種あたりの個数
        note = "／全種に同じ個数が入ります" if per else ""
        self.field = ui.TextInput(
            label=f"{label} (最大 {per}{maxv:,})",
            placeholder=f"空欄で最大値 ({per}{maxv:,}){note}",
            required=False,
            default=str(cur) if cur not in (None, "") else None,
            max_length=12,
        )
        self.add_item(self.field)

    async def on_submit(self, i: discord.Interaction):
        v = self.field.value.strip().replace(",", "")
        if v == "":
            self.cfg.amounts.pop(self.key, None)
        elif v.isdigit():
            self.cfg.amounts[self.key] = v
        else:
            return await i.response.send_message("❌ 数字を入力してください。", ephemeral=True)
        await i.response.edit_message(embed=self.cfg.build_embed(), view=self.cfg)


# --- ② 指定キャラID入力モーダル (カンマ区切りで複数可) ---
class CatIdModal(ui.Modal):
    def __init__(self, cfg: "ConfigView"):
        super().__init__(title="指定キャラID入力")
        self.cfg = cfg
        cur = ", ".join(str(x) for x in cfg.spec_cat_ids)
        self.field = ui.TextInput(
            label="キャラID (カンマ区切りで複数可)",
            placeholder="例: 25, 26, 100",
            required=False,
            default=cur or None,
            style=discord.TextStyle.paragraph,
        )
        self.add_item(self.field)

    async def on_submit(self, i: discord.Interaction):
        ids = []
        for x in self.field.value.replace(" ", ",").split(","):
            x = x.strip()
            if x.isdigit() and int(x) not in ids:
                ids.append(int(x))
        self.cfg.spec_cat_ids = ids
        await i.response.edit_message(embed=self.cfg.build_embed(), view=self.cfg)


# --- メイン章の選択ビュー (「メイン全クリア＋金お宝」で章を個別指定 / 未選択で全章) ---
def chapter_select_embed(cfg: "ConfigView") -> discord.Embed:
    sel = main_chapter_label(cfg.main_chapters)
    cleared = sorted(cfg.cleared_chapters)
    cleared_txt = main_chapter_label(cleared) if cleared else "なし"
    return discord.Embed(
        title="メインストーリーの章を選択",
        description=(
            f"クリアする章を選んでください（複数可）。押すと ✅ が付きます。\n"
            f"**何も選ばずに戻ると全章（メイン全クリア）が適用されます。**\n"
            f"🔒 の章は前の章が未クリアで**まだ解放されていません**"
            f"（前の章を選ぶ／クリア済みになると解放されます）。\n\n"
            f"このアカウントで既にクリア済み: **{cleared_txt}**\n"
            f"今回クリアする章: **{sel}**"
        ),
        color=0x00aaff,
    )


class ChapterSelectView(ui.View):
    def __init__(self, cfg: "ConfigView"):
        super().__init__(timeout=600)
        self.cfg = cfg
        # 9章のトグルボタン(日本編1章〜宇宙編3章)。3章ずつ行を分ける。
        for idx, name in enumerate(MAIN_CHAPTER_NAMES):
            on = idx in cfg.main_chapters
            unlocked = chapter_unlocked(idx, cfg.cleared_chapters, cfg.main_chapters)
            already = idx in cfg.cleared_chapters
            if already and not on:
                label, style = f"済 {name}", discord.ButtonStyle.secondary
            elif on:
                label, style = f"✅ {name}", discord.ButtonStyle.success
            elif unlocked:
                label, style = name, discord.ButtonStyle.secondary
            else:
                label, style = f"🔒 {name}", discord.ButtonStyle.secondary
            b = ui.Button(label=label, style=style, row=idx // 3)
            b.callback = self._make_toggle(idx)
            self.add_item(b)
        done = ui.Button(label="決定して戻る", style=discord.ButtonStyle.primary, row=3)
        done.callback = self._done
        self.add_item(done)

    def _make_toggle(self, idx: int):
        async def cb(i: discord.Interaction):
            cfg = self.cfg
            if idx in cfg.main_chapters:
                # 解除: この章より後で選択済みの章も連鎖して外す(歯抜け防止)
                cfg.main_chapters = [j for j in cfg.main_chapters if j < idx]
            else:
                if not chapter_unlocked(idx, cfg.cleared_chapters, cfg.main_chapters):
                    prev = MAIN_CHAPTER_NAMES[idx - 1]
                    return await i.response.send_message(
                        f"「{MAIN_CHAPTER_NAMES[idx]}」はまだ解放されていません。"
                        f"先に「{prev}」をクリア（選択）してください。", ephemeral=True)
                cfg.main_chapters.append(idx)
            await i.response.edit_message(embed=chapter_select_embed(cfg),
                                          view=ChapterSelectView(cfg))
        return cb

    async def _done(self, i: discord.Interaction):
        await i.response.edit_message(embed=self.cfg.build_embed(), view=self.cfg)


# --- ③ 個数入力 & 実行ビュー (引継ぎ成功後に表示 / ユーザー個別) ---
class ConfigView(ui.View):
    def __init__(self, opts: list[str], ed: "CEd", requester=None, spec_ids=None,
                 tc: str = "", pin: str = "", free_ticket: bool = False,
                 total_price: int = 0, user_id=None, admin_free: bool = False,
                 set_info: dict = None, fixed: bool = False):
        super().__init__(timeout=600)
        self.opts = opts
        self.ed = ed
        self.requester = requester
        self.paid_amount = 0              # 支払い完了後に設定される
        self.total_price = total_price    # 支払うべき合計金額
        self.user_id = user_id
        # セット商品(固定価格の束売り)。売上を1件=1セットで記録し、個数指定などの
        # ボタンは出さない(中身は固定でMAX適用)。set_info={"name","price"}。
        self.set_info = dict(set_info) if set_info else None
        self.fixed = bool(fixed) or bool(set_info)
        self.tc = tc                      # 入力された引き継ぎコード(非公開ログ用)
        self.pin_code = pin               # 入力されたPIN(非公開ログ用)
        self.pay_link = None              # 支払いに使われた送金リンク(非公開ログ用)
        self.method = payments.PAYPAY     # 実際に使われた支払い方法
        self.free_ticket = free_ticket    # 無料券適用か
        self.admin_free = admin_free      # 管理者の動作確認(全商品0円)か
        self._done = False                # 二重実行防止
        self.amounts: dict[str, str] = {}
        self.spec_cat_ids: list[int] = list(spec_ids) if spec_ids else []
        self.main_chapters: list[int] = []  # メイン章の選択(空=全章)
        # 現在のセーブで既にクリア済みの章(解放判定に使う)
        self.cleared_chapters: set = current_cleared_chapters(getattr(ed, "sf", None))
        self.quantity_keys = [k for k in QUANTITY_ITEMS if k in opts]
        # 指定キャラIDは支払い前に入力済みのためボタンは出さない(未指定時のみ)
        self.needs_cat_ids = any(o in opts for o in CAT_ID_OPTS) and not self.spec_cat_ids
        # メイン全クリアが選択されていれば章選択ボタンを出す
        self.has_main_stages = "main_stages" in opts

        # セットは中身が固定なので、個数・キャラID・章の変更ボタンは出さない
        # (全部まとめてMAX/全章で適用する)。通常の代行だけ調整ボタンを並べる。
        if not self.fixed:
            # 選択した個数指定アイテムごとにボタンを配置
            for k in self.quantity_keys:
                label, maxv = QUANTITY_ITEMS[k]
                b = ui.Button(label=f"{label}の個数", style=discord.ButtonStyle.secondary)
                b.callback = self._make_qty_cb(k, label, maxv)
                self.add_item(b)
            if self.needs_cat_ids:
                b = ui.Button(label="指定キャラID入力", style=discord.ButtonStyle.secondary)
                b.callback = self._cat_id_cb
                self.add_item(b)
            if self.has_main_stages:
                b = ui.Button(label="メイン章を選択（未選択で全章）", style=discord.ButtonStyle.primary)
                b.callback = self._chapter_cb
                self.add_item(b)
        eb = ui.Button(label="この内容で実行", style=discord.ButtonStyle.success)
        eb.callback = self._execute_cb
        self.add_item(eb)

    def sale_record(self) -> tuple:
        """売上記録に渡す (items, item_prices)。

        セットは「1件=1セット」でまとめて記録する。個別項目の単価に割ると、
        セットの値付け(まとめ割引/上乗せ)が /profit のメニュー別で崩れて
        客単価が見えなくなるため。通常の代行は従来どおり項目ごとに配分する。
        """
        if self.set_info:
            key = set_sale_key(self.set_info.get("name", ""))
            price = int(self.paid_amount or self.set_info.get("price", 0) or 0)
            return [key], {key: price}
        return list(self.opts), compute_item_prices(self.opts, self.spec_cat_ids)

    def main_stage_label(self) -> str:
        """メイン章の選択表示。未選択なら全章。"""
        return main_chapter_label(self.main_chapters)

    def log_lines(self, public: bool = False) -> list[str]:
        """内容行。数量アイテムは適用値を x付きで、指定キャラはキャラIDを表示する。

        セットは中身を1つずつ並べず「・セット名」の1行で出す(ログ・お客さんの
        購入内容ともに)。中身は購入前の確認画面と /daiko set_list で見られる。

        public=True(公開ログ)では、メイン全クリアの章の内訳は出さず
        「・メイン全クリア＋金お宝」の1行にまとめる(章まで晒さない)。
        """
        if self.set_info:
            return [f"・{self.set_info.get('name', 'セット')}"]
        lines = []
        for k in self.opts:
            label = LABELS.get(k, k)
            if k in CAT_ID_OPTS:
                lines.append(f"・{label} - {spec_cat_names(self.spec_cat_ids)}")
            elif k == "main_stages":
                lines.append(f"・{label}" if public
                             else f"・{label}（{self.main_stage_label()}）")
            elif k in QUANTITY_ITEMS and k in self.amounts:
                lines.append(f"・{label} {qty_prefix(k)}x{int(self.amounts[k]):,}")
            else:
                cap = item_cap(k)
                lines.append(f"・{label} {qty_prefix(k)}x{cap:,}" if cap is not None else f"・{label}")
        return lines

    async def _get_log_channel(self, ch_id):
        if not ch_id:
            return None
        channel = bot.get_channel(int(ch_id))
        if channel is None:
            try:
                channel = await bot.fetch_channel(int(ch_id))
            except Exception as e:
                print(f"[LOG ERROR] チャンネル取得失敗: {e}", flush=True)
                return None
        return channel

    def method_note(self) -> str:
        """ログに出す支払い方法(無料券・0円もそのまま分かるようにする)。

        0円なら支払いそのものが発生していないので「なし」。無料券は
        「どの券で通ったか」が後から要るので、そちらは券として残す。
        """
        if self.admin_free:
            return payments.ADMIN_FREE_LABEL
        if self.free_ticket:
            return payments.FREE_TICKET_LABEL
        if self.paid_amount <= 0:
            return "なし"
        return payments.method_label(self.method)

    async def send_daiko_log(self, i: discord.Interaction = None, issued_codes: list = None,
                             guild=None, channel=None):
        """代行完了ログを送信する。公開ログ(要約のみ)と非公開ログ(購入者の詳細つき)。

        LTCのように後から(Interaction無しで)実行する場合は、購入場所の表示に使う
        guild / channel を直接渡す。
        """
        cfg = load_config()
        # 「購入場所」に出すサーバー・チャンネル(ログの送信先とは別物)
        place_guild = guild if guild is not None else (i.guild if i is not None else None)
        place_channel = channel if channel is not None else (i.channel if i is not None else None)

        # --- 公開ログ(要約) ---
        # 管理者の動作確認はお客さんの購入ではない。公開ログに0円の代行が並ぶと
        # 「無料で買えた人がいる」と読めてしまうので、こちらには出さない
        # (管理者が中身を確かめられるよう、非公開ログには残す)。
        channel = (None if self.admin_free
                   else await self._get_log_channel(cfg.get("log_channel_id")))
        if channel:
            requester = f"<@{self.requester.id}>" if self.requester else "不明"
            embed = discord.Embed(title="代行ログ", color=0x00aaff)
            if self.requester:
                # 依頼者のアイコンを右側のサムネイルに表示する
                try:
                    embed.set_thumbnail(url=self.requester.display_avatar.url)
                except Exception:
                    pass
            embed.add_field(name="依頼情報", value=f"依頼者:\n{requester}", inline=False)
            embed.add_field(name="利用金額", value=f"{self.paid_amount:,}円", inline=True)
            embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
            embed.add_field(name="代行内容", value="\n".join(self.log_lines(public=True)), inline=False)
            jst_now = datetime.now(timezone(timedelta(hours=9)))
            embed.set_footer(text=f"24/h稼働中🔥 | {jst_now.strftime('%Y/%m/%d %H:%M')}")
            try:
                await channel.send(embed=embed)
            except Exception as e:
                print(f"[LOG ERROR] {e}", flush=True)

        # --- 非公開ログ(管理者用: 購入者情報を全て記録) ---
        prv = await self._get_log_channel(cfg.get("daiko_private_log_channel_id"))
        if not prv:
            return
        e = discord.Embed(
            title="非公開代行ログ" + ("（管理者の動作確認）" if self.admin_free else ""),
            color=0x7289DA, timestamp=discord.utils.utcnow())
        u = self.requester
        if u:
            try:
                e.set_thumbnail(url=u.display_avatar.url)
            except Exception:
                pass
            e.add_field(
                name="購入者",
                value=(f"{u.mention}\n"
                       f"ユーザー名: `{str(u)}`\n"
                       f"表示名: `{u.display_name}`\n"
                       f"ID: `{u.id}`"),
                inline=False,
            )
            created = int(u.created_at.timestamp())
            e.add_field(name="アカウント作成", value=f"<t:{created}:f>（<t:{created}:R>）", inline=True)
            joined = getattr(u, "joined_at", None)
            if joined:
                j = int(joined.timestamp())
                e.add_field(name="サーバー参加", value=f"<t:{j}:f>（<t:{j}:R>）", inline=True)
        e.add_field(name="利用金額", value=f"{self.paid_amount:,}円", inline=True)
        e.add_field(name="支払い方法", value=self.method_note(), inline=True)
        if self.pay_link:
            e.add_field(name="支払い情報", value=self.pay_link, inline=False)
        if self.tc:
            e.add_field(name="引き継ぎ情報（入力時）",
                        value=f"コード: `{self.tc}` / PIN: `{self.pin_code}`", inline=False)
        if issued_codes:
            lines = [f"{(lbl + ': ') if lbl else ''}コード `{t}` / PIN `{p}`" for lbl, t, p in issued_codes]
            e.add_field(name="発行した引き継ぎコード", value="\n".join(lines)[:1024], inline=False)
        e.add_field(name="代行内容", value="\n".join(self.log_lines())[:1024], inline=False)
        if place_guild is not None:
            place = place_guild.name
            if place_channel is not None:
                place += f" / {place_channel.mention}"
            e.add_field(name="購入場所", value=place, inline=False)
        try:
            await prv.send(embed=e)
        except Exception as ex:
            print(f"[PRIVATE LOG ERROR] {ex}", flush=True)

    async def send_trouble_log(self, reason: str, guild=None, channel=None):
        """「お金は受け取ったのに代行できなかった」ときのログ。

        成功したときしかログを出さないと、失敗はどこにも残らない。管理者からは
        「残高だけ増えてログが流れていない」状態になり、誰の分が失敗したのかも
        分からない。非公開ログ(無ければ公開ログ)と管理者DMの両方に必ず残す。
        """
        if int(self.paid_amount or 0) <= 0:
            return
        cfg = load_config()
        e = discord.Embed(
            title="代行に失敗しました（支払い済み）",
            description=("支払いは受け取れましたが、代行の処理が失敗しました。\n"
                         "手動で対応するか返金してください。"),
            color=0xff3333, timestamp=discord.utils.utcnow(),
        )
        u = self.requester
        if u:
            e.add_field(name="購入者", value=f"{u.mention}（`{u.id}`）", inline=False)
        e.add_field(name="受取済みの金額", value=f"{self.paid_amount:,}円", inline=True)
        e.add_field(name="支払い方法", value=self.method_note(), inline=True)
        if self.pay_link:
            e.add_field(name="支払い情報", value=self.pay_link, inline=False)
        if self.tc:
            e.add_field(name="引き継ぎ情報（入力時）",
                        value=f"コード: `{self.tc}` / PIN: `{self.pin_code}`", inline=False)
        e.add_field(name="代行内容", value="\n".join(self.log_lines())[:1024], inline=False)
        e.add_field(name="エラー", value=f"```{str(reason)[:500]}```", inline=False)
        place_guild = guild if guild is not None else None
        if place_guild is not None:
            place = place_guild.name
            if channel is not None:
                place += f" / {channel.mention}"
            e.add_field(name="購入場所", value=place, inline=False)
        e.set_footer(text="返金または手動対応が必要です")

        for key in ("daiko_private_log_channel_id", "log_channel_id"):
            ch = await self._get_log_channel(cfg.get(key))
            if ch is None:
                continue
            try:
                await ch.send(embed=e)
                break
            except Exception as ex:
                print(f"[TROUBLE LOG ERROR] {ex}", flush=True)
        # ログ先が未設定・送信不能でも管理者には必ず届くようにする
        for uid in ADMIN_IDS:
            try:
                user = bot.get_user(uid) or await bot.fetch_user(uid)
                await user.send(embed=e)
            except Exception:
                continue

    def _make_qty_cb(self, key, label, maxv):
        async def cb(i: discord.Interaction):
            await i.response.send_modal(QuantityModal(self, key, label, maxv))
        return cb

    async def _cat_id_cb(self, i: discord.Interaction):
        await i.response.send_modal(CatIdModal(self))

    async def _chapter_cb(self, i: discord.Interaction):
        await i.response.edit_message(embed=chapter_select_embed(self), view=ChapterSelectView(self))

    def build_embed(self) -> discord.Embed:
        lines = []
        for k in self.opts:
            label = LABELS.get(k, k)
            if k in QUANTITY_ITEMS:
                per = qty_prefix(k)
                if k in self.amounts:
                    lines.append(f"・{label}: `{per}{int(self.amounts[k]):,}`")
                else:
                    lines.append(f"・{label}: `MAX ({per}{QUANTITY_ITEMS[k][1]:,})`")
            elif k in CAT_ID_OPTS:
                lines.append(f"・{label}: `{spec_cat_names(self.spec_cat_ids)}`")
            elif k == "main_stages":
                lines.append(f"・{label}: `{self.main_stage_label()}`")
            else:
                cap = item_cap(k)
                if cap is not None:
                    lines.append(f"・{label}: `MAX ({cap:,})`")
                else:
                    lines.append(f"・{label}")
        desc = "\n".join(lines)
        if self.set_info:
            head = f"**{self.set_info.get('name', 'セット')}**（セット商品）\n\n【セット内容】\n"
            desc = head + desc
        if self.quantity_keys and not self.fixed:
            desc += "\n\n個数は各ボタンから入力できます (未入力はMAX)。"
            if any(k in FULL_SET_ITEMS for k in self.quantity_keys):
                desc += "\n「全種」は指定した個数がその種類すべてに入ります (「各」は1種あたりの個数)。"
        if self.needs_cat_ids and not self.fixed:
            desc += "\n指定キャラは「指定キャラID入力」からカンマ区切りで複数指定できます。"
        if self.has_main_stages and not self.fixed:
            desc += "\nメインは「メイン章を選択」から章を選べます (未選択で全章)。"
        if self.admin_free:
            desc += ("\n\n🛠 **管理者の動作確認（全商品0円）**。"
                     "「この内容で実行」で代行を開始します。売上には入りません。")
        elif self.free_ticket:
            desc += "\n\n🎫 **無料利用券適用（0円）**。「この内容で実行」で代行を開始します。"
        elif self.total_price > 0:
            desc += (f"\n\n💰 **お支払い: {self.total_price:,}円**"
                     f"\n「この内容で実行」を押すと支払い方法を選べます。")
        else:
            desc += "\n\n無料項目のみのため、「この内容で実行」で代行を開始します。"
        return discord.Embed(title="内容を確認して実行", description=desc, color=0x00aaff)

    async def _execute_cb(self, i: discord.Interaction):
        if self._done:
            return await i.response.send_message("既に処理を開始しています。", ephemeral=True)
        if self.needs_cat_ids and not self.spec_cat_ids:
            return await i.response.send_message(
                "❌ 指定キャラID系を選択中です。「指定キャラID入力」からIDを入力してください。", ephemeral=True)
        # 有料なら先に支払い方法を選ぶ。無料(0円/無料券)はそのまま実行。
        if self.total_price > 0 and not self.free_ticket:
            if not payments.available_methods():
                return await i.response.send_message(
                    "現在ご利用いただける支払い方法がありません。\n" + support.contact_line(),
                ephemeral=True)
            return await i.response.edit_message(
                embed=payments.picker_embed(self.total_price),
                view=payments.MethodPicker(self._on_method_picked))
        self._done = True
        await i.response.edit_message(content="⏳ 処理中です…しばらくお待ちください。", embed=None, view=None)
        await self.run(i)

    async def _on_method_picked(self, i: discord.Interaction, method_id: str):
        """支払い方法が選ばれたとき(リンク方式の入力モーダルを出す)。"""
        if self._done:
            return await i.response.send_message("既に処理を開始しています。", ephemeral=True)
        self.method = method_id
        return await i.response.send_modal(PaymentModal(self, method_id))

    async def _apply_and_upload(self):
        """セーブを編集して再アップロードする。

        戻り値 (完了Embed, 発行コード一覧, エラー文言)。
        エラー文言が入っていたら Embed は None。
        """
        try:
            # ダウンロード済みの元バイト列を再利用(再シリアライズを省略)
            raw = self.ed.raw if self.ed.raw is not None else self.ed.sf.to_data().to_bytes()
            # 編集した結果は、バイト列とセーブの両方を受け取る。ここで
            # バイト列から読み直すと、同じセーブを2回パースすることになり、
            # しかもその1回はイベントループ上で動いてBot全体を止めていた。
            mod_bytes, lgs, mod_save = await asyncio.to_thread(
                apply_modifications, raw, self.opts, self.amounts, self.spec_cat_ids, self.main_chapters)
            self.ed.mod_bytes = mod_bytes  # up() で再シリアライズせず直接アップロード
            self.ed.sf = mod_save
        except Exception as e:
            return None, [], f"❌ 処理エラー: {e}"

        dup = "account_dup" in self.opts
        unban = "unban" in self.opts

        # 発行するアカウント(ラベル, 引き継ぎコード, PIN)を順に用意する。
        # ・バン解除: メインを新IDで発行(バン回避)
        # ・垢複製  : 上記に加えて、同じ進行状況の独立した複製をもう1つ発行
        codes = []
        if unban:
            t, p = await asyncio.to_thread(self.ed.up_new_account)
            lgs.append("✅ バン解除")
            codes.append(("バン回避アカウント", t, p))
        else:
            t, p = await asyncio.to_thread(self.ed.up)
            codes.append(("元アカウント" if dup else None, t, p))

        if dup:
            t2, p2 = await asyncio.to_thread(self.ed.up_new_account)
            lgs.append("✅ 垢複製")
            codes.append(("複製アカウント", t2, p2))

        valid = [(lbl, t, p) for (lbl, t, p) in codes if t]
        if not valid:
            emsg = getattr(self.ed, "err", "") or ""
            return None, [], ("❌ サーバーへの保存に失敗しました。時間をおいて再度お試しください。"
                              + (f"\n```{emsg[:300]}```" if emsg else ""))

        reset_account = unban or dup
        if len(valid) == 1 and valid[0][0] is None:
            _, t, p = valid[0]
            code_block = f"**引き継ぎコード:** `{t}`\n**認証番号(PIN):** `{p}`"
        else:
            code_block = "\n\n".join(
                f"**【{lbl}】**\n引き継ぎコード: `{t}`\n認証番号(PIN): `{p}`"
                for lbl, t, p in valid
            )
        note = ""
        if reset_account:
            note = ("\n\n**上記は新しい引き継ぎコードです。**\n"
                    "以前のコードは使えないので、必ず上記のコードで引き継いでください。")
        if dup and not unban:
            note += "\n複製アカウントは元と同じ進行状況の別アカウントです(以降は独立)。"
        content = "\n".join(self.log_lines())
        embed = discord.Embed(
            title="完了",
            description=code_block + "\n\n" + f"**【購入内容】**\n" + content + note,
            color=0x00ff00,
        )
        return embed, valid, ""

    async def run(self, i: discord.Interaction):
        """apply_modifications → 再アップロード → 結果通知。iは応答済みInteraction。"""
        self._done = True
        # 購入時ロール付与(実際に支払いがあった有料代行のみ / 0円・無料券は付与しない)
        await grant_daiko_purchase_role(i, self.paid_amount)
        embed, valid, error = await self._apply_and_upload()
        if error:
            # 支払いは受け取れているので、失敗も必ずログに残す(成功時しか
            # ログが出ないと「残高だけ増えてログが流れない」ことになる)。
            await self.send_trouble_log(error, guild=i.guild, channel=i.channel)
            return await i.followup.send(error, ephemeral=True)
        await i.followup.send(embed=embed, ephemeral=True)
        try: await i.user.send(embed=embed)
        except: pass
        await self.send_daiko_log(i, valid)

    async def run_offline(self, user, guild=None, channel=None) -> bool:
        """Interaction が無い状態(LTCの入金確認後)で代行を実行し、DMで納品する。

        代行そのものが失敗したときだけ例外にする(監視ループが再試行する)。
        引き継ぎコードを発行できた後は、DMが送れなくてもやり直さない
        (やり直すとコードが作り直しになるため)。戻り値はDMを送れたかどうかで、
        送れなかった場合も非公開ログにはコードを残すので管理者が手渡しできる。
        """
        self._done = True
        await grant_daiko_purchase_role_in(guild, user.id, self.paid_amount)
        embed, valid, error = await self._apply_and_upload()
        if error:
            if getattr(self.ed, "auth_failed", False):
                # ゲームサーバーがこのアカウントの認証を通さない。預かった情報
                # では何度やっても同じ結果なので、再試行に回さず新しい引き継ぎ
                # コードをもらう(落とし直せばパスワードも新しくなる)。
                raise link_orders.NeedsCustomerInput(
                    error[:500],
                    prompt="お預かりした情報ではゲームサーバーにアクセスできませんでした。")
            # 再試行のたびに送ると、うまくいかない間じゅうDMが積み上がる。
            # 1通目だけ「確認しています」と伝え、以降は黙って裏で試す。
            # 最終的に駄目だったときは、見張りがチケットの案内を送る。
            if int(getattr(self, "notified_retry", 0)) == 0:
                self.notified_retry = 1
                try:
                    await user.send(embed=support.trouble_embed(
                        support.NEEDS_SUPPORT, "処理に少しお時間をいただいています",
                        ("ご入金は確認できています。ただいま自動でやり直しています。\n"
                         "しばらくお待ちください（数時間かかることがあります）。")))
                except discord.HTTPException:
                    pass
            raise RuntimeError(error[:500])
        embed.add_field(name="内容の確認のお願い",
                        value=(support.CHECK_YOUR_ORDER + "\n" + support.contact_line()),
                        inline=False)
        try:
            await user.send(embed=embed)
            dm_ok = True
        except discord.HTTPException:
            dm_ok = False
        await self.send_daiko_log(issued_codes=valid, guild=guild, channel=channel)
        return dm_ok


# --- 支払いモーダル (ログイン&前提判定OKの後に表示) ---
class PaymentModal(ui.Modal):
    """リンク方式(PayPay / Kyash)の支払い入力。"""

    def __init__(self, cfg: "ConfigView", method: str = payments.PAYPAY):
        m = payments.method(method)
        super().__init__(title=f"お支払い（{m.label}）"[:45])
        self.cfg = cfg
        self.method = method
        self.link = ui.TextInput(
            label=f"{m.label}リンク（{cfg.total_price:,}円）"[:45],
            placeholder=m.placeholder, required=True)
        self.add_item(self.link)
        self.link_pw = None
        if method == payments.PAYPAY:
            self.link_pw = ui.TextInput(label="PayPayリンクパスワード（なしなら空欄）", required=False)
            self.add_item(self.link_pw)

    async def on_submit(self, i: discord.Interaction):
        """支払いの受け取りから代行まで。試行の記録を必ず開いて必ず閉じる。

        出口がいくつもあるので、記録の締めは finally に置く。1つ書き漏らすと
        そこだけ「誰のものか分からない入金」に戻ってしまう。
        """
        cfg = self.cfg
        if cfg._done:
            return await i.response.send_message("既に処理を開始しています。", ephemeral=True)
        labels = [LABELS.get(k, k) for k in cfg.opts]
        attempt = await payment_attempts.record_async(
            "daiko", i.user.id, amount=int(cfg.total_price), method=self.method,
            link=self.link.value.strip(),
            summary=" / ".join(labels[:3]) + (f" ほか{len(labels) - 3}件" if len(labels) > 3 else ""),
            guild_id=i.guild.id if i.guild else None,
            channel_id=i.channel.id if i.channel else None,
            # 入金だけ確認できたときに、この内容でそのまま代行し直せるようにする。
            payload={
                "opts": list(cfg.opts),
                "amounts": dict(cfg.amounts),
                "spec_cat_ids": list(cfg.spec_cat_ids),
                "main_chapters": list(cfg.main_chapters),
                "tc": cfg.tc,
                "pin": cfg.pin_code,
                "total_price": int(cfg.total_price),
                "set_info": cfg.set_info,   # セットなら売上を1件で記録し直せるように
                # 引き継ぎコードは既に使い切っているので、落としたセーブ自体を
                # 取っておく。これが無いと後から代行し直せない。
                **(await stash_save_async(cfg.ed)),
            })
        hold = None
        try:
            # 同じリンクを見張り(または別の画面)が持っていないか先に確かめる。
            # ここを通さずに受け取ると、入金1回で代行が2回走る。
            hold = await payments.hold_link_for(i, "daiko", self.link.value.strip(), attempt)
            if hold is None:
                return
            await self._submit(i, attempt)
        finally:
            await payment_attempts.finish_async(attempt)
            await link_orders.release_link(hold)

    async def _submit(self, i: discord.Interaction, attempt: str):
        cfg = self.cfg
        await i.response.defer(ephemeral=True, thinking=True)
        passcode = (self.link_pw.value.strip() or None) if self.link_pw else None

        async def notify_pending(deadline: float):
            labels = [LABELS.get(k, k) for k in cfg.opts]
            items = " / ".join(labels[:3]) + (f" ほか{len(labels) - 3}件" if len(labels) > 3 else "")
            await notify_payment_pending(
                i, deadline, amount=cfg.total_price,
                title="⏳ 代行のお支払いが保留中です",
                detail=(f"承認され次第、自動で代行（{items}）を開始します。\n"
                        "**承認が終わるまでゲームを起動しないでください。**"
                        "起動すると引き継ぎコードが新しいものに変わり、代行できなくなります。"),
                footer="承認が遅れても、確認でき次第そのまま自動で代行します",
                ephemeral_hint="DMを確認して、「承認する」を押してください。承認され次第、代行を開始します。",
                app_name=payments.method_label(self.method),
            )

        state = {}
        try:
            paid = await payments.receive_link_payment(
                self.method, self.link.value.strip(),
                passcode=passcode, min_amount=cfg.total_price,
                on_pending=notify_pending, client=i.client, state=state,
                buyer=i.user, kind="にゃんこ代行",
            )
        except payments.PaymentNotRegistered as e:
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await i.followup.send(str(e), ephemeral=True)
        except payments.PaymentError as e:
            # 支払いが決着しなかった。リンクがまだ生きている(保留・承認待ち・
            # 通信不良)なら注文を捨てずに見張りへ渡す。ここで捨てると、あとから
            # 承認されたお金だけがこちらに入って代行が走らない事故になる。
            if getattr(e, "watchable", False) and await self._watch_pending(i, e):
                await payment_attempts.resolve_async(attempt, payment_attempts.WATCHING, str(e))
                return
            if getattr(e, "accepted", False):
                # 受け取りは投げてある(=あとから入金しうる)のに、見張りにも
                # 載せられなかった。ここが最後の砦。やり直しは促さない(二重払い)。
                await cfg.send_trouble_log(
                    "受け取りのリクエストは送信済みですが、見張りに載せられませんでした。"
                    f"{getattr(e, 'watch_note', '') or str(e)} "
                    "入金されていれば、手動で代行するか返金してください。",
                    guild=i.guild, channel=i.channel)
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.DROPPED,
                    f"受け取り送信済みだが見張りに載せられず: {getattr(e, 'watch_note', '') or e}")
                return await i.followup.send(
                    str(e) if isinstance(e, payments.PaymentUnsure) else
                    ("受け取りのリクエストは送信済みですが、処理を完了できませんでした。\n"
                     "**お代をいただいている可能性があります。もう一度支払わないでください。**\n"
                     "こちらで確認して対応します。\n" + support.contact_line()),
                    ephemeral=True)
            if isinstance(e, payments.PaymentAuthError):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
                return await i.followup.send(str(e), ephemeral=True)
            if isinstance(e, payments.PaymentPending):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, "承認されませんでした")
                return await i.followup.send(
                    "支払いがまだ承認されていません。PayPayアプリで「承認する」を押してから、"
                    "もう一度お試しください。**お代はいただいていません。**",
                    ephemeral=True)
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            # 理由はそのまま出す(リンク違い・金額不足など、本人が直せるものが
            # 多い)。ただしお代は動いていないので、そう書いて不安を残さない。
            return await i.followup.send(
                f"支払いを確認できませんでした。\n```{e}```\n"
                "**お代はいただいていません。** もう一度お試しいただくか、\n"
                + support.contact_line(), ephemeral=True)

        await payment_attempts.resolve_async(attempt, payment_attempts.DELIVERED, f"{paid:,}円")
        # このリンクのお金はここで受け取った。同じリンクを持っている見張りが
        # あれば畳む(畳まないと、見張りが同じ入金でもう一度代行を走らせる)。
        try:
            labels = [LABELS.get(k, k) for k in cfg.opts]
            for closed in await link_orders.record_screen_receipt(
                    "daiko", i.user.id, self.link.value.strip(), paid=paid,
                    method=self.method, summary=" / ".join(labels[:3]),
                    guild_id=i.guild.id if i.guild else None,
                    channel_id=i.channel.id if i.channel else None):
                print(f"[LINK SETTLED ON SCREEN] {closed.get('id')} を畳みました", flush=True)
        except Exception as e:
            print(f"[LINK SETTLED ON SCREEN ERROR] {e}", flush=True)
        # 買い直しで置き去りになった見張りを畳む。渡し終わっているのに
        # 「保留中」に並び続けると、どれが本当に要対応なのか分からなくなる。
        try:
            for closed in await link_orders.cancel_superseded(
                    i.user.id, "daiko", int(cfg.total_price)):
                print(f"[ORDER SUPERSEDED] {closed.get('id')} を畳みました", flush=True)
        except Exception as e:
            print(f"[ORDER SUPERSEDED ERROR] {e}", flush=True)
        cfg.paid_amount = paid
        cfg.method = self.method
        cfg.pay_link = self.link.value.strip()
        try:
            items, item_prices = cfg.sale_record()
            record_sale(paid, i.user.id, items, item_prices, method=self.method)
        except Exception as e:
            # 売上の記録に失敗しても代行は止めない(お金は受け取っている)
            print(f"[SALES RECORD ERROR] {e}", flush=True)
        try:
            await i.followup.send(f"{paid:,}円を受け取りました。代行を開始します。", ephemeral=True)
        except discord.HTTPException:
            pass
        try:
            await cfg.run(i)
        except Exception as e:
            # 受け取った後は何があってもログに残す(残高だけ増えて誰にも
            # 気付かれない状態を作らない)。
            print(f"[DAIKO RUN ERROR] {e}", flush=True)
            await cfg.send_trouble_log(f"想定外のエラー: {e}", guild=i.guild, channel=i.channel)
            try:
                await i.followup.send(
                    embed=support.trouble_embed(
                        support.NEEDS_SUPPORT, "代行の処理に失敗しました",
                        support.PAID_AND_STUCK, amount=paid),
                    ephemeral=True)
            except discord.HTTPException:
                pass

    async def _watch_pending(self, i: discord.Interaction, error: Exception) -> bool:
        """決着しなかった支払いを見張りに引き継ぐ。引き継げたら True。

        承認が遅れただけの注文をここで捨てないためのもの。以降は見張りループが
        受け取りとお渡しまで面倒を見るので、この画面はもう使えないようにする。
        """
        cfg = self.cfg
        if self.method != payments.PAYPAY:
            error.watch_note = "PayPay以外は後追いの見張りに対応していません。"
            return False
        accepted = bool(getattr(error, "accepted", False))
        labels = [LABELS.get(k, k) for k in cfg.opts]
        summary = " / ".join(labels[:3]) + (f" ほか{len(labels) - 3}件" if len(labels) > 3 else "")
        rec_items, rec_prices = cfg.sale_record()
        payload = {
            "opts": list(cfg.opts),
            "amounts": dict(cfg.amounts),
            "spec_cat_ids": list(cfg.spec_cat_ids),
            "main_chapters": list(cfg.main_chapters),
            "tc": cfg.tc,
            "pin": cfg.pin_code,
            "total_price": int(cfg.total_price),
            "set_info": cfg.set_info,   # セットなら売上を1件で記録し直せるように
            "item_prices": {k: int(v) for k, v in rec_prices.items()},
            # 引き継ぎコードは dl() の時点で消費済み。落としたセーブ自体を
            # 取っておかないと、後から代行し直せない。
            **(await stash_save_async(cfg.ed)),
        }
        try:
            order = await link_orders.create_order(
                "daiko", i.user.id, self.link.value.strip(),
                amount_jpy=int(cfg.total_price), payload=payload, method=self.method,
                passcode=(self.link_pw.value.strip() or None) if self.link_pw else None,
                accepted=accepted, summary=summary,
                guild_id=i.guild.id if i.guild else None,
                channel_id=i.channel.id if i.channel else None,
            )
        except Exception as e:
            print(f"[LINK WATCH ERROR] {e}", flush=True)
            error.watch_note = f"見張りへの登録に失敗しました: {str(e)[:150]}"
            return False
        if not order:
            error.watch_note = "見張りへの登録に失敗しました。"
            return False

        # 同じ内容をこの画面から走らせないようにする(二重代行・二重払い防止)
        cfg._done = True
        if accepted:
            text = ("⏳ PayPayアプリに「◯◯さんへの送金が保留になっています」と出ています。\n"
                    "**「承認する」を押してください。**\n"
                    "⚠️ **「キャンセル」を押すと送金が失敗してお金が戻り、代行は始まりません。**\n"
                    "**承認が確認でき次第、自動で代行してDMでお渡しします**。")
        else:
            text = ("⏳ まだ承認が確認できていません。PayPayアプリに保留の案内が出ていれば"
                    "**「承認する」**を押してください。\n"
                    "⚠️ **「キャンセル」を押すと送金が失敗します。**\n"
                    "**承認され次第、自動で代行してDMでお渡しします**。\n"
                    "支払い直す必要はありません。")
        # 先にDMを試す。ここで閉じていることが分かれば、承認を待つあいだに
        # 開放してもらえる。黙って握りつぶすと、渡す段になって初めて詰まる。
        try:
            await i.user.send(f"{text}\n注文番号: `{order['id']}`")
            dm_note = ""
        except discord.HTTPException:
            dm_note = support.DM_CLOSED_NOTE
        try:
            await i.followup.send(f"{text}\n注文番号: `{order['id']}`{dm_note}",
                                  ephemeral=True)
        except discord.HTTPException:
            pass
        return True


# --- 引継ぎ情報入力モーダル (引継ぎコード + 認証番号のみ / 支払いは後) ---
class LoginModal(ui.Modal):
    def __init__(self, opts: list[str], user_id=None, spec_ids=None,
                 admin_free: bool = False, set_info: dict = None):
        self.opts = opts
        self.user_id = user_id
        self.spec_ids = list(spec_ids) if spec_ids else []
        # 管理者の動作確認パネルから来たものは全商品0円(券は消費しない)
        self.admin_free = admin_free
        # セット商品(固定価格の束売り)。中身は set_info["opts"]、価格は固定。
        self.set_info = dict(set_info) if set_info else None
        # 無料券を持っているユーザーは全代行が無料(合計0円扱い)
        self.free_ticket = (not admin_free) and bool(user_id) and has_free_ticket(user_id)
        # 価格: セットは固定価格、それ以外は項目合計(指定キャラ系は体数分)
        if self.admin_free or self.free_ticket:
            self.total_price = 0
        elif self.set_info:
            self.total_price = int(self.set_info.get("price", 0) or 0)
        else:
            self.total_price = compute_total(opts, self.spec_ids)

        # タイトルはセット名 or 選択した商品名を並べる(45文字制限に収める)
        if self.set_info:
            head = f"{self.set_info.get('name', 'セット')}"
        else:
            labels = [LABELS.get(k, k) for k in opts]
            if len(labels) <= 2:
                head = " / ".join(labels)
            else:
                head = " / ".join(labels[:2]) + f" ほか{len(labels) - 2}件"
        title = f"{head}：引き継ぎ情報を入力"
        super().__init__(title=title[:45])

        self.tc = ui.TextInput(label="引継ぎコード", placeholder="例: 000000000", required=True)
        self.pin = ui.TextInput(label="認証番号 (PIN 4桁)", min_length=4, max_length=4, required=True)
        self.add_item(self.tc)
        self.add_item(self.pin)

    async def on_submit(self, i: discord.Interaction):
        # 0円で通す道は、ここでもう一度だけ管理者か確かめる。押した人しか
        # 見えない画面から来るとはいえ、ただで通す判断は入口任せにしない。
        if self.admin_free and not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        await i.response.defer(ephemeral=True, thinking=True)

        # ① 先にログイン(セーブをダウンロード)。失敗したら課金前に止める。
        ed = CEd(self.tc.value.strip(), self.pin.value.strip())
        if not await asyncio.to_thread(ed.dl):
            return await i.followup.send(
                f"ログインに失敗しました: {ed.err}\n引き継ぎコード/PINを確認してもう一度お試しください。",
                ephemeral=True)

        # ② 解放依存の判定(前提が未達なら課金せずエラー→選び直し)
        ok, msg = validate_stage_prereqs(ed.sf, self.opts)
        if not ok:
            return await i.followup.send(
                f"❌ {msg}\nこのアカウントでは適用できないため、内容を選び直してください。",
                ephemeral=True)

        # ③ 内容確認 → 実行(有料なら実行時に支払い方法の選択へ)
        cfg = ConfigView(
            self.opts, ed, requester=i.user, spec_ids=self.spec_ids,
            tc=self.tc.value.strip(), pin=self.pin.value.strip(),
            free_ticket=self.free_ticket, total_price=self.total_price, user_id=self.user_id,
            admin_free=self.admin_free, set_info=self.set_info,
        )
        await i.followup.send(embed=cfg.build_embed(), view=cfg, ephemeral=True)


# --- 入金確認後に代行を実行する (Interaction は既に切れている) ---
# LTCの請求書と、保留から承認された送金リンク(link_orders)の両方から呼ばれる。

async def offline_daiko_deliver(invoice: dict) -> bool:
    """入金が確認できた代行注文を後追いで実行して、結果をDMで渡す。

    支払い画面から時間が経っているため、セーブは引き継ぎコードから取り直す。
    代行に失敗したときは例外にして、監視ループに再試行させる。
    """
    payload = invoice.get("payload") or {}
    uid = int(invoice["user_id"])
    user = bot.get_user(uid) or await bot.fetch_user(uid)

    # 注文時に落としておいたセーブから始める。引き継ぎコードは dl() を投げた
    # 時点で消費されている(だから up() が新しいコードを発行して返す)。同じ
    # コードで落とし直すことはできないので、退避しておいたセーブを使う。
    ed = await asyncio.to_thread(load_stashed, payload)
    if ed is None:
        # 預かりが使えない。落とし直すしかないが、注文時に一度 dl() している
        # 以上ふつうは失敗する(コードは消費済み)。入れ直してもらった直後だけ
        # ここが通る。なぜ預かりが使えなかったのかは必ず記録に残す。
        why = stash_reason(payload) or "預かりセーブを読み込めませんでした"
        ed = CEd(payload.get("tc", ""), payload.get("pin", ""))
        if not await asyncio.to_thread(ed.dl):
            # 何度やり直しても結果は変わらないので、本人に入れ直してもらう。
            raise link_orders.NeedsCustomerInput(
                f"引き継ぎに失敗しました。\n"
                f"預かりセーブ: {why}\n"
                f"落とし直し: {getattr(ed, 'err', '') or '失敗'}",
                prompt="お預かりした引き継ぎコードが使えなくなっていました。")

    cfg = ConfigView(
        list(payload.get("opts") or []), ed, requester=user,
        spec_ids=payload.get("spec_cat_ids") or [],
        tc=payload.get("tc", ""), pin=payload.get("pin", ""),
        total_price=int(payload.get("total_price") or invoice["amount_jpy"]), user_id=uid,
        set_info=payload.get("set_info"),
    )
    cfg.stop()  # 画面には出さないViewなので、タイムアウト待ちを持たせない
    # 「お待ちください」のDMは1回だけ。ここは試行のたびに作り直されるので、
    # 何度目かは注文側の回数で判断する(0 = まだ一度も試していない)。
    cfg.notified_retry = 1 if int(invoice.get("deliver_attempts") or 0) > 0 else 0
    cfg.amounts = dict(payload.get("amounts") or {})
    cfg.main_chapters = list(payload.get("main_chapters") or [])
    # 実際に受け取った額(リンクは請求額より多いことがある)を優先する
    cfg.paid_amount = int(invoice.get("paid_amount") or invoice.get("amount_jpy") or 0)
    cfg.method = invoice.get("method") or payments.PAYPAY
    # 保留を挟んだ注文は「ログは流れたのに見張りには残っている」ように見える。
    # どのログがどの注文のものか、番号で一発で突き合わせられるようにしておく。
    paid_with = [f"注文番号: `{invoice['id']}`"] if invoice.get("id") else []
    if invoice.get("txid"):
        paid_with.append(f"LTC TXID: `{invoice['txid']}`")
    elif invoice.get("link"):
        paid_with.append(f"{payments.method_label(cfg.method)}リンク: {str(invoice['link'])[:200]}")
    cfg.pay_link = "\n".join(paid_with) or None

    guild = bot.get_guild(int(invoice["guild_id"])) if invoice.get("guild_id") else None
    channel = bot.get_channel(int(invoice["channel_id"])) if invoice.get("channel_id") else None

    dm_ok = await cfg.run_offline(user, guild=guild, channel=channel)
    # 代行が通った = 新しい引き継ぎコードを発行済み。預かったセーブはもう古い
    # 状態なので消す(残しておくと古い状態で渡し直しかねない)。
    drop_stashed(payload)
    rec_items, rec_prices = cfg.sale_record()
    record_sale(cfg.paid_amount, uid, rec_items, rec_prices, method=cfg.method)
    if not dm_ok and channel is not None:
        try:
            await channel.send(
                f"{user.mention} 代行が完了しましたが、DMをお送りできませんでした。\n"
                "DMを開放していただくか、" + support.contact_line())
        except discord.HTTPException:
            pass
    return True


# --- 項目選択ビュー (パネルのボタンから開く / ユーザー個別・一時) ---
SELECT_MAX_OPTIONS = 25      # Discord のセレクト1つに載せられる選択肢の上限
SELECT_MAX_ROWS = 4          # セレクトに使える行数(残り1行はボタン)


def group_categories(cat_keys) -> list:
    """カテゴリを、セレクト1つ(25件まで)に収まる単位でまとめる。

    戻り値 [(まとめた名前, [(key, label), ...]), ...]。順番は CATEGORIES のまま。
    いまの品数(16/7/7/5/12)なら「アイテム系・ステージ系」「キャラ系・ガマトト系・システム系」の2つ。
    """
    groups, names, opts = [], [], []
    for cat_key in cat_keys:
        _emoji, name, _desc, items = CATEGORIES[cat_key]
        if opts and len(opts) + len(items) > SELECT_MAX_OPTIONS:
            groups.append(("・".join(names), opts))
            names, opts = [], []
        names.append(name)
        opts = opts + list(items)
    if opts:
        groups.append(("・".join(names), opts))
    return groups


class SelectionView(ui.View):
    """代行内容を選ぶ一時ビュー。

    cat_key を渡すと(お客さんのパネル)そのカテゴリだけ。cat_keys を渡すと(管理者の
    動作確認パネル)複数のカテゴリを一度に選べる。カテゴリはセレクト1つ(25件まで)に
    収まる単位でまとめ、選んだ項目は全部まとめて1回の引き継ぎ情報入力・1回の代行に
    する(アイテム系とステージ系のように、カテゴリをまたぐ注文で引き継ぎコードと
    PINを2回もらわなくて済むように)。
    """

    def __init__(self, cat_key: str = None, admin_free: bool = False, cat_keys=None):
        super().__init__(timeout=300)
        self.cat_key = cat_key
        self.admin_free = admin_free      # 管理者の動作確認(全商品0円)
        keys = list(cat_keys) if cat_keys else [cat_key]
        self.groups = group_categories(keys)[:SELECT_MAX_ROWS]
        self._picked = {idx: [] for idx in range(len(self.groups))}
        prices = load_prices()
        for idx, (name, opts) in enumerate(self.groups):
            sel = ui.Select(
                placeholder=(f"{name} を選択（複数可）" if len(self.groups) > 1
                             else "代行内容を選択（複数可）")[:150],
                options=[
                    discord.SelectOption(
                        label=item_display_name(k)[:100], value=k,
                        description=("0円（動作確認）" if admin_free
                                     else f"{int(prices.get(k, DAIKO_PRICE)):,}円"))
                    for k, l in opts
                ],
                min_values=0,
                max_values=len(opts),
            )
            sel.callback = self._make_sel_cb(idx)
            self.add_item(sel)
        eb = ui.Button(label="引き継ぎ情報入力", style=discord.ButtonStyle.success)
        eb.callback = self._exec_cb
        self.add_item(eb)

    @property
    def selected(self) -> list:
        """いま選ばれている項目(セレクトをまたいで全部・CATEGORIES の順)。"""
        out = []
        for idx in range(len(self.groups)):
            out.extend(self._picked.get(idx, []))
        return out

    def _make_sel_cb(self, idx: int):
        async def cb(i: discord.Interaction):
            self._picked[idx] = list(i.data.get("values", []))
            await i.response.defer()
        return cb

    async def _exec_cb(self, i: discord.Interaction):
        if not self.selected:
            return await i.response.send_message("❌ 代行内容を選択してください。", ephemeral=True)
        # バン解除は引き継ぎコードが発行できる場合のみ成立するため、先に条件を確認してもらう
        if "unban" in self.selected:
            return await self._confirm_unban(i)
        await self._open_entry(i)

    async def _open_entry(self, i: discord.Interaction):
        """引き継ぎ情報の入力へ進む。指定キャラ系は体数で課金するため先にキャラID入力。"""
        if any(o in CAT_ID_OPTS for o in self.selected):
            await i.response.send_modal(
                CatIdEntryModal(self.selected, i.user.id, admin_free=self.admin_free))
        else:
            await i.response.send_modal(
                LoginModal(self.selected, i.user.id, admin_free=self.admin_free))

    async def _confirm_unban(self, i: discord.Interaction):
        """バン解除の適用条件を、引き継ぎコードを入力してもらう前に提示する。"""
        opts = list(self.selected)
        admin_free = self.admin_free
        view = ui.View(timeout=300)
        btn = ui.Button(label="確認しました。引き継ぎ情報の入力へ進む", style=discord.ButtonStyle.success)

        async def proceed(inter: discord.Interaction):
            if any(o in CAT_ID_OPTS for o in opts):
                await inter.response.send_modal(
                    CatIdEntryModal(opts, inter.user.id, admin_free=admin_free))
            else:
                await inter.response.send_modal(
                    LoginModal(opts, inter.user.id, admin_free=admin_free))
        btn.callback = proceed
        view.add_item(btn)

        embed = discord.Embed(
            title="バン解除をご希望の方へ",
            description=(
                "お手続きの前に、以下をご確認ください。\n\n"
                "**引き継ぎコードが発行できる状態のアカウントのみ対応できます。**\n"
                "バンの影響でゲーム側から引き継ぎコードそのものが発行できない場合、"
                "こちらでセーブデータを取得できないため対応できません。\n\n"
                "**処理後は新しい引き継ぎコードをお渡しします。**\n"
                "これまでお使いのコードは使えなくなりますので、必ず新しいコードで引き継いでください。\n\n"
                "引き継ぎコードが発行できる場合は、下のボタンから進んでください。"
            ),
            color=0xffaa00,
        )
        await i.response.send_message(embed=embed, view=view, ephemeral=True)


# --- 指定キャラID入力(支払い前 / 体数で課金するため) ---
class CatIdEntryModal(ui.Modal, title="指定キャラID入力"):
    def __init__(self, opts: list[str], user_id, admin_free: bool = False):
        super().__init__()
        self.opts = opts
        self.user_id = user_id
        self.admin_free = admin_free      # 管理者の動作確認(全商品0円)
        self.field = ui.TextInput(
            label="キャラID (カンマ区切りで複数可)",
            placeholder="例: 25, 100, 811",
            style=discord.TextStyle.paragraph,
            required=True,
        )
        self.add_item(self.field)

    async def on_submit(self, i: discord.Interaction):
        ids = []
        for x in self.field.value.replace(" ", ",").split(","):
            x = x.strip()
            if x.isdigit() and int(x) not in ids:
                ids.append(int(x))
        if not ids:
            return await i.response.send_message("有効なキャラIDを入力してください。", ephemeral=True)

        free = (not self.admin_free) and has_free_ticket(self.user_id)
        total = 0 if (self.admin_free or free) else compute_total(self.opts, ids)
        if self.admin_free:
            price_txt = "🛠 管理者の動作確認のため0円です"
        elif free:
            price_txt = "🎫 無料利用券が適用されます（0円）"
        else:
            price_txt = f"合計 **{total:,}円**（指定キャラ {len(ids)}体分）"

        # モーダルからモーダルは開けないため、ボタン経由で引き継ぎ情報入力へ進む
        opts, uid = self.opts, self.user_id
        admin_free = self.admin_free
        view = ui.View(timeout=300)
        btn = ui.Button(label="引き継ぎ情報を入力", style=discord.ButtonStyle.success)
        async def open_login(inter: discord.Interaction):
            await inter.response.send_modal(
                LoginModal(opts, inter.user.id, spec_ids=ids, admin_free=admin_free))
        btn.callback = open_login
        view.add_item(btn)
        await i.response.send_message(
            f"指定キャラ: {spec_cat_names(ids)}\n{price_txt}\n\n下のボタンから引き継ぎ情報を入力してください。",
            view=view, ephemeral=True,
        )


# --- カテゴリパネル (常設 / custom_idで復元) ---
class PanelView(ui.View):
    def __init__(self, cat_key: str):
        super().__init__(timeout=None)
        self.cat_key = cat_key
        b = ui.Button(label="代行内容を選択（複数可）",
                      style=discord.ButtonStyle.primary, custom_id=f"panel_open_{cat_key}")
        b.callback = self._open_cb
        self.add_item(b)
        if cat_key == "char":
            s = ui.Button(label="キャラID検索",
                          style=discord.ButtonStyle.secondary, custom_id="panel_search_cat")
            s.callback = self._search_cb
            self.add_item(s)

    @panels.guard
    async def _open_cb(self, i: discord.Interaction):
        emoji, name, desc, opts = CATEGORIES[self.cat_key]
        prices = load_prices()
        embed = discord.Embed(
            title=f"{name} — 代行内容を選択",
            description="\n".join(f"・{item_display_name(k)} … {int(prices.get(k, DAIKO_PRICE)):,}円" for k, l in opts),
            color=0x00aaff,
        )
        await i.response.send_message(embed=embed, view=SelectionView(self.cat_key), ephemeral=True)

    @panels.guard
    async def _search_cb(self, i: discord.Interaction):
        await i.response.send_modal(CatSearchModal())


def category_embed(cat_key: str) -> discord.Embed:
    emoji, name, desc, opts = CATEGORIES[cat_key]
    e = discord.Embed(
        title=f"{name}メニュー",
        description="購入したい商品を以下から選択してください。",
        color=0x00aaff,
    )
    prices = load_prices()
    lines = []
    for k, l in opts:
        price = int(prices.get(k, DAIKO_PRICE))
        lines.append(f"**{item_display_name(k)}**\n{price:,}円")
    e.add_field(name="商品一覧", value="\n".join(lines), inline=False)
    return e


# --- 管理者の動作確認パネル (常設 / 全商品0円) ---
# 価格を0円に直して確かめると、その間はお客さんも0円で買えてしまう。
# 押せる人を管理者に限ったパネルを別に置く。
# カテゴリごとにボタンを分けず、全メニューから複数まとめて選べるようにしてある
# (別の場所で受けた注文をここで流すとき、アイテム系とステージ系のようにカテゴリを
# またいでも、引き継ぎコードとPINは1回で済む)。
async def admin_open_all_menu(i: discord.Interaction):
    """全メニューの選択画面(管理者だけ)。"""
    if not is_admin(i.user.id):
        return await i.response.send_message(
            "これは管理者が動作確認するためのパネルです。ご購入は通常のパネルからお願いします。",
            ephemeral=True)
    blocks = []
    for cat_key, (emoji, name, desc, opts) in CATEGORIES.items():
        blocks.append(f"**{name}**\n" + "\n".join(f"・{item_display_name(k)} … 0円" for k, l in opts))
    embed = discord.Embed(
        title="【動作確認】代行内容を選択（全メニュー・複数可）",
        description=("カテゴリをまたいで選べます。選んだ分は1回の引き継ぎ情報入力でまとめて流します。\n\n"
                     + "\n\n".join(blocks)
                     + "\n\n支払いは発生しません。売上にも入りません。")[:4096],
        color=0xffcc00,
    )
    await i.response.send_message(
        embed=embed, view=SelectionView(admin_free=True, cat_keys=list(CATEGORIES)), ephemeral=True)


class AdminFreePanelView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        b = ui.Button(label="代行内容を選択（全メニュー・複数可）", style=discord.ButtonStyle.primary,
                      custom_id="daiko_test_open_all")
        b.callback = self._open_all_cb
        self.add_item(b)
        s = ui.Button(label="キャラID検索", style=discord.ButtonStyle.secondary,
                      custom_id="daiko_test_search_cat")
        s.callback = self._search_cb
        self.add_item(s)
        st = ui.Button(label="セット", style=discord.ButtonStyle.secondary,
                       custom_id="daiko_test_set")
        st.callback = self._set_cb
        self.add_item(st)

    @panels.guard
    async def _open_all_cb(self, i: discord.Interaction):
        await admin_open_all_menu(i)

    @panels.guard
    async def _set_cb(self, i: discord.Interaction):
        if not is_admin(i.user.id):
            return await i.response.send_message(
                "これは管理者が動作確認するためのパネルです。ご購入は通常のパネルからお願いします。",
                ephemeral=True)
        if not load_sets():
            return await i.response.send_message(
                "セットがまだありません。`/daiko set_create` で作ってください。", ephemeral=True)
        await i.response.send_message(
            embed=set_selection_embed(admin_free=True),
            view=SetSelectionView(admin_free=True), ephemeral=True)

    @panels.guard
    async def _search_cb(self, i: discord.Interaction):
        if not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        await i.response.send_modal(CatSearchModal())


class LegacyAdminFreeButtons(ui.View):
    """前の動作確認パネル(カテゴリごとのボタン)の受け口。

    置き直す前の古いパネルが押されても、全メニューの選択画面に進めるようにする
    (画面には出さず、custom_id を受けるためだけに登録しておく)。
    """

    def __init__(self):
        super().__init__(timeout=None)
        for cat_key, (emoji, name, desc, opts) in CATEGORIES.items():
            b = ui.Button(label=name, style=discord.ButtonStyle.secondary,
                          custom_id=f"daiko_test_open_{cat_key}")
            b.callback = self._open_cb
            self.add_item(b)

    @panels.guard
    async def _open_cb(self, i: discord.Interaction):
        await admin_open_all_menu(i)


def admin_free_panel_embed() -> discord.Embed:
    e = discord.Embed(
        title="【管理者用】代行",
        description="管理者専用。**全商品0円**で動作確認できます。",
        color=0xffcc00,
    )
    for cat_key, (emoji, name, desc, opts) in CATEGORIES.items():
        e.add_field(name=name, value=f"{len(opts)}商品（すべて0円）", inline=True)
    n_sets = len(load_sets())
    if n_sets:
        e.add_field(name="セット", value=f"{n_sets}セット（すべて0円）", inline=True)
    return e


# ==== セット商品 ============================================================
# 作る側(管理者): カテゴリごとに項目を選び、名前と価格を決めて保存(最大5個)。
# 置く側(管理者): SetPanelView をチャンネルに設置。
# 買う側(お客さん): セレクトでセットを選ぶ → 通常の代行と同じ入力→支払い→適用。

SET_PANEL_KEY = "daiko:sets"       # 設置パネルの居場所を覚えるキー(panels.py)


def _normalize_set_emoji(text: str):
    """セレクトに載せられる絵文字だけ通す。おかしな文字はNone(パネルが壊れないように)。"""
    text = (text or "").strip()
    if not text:
        return None
    if re.fullmatch(r"<a?:\w+:\d+>", text):     # カスタム絵文字
        return text
    ch = text[0]
    return ch if ord(ch) > 0x2000 else None     # 記号・ユニコード絵文字だけ


def set_panel_embed() -> discord.Embed:
    """お客さんに見せるセット一覧のパネル。"""
    sets = load_sets()
    e = discord.Embed(
        title="セット商品",
        description=("まとめておトクなセットです。購入したいセットを以下から選択してください。"
                     if sets else "現在ご用意しているセットはありません。"),
        color=0x00aaff,
    )
    for s in sets:
        contents = " / ".join(LABELS.get(k, k) for k in s.get("opts", []))
        e.add_field(
            name=f"{(s.get('emoji') or '')}{s.get('name', 'セット')} … {int(s.get('price', 0)):,}円",
            value=(contents or "（内容未設定）")[:1024], inline=False)
    return e


class SetSaveModal(ui.Modal, title="セットの名前と価格"):
    """選んだ中身に名前と価格を付けて保存する。"""

    def __init__(self, opts: list[str]):
        super().__init__()
        self.opts = list(opts)
        ref = set_price_reference(self.opts)
        self.name = ui.TextInput(label="セット名", placeholder="例: 松盛りセット",
                                 max_length=80, required=True)
        self.price = ui.TextInput(
            label="価格(円)", placeholder=f"単品合計は {ref:,}円。まとめ割引や上乗せはお好みで",
            required=True, max_length=9)
        self.emoji = ui.TextInput(label="絵文字(任意)", placeholder="例: 🔥", required=False,
                                  max_length=8)
        self.add_item(self.name)
        self.add_item(self.price)
        self.add_item(self.emoji)

    async def on_submit(self, i: discord.Interaction):
        if not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        raw = self.price.value.strip().replace(",", "").replace("円", "")
        if not raw.isdigit():
            return await i.response.send_message("価格は数字で入力してください。", ephemeral=True)
        price = int(raw)
        sets = load_sets()
        name = self.name.value.strip()
        if any(s.get("name") == name for s in sets):
            return await i.response.send_message(
                f"「{name}」というセットは既にあります。別の名前にしてください。", ephemeral=True)
        if len(sets) >= SET_MAX:
            return await i.response.send_message(
                f"セットは最大{SET_MAX}個までです。`/daiko set_delete` で減らしてから追加してください。",
                ephemeral=True)
        sets.append({
            "id": secrets.token_hex(4),
            "name": name,
            "price": price,
            "opts": self.opts,
            "emoji": _normalize_set_emoji(self.emoji.value),
        })
        save_sets(sets)
        # 設置済みのパネルがあれば、その場で最新の一覧に更新する。
        try:
            await panels.refresh(i.client, SET_PANEL_KEY, set_panel_embed(), SetPanelView(),
                                 guild=i.guild)
        except Exception as e:
            print(f"[SET PANEL REFRESH ERROR] {e}", flush=True)
        contents = " / ".join(LABELS.get(k, k) for k in self.opts)
        await i.response.send_message(
            f"✅ セット「{name}」を作成しました（{price:,}円 / {len(sets)}個目）。\n"
            f"内容: {contents}\n\n"
            f"`/daiko set_panel` でパネルを設置（設置済みなら自動更新）。", ephemeral=True)


class SetBuilderView(ui.View):
    """管理者がセットの中身を選ぶ一時パネル。カテゴリごとに選んで積み上げる。"""

    def __init__(self):
        super().__init__(timeout=600)
        self.selected: set[str] = set()
        self.cur_cat: str = None
        self._select: ui.Select = None
        for cat_key, (emoji, name, desc, opts) in CATEGORIES.items():
            b = ui.Button(label=name, style=discord.ButtonStyle.secondary, row=0)
            b.callback = self._make_cat_cb(cat_key)
            self.add_item(b)
        save = ui.Button(label="名前と価格を決めて保存", style=discord.ButtonStyle.success, row=2)
        save.callback = self._save_cb
        self.add_item(save)
        clear = ui.Button(label="選択をクリア", style=discord.ButtonStyle.danger, row=2)
        clear.callback = self._clear_cb

        self.add_item(clear)

    def _cat_opts(self, cat_key: str) -> list:
        """そのカテゴリの、セットに入れられる項目 [(k,l), ...]。"""
        excluded = set(CAT_ID_OPTS) | set(ACCOUNT_RESET_OPTS)
        return [(k, l) for k, l in CATEGORIES[cat_key][3] if k not in excluded]

    def _show_category(self, cat_key: str):
        """カテゴリのセレクトを差し替える(選択済みはチェックを付けておく)。"""
        self.cur_cat = cat_key
        if self._select is not None:
            self.remove_item(self._select)
        pairs = self._cat_opts(cat_key)
        options = [
            discord.SelectOption(label=item_display_name(k)[:100], value=k,
                                 default=(k in self.selected))
            for k, l in pairs
        ]
        sel = ui.Select(placeholder=f"{CATEGORIES[cat_key][1]}から選ぶ（複数可）",
                        options=options, min_values=0, max_values=len(options), row=1)
        sel.callback = self._sel_cb
        self._select = sel
        self.add_item(sel)

    def _make_cat_cb(self, cat_key: str):
        async def cb(i: discord.Interaction):
            if not is_admin(i.user.id):
                return await i.response.send_message("権限がありません。", ephemeral=True)
            self._show_category(cat_key)
            await i.response.edit_message(embed=self._embed(), view=self)
        return cb

    async def _sel_cb(self, i: discord.Interaction):
        # いま開いているカテゴリのぶんだけ入れ替える(他カテゴリの選択は残す)。
        chosen = set(i.data.get("values", []))
        for k, l in self._cat_opts(self.cur_cat):
            self.selected.discard(k)
        self.selected |= chosen
        self._show_category(self.cur_cat)      # チェック状態を反映して作り直す
        await i.response.edit_message(embed=self._embed(), view=self)

    async def _clear_cb(self, i: discord.Interaction):
        self.selected.clear()
        if self.cur_cat:
            self._show_category(self.cur_cat)
        await i.response.edit_message(embed=self._embed(), view=self)

    async def _save_cb(self, i: discord.Interaction):
        if not self.selected:
            return await i.response.send_message(
                "先にセットに入れる項目を選んでください。", ephemeral=True)
        if len(load_sets()) >= SET_MAX:
            return await i.response.send_message(
                f"セットは最大{SET_MAX}個までです。`/daiko set_delete` で減らしてください。",
                ephemeral=True)
        # 選んだ順ではなくメニュー順に並べて保存(表示・適用の順を安定させる)
        order = [k for _, k, _ in set_selectable_opts()]
        opts = [k for k in order if k in self.selected]
        await i.response.send_modal(SetSaveModal(opts))

    def _embed(self) -> discord.Embed:
        order = {k: idx for idx, (_, k, _) in enumerate(set_selectable_opts())}
        chosen = sorted(self.selected, key=lambda k: order.get(k, 999))
        ref = set_price_reference(chosen)
        body = ("\n".join(f"・{LABELS.get(k, k)}" for k in chosen)
                if chosen else "（まだ何も選ばれていません）")
        e = discord.Embed(
            title="セット商品を作る",
            description=("上のカテゴリボタンから項目を選び、"
                         "「名前と価格を決めて保存」で確定します。\n"
                         f"作れるセットは残り **{max(0, SET_MAX - len(load_sets()))}個** です。"),
            color=0xffaa00,
        )
        e.add_field(name=f"選択中（{len(chosen)}項目）", value=body[:1024], inline=False)
        if chosen:
            e.add_field(name="単品で買った場合の合計（値付けの目安）",
                        value=f"{ref:,}円", inline=False)
        return e


def set_opts_and_info(s: dict):
    """セット定義から、適用する opts と set_info を作る。不備なら (None, None)。"""
    excluded = set(CAT_ID_OPTS) | set(ACCOUNT_RESET_OPTS)
    opts = [k for k in s.get("opts", []) if k in LABELS and k not in excluded]
    if not opts:
        return None, None
    info = {"id": s.get("id"), "name": s.get("name", "セット"),
            "price": int(s.get("price", 0)), "opts": opts}
    return opts, info


def set_selection_embed(admin_free: bool = False) -> discord.Embed:
    """「代行内容を選択」を押したときに出す、セット一覧の内訳。"""
    lines = []
    for s in load_sets():
        contents = " / ".join(LABELS.get(k, k) for k in s.get("opts", []))
        price = "0円（動作確認）" if admin_free else f"{int(s.get('price', 0)):,}円"
        lines.append(f"**{s.get('name', 'セット')}** … {price}\n　{contents}")
    head = "【動作確認】セット — 代行内容を選択" if admin_free else "セット — 代行内容を選択"
    desc = "\n".join(lines) or "現在ご用意しているセットはありません。"
    if admin_free:
        desc += "\n\n支払いは発生しません。売上にも入りません。"
    return discord.Embed(title=head, description=desc[:4096], color=0x00aaff)


class SetSelectionView(ui.View):
    """セットを1つ選ぶ一時ビュー(通常パネルの項目選択と同じ手順・単一選択)。"""

    def __init__(self, admin_free: bool = False):
        super().__init__(timeout=300)
        self.admin_free = admin_free
        self.selected_id: str = None
        sets = load_sets()
        options = [
            discord.SelectOption(
                label=s.get("name", "セット")[:100], value=s.get("id", "?"),
                description=("0円（動作確認）" if admin_free
                             else f"{int(s.get('price', 0)):,}円")[:100],
                emoji=s.get("emoji") or None)
            for s in sets
        ] or [discord.SelectOption(label="（セット未登録）", value="none")]
        # 複数可の通常パネルと違い、セットは1つだけ選ぶ(min=max=1)。
        sel = ui.Select(placeholder="代行内容を選択", options=options,
                        min_values=1, max_values=1)
        sel.callback = self._sel_cb
        self.add_item(sel)
        eb = ui.Button(label="引き継ぎ情報入力", style=discord.ButtonStyle.success)
        eb.callback = self._exec_cb
        self.add_item(eb)

    async def _sel_cb(self, i: discord.Interaction):
        self.selected_id = (i.data.get("values") or [None])[0]
        await i.response.defer()

    async def _exec_cb(self, i: discord.Interaction):
        if self.admin_free and not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        if not self.selected_id or self.selected_id == "none":
            return await i.response.send_message("❌ セットを選択してください。", ephemeral=True)
        s = get_set(self.selected_id)
        if s is None:
            return await i.response.send_message(
                "このセットは現在ご利用いただけません。パネルが更新されるまでお待ちください。",
                ephemeral=True)
        opts, set_info = set_opts_and_info(s)
        if not opts:
            return await i.response.send_message(
                "このセットは設定に不備があります。管理者にお知らせください。", ephemeral=True)
        await i.response.send_modal(
            LoginModal(opts, i.user.id, set_info=set_info, admin_free=self.admin_free))


class SetPanelView(ui.View):
    """お客さん向けの常設パネル。通常パネルと同じくボタンから選択画面を開く。"""

    def __init__(self):
        super().__init__(timeout=None)
        b = ui.Button(label="代行内容を選択", style=discord.ButtonStyle.primary,
                      custom_id="daiko_set_open")
        b.callback = self._open_cb
        self.add_item(b)

    @panels.guard
    async def _open_cb(self, i: discord.Interaction):
        if not load_sets():
            return await i.response.send_message(
                "現在ご用意しているセットはありません。", ephemeral=True)
        await i.response.send_message(
            embed=set_selection_embed(), view=SetSelectionView(), ephemeral=True)


# --- 値段設定 (管理者用) ---
class PriceSetModal(ui.Modal, title="価格設定"):
    def __init__(self, keys: list[str]):
        super().__init__()
        self.keys = keys
        names = " / ".join(LABELS.get(k, k) for k in keys)
        self.price = ui.TextInput(
            label="価格(円)",
            placeholder=f"{names[:80]} に設定する価格",
            required=True,
        )
        self.add_item(self.price)

    async def on_submit(self, i: discord.Interaction):
        try:
            price = int(self.price.value.strip())
        except ValueError:
            return await i.response.send_message("❌ 価格は整数で入力してください。", ephemeral=True)
        if price < 0:
            return await i.response.send_message("❌ 価格は0円以上で入力してください。", ephemeral=True)

        prices = load_prices()
        for k in self.keys:
            prices[k] = price
        save_prices(prices)

        names = "、".join(LABELS.get(k, k) for k in self.keys)
        await i.response.send_message(f"✅ {names} を **{price:,}円** に設定しました。", ephemeral=True)


class PriceProductSelectView(ui.View):
    def __init__(self, cat_key: str):
        super().__init__(timeout=300)
        opts = CATEGORIES[cat_key][3]
        prices = load_prices()
        sel = ui.Select(
            placeholder="価格を設定する商品を選択（複数可・同額設定）",
            options=[
                discord.SelectOption(label=l, value=k, description=f"現在 {int(prices.get(k, DAIKO_PRICE)):,}円")
                for k, l in opts
            ],
            min_values=1,
            max_values=len(opts),
        )
        sel.callback = self._cb
        self.add_item(sel)

    async def _cb(self, i: discord.Interaction):
        await i.response.send_modal(PriceSetModal(i.data.get("values", [])))


class PricePanelView(ui.View):
    """カテゴリごとに価格設定を開く常設パネル。"""
    def __init__(self):
        super().__init__(timeout=None)
        for cat_key, (emoji, name, _desc, _opts) in CATEGORIES.items():
            b = ui.Button(label=name,
                          style=discord.ButtonStyle.secondary, custom_id=f"price_cat_{cat_key}")
            b.callback = self._make_cb(cat_key)
            self.add_item(b)

    def _make_cb(self, cat_key: str):
        @panels.guard
        async def cb(i: discord.Interaction):
            if not is_admin(i.user.id):
                return await i.response.send_message("権限がありません。", ephemeral=True)
            emoji, name, _desc, opts = CATEGORIES[cat_key]
            prices = load_prices()
            embed = discord.Embed(
                title=f"{name} — 価格設定",
                description="\n".join(f"・{item_display_name(k)}：{int(prices.get(k, DAIKO_PRICE)):,}円" for k, l in opts),
                color=0xffcc00,
            )
            await i.response.send_message(embed=embed, view=PriceProductSelectView(cat_key), ephemeral=True)
        return cb


def price_panel_embed() -> discord.Embed:
    return discord.Embed(
        title="価格設定パネル",
        description="下のカテゴリボタンから、各商品の価格を設定できます。\n複数選択すると同じ価格をまとめて設定できます。",
        color=0xffcc00,
    )


class Bot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True          # メンバー情報取得に必要
        intents.message_content = True  # NGワードブロックに必要
        super().__init__(command_prefix="!", intents=intents)
    async def setup_hook(self):
        for cat_key in CATEGORIES:
            self.add_view(PanelView(cat_key))
        self.add_view(PricePanelView())
        self.add_view(AdminFreePanelView())
        self.add_view(LegacyAdminFreeButtons())   # 置き直す前の古いパネルのボタンも受ける
        self.add_view(SetPanelView())
        # キャラ名索引を先に温めておく(表示時にイベントループを止めない)
        await asyncio.to_thread(load_cat_name_index)
        # 保留から遅れて承認された送金リンクの入金が確認できたら、後追いで代行を実行する
        # (支払い画面はもう閉じているため)。
        link_orders.register_handler("daiko", offline_daiko_deliver)
        await load_extensions(self)
        await self.tree.sync()
        if not game_version_watch.is_running():
            game_version_watch.start()
        # Telegram の販売窓口(在庫は Discord と共有)。TELEGRAM_BOT_TOKEN があるときだけ
        # 起動する。無ければ Discord だけ動く。支払い・取り置き・入金突合は共通処理。
        try:
            import telegram_shop
            if telegram_shop.start(self):
                print("[TELEGRAM] 自販機を起動しました。", flush=True)
        except Exception as e:
            print(f"[TELEGRAM START ERROR] {e}", flush=True)


# 順番に意味がある。linkwatch は最後。起動時に「入れ直し待ち」の画面を
# 種類ごとに登録し直すので、他のハンドラが揃う前に動かすと取り違える。
EXTENSIONS = ("Cogs.paypay", "Cogs.kyash", "Cogs.shop", "Cogs.tsum", "Cogs.puni",
              "Cogs.wordblock", "Cogs.auth", "Cogs.moderation", "Cogs.announce",
              "Cogs.linkwatch")

# 読み込めなかったもの。on_ready で入れ直しを試み、管理者にも知らせる。
FAILED_EXTENSIONS: dict = {}


async def load_extensions(bot_) -> dict:
    """Cogを1つずつ読み込む。1つ落ちても残りは読み込む。

    まとめて await すると、1つ失敗した時点で setup_hook ごと止まり、下の
    Cogが丸ごと入らない。パネルのボタンは各Cogが登録するので、入らなかった
    ぶんのパネルは押しても無反応になる(置き直しても直らない)。

    戻り値 {拡張名: 失敗の理由}。空なら全部入っている。
    """
    failed = {}
    for name in EXTENSIONS:
        if name in bot_.extensions:
            continue
        try:
            await bot_.load_extension(name)
        except Exception as e:
            failed[name] = f"{type(e).__name__}: {e}"
            print(f"[COG LOAD ERROR] {name}: {type(e).__name__}: {e}", flush=True)
            traceback.print_exc()
    FAILED_EXTENSIONS.clear()
    FAILED_EXTENSIONS.update(failed)
    loaded = [n for n in EXTENSIONS if n in bot_.extensions]
    print(f"[COG] 読み込み済み {len(loaded)}/{len(EXTENSIONS)}: "
          + ", ".join(n.split(".")[-1] for n in loaded), flush=True)
    return failed


async def notify_admins_cog_failed(failed: dict):
    """Cogが入らなかったことを管理者に伝える。

    そのパネルは押しても無反応になる。黙っていると「壊れた」としか
    分からないまま何日も過ぎる。
    """
    embed = discord.Embed(
        title="一部の機能を読み込めませんでした",
        description=("下の機能はこの起動では動いていません。\n"
                     "**そのパネルはボタンを押しても反応しません**"
                     "（パネルを置き直しても直りません）。\n\n"
                     + "\n".join(f"**{n.split('.')[-1]}**\n```{v[:300]}```"
                                 for n, v in failed.items())),
        color=0xff5555,
    )
    for uid in ADMIN_IDS:
        try:
            user = bot.get_user(uid) or await bot.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue

bot = Bot()

# --- ゲームバージョンの自動追従 ---
# にゃんこ大戦争が更新されるとPONOSのAPIが古いバージョンを弾き、代行が止まる。
# 定期的にApp Storeの最新版を見て、新しければ自動で切り替え、管理者へ通知する。

async def notify_admins_version_update(before: str, after: str):
    embed = discord.Embed(
        title="ゲームバージョンを自動更新しました",
        description=(
            f"にゃんこ大戦争の更新を検知したため、代行で使うバージョンを切り替えました。\n\n"
            f"**{before}** → **{after}**\n\n"
            "次の代行から新しいバージョンで動作します。再デプロイは不要です。\n"
            "もし代行が失敗する場合は `/nyanko_version set` で手動指定してください。"
        ),
        color=0x00ff88,
    )
    for uid in ADMIN_IDS:
        try:
            user = bot.get_user(uid) or await bot.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue

@tasks.loop(hours=VERSION_CHECK_INTERVAL_HOURS)
async def game_version_watch():
    try:
        result = await asyncio.to_thread(check_and_update_game_version)
    except Exception as e:
        print(f"[VERSION WATCH ERROR] {e}", flush=True)
    else:
        if result.get("updated"):
            await notify_admins_version_update(result["before"], result["latest"])
    # キャラ名・図鑑のゲームデータも、配布所に新しいものがあれば取り寄せる
    # (新コラボのキャラをID検索・解放できるように)。起動直後の1回目も含む。
    # 取り寄せても管理者には知らせない(コンテナのログと /nyanko_version data で分かる)。
    try:
        data = await asyncio.to_thread(sync_game_data)
    except Exception as e:
        print(f"[GDATA WATCH ERROR] {e}", flush=True)
        return
    if data.get("downloaded"):
        await asyncio.to_thread(load_cat_name_index)

@game_version_watch.before_loop
async def _before_game_version_watch():
    await bot.wait_until_ready()

_guilds_cleaned = False

@bot.event
async def on_ready():
    global _guilds_cleaned
    print(f"✅ READY - {bot.user.name} が起動しました", flush=True)
    await apply_presence()
    # 読み込めなかったCogを入れ直す。一時的な失敗ならこれで直る。
    if FAILED_EXTENSIONS:
        still = await load_extensions(bot)
        if still:
            await notify_admins_cog_failed(still)
        else:
            print("[COG] 入れ直しで全部読み込めました", flush=True)
        try:
            await bot.tree.sync()
        except Exception as e:
            print(f"[TREE SYNC ERROR] {e}", flush=True)
    # コマンド重複対策: 各サーバーのギルド固有コマンドを消してグローバルのみにする
    if not _guilds_cleaned:
        _guilds_cleaned = True
        for g in list(bot.guilds):
            try:
                bot.tree.clear_commands(guild=g)
                await bot.tree.sync(guild=g)
            except Exception as e:
                print(f"[GUILD CLEAN ERROR] {g.id}: {e}", flush=True)

@bot.event
async def on_resumed():
    # 再接続後にオンライン表示を復帰させる(設定中のステータスを維持)
    await apply_presence()

@bot.event
async def on_guild_join(guild: discord.Guild):
    # グローバルコマンドは参加済みの全サーバーで使えるため、ギルド個別同期はしない。
    # 念のためギルド固有コマンドを空にして重複を防ぐ。
    try:
        bot.tree.clear_commands(guild=guild)
        await bot.tree.sync(guild=guild)
    except Exception as e:
        print(f"[GUILD JOIN CLEAN ERROR] {e}", flush=True)

@bot.tree.error
async def on_app_command_error(i: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure): return
    print(f"❌ [ERROR] コマンドエラー: {error}", flush=True)

@bot.tree.command(name="count_messages", description="メッセージ数をかぞえる")
@app_commands.describe(channel="対象チャンネル", limit="さかのぼる上限(既定10000)")
async def count_messages(i: discord.Interaction, channel: typing.Union[discord.TextChannel, discord.Thread], limit: int = 10000):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.defer(ephemeral=True, thinking=True)
    limit = max(1, min(limit, 100000))
    total = 0
    humans = 0
    try:
        async for msg in channel.history(limit=limit):
            total += 1
            if not msg.author.bot:
                humans += 1
    except discord.Forbidden:
        return await i.followup.send("そのチャンネルの履歴を読む権限がありません。", ephemeral=True)
    capped = "（上限に達したため、それ以前は未集計の可能性あり）" if total >= limit else ""
    await i.followup.send(
        f"{channel.mention} のメッセージ数\n"
        f"合計: **{total:,}件**（うち人間: {humans:,}件 / Bot: {total - humans:,}件）{capped}",
        ephemeral=True,
    )

@bot.tree.command(name="support_channel",
                  description="問い合わせ先チャンネル")
@app_commands.describe(channel="チケットを開くチャンネル(省略で解除)")
async def set_support_channel(i: discord.Interaction, channel: discord.TextChannel = None):
    """トラブル時にお客さんへ案内する行き先を決める。

    未設定でも案内文は出るが、チャンネル名が入らないぶん「どこへ行けばいいか」が
    伝わりにくい。DMに来られたくないなら必ず設定しておく。
    """
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    support.set_support_channel_id(channel.id if channel else None)
    e = discord.Embed(title="問い合わせ先の設定", color=discord.Color.green())
    e.add_field(name="案内先",
                value=(channel.mention if channel else "未設定（チャンネル名を出しません）"),
                inline=False)
    e.add_field(name="お客さんに出る文面", value=support.contact_line(), inline=False)
    e.add_field(
        name="⚠️ チャンネルの権限を確認してください",
        value=("トラブルの相談先なので、引き継ぎコードや購入内容の話になります。"
               "チケットが**本人と管理者だけの非公開チャンネル**として作られる"
               "設定にしておいてください。"),
        inline=False)
    e.set_footer(text="代行・自販機のすべてのトラブル案内で使われます")
    await i.response.send_message(embed=e, ephemeral=True)


# --- 代行系の管理コマンド(/daiko ○○)。自販機(/shop ○○)と対になる命名で区別する ---
daiko = app_commands.Group(name="daiko", description="代行系の管理コマンド")
bot.tree.add_command(daiko)

@daiko.command(name="panel", description="代行パネルを設置")
async def pnl(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.send_message("全カテゴリのパネルを設置しました。", ephemeral=True)
    for cat_key in CATEGORIES:
        await panels.put(bot, f"daiko:{cat_key}", i.channel,
                         category_embed(cat_key), PanelView(cat_key))

@daiko.command(name="price", description="価格設定パネルを設置")
async def price_panel(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.send_message("価格設定パネルを設置しました。", ephemeral=True)
    await i.channel.send(embed=price_panel_embed(), view=PricePanelView())

@daiko.command(name="0change", description="全商品を0円にする")
async def all_free(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    save_prices({k: 0 for k in LABELS})
    await i.response.send_message(f"全 {len(LABELS)} 商品の価格を 0円 に設定しました。", ephemeral=True)

@daiko.command(name="set_create", description="セット商品を作る(項目を選んで価格を決める)")
async def set_create(i: discord.Interaction):
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    if len(load_sets()) >= SET_MAX:
        return await i.response.send_message(
            f"セットは最大{SET_MAX}個までです。`/daiko set_delete` で減らしてから作ってください。",
            ephemeral=True)
    view = SetBuilderView()
    await i.response.send_message(embed=view._embed(), view=view, ephemeral=True)

@daiko.command(name="set_panel", description="セット商品パネルを設置")
async def set_panel(i: discord.Interaction):
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    if not load_sets():
        return await i.response.send_message(
            "先に `/daiko set_create` でセットを作ってください。", ephemeral=True)
    result = await panels.put(bot, SET_PANEL_KEY, i.channel,
                              set_panel_embed(), SetPanelView())
    msg = "セット商品パネルを設置しました。" if result == "posted" else "セット商品パネルを更新しました。"
    await i.response.send_message(msg, ephemeral=True)

@daiko.command(name="set_list", description="作成済みのセットを見る")
async def set_list(i: discord.Interaction):
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    sets = load_sets()
    if not sets:
        return await i.response.send_message("セットはまだありません。", ephemeral=True)
    e = discord.Embed(title=f"セット商品（{len(sets)}/{SET_MAX}）", color=0x00aaff)
    for s in sets:
        contents = " / ".join(LABELS.get(k, k) for k in s.get("opts", []))
        ref = set_price_reference(s.get("opts", []))
        e.add_field(
            name=f"{(s.get('emoji') or '')}{s.get('name')} … {int(s.get('price', 0)):,}円（単品計 {ref:,}円）",
            value=(contents or "（内容未設定）")[:1024] + f"\n`id: {s.get('id')}`", inline=False)
    await i.response.send_message(embed=e, ephemeral=True)

async def set_name_autocomplete(i: discord.Interaction, current: str):
    cur = (current or "").lower()
    return [app_commands.Choice(name=s.get("name", "")[:100], value=s.get("name", ""))
            for s in load_sets() if cur in s.get("name", "").lower()][:25]

@daiko.command(name="set_delete", description="セットを消す")
@app_commands.describe(name="消すセットの名前")
@app_commands.autocomplete(name=set_name_autocomplete)
async def set_delete(i: discord.Interaction, name: str):
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    sets = load_sets()
    keep = [s for s in sets if s.get("name") != name and s.get("id") != name]
    if len(keep) == len(sets):
        return await i.response.send_message(
            f"「{name}」というセットは見つかりませんでした。`/daiko set_list` で名前を確認してください。",
            ephemeral=True)
    save_sets(keep)
    try:
        await panels.refresh(bot, SET_PANEL_KEY, set_panel_embed(), SetPanelView(), guild=i.guild)
    except Exception as e:
        print(f"[SET PANEL REFRESH ERROR] {e}", flush=True)
    await i.response.send_message(
        f"🗑 セット「{name}」を消しました（残り{len(keep)}個）。", ephemeral=True)

@daiko.command(name="selllog", description="完了ログの送り先")
@app_commands.describe(channel="ログを送信するチャンネル(省略時は今のチャンネル)")
async def set_log_channel(
    i: discord.Interaction,
    channel: typing.Optional[typing.Union[discord.TextChannel, discord.Thread]] = None,
):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    target = channel or i.channel
    if not hasattr(target, "send"):
        return await i.response.send_message("テキストチャンネルかスレッドを指定してください。", ephemeral=True)
    cfg = load_config()
    cfg["log_channel_id"] = target.id
    save_config(cfg)
    await i.response.send_message(f"代行の公開ログの送信先を {target.mention} に設定しました。", ephemeral=True)

@daiko.command(name="logchannel", description="非公開ログの送り先")
@app_commands.describe(channel="管理者専用チャンネル(省略時は今のチャンネル)")
async def set_private_log_channel(
    i: discord.Interaction,
    channel: typing.Optional[typing.Union[discord.TextChannel, discord.Thread]] = None,
):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    target = channel or i.channel
    if not hasattr(target, "send"):
        return await i.response.send_message("テキストチャンネルかスレッドを指定してください。", ephemeral=True)
    cfg = load_config()
    cfg["daiko_private_log_channel_id"] = target.id
    save_config(cfg)
    await i.response.send_message(
        f"代行の非公開ログを {target.mention} に設定しました。\n"
        f"⚠️ 購入者のID・支払いリンク・引き継ぎコード等の機密情報が送られます。**管理者だけが見られるチャンネル**にしてください。",
        ephemeral=True,
    )

@bot.tree.command(
    name="free_ticket",
    description=(f"指定ユーザーに無料利用券"
                 f"({FREE_TICKET_MIN_DAYS}〜{FREE_TICKET_MAX_DAYS}日 / "
                 f"既定{FREE_TICKET_DEFAULT_DAYS}日)を付与します"))
@app_commands.describe(
    user_id="対象ユーザーのID",
    days=(f"有効日数 {FREE_TICKET_MIN_DAYS}〜{FREE_TICKET_MAX_DAYS}日"
          f"(省略時は{FREE_TICKET_DEFAULT_DAYS}日)"))
async def free_ticket(i: discord.Interaction, user_id: str,
                      days: app_commands.Range[int, FREE_TICKET_MIN_DAYS, FREE_TICKET_MAX_DAYS]
                      = FREE_TICKET_DEFAULT_DAYS):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    uid = user_id.strip().strip("<@!>")
    if not uid.isdigit():
        return await i.response.send_message("ユーザーIDは数字で指定してください。", ephemeral=True)
    if not FREE_TICKET_MIN_DAYS <= days <= FREE_TICKET_MAX_DAYS:
        return await i.response.send_message(
            f"有効日数は{FREE_TICKET_MIN_DAYS}〜{FREE_TICKET_MAX_DAYS}日の範囲で指定してください。",
            ephemeral=True)
    ts = int(grant_free_ticket(uid, days))
    await i.response.send_message(
        f"<@{uid}> に **{days}日間** の無料利用券を付与しました。\n"
        f"有効期限: <t:{ts}:f>（<t:{ts}:R>まで）",
        ephemeral=True)

@bot.tree.command(name="delet_free_ticket", description="無料券を取り消す")
@app_commands.describe(user_id="対象ユーザーのID")
async def delet_free_ticket(i: discord.Interaction, user_id: str):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    uid = user_id.strip().strip("<@!>")
    if not uid.isdigit():
        return await i.response.send_message("ユーザーIDは数字で指定してください。", ephemeral=True)
    if revoke_free_ticket(uid):
        await i.response.send_message(f"<@{uid}> の無料利用券を剥奪しました。", ephemeral=True)
    else:
        await i.response.send_message(f"<@{uid}> は無料利用券を持っていません。", ephemeral=True)

@bot.tree.command(name="list_free_ticket", description="無料券の一覧")
async def list_free_ticket(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    tickets = list_active_free_tickets()
    if not tickets:
        return await i.response.send_message("有効な無料利用券を持つユーザーはいません。", ephemeral=True)
    lines = [f"・<@{uid}> — <t:{int(exp)}:f>まで（<t:{int(exp)}:R>）" for uid, exp in tickets[:40]]
    more = f"\n…他 {len(tickets) - 40} 人" if len(tickets) > 40 else ""
    embed = discord.Embed(title="無料利用券 保有ユーザー",
                          description="\n".join(lines) + more, color=0x00aaff)
    embed.set_footer(text=f"計 {len(tickets)} 人")
    await i.response.send_message(embed=embed, ephemeral=True)

def _profit_period_range(period: str, date: str):
    """集計期間の (開始ts, 終了ts, 表示ラベル) を返す。不正な日付は ValueError。"""
    JST = timezone(timedelta(hours=9))
    now = datetime.now(JST)
    if period == "day":
        base = datetime.strptime(date.strip(), "%Y-%m-%d").replace(tzinfo=JST) if date else now
        start = base.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        return start.timestamp(), end.timestamp(), start.strftime("%Y/%m/%d")
    if period == "week":
        monday = now - timedelta(days=now.weekday())
        start = monday.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=7)
        return start.timestamp(), end.timestamp(), f"今週（{start.strftime('%m/%d')}〜{(end - timedelta(days=1)).strftime('%m/%d')}）"
    if period == "month":
        start = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        end = start.replace(year=start.year + 1, month=1) if start.month == 12 else start.replace(month=start.month + 1)
        return start.timestamp(), end.timestamp(), start.strftime("%Y年%m月")
    return 0.0, float("inf"), "全期間"

def _method_breakdown(sales: list) -> str:
    """売上を支払い方法ごとに集計した表示行。方法の記録が無い古い売上はPayPay扱い。"""
    agg = {}
    for s in sales:
        key = s.get("method") or payments.PAYPAY
        cur = agg.setdefault(key, [0, 0])
        cur[0] += int(s.get("amount", 0))
        cur[1] += 1
    lines = [f"・{payments.method_label(k)}: {amt:,}円（{cnt}件）"
             for k, (amt, cnt) in sorted(agg.items(), key=lambda x: -x[1][0])]
    return "\n".join(lines)[:1024] or "まだ売上はありません。"

@bot.tree.command(name="profit", description="売上を見る")
@app_commands.describe(
    target="どの売上を表示するか",
    period="集計期間(省略時は全期間)",
    date="日を指定する場合 YYYY-MM-DD（period=日 のとき有効）",
    machine_id="自販機を指定(自販機のみ/省略で全自販機)",
)
@app_commands.choices(
    target=[
        app_commands.Choice(name="代行", value="daiko"),
        app_commands.Choice(name="ツムツム代行", value="tsum"),
        app_commands.Choice(name="自販機", value="shop"),
    ],
    period=[
        app_commands.Choice(name="日（今日/指定日）", value="day"),
        app_commands.Choice(name="週（今週）", value="week"),
        app_commands.Choice(name="月（今月）", value="month"),
        app_commands.Choice(name="全期間", value="all"),
    ],
)
@app_commands.autocomplete(machine_id=shop_machine_autocomplete)
async def profit(i: discord.Interaction, target: app_commands.Choice[str],
                 period: app_commands.Choice[str] = None, date: str = None, machine_id: str = None):
    p = period.value if period else ("day" if date else "all")
    try:
        s_ts, e_ts, label = _profit_period_range(p, date)
    except ValueError:
        return await i.response.send_message("日付は YYYY-MM-DD 形式で指定してください。", ephemeral=True)

    # --- 代行の売上(管理者のみ) ---
    if target.value == "daiko":
        if not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        all_sales = load_sales()
        sales = [x for x in all_sales if s_ts <= float(x.get("ts", 0)) < e_ts]
        total = sum(int(x.get("amount", 0)) for x in sales)
        grand_total = sum(int(x.get("amount", 0)) for x in all_sales)
        embed = discord.Embed(title="代行 売上", color=0x00ff88)
        embed.add_field(name="期間", value=label, inline=False)
        # 商品別内訳(金額は各売上の実受取額を商品ごとに配分)
        by_item = {}
        for s in sales:
            for k, amt in sale_item_amounts(s).items():
                agg = by_item.setdefault(k, [0, 0])
                agg[0] += amt
                agg[1] += 1
        lines = [f"・{LABELS.get(k, k)}: {amt:,}円（{cnt}件）" for k, (amt, cnt) in
                 sorted(by_item.items(), key=lambda x: -x[1][0])] or ["まだ売上はありません。"]
        embed.add_field(name="商品別売上", value="\n".join(lines)[:1024], inline=False)
        embed.add_field(name="支払い方法別", value=_method_breakdown(sales), inline=False)
        embed.add_field(name="合計", value=f"**{total:,}円**", inline=True)
        embed.add_field(name="件数", value=f"{len(sales)}件", inline=True)
        embed.add_field(name="総売上（全期間）",
                        value=f"**{grand_total:,}円**（{len(all_sales)}件）", inline=False)
        return await i.response.send_message(embed=embed, ephemeral=True)

    # --- ツムツム代行の売上(管理者のみ) ---
    # にゃんこ代行とは商品キーの体系が違うので、売上ファイルごと分けてある。
    if target.value == "tsum":
        if not is_admin(i.user.id):
            return await i.response.send_message("権限がありません。", ephemeral=True)
        all_sales = tsum_daiko.load_sales()
        sales = [x for x in all_sales if s_ts <= float(x.get("ts", 0)) < e_ts]
        total = sum(int(x.get("amount", 0)) for x in sales)
        grand_total = sum(int(x.get("amount", 0)) for x in all_sales)
        embed = discord.Embed(title="ツムツム代行 売上", color=0x06c755)
        embed.add_field(name="期間", value=label, inline=False)
        by_item = {}
        for s in sales:
            for k, amt in tsum_daiko.sale_item_amounts(s).items():
                agg = by_item.setdefault(k, [0, 0])
                agg[0] += amt
                agg[1] += 1
        lines = [f"・{tsum_daiko.menu_label(k)}: {amt:,}円（{cnt}件）" for k, (amt, cnt) in
                 sorted(by_item.items(), key=lambda x: -x[1][0])] or ["まだ売上はありません。"]
        embed.add_field(name="メニュー別売上", value="\n".join(lines)[:1024], inline=False)
        embed.add_field(name="支払い方法別", value=_method_breakdown(sales), inline=False)
        embed.add_field(name="合計", value=f"**{total:,}円**", inline=True)
        embed.add_field(name="件数", value=f"{len(sales)}件", inline=True)
        embed.add_field(name="総売上（全期間）",
                        value=f"**{grand_total:,}円**（{len(all_sales)}件）", inline=False)
        return await i.response.send_message(embed=embed, ephemeral=True)

    # --- 自販機の売上(管理者は全台、それ以外は自分の自販機のみ) ---
    if not is_admin(i.user.id):
        vending = shop_load_vending()
        owned = {mid for mid, m in vending.items() if m.get("owner_id") == str(i.user.id)}
        if machine_id and machine_id not in owned:
            return await i.response.send_message("その自販機の権限がありません。", ephemeral=True)
    else:
        owned = None  # 全件

    # スコープ(machine指定 or 自分の自販機)を適用した全期間の売上
    scoped_all = shop_load_sales()
    if machine_id:
        scoped_all = [s for s in scoped_all if s.get("machine_id") == machine_id]
    elif owned is not None:
        scoped_all = [s for s in scoped_all if s.get("machine_id") in owned]
    sales = [s for s in scoped_all if s_ts <= float(s.get("ts", 0)) < e_ts]
    grand_total = sum(int(s.get("amount", 0)) for s in scoped_all)

    total = sum(int(s.get("amount", 0)) for s in sales)
    embed = discord.Embed(title="自販機 売上", color=0x00ff88)
    embed.add_field(name="期間", value=label, inline=False)
    if machine_id:
        vending = shop_load_vending()
        embed.add_field(name="対象", value=vending.get(machine_id, {}).get("name", machine_id), inline=False)
        # 商品別内訳
        by_prod = {}
        for s in sales:
            key = s.get("product_name") or s.get("product_id") or "不明"
            agg = by_prod.setdefault(key, [0, 0])
            agg[0] += int(s.get("amount", 0))
            agg[1] += int(s.get("qty", 0))
        lines = [f"・{name}: {amt:,}円（{q}個）" for name, (amt, q) in
                 sorted(by_prod.items(), key=lambda x: -x[1][0])] or ["まだ売上はありません。"]
        embed.add_field(name="商品別売上", value="\n".join(lines)[:1024], inline=False)
    else:
        embed.add_field(name="対象", value="全自販機", inline=False)
        # 自販機別内訳
        by_m = {}
        for s in sales:
            key = s.get("machine_name") or s.get("machine_id") or "不明"
            by_m[key] = by_m.get(key, 0) + int(s.get("amount", 0))
        lines = [f"・{name}: {amt:,}円" for name, amt in
                 sorted(by_m.items(), key=lambda x: -x[1])] or ["まだ売上はありません。"]
        embed.add_field(name="自販機別売上", value="\n".join(lines)[:1024], inline=False)
    embed.add_field(name="支払い方法別", value=_method_breakdown(sales), inline=False)
    embed.add_field(name="合計", value=f"**{total:,}円**", inline=True)
    embed.add_field(name="件数", value=f"{len(sales)}件", inline=True)
    embed.add_field(name="総売上（全期間）",
                    value=f"**{grand_total:,}円**（{len(scoped_all)}件）", inline=False)
    await i.response.send_message(embed=embed, ephemeral=True)

@daiko.command(name="panel_one", description="カテゴリを1つだけ設置")
@app_commands.describe(category="設置するカテゴリ")
@app_commands.choices(category=[
    app_commands.Choice(name=v[1], value=k) for k, v in CATEGORIES.items()
])
async def pnl_one(i: discord.Interaction, category: app_commands.Choice[str]):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.send_message(f"{CATEGORIES[category.value][1]} パネルを設置しました。", ephemeral=True)
    await panels.put(bot, f"daiko:{category.value}", i.channel,
                     category_embed(category.value), PanelView(category.value))

@daiko.command(name="test_panel",
               description="動作確認パネルを設置（全商品0円）")
async def daiko_test_panel(i: discord.Interaction):
    """お客さんに見せる価格はそのままに、管理者だけが最後まで流せるパネルを置く。

    管理者用チャンネルに置くこと。誰でも見えるところに置いても管理者以外は
    先へ進めないが、0円のメニューが並ぶと問い合わせのもとになる。
    """
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.send_message("動作確認パネルを設置しました。", ephemeral=True)
    await panels.put(bot, "daiko:test", i.channel,
                     admin_free_panel_embed(), AdminFreePanelView())

SET_REDISPLAY_VALUE = "__set__"      # redisplay でセットパネルだけを指す値

@daiko.command(name="redisplay", description="パネルを最新の内容に更新")
@app_commands.describe(category="更新するカテゴリ(省略で全カテゴリ＋セット)")
@app_commands.choices(category=[
    app_commands.Choice(name=v[1], value=k) for k, v in CATEGORIES.items()
] + [app_commands.Choice(name="セット", value=SET_REDISPLAY_VALUE)])
async def daiko_redisplay(i: discord.Interaction, category: app_commands.Choice[str] = None):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    val = category.value if category else None
    await i.response.defer(ephemeral=True, thinking=True)
    # 置き直すと古いパネルが上に残り、お客さんがそちらを押してしまう。
    # 今あるパネルをその場で書き換える(見つからないときだけ新しく置く)。
    done = {"updated": [], "posted": [], "failed": []}
    # 通常パネル(カテゴリ)。セットだけを指定したときは触らない。
    if val != SET_REDISPLAY_VALUE:
        keys = [val] if val else list(CATEGORIES)
        for cat_key in keys:
            result = await panels.put(bot, f"daiko:{cat_key}", i.channel,
                                      category_embed(cat_key), PanelView(cat_key))
            done[result].append(CATEGORIES[cat_key][1])
    # セットパネル。指定なし(全体更新)か、セット指定のときに更新する。
    if val is None or val == SET_REDISPLAY_VALUE:
        result = await panels.put(bot, SET_PANEL_KEY, i.channel,
                                  set_panel_embed(), SetPanelView())
        done[result].append("セット")
    lines = []
    if done["updated"]:
        lines.append(f"✏️ その場で更新: {' / '.join(done['updated'])}")
    if done["posted"]:
        lines.append(f"🆕 見つからなかったので設置: {' / '.join(done['posted'])}")
    if done["failed"]:
        lines.append(f"❌ 失敗: {' / '.join(done['failed'])}")
    await i.followup.send("\n".join(lines) or "対象がありませんでした。", ephemeral=True)

@daiko.command(name="role", description="購入時に付けるロール")
@app_commands.describe(role="付与するロール(省略で解除)")
async def daiko_role(i: discord.Interaction, role: discord.Role = None):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    if i.guild is None:
        return await i.response.send_message("サーバー内で実行してください。", ephemeral=True)
    if role is not None and role >= i.guild.me.top_role:
        return await i.response.send_message(
            "そのロールはBotより上位のため付与できません。Botのロールを上に移動してください。", ephemeral=True)
    set_daiko_role_id(i.guild.id, role.id if role else None)
    if role:
        await i.response.send_message(
            f"代行の購入時付与ロールを {role.mention} に設定しました。\n"
            f"※ 0円・無料利用券の利用では付与されません。**実際に支払いがあった代行のみ**付与されます。",
            ephemeral=True)
    else:
        await i.response.send_message("代行の購入時付与ロールを解除しました。", ephemeral=True)

# --- 安全確認: 誤検知の解除 ---
# 検知は常に効いていて、当たれば名簿に載せて断る(risk.py)。管理者がやる
# ことは誤検知を戻すことだけなので、コマンドも1つ。

_UNBLOCK_CHOICES = [
    app_commands.Choice(name="Discordアカウント", value=risk.DISCORD),
    app_commands.Choice(name="PayPayの送金元", value=risk.PAYPAY),
    app_commands.Choice(name="Kyashの送金元", value=risk.KYASH),
]


@bot.tree.command(name="unblock",
                  description="止めたアカウントを解除")
@app_commands.describe(kind="種類", target="Discord IDまたは送金元ID",
                       note="解除の理由(記録用・省略可)")
@app_commands.choices(kind=_UNBLOCK_CHOICES)
async def unblock_cmd(i: discord.Interaction, kind: app_commands.Choice[str],
                      target: str, note: str = ""):
    if not is_admin(i.user.id):
        return await i.response.send_message("権限がありません。", ephemeral=True)
    ident = target.strip().strip("<@!>")
    if not risk.unblock(kind.value, ident, by=str(i.user.id), note=note):
        held = risk.blocked_list(kind.value)
        hint = ("\n止まっているのは: "
                + "、".join(f"`{row['id']}`" for row in held[:10])) if held else ""
        return await i.response.send_message(
            f"`{ident}` は止まっていませんでした。{hint}", ephemeral=True)
    await i.response.send_message(
        f"解除しました（`{ident}`）。\n"
        "※ Discordアカウントと送金元は別々に載ります。"
        "断ったときのDMに両方のコマンドが書いてあるので、両方戻してください。",
        ephemeral=True)


# --- にゃんこ大戦争のゲームバージョン管理(ゲーム更新で代行が止まった時の即時対応) ---
nyanko_version = app_commands.Group(name="nyanko_version", description="ゲームバージョン管理(代行の即時復旧用)")
bot.tree.add_command(nyanko_version)

def _version_status_embed(current: str, latest) -> discord.Embed:
    e = discord.Embed(title="🎮 にゃんこ大戦争 ゲームバージョン", color=0x00aaff)
    e.add_field(name="現在の使用バージョン", value=f"`{current}`", inline=True)
    if latest:
        match = "✅ 一致" if latest == current else "⚠️ 最新と不一致"
        e.add_field(name="App Store最新版", value=f"`{latest}`（{match}）", inline=True)
        if is_newer_version(latest, current):
            e.add_field(name="対応", value="`/nyanko_version auto` で今すぐ更新できます。", inline=False)
    else:
        e.add_field(name="App Store最新版", value="取得できませんでした", inline=True)

    st = get_version_check_state()
    hours = VERSION_CHECK_INTERVAL_HOURS
    interval = f"{int(hours)}時間ごと" if hours == int(hours) else f"{hours}時間ごと"
    last = st.get("last_checked_at")
    auto = f"自動チェック: {interval}"
    if last:
        auto += f"\n最終チェック: <t:{int(last)}:R>"
    else:
        auto += "\n最終チェック: まだ実行されていません"
    if st.get("last_updated_at"):
        auto += (f"\n最終自動更新: `{st.get('last_updated_from')}` → "
                 f"`{st.get('last_updated_to')}`（<t:{int(st['last_updated_at'])}:R>）")
    e.add_field(name="自動更新", value=auto, inline=False)
    return e

@nyanko_version.command(name="show", description="いまのバージョンを見る")
async def nv_show(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.defer(ephemeral=True, thinking=True)
    current = get_game_version()
    latest = await asyncio.to_thread(fetch_latest_game_version)
    await i.followup.send(embed=_version_status_embed(current, latest), ephemeral=True)

@nyanko_version.command(name="set", description="バージョンを手で決める")
@app_commands.describe(version="例: 15.6.0")
async def nv_set(i: discord.Interaction, version: str):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    version = version.strip()
    if not re.fullmatch(r"\d+(\.\d+){1,3}", version):
        return await i.response.send_message(
            "バージョンは `15.6.0` のような数字とドットの形式で入力してください。", ephemeral=True)
    set_game_version(version)
    await i.response.send_message(
        f"ゲームバージョンを `{version}` に設定しました。次の代行から即反映されます（再デプロイ不要）。",
        ephemeral=True)

@nyanko_version.command(name="data", description="キャラ名・図鑑のゲームデータをいますぐ取り寄せる")
async def nv_data(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.defer(ephemeral=True, thinking=True)
    r = await asyncio.to_thread(sync_game_data)
    if r.get("downloaded"):
        await asyncio.to_thread(load_cat_name_index)
    local = downloaded_game_data_versions()
    if r.get("downloaded"):
        outcome = f"✅ `{r['local']}` を取り寄せました。"
    elif r.get("error"):
        outcome = f"⚠️ {r['error']}（手元のデータのまま使います）"
    else:
        outcome = "手元のデータが最新です。"
    text = (f"{outcome}\n手元のデータ: {', '.join(local) or 'なし'}\n"
            f"配布所の最新: {r.get('remote') or '取得できず'}\n"
            f"キャラ名索引: {len(load_cat_name_index())}体（ID {known_cat_max_id() + 1} まで）")
    await i.followup.send(text, ephemeral=True)

@nyanko_version.command(name="auto", description="いますぐ更新を確認")
async def nv_auto(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    await i.response.defer(ephemeral=True, thinking=True)
    r = await asyncio.to_thread(check_and_update_game_version)
    if not r["latest"]:
        return await i.followup.send(
            "App Storeから最新版を取得できませんでした。時間をおくか `/nyanko_version set` で手動設定してください。",
            ephemeral=True)
    if r["updated"]:
        msg = f"ゲームバージョンを `{r['before']}` → `{r['latest']}` に更新しました。次の代行から即反映されます。"
    elif r["current"] == r["latest"]:
        msg = f"既に最新版 `{r['latest']}` です（変更なし）。"
    else:
        msg = (f"現在 `{r['current']}` はApp Store最新版 `{r['latest']}` より新しいため変更しませんでした。\n"
               f"戻す場合は `/nyanko_version set` を使ってください。")
    await i.followup.send(msg, ephemeral=True)

# --- Botのステータス設定(再接続で戻らないよう一元管理) ---
status_group = app_commands.Group(name="status", description="Botのステータス(プレイ中表示)を変更します")
bot.tree.add_command(status_group)

_STATUS_TYPE_LABEL = {"playing": "プレイ中", "watching": "視聴中", "listening": "再生中", "competing": "参加中"}

@status_group.command(name="set", description="ステータスを変える")
@app_commands.describe(text="表示するテキスト(例: 仕事中)", type="表示の種類")
@app_commands.choices(type=[
    app_commands.Choice(name="プレイ中", value="playing"),
    app_commands.Choice(name="視聴中", value="watching"),
    app_commands.Choice(name="再生中", value="listening"),
    app_commands.Choice(name="参加中", value="competing"),
])
async def status_set(i: discord.Interaction, text: str, type: app_commands.Choice[str] = None):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    text = text.strip()
    if not text:
        return await i.response.send_message("テキストを入力してください。", ephemeral=True)
    type_val = type.value if type else get_status()["type"]
    set_status(text=text, type_=type_val)
    await apply_presence()
    label = _STATUS_TYPE_LABEL.get(type_val, "プレイ中")
    await i.response.send_message(
        f"ステータスを「{label}: {text}」に変更しました。再接続後も維持されます。", ephemeral=True)

@status_group.command(name="show", description="いまのステータスを見る")
async def status_show(i: discord.Interaction):
    if not is_admin(i.user.id): return await i.response.send_message("権限がありません。", ephemeral=True)
    st = get_status()
    label = _STATUS_TYPE_LABEL.get(st["type"], "プレイ中")
    await i.response.send_message(f"現在のステータス: **{label}: {st['text']}**", ephemeral=True)

def _auth_callback_html(title: str, message: str) -> bytes:
    return (
        "<!doctype html><html lang='ja'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{title}</title></head>"
        "<body style='margin:0;display:flex;min-height:100vh;align-items:center;justify-content:center;"
        "font-family:sans-serif;background:#2b2d31;color:#fff;text-align:center'>"
        f"<div style='padding:32px'><h1 style='margin:0 0 12px'>{title}</h1>"
        f"<p style='color:#b5bac1'>{message}</p></div></body></html>"
    ).encode("utf-8")


def _handle_auth_callback(handler):
    """OAuth2 のリダイレクト(/callback)を処理する。http.serverスレッド上で動作。"""
    from urllib.parse import urlparse, parse_qs
    import auth_backup as ab

    qs = parse_qs(urlparse(handler.path).query)
    code = (qs.get("code") or [None])[0]
    state = (qs.get("state") or [None])[0]  # 認証元サーバーのID

    def reply(status, title, message):
        body = _auth_callback_html(title, message)
        handler.send_response(status)
        handler.send_header("Content-Type", "text/html; charset=utf-8")
        handler.send_header("Content-Length", str(len(body)))
        handler.end_headers()
        handler.wfile.write(body)

    if not code:
        return reply(400, "認証エラー", "認可コードがありません。もう一度お試しください。")
    try:
        token = ab.exchange_code(code)
        scope = token.get("scope", "")
        if "guilds.join" not in scope or "identify" not in scope:
            return reply(400, "認証エラー",
                         "「サーバーへの参加」の許可が必要です。チェックを外さずにもう一度認証してください。")
        user = ab.get_user(token["access_token"])
        uid = user["id"]
        uname = user.get("username", "")
        ab.store_token(uid, token, guild_id=state, username=uname)
        # 既にサーバーにいる場合は認証ロールを付与
        if state:
            role_id = ab.get_role_id(state)
            if role_id:
                try:
                    ab.add_role(state, uid, role_id)
                except Exception as e:
                    print(f"[AUTH ROLE ERROR] {e}", flush=True)
    except Exception as e:
        print(f"[AUTH CALLBACK ERROR] {e}", flush=True)
        return reply(400, "認証エラー", "認証に失敗しました。時間をおいて再度お試しください。")
    return reply(200, "✅ 認証が完了しました", "このタブは閉じて構いません。ご協力ありがとうございます。")


def run_server():
    class H(http.server.BaseHTTPRequestHandler):
        def do_GET(s):
            if s.path.startswith("/callback"):
                try:
                    _handle_auth_callback(s)
                except Exception as e:
                    print(f"[CALLBACK ERROR] {e}", flush=True)
                    try:
                        s.send_response(500); s.end_headers()
                    except Exception:
                        pass
                return
            s.send_response(200); s.end_headers(); s.wfile.write(b"OK")
        def log_message(s, *a): pass

    server = http.server.ThreadingHTTPServer(("", int(os.environ.get("PORT", 8080))), H)
    threading.Thread(target=server.serve_forever, daemon=True).start()

if __name__ == "__main__":
    run_server()
    bot.run(TKN)
