"""お客さんに「困ったときはここへ」を案内するための文面をまとめる。

トラブルの出方は突き詰めると3つしかない。

  NEEDS_CODE     引き継ぎコードを入れ直してもらえば、こちらで完結できる
  NEEDS_SUPPORT  こちらで調べないと分からない（人が動く必要がある）
  PAYMENT_DOWN   支払いの受け取り口が今使えない（お客さんは何も悪くない）

このうち NEEDS_CODE だけがお客さんの操作で直る。残りの2つは必ず
「チケットからご連絡ください」で終わらせる。DMに来られると運用が回らない。

案内先は /support_channel で設定する。未設定でも文面は出る(その場合は
チャンネル名を出さずに「サポートチケット」とだけ言う)。
"""
import discord

from datapath import data_path, read_json, write_json

# main.py と同じ設定ファイルを共有する。設定の置き場所を増やさない。
CONFIG_FILE = data_path("config.json")

NEEDS_CODE = "needs_code"
NEEDS_SUPPORT = "needs_support"
PAYMENT_DOWN = "payment_down"

_COLORS = {NEEDS_CODE: 0xffaa00, NEEDS_SUPPORT: 0xff3333, PAYMENT_DOWN: 0xffaa00}


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


def get_support_channel_id():
    value = _config().get("support_channel_id")
    try:
        return int(value) if value else None
    except (TypeError, ValueError):
        return None


def set_support_channel_id(channel_id):
    cfg = _config()
    if channel_id:
        cfg["support_channel_id"] = int(channel_id)
    else:
        cfg.pop("support_channel_id", None)
    write_json(CONFIG_FILE, cfg)


def contact_line() -> str:
    """「チケットから連絡してください」の案内。設定済みならチャンネルを指す。"""
    channel_id = get_support_channel_id()
    where = f"<#{channel_id}> " if channel_id else ""
    return f"お手数ですが {where}**サポートチケット**からご連絡ください。".replace("  ", " ")


def contact_short() -> str:
    """1行だけの案内。本題が別にあるとき(入れ直しのお願いなど)に使う。

    そこではチケットは「うまくいかなかったときの逃げ道」でしかないので、
    非公開である説明まで載せると本題がぼやける。
    """
    channel_id = get_support_channel_id()
    where = f"<#{channel_id}>" if channel_id else "サポートチケット"
    return f"うまくいかないときは {where} からご連絡ください。"


def trouble_embed(kind: str, title: str, detail: str = "", *,
                  order_id: str = None, amount: int = None,
                  summary: str = "", note: str = "") -> discord.Embed:
    """お客さんに見せるトラブル通知。

    決まりごとを2つ守る。
      - お代を受け取っている場合は必ずそう書く(不安にさせない)
      - 連絡先はチケット1本に絞る
    note には「どの段階で止まったか」の短い説明だけを入れる。
    生のHTTP応答やスタックトレースはお客さんには出さない。
    """
    description = detail
    if kind in (NEEDS_SUPPORT, PAYMENT_DOWN):
        description = (detail + "\n\n" + contact_line()).strip()
    embed = discord.Embed(title=title, description=description,
                          color=_COLORS.get(kind, 0xff3333),
                          timestamp=discord.utils.utcnow())
    if amount is not None:
        embed.add_field(name="金額", value=f"{int(amount):,}円", inline=True)
    if summary:
        embed.add_field(name="内容", value=str(summary)[:1024], inline=False)
    if note:
        embed.add_field(name="状況", value=f"```{str(note)[:300]}```", inline=False)
    if order_id:
        embed.set_footer(text=f"注文番号 {order_id}（お問い合わせの際はこの番号をお伝えください）")
    return embed


PAID_AND_STUCK = ("**お代は受け取っています。**追加のお支払いは必要ありません。\n"
                  "こちらで内容を確認して対応します。")

PAYMENT_UNAVAILABLE = ("ただいまこの支払い方法をご利用いただけません。\n"
                       "**お代はいただいていません。** 復旧までお待ちいただくか、"
                       "他の支払い方法をお試しください。")

CHECK_YOUR_ORDER = "内容に不備があれば、そのままにせずご連絡ください。"

# 支払いを待っている段階でDMが閉じていると分かったときに足す一言。
# 渡す段になってから気付くと、承認は済んでいるのに届け先が無い状態になる。
# 待っているあいだに開放してもらえれば、そのまま自動で届く。
DM_CLOSED_NOTE = ("\n\n⚠️ **DMをお送りできませんでした。**完成品はDMでお届けするので、"
                  "このサーバーからのDMを開放してください"
                  "（開放しておけば、承認後そのまま自動で届きます）。")

# 入れ直しをお願いするときに、これだけは必ず伝える。
# 「また払うのか」「急がないと期限が切れるのか」の2つが最大の不安なので、
# そこを1行で潰す。
PAID_NO_DEADLINE = ("**お代は受け取り済みです。**追加のお支払いは不要で、"
                    "期限もありません。")


async def send_private(bot, order: dict, embed: discord.Embed,
                       view: discord.ui.View = None) -> bool:
    """本人にだけ届くように送る。DM → 買った場所での呼びかけ、の順。

    購入チャンネルに出すときは中身を書かない(他の人に見えるため)。
    どちらも駄目なら False を返す。呼び出し側が管理者に知らせる。
    """
    user = None
    try:
        uid = int(order.get("user_id"))
        user = bot.get_user(uid) or await bot.fetch_user(uid)
    except (TypeError, ValueError, discord.HTTPException):
        user = None

    if user is not None:
        try:
            if view is not None:
                await user.send(embed=embed, view=view)
            else:
                await user.send(embed=embed)
            return True
        except discord.HTTPException:
            pass

    channel = None
    if order.get("channel_id"):
        try:
            channel = bot.get_channel(int(order["channel_id"]))
        except (TypeError, ValueError):
            channel = None
    if channel is not None:
        try:
            await channel.send(
                f"<@{order.get('user_id')}> DMをお送りできませんでした。"
                "DMを開放していただくか、こちらからご確認ください。",
                embed=embed, view=view)
            return True
        except discord.HTTPException:
            pass
    return False
