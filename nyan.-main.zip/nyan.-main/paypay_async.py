"""PayPaython-Mobile(同梱ライブラリ)を discord.py の非同期処理から使うためのブリッジ。

ライブラリ本体は requests ベースの同期実装なので、ネットワーク呼び出しは
すべて asyncio.to_thread でスレッドに逃がしてイベントループを止めないようにする。
ログイン・受け取り・トークン更新・認証情報の保存をここに集約する。

セッションが切れたら、次の順で自分で立て直す。人を呼ぶのは最後。
  1. リフレッシュトークンで更新する
  2. 保存済みの端末UUIDで入り直す。PayPayは一度ログインした端末を覚えている
     ので、電話番号とパスワードだけでSMS認証なしに取り直せる
  3. それも通らないときだけ、SMS認証からの再登録を管理者に頼む

PayPayは1アカウント1端末で、スマホのアプリで同じアカウントに入られると
Bot側は必ず切られる。毎回SMSを貼り直すのでは受取が止まるので、2 を用意した。
"""
import asyncio
import contextlib
import os
import random
import threading
import time
from typing import NamedTuple
from uuid import uuid4

import requests

from crosslock import LockTimeout, cross_process_lock
from paypay_mobile import PayPay, PayPayLoginError, PayPayError, PayPayNetWorkError
from datapath import data_path, read_json, write_json


def _proxy():
    """PayPayとの通信に使うプロキシ。PAYPAY_PROXY があればそれ、無ければ直結。

    送金系(create_link 等)がデータセンターIPから出ていると、PayPayのリスク判定で
    実機ではないと見なされ P2P_BLOCK_FOR_MAYBE_EMULATOR で弾かれることがある。
    日本の住宅/モバイル回線のプロキシ("http://user:pass@host:port" 等)を入れておくと
    そこを通して出られる。ログインと操作でIPが変わると不整合になるので、この関数を
    すべての PayPay 生成で使い、同じ経路に揃える。未設定なら None を返し、
    従来どおり直結で動く(挙動は変わらない)。
    """
    return (os.environ.get("PAYPAY_PROXY") or "").strip() or None


class ReceiveUnsure(Exception):
    """受け取れたのかどうか確認できなかった(お金が動いた可能性がある)。

    acceptP2PSendMoneyLink を投げた後で通信が切れた場合など。「失敗した」と
    言い切ると、実際には入金済みなのに商品を渡さないことになるので分けて扱う。
    """


class LinkAlreadyTaken(ReceiveUnsure):
    """すでに受け取られていたリンク(こちらが投げた記録は無い)。

    他所で受け取られたようにも見えるが、こちらの受け取りが記録される前に
    落ちた場合もここに来る。つまり入金済みの可能性がある。確定エラーにすると
    「残高だけ増えて何も渡さない」になるので、ReceiveUnsure の仲間として扱い、
    お客さんには二重払いを止めて管理者に確認してもらう。
    """


class LinkRejected(PayPayError):
    """そのリンクでは受け取れない(金額不足・パスワード必須・キャンセル済みなど)。

    お金は動いていないと言い切れる場合だけここに来る。待っても状況が変わらない
    ので、後追いの見張りに回しても意味がない。
    """


class PendingTimeout(PayPayError):
    """保留(承認待ち)のまま待ち時間が終わった。

    accepted が True なら受け取りのPOSTは投げてある。承認され次第あとから入金
    するので、呼び出し側はこの注文を絶対に捨ててはいけない(捨てると残高だけ
    増えて商品が渡らない)。False なら投げていない=入金なしだが、お客さんが
    後から承認することは珍しくないので、やはり見張りへ引き継ぐ。
    """

    def __init__(self, message="支払いが保留のまま承認されませんでした。", accepted: bool = False):
        super().__init__(message)
        self.accepted = bool(accepted)


# 同梱ライブラリは requests を素で使っていて、どのリクエストにも timeout が
# 付いていない。受け取りのPOSTで応答待ちのまま固まると、お金だけ動いて
# こちらは永遠に待つ(=お客さんにはエラー、こちらは残高だけ増える)ことになる。
# セッション側で既定のタイムアウトを入れておく。
CONNECT_TIMEOUT = 10
READ_TIMEOUT = 30


class _TimeoutSession(requests.Session):
    def request(self, *args, **kwargs):
        kwargs.setdefault("timeout", (CONNECT_TIMEOUT, READ_TIMEOUT))
        return super().request(*args, **kwargs)


def _client(access_token=None, device_uuid=None, client_uuid=None, **kwargs) -> PayPay:
    """タイムアウト付きのセッションを持つ PayPay クライアントを作る。

    セッションの差し替えは、まだ1度もリクエストを投げていない生成直後に行う
    (Cookieを引き継ぐ必要がないタイミング)。
    """
    kwargs.setdefault("proxy", _proxy())
    pp = PayPay(access_token=access_token, device_uuid=device_uuid,
                client_uuid=client_uuid or str(uuid4()), **kwargs)
    session = _TimeoutSession()
    session.cookies.update(pp.session.cookies)
    pp.session = session
    return pp


# ログイン(電話番号・パスワードを渡す形)はコンストラクタの中で通信まで済ませて
# しまうので、後から session を差し替えてもタイムアウトを付けられない。生成の
# 間だけ requests.Session を差し替えて、ログイン中のリクエストにも既定の
# タイムアウトを効かせる。付けないと、応答が返らないときにスレッドが永久に
# 残り、to_thread のワーカーを食い潰して受け取りまで止まる。
_login_session_lock = threading.Lock()


@contextlib.contextmanager
def _timeout_login_session():
    with _login_session_lock:
        original = requests.Session
        requests.Session = _TimeoutSession
        try:
            yield
        finally:
            requests.Session = original


PAYPAY_DATA_FILE = data_path("paypay_data.json")
# PayPayアカウントは1つだけ。誰が /paypay登録 しても同じ共有スロットに保存し、
# 受取もここを見る(本垢・サブ垢どちらでログインしても同じ受取先になる)。
OWNER_KEY = "owner"

# トークン更新は回すほど安全、ではない。リフレッシュトークンは使うたびに
# 入れ替わり、古いほうを一度でも投げ直すと使い回しとみなされてセッションごと
# 失効する(S1003)。1回の更新は1回の失効チャンス。
# アクセストークン自体は長寿命(90日)なので、こまめに更新する意味はない。
# 定期更新は「放置されたリフレッシュトークンの失効を防ぐ」ためだけなので1日1回。
#
# STALE_AFTER_HOURS は必ず REFRESH_INTERVAL_HOURS より短くすること。同じ値だと
# 定期実行が毎回スキップして、実際の更新間隔が2倍になる。
REFRESH_INTERVAL_HOURS = 24
STALE_AFTER_HOURS = 20

# 生存確認(アプリを開いたのと同じリクエスト)の間隔(分)。放置されたセッションは
# 切られるので回し続けるが、等間隔で24時間叩くと「1日48回・完全に等間隔・
# 就寝なし」という行動になる。幅を持たせ、深夜は控えめにする。
KEEP_ALIVE_DAY_MINUTES = (40, 100)
KEEP_ALIVE_NIGHT_MINUTES = (150, 300)
# 深夜とみなす時間帯(JST)。この間は間隔を伸ばす。
KEEP_ALIVE_NIGHT_HOURS = range(1, 7)


# 保留(承認待ち)を待つ時間。案内文の「◯分以内に承認してください」もこの値から
# 作るので、ここを変えれば表示も一緒に変わる(文面と実挙動がズレないように)。
PENDING_WAIT_SECONDS = 180

# 保留中の確認間隔。同じリンクを一定間隔で叩き続けると機械的で目立つので、
# 最初だけ細かく見て、その後は間隔を伸ばしながら確認する(毎回ゆらぎも入れる)。
# 3分間の確認回数が 36回 → 14回程度まで減る。
POLL_INTERVAL_START = 5
POLL_INTERVAL_MAX = 15
POLL_BACKOFF = 1.4

# 保留に入った後、同じ支払い画面の中で受け取りを投げ直す間隔(秒)と回数。
#
# 保留は「送金者のアプリに承認ボタンが出ている」状態で、承認されても、こちらが
# もう一度受け取りを投げるまで入らないことがある。投げっぱなしで状態を見るだけに
# していると、お客さんがその場で承認しても画面は「まだ承認されていません」で終わり、
# 入金は見張りが投げ直すまで(最短でも2分後)持ち越しになる。承認したのに完了しない、
# の正体はこれ。画面が開いている間は、画面の側でも投げ直す。
#
# ただし投げるたびに送金者のアプリへ承認の催促が出る。立て続けに出すとどれを
# 押せばいいのか分からなくなってキャンセルを選ばれるので、間隔を空けて数回だけ。
HELD_RETRY_SECONDS = 45
HELD_RETRY_BACKOFF = 2.0
HELD_RETRY_MAX_SECONDS = 120
# 1回の支払い画面で投げ直す上限(保留に入る前の1回目は数に入れない)。
HELD_RETRY_LIMIT = 2


class NotRegisteredError(Exception):
    """代行の受取先アカウントが未登録のときに送出する。"""


class TokenExpiredError(PayPayLoginError):
    """リフレッシュトークンまで失効した状態。SMS認証からの再ログインが必要。

    PayPayLoginError を継承しているので、既存の except PayPayLoginError でも拾える。
    """


class RefreshFailedError(Exception):
    """一時的な理由(通信断など)でトークン更新に失敗した。再ログインは不要。"""


class RefreshUnsafeError(RefreshFailedError):
    """更新の結果が確認できず、そのリフレッシュトークンをもう使えない状態。

    PayPayが入れ替えを済ませていた場合、同じものを投げ直すと使い回しとみなされて
    セッションごと失効する。安否が分からないトークンは二度と使わない。
    セッション自体はアクセストークン(長寿命)で生きているので受取は続けられる。
    ただし延命はできなくなるので、都合のいいタイミングでの再ログインが要る。
    """


class ReloginUnavailableError(PayPayLoginError):
    """端末UUIDでの自動再ログインができず、SMS認証からの登録が必要な状態。

    PayPayは一度ログインした端末(Device-UUID)を覚えていて、その端末からなら
    電話番号・パスワードだけで入り直せる。それが通らない = 端末を忘れられたか、
    パスワードが変わったか、保存が欠けているということなので人手が要る。
    """


class ReloginFailedError(RefreshFailedError):
    """一時的な理由(通信断など)で再ログインに失敗した。人手は不要。

    RefreshFailedError を継承しているので、既存の「一時的な失敗」の扱いに乗る。
    """


def _resolve_owner(data: dict):
    """受取に使う認証情報を返す。共有スロット優先、無ければ既存の登録を1件使う。"""
    creds = data.get(OWNER_KEY)
    if creds and creds.get("access_token"):
        return OWNER_KEY, creds
    # 旧仕様(ユーザーID別に保存)のデータでも動くようフォールバック
    for k, v in data.items():
        if isinstance(v, dict) and v.get("access_token"):
            return k, v
    return None, None


def load_paypay_data() -> dict:
    return read_json(PAYPAY_DATA_FILE, {})


def save_paypay_data(data: dict):
    write_json(PAYPAY_DATA_FILE, data)


# セッションに起きたこと(ログイン・更新・失効)の記録。失効はPayPay側の判断で
# 理由も返ってこないため、こちらに履歴が無いと「なぜ切れたか」を追えない。
SESSION_LOG_FILE = data_path("paypay_session_log.json")
SESSION_LOG_KEEP = 60


def _tail(token) -> str:
    """トークンの末尾だけを返す(記録用。丸ごとは残さない)。"""
    return f"...{token[-4:]}" if isinstance(token, str) and len(token) >= 4 else "-"


def journal(event: str, **fields):
    """セッションの出来事を1行追記する。

    「切れる直前に何をしていたか」「同じリフレッシュトークンを二度使って
    いないか」が後から分かるようにするためのもの。トークンは末尾4文字だけ。
    """
    entry = {"at": time.time(), "event": event}
    entry.update(fields)
    try:
        history = read_journal()
        history.append(entry)
        write_json(SESSION_LOG_FILE, history[-SESSION_LOG_KEEP:])
    except OSError:
        pass


def read_journal() -> list:
    """記録を古い順で返す。読めなければ空。"""
    return read_json(SESSION_LOG_FILE, [])


def _store_credentials(user_id, pp: PayPay, phone: str, password: str):
    # user_id に関わらず共有スロットに保存する(PayPayアカウントは1つ)。
    data = load_paypay_data()
    now = time.time()
    data[OWNER_KEY] = {
        "phone": phone,
        "password": password,
        "client_uuid": pp.client_uuid,
        "device_uuid": pp.device_uuid,
        "access_token": pp.access_token,
        "refresh_token": pp.refresh_token,
        "logged_in_at": now,
        "refreshed_at": now,
    }
    save_paypay_data(data)
    journal("login", token=_tail(pp.refresh_token))


def _save_creds(key: str, creds: dict):
    """更新後の認証情報をディスクへ書き戻す(他のキーは触らない)。"""
    data = load_paypay_data()
    data[key] = creds
    save_paypay_data(data)


# ---- ログイン(電話番号 / パスワード / OTLリンク) ----

async def start_login(phone: str, password: str) -> PayPay:
    """電話番号・パスワードでログインを開始する。

    成功すると SMS にログイン用リンク(OTL)が届く。返した PayPay オブジェクトを
    そのまま保持し、届いた URL を complete_login() に渡してログインを完了する。
    電話番号・パスワード誤りなどは PayPayLoginError を送出する。
    """
    def _do():
        with _timeout_login_session():
            return PayPay(phone, password, client_uuid=str(uuid4()), proxy=_proxy())
    return await asyncio.to_thread(_do)


async def complete_login(pp: PayPay, url: str, user_id, phone: str, password: str) -> PayPay:
    """SMS で届いたログイン用リンクを渡してログインを完了し、認証情報を保存する。"""
    await asyncio.to_thread(pp.login, url)
    _store_credentials(user_id, pp, phone, password)
    return pp


def _device_login_sync(phone: str, password: str, device_uuid: str, client_uuid: str = None) -> PayPay:
    """保存済みの端末UUIDでログインし直す(SMS認証なし・同期)。

    PayPayは一度ログインした端末(Device-UUID)を覚えているので、その端末を
    名乗れば電話番号とパスワードだけでトークンを取り直せる。SMSのURLを人が
    貼り付ける必要が無いので、セッションが切られてもBotだけで復帰できる。

    端末を忘れられていた / パスワードが変わっていた等は ReloginUnavailableError
    (人手が必要)。通信断などは ReloginFailedError(あとで再試行すればよい)。
    """
    if not (phone and password and device_uuid):
        raise ReloginUnavailableError(
            "電話番号・パスワード・端末UUIDのどれかが保存されていません")

    try:
        with _timeout_login_session():
            pp = PayPay(phone, password, device_uuid=device_uuid,
                        client_uuid=client_uuid or str(uuid4()), proxy=_proxy())
    except PayPayLoginError as e:
        # 端末が登録されていない / 資格情報が違う。投げ直しても同じなので人手へ。
        raise ReloginUnavailableError(e.args[0] if e.args else str(e))
    except (PayPayError, PayPayNetWorkError, requests.RequestException, OSError, ValueError) as e:
        raise ReloginFailedError(e)

    if not getattr(pp, "access_token", None) or not getattr(pp, "refresh_token", None):
        raise ReloginUnavailableError("トークンを受け取れませんでした")
    return pp


async def device_login(phone: str, password: str, device_uuid: str,
                       client_uuid: str = None, user_id=None) -> PayPay:
    """端末UUIDでログインし直して認証情報を保存する(SMS認証なし)。"""
    pp = await asyncio.to_thread(_device_login_sync, phone, password, device_uuid, client_uuid)
    _store_credentials(user_id, pp, phone, password)
    return pp


def _normalize_phone(phone) -> str:
    return str(phone or "").replace("-", "").strip()


def owner_device_uuid(phone: str = None):
    """保存済みの端末UUIDを返す。phone を渡すとその番号の登録に限る。

    同じ番号を登録し直すときは、前と同じ端末を名乗ればSMS認証が要らない。
    端末を新しくするたびにPayPay側の登録端末が増える(=先に入っていた
    セッションが切られる)ので、使い回せるなら使い回す。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return None
    if phone and _normalize_phone(creds.get("phone")) != _normalize_phone(phone):
        return None
    return creds.get("device_uuid")


# ---- 受け取り ----
#
# ここで効いてくる事実は1つ。acceptP2PSendMoneyLink は投げた時点でお金が
# 動きうる。その場で通ることも、承認待ち(保留)で後から入ることも、応答が
# 読めないまま入っていることもある。だからこの層の掟は一行:
#
#     投げた後は、二度と「失敗しました」で終わらせない。
#
# 投げた後に許される結末は3つだけ。
#   RECEIVED  入金を確認した
#   HELD      保留。承認され次第入るので見張り続ける
#   UNSURE    結果が読めない。見張りつつ管理者に知らせる
#
# HELD は「POSTが弾かれ、リンクはまだ PENDING」という形で返る。これは
# PayPayが送金を保留にして、送金者(お客さん)に確認を求めている状態。
# お客さんのPayPayアプリには、こう出る:
#
#     「〇〇さんへの送金が保留になっています」  [承認する] [キャンセル]
#
# つまりお客さんには押すべきボタンがあり、こちらから案内しなければならない。
#   承認する   → お金が動く。あとから入金するので、見張り続けて必ず受け取る
#   キャンセル → 送金は失敗し、お金は送り主へ戻る(送り主のアプリでは
#                「送金（譲渡）失敗」)。こちらには入らない
# ここを失敗と判定して捨てると、承認は後から通るので、お金だけ入って商品が
# 渡らない。逆に案内を怠ると、お客さんはキャンセルを押して代行が始まらない。

# PayPayが返す orderStatus を、こちらの意味に振り分ける。
# 受け取りが通った直後のリンクは PENDING → SUCCESS に変わる。SUCCESS を
# 落とすと、通った受け取りが「知らない状態」に落ちて UNSURE(結果が読めない)や
# PENDING(まだ受け取れない)に化ける。COMPLETED / RECEIVED は名前が変わった
# ときの保険。
_RECEIVED_STATUSES = ("SUCCESS", "COMPLETED", "RECEIVED")
# 送金が送り主へ戻った状態。お金はこちらに入らない。
_DEAD_STATUSES = ("CANCELED", "CANCELLED", "DECLINED", "EXPIRED", "REJECTED")
# まだ受け取れる(誰も受け取っていない)状態。
_OPEN_STATUS = "PENDING"

# 受け取り1回分の結末。
RECEIVED = "received"   # 入金した(金額が分かる)
HELD = "held"           # PayPayが保留。送金者の承認待ち=承認されれば入る
PENDING = "pending"     # まだ受け取れる状態にない。投げていない=入金なし
GONE = "gone"           # もう受け取れない(キャンセル/期限切れ/金額不足など)
TAKEN = "taken"         # すでに受け取られていた。こちらが受け取った可能性あり
UNSURE = "unsure"       # 投げたが結果が読めない
ERROR = "error"         # 一時的な不調(通信・ログイン)。入金なし

# 「こちらの操作でお金が動いた可能性がある」結末。この集合に入った注文は、
# 何があっても捨ててはいけない(捨てた瞬間に残高だけ増える)。
MONEY_AT_RISK = frozenset((RECEIVED, HELD, TAKEN, UNSURE))

# PayPayがリンクを閉じていた = 送金はこちらに入らず送り主へ戻っている。
# 保留の案内で「キャンセル」を押されたか、承認されないまま期限が来たか。
# 送り主のアプリには「送金（譲渡）失敗」と出る。受け取りを投げた後であっても、
# ここだけは「入金されているかも」ではなく「入っていない」と言い切れる。
RETURNED_NOTE = ("送金が承認されず（キャンセルまたは期限切れ）、"
                 "お金は送り主に戻りました")


class Outcome(NamedTuple):
    """受け取り1回分の結末。保留を例外で表さないための型。

    accepted  … この注文で受け取りのPOSTを投げたことがあるか(過去の回も含む)
    attempted … この回に投げたか(投げ直しの間引きに使う)
    returned  … PayPayがリンクを閉じた(=お金は送り主に戻っていて入金しない)。
                同じ GONE でも「金額が足りないので受け取らなかった」ときは
                リンクが生きたままなので、これは立てない。
    blocked   … こちら側の都合で受け取れなかった(受取口の設定)。お客さんには
                直せないので、管理者に知らせる必要がある。
    unreadable… リンクの状態そのものを読めなかった。「まだ承認されていない」と
                見分けが付かないが、受け取り済みのリンクは問い合わせ自体が
                失敗することがあるので、投げた後のこれは入金済みかもしれない。
                答えは入金履歴にしか無いので、突合を急がせるのに使う。
    sender    … 送り主の表示名(投げた回だけ)。入金履歴で確かめるときの照合に使う。
    posted_at … 受け取りを投げた時刻(投げた回だけ)。同上。
    """
    state: str
    amount: int = 0
    accepted: bool = False
    attempted: bool = False
    detail: str = ""
    returned: bool = False
    blocked: bool = False
    unreadable: bool = False
    sender: str = ""
    posted_at: float = 0.0

    @property
    def at_risk(self) -> bool:
        """お金が動いた可能性があるか(=この注文を捨ててはいけないか)。"""
        return self.state in MONEY_AT_RISK


def _find_backend_code(node, depth: int = 0):
    """応答の奥にある backendResultCode を探す。

    PayPayが受け取りを弾いた本当の理由(P2P_BLOCK_FOR_MAYBE_EMULATOR など)は
    header の文言ではなくここに入る。拾わないと「取引が完了できませんでした」
    しか残らず、何が起きたのか分からないまま同じことが繰り返される。
    """
    if depth > 5:
        return None
    if isinstance(node, dict):
        code = node.get("backendResultCode")
        if isinstance(code, str) and code.strip():
            return code.strip()
        for value in node.values():
            found = _find_backend_code(value, depth + 1)
            if found:
                return found
    elif isinstance(node, list):
        for value in node[:5]:
            found = _find_backend_code(value, depth + 1)
            if found:
                return found
    return None


def _detail(e: Exception) -> str:
    """PayPayの例外から短い説明を作る(生のJSONをそのまま見せない)。"""
    raw = e.args[0] if getattr(e, "args", None) else str(e)
    if isinstance(raw, dict):
        header = raw.get("header") or {}
        code = _find_backend_code(raw)
        text = header.get("resultMessage") or header.get("resultCode") or raw
        raw = f"{text}（{code}）" if code and code not in str(text) else text
    return str(raw)[:200]


def classify_status(status):
    """orderStatus を RECEIVED / GONE / PENDING に振り分ける。読めなければ None。

    画面側もこれを使う。同じ判定を各所で書き直すと、片方だけ知らない値のまま
    残って「受け取れたのに、まだ開いています」と出る。
    """
    if status in _RECEIVED_STATUSES:
        return RECEIVED
    if status in _DEAD_STATUSES:
        return GONE
    if status == _OPEN_STATUS:
        return PENDING
    return None


_classify = classify_status


def _read_status(pp: PayPay, url: str):
    """リンクの今の状態を読む(best-effort)。

    戻り値は (振り分けた結果, PayPayが返した生の値)。生の値も返すのは、
    知らないステータスが来たときに何だったかを残すため。捨ててしまうと
    「判別できませんでした」だけが残り、次に同じことが起きても直せない。
    """
    try:
        raw = (pp.link_check(url).raw.get("payload") or {}).get("orderStatus")
    except Exception:
        return None, None
    return _classify(raw), raw


# 受け取りのPOSTを投げた後、その結果をどれだけ粘って確かめるか。
# PayPay側の反映は即時とは限らず、保留を承認してもらった直後は特に遅れる。
CONFIRM_TRIES = 4
CONFIRM_INTERVAL = 5
# 投げた後にリンクの状態が読めなくなったとき、入金履歴を見直す間隔(秒)。
# 受け取り済みのリンクは問い合わせ自体が失敗することがあり、画面側の待ちからは
# 「まだ保留」と見分けが付かない。履歴は見張りに回ってから見ていたので、実際には
# 入っているのに 3分待たせた末に「承認してください」と案内していた。
HISTORY_RECHECK_SECONDS = 20

# リンクの状態がどうしても読めなかったときの、最後の確認先。
# 入ったかどうかの本当の答えは入金履歴にある。ここで拾えないと UNSURE
# (結果が読めない)で終わり、お客さんには「二重払いをしないでください」、
# 管理者には手動確認の依頼が飛ぶ——実際には入っているのに。
HISTORY_CONFIRM_SIZE = 20
# 履歴の時刻はPayPay側で分単位に丸められることがある。少し前まで見ないと、投げた
# 直後の入金を「投げる前のもの」として捨ててしまう。ただし広げすぎると、少し前に
# 済んだ【別の注文】の同額入金まで拾ってしまう(1入金で2回代行の原因になった)。
# 丸め(最大60秒)＋時計ずれぶんだけに絞る。
HISTORY_CONFIRM_SLACK = int(os.getenv("PAYPAY_HISTORY_CONFIRM_SLACK", "90"))

# 同じ入金で二度代行しないための台帳。確保した入金の一意ID(historyId等)を残し、
# 以降は同じIDの入金を「使用済み」として弾く。照合は入金直後の数分で済むので、
# 古い印は落として肥大化を防ぐ。
CLAIMED_FILE = data_path("paypay_claimed_deposits.json")
CLAIMED_TTL = int(os.getenv("PAYPAY_CLAIMED_TTL", str(7 * 24 * 3600)))
_CLAIM_LOCK = threading.Lock()


def _load_claimed() -> dict:
    data = read_json(CLAIMED_FILE, {})
    return data if isinstance(data, dict) else {}


def _save_claimed(claimed: dict):
    now = time.time()
    pruned = {k: t for k, t in claimed.items()
              if isinstance(t, (int, float)) and now - t < CLAIMED_TTL}
    write_json(CLAIMED_FILE, pruned)


def _claim_deposit(pp: PayPay, amount: int, since: float, sender: str):
    """この受け取りに当たる入金を履歴から1件だけ確保し、その一意IDを返す。無ければ None。

    金額だけで決めない。同じ額の入金は日常的にあるので、送り主の表示名まで
    一致したものだけを「この受け取り」と認める。さらに【まだ他の注文で使って
    いない入金】に限る。一度使った入金IDは台帳に残して二度は返さない。これが
    無いと、少し前の別注文の入金を今の注文にも当てて、1入金で2回代行してしまう。
    """
    if amount <= 0 or not sender:
        return None
    try:
        raw = pp.get_history(size=HISTORY_CONFIRM_SIZE)
    except Exception as e:
        print(f"[PAYPAY] 入金履歴を確認できませんでした: {_detail(e)}", flush=True)
        return None

    # reconcile はこのモジュールを読むので、循環参照を避けてここで読む。
    # 履歴の読み方(キー名・向きの判定)を突合と1か所にそろえておかないと、
    # 片方だけ古い読み方のまま残って、入金を「読めなかった」で落とすことになる。
    from reconcile import PAYPAY_KEYS, classify, normalize_entry

    floor = since - HISTORY_CONFIRM_SLACK
    entries = ((raw or {}).get("payload") or {}).get("paymentInfoList") or []
    with _CLAIM_LOCK:
        claimed = _load_claimed()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            try:
                row = normalize_entry(entry, PAYPAY_KEYS, "pp")
                if row["amount"] != amount or row["ts"] < floor:
                    continue
                if row["name"] != sender or classify(row) != "incoming":
                    continue
            except Exception:
                continue
            key = row.get("key")
            # IDが読めない/既に別注文で使った入金は当てない(安全側=人手確認へ)。
            if not key or key in claimed:
                continue
            claimed[key] = time.time()
            _save_claimed(claimed)
            return key
    return None


def _deposit_in_history(pp: PayPay, amount: int, since: float, sender: str) -> bool:
    """この受け取りの入金が履歴にあり、まだ他で使っていなければ確保して True。"""
    return _claim_deposit(pp, amount, since, sender) is not None


def _deposit_landed(creds: dict, state: dict) -> bool:
    """投げた受け取りの入金が履歴に載っているか(画面側の待ちループから使う)。

    state には投げた回の amount / sender / posted_at が入っている。送り主の表示名が
    取れていないときは照合しない(同額というだけで当てない=安全側)。
    """
    amount, sender = int(state.get("amount") or 0), state.get("sender") or ""
    if amount <= 0 or not sender:
        return False
    pp = _client(access_token=creds["access_token"], device_uuid=creds.get("device_uuid"),
                 client_uuid=creds.get("client_uuid"))
    return _deposit_in_history(pp, amount, float(state.get("posted_at") or 0), sender)


# ---- 送金で先に使う財布(支払い優先順位) ----
#
# PayPayの口座ぜんたいの設定で、**送るときにどちらの財布から先に出るか**を決める。
# マネーが先ならマネーから、尽きたらライトが混ざる。逆も同じ。
#
# 受け取りにはこの設定は効かない。受け取った額がどちらの財布に入るかは
# 「送り主がどちらから出したか」で決まっていて、受け取る側では選べない
# (送金リンクの subWalletSplit がそのまま運ばれてくる)。UIでもそう書くこと。
# ここを「受け取りの種別も選べる」と見せると、選んだのに変わらない設定になる。
MONEY_FIRST = "MONEY_FIRST"
MONEY_LITE_FIRST = "MONEY_LITE_FIRST"

PRIORITY_LABELS = {
    MONEY_FIRST: "PayPayマネーから先に出す",
    MONEY_LITE_FIRST: "PayPayマネーライトから先に出す",
}

# PayPayには「今どちらが優先か」を返す取得APIが見当たらない。設定した値を
# こちらで控えておき、応答の中に優先順位が入っていればそちらを正とする。
# 控えだけのときは、表示側で「Botが設定した値」と断る(実際にアプリから
# 変えられていても、こちらには分からないため)。
PRIORITY_FILE = data_path("paypay_priority.json")


def _find_money_priority(node, depth: int = 0):
    """応答のどこかに入っている moneyPriority を拾う。無ければ None。

    PayPayは項目の位置をよく変えるので、キー名だけを頼りに深く探す。
    見つからないこと自体は異常ではない(取得APIが無いだけ)。
    """
    if depth > 6:
        return None
    if isinstance(node, dict):
        for key, value in node.items():
            if "moneypriority" in str(key).lower() and isinstance(value, str):
                upper = value.strip().upper()
                if upper in PRIORITY_LABELS:
                    return upper
            found = _find_money_priority(value, depth + 1)
            if found:
                return found
    elif isinstance(node, (list, tuple)):
        for item in node:
            found = _find_money_priority(item, depth + 1)
            if found:
                return found
    return None


def _save_priority(value: str):
    try:
        write_json(PRIORITY_FILE, {"value": value, "at": time.time()})
    except OSError:
        pass


def saved_priority() -> dict:
    """控えてある優先順位。無ければ value=None。

    source は必ず "record"。ディスクから読んだ時点で、それは「いつか見た値」で
    あって「今の設定」ではない。前に応答から読めたからといって "paypay" のまま
    返すと、その後アプリ側で変えられていても「今の設定」として見せてしまう。
    """
    saved = read_json(PRIORITY_FILE, {})
    if not isinstance(saved, dict) or saved.get("value") not in PRIORITY_LABELS:
        return {"value": None, "source": None, "at": 0.0}
    return {"value": saved["value"], "source": "record",
            "at": float(saved.get("at") or 0)}


async def money_priority() -> dict:
    """今どちらの財布から先に出る設定かを返す。

    戻り値: {"value": MONEY_FIRST|MONEY_LITE_FIRST|None,
             "source": "paypay"(応答から読めた) | "record"(こちらの控え) | None,
             "at": 控えた時刻}

    設定を書き換えてまで読みにいくことはしない。読めなければ控えを返し、
    それも無ければ None。分からないものを断定して見せないため。
    """
    try:
        bal = await run_owner_op(lambda pp: pp.get_balance())
    except Exception:
        return saved_priority()
    found = _find_money_priority(getattr(bal, "raw", None))
    if found:
        _save_priority(found)
        return {"value": found, "source": "paypay", "at": time.time()}
    return saved_priority()


async def set_money_priority(paypay_money: bool) -> dict:
    """送金で先に使う財布を切り替える。切り替え後の状態を返す。

    口座ぜんたいの設定なので、ここを変えると以後の送金すべてに効く。
    """
    raw = await run_owner_op(lambda pp: pp.set_money_priority(paypay_money=paypay_money))
    value = MONEY_FIRST if paypay_money else MONEY_LITE_FIRST
    # 応答が結果を返しているならそちらを正とする(こちらの思い込みで上書きしない)
    echoed = _find_money_priority(raw)
    source = "paypay" if echoed else "record"
    if echoed:
        value = echoed
    _save_priority(value)
    journal("money_priority", detail=value)
    return {"value": value, "source": source, "at": time.time(), "raw": raw}


# 受取口がPayPayマネーを持てるか。本人確認が済んでいない口には emoney の財布
# そのものが無く(get_balance の money が None)、マネーで送られた送金を
# 受け取れない。本人確認の状態はそう頻繁に変わらないので使い回す。
EMONEY_CHECK_SECONDS = 600
_emoney_state = {"at": 0.0, "ok": None}


def emoney_wallet_state(bal):
    """受取口がPayPayマネーの財布を持っているか。読み取れなければ None。

    「財布が無い(本人確認が未完了)」と「こちらの読み方が古い」を必ず分ける。
    キー名が変わっただけで「受け取れない」と判定すると、通るはずの支払いまで
    こちらから断ってしまい、売上が丸ごと止まる。分からないときは None。
    """
    if getattr(bal, "money", None) is not None:
        return True
    detail = ((getattr(bal, "raw", None) or {}).get("payload") or {}).get("walletDetail")
    if not isinstance(detail, dict):
        return None      # 応答の形が変わっている。決めつけない
    for key, value in detail.items():
        if "emoney" in key.lower() and value:
            return True  # 名前が変わっただけで財布はある
    return False


def _can_hold_emoney(pp: PayPay) -> bool:
    """受取口がPayPayマネーを受け取れるか。分からなければ True(止めない)。

    確かめられないことを理由に受け取りを断ると、受け取れるはずのお金まで
    落としてしまう。迷ったら投げる側に倒す。
    """
    now = time.time()
    if _emoney_state["ok"] is not None and now - _emoney_state["at"] < EMONEY_CHECK_SECONDS:
        return _emoney_state["ok"]
    try:
        state = emoney_wallet_state(pp.get_balance())
    except Exception as e:
        print(f"[PAYPAY] 受取口の残高種別を確認できませんでした: {e}", flush=True)
        return True
    if state is None:
        print("[PAYPAY] 受取口の残高の形を読めませんでした（判定は保留し、投げます）",
              flush=True)
        return True
    _emoney_state.update(at=now, ok=state)
    if not state:
        print("[PAYPAY] 受取口にPayPayマネーの財布がありません"
              "（本人確認が未完了。マネーでの送金は受け取れません）", flush=True)
    return state


# 受取口のPayPay内部ID。自分で送ったリンクは自分で受け取れない(取り消しは
# できる)ので、投げる前に見分けるのに使う。変わらない値なので長く使い回す。
OWNER_ID_CHECK_SECONDS = 24 * 3600
_owner_id_state = {"at": 0.0, "id": None}


def _owner_external_id(pp: PayPay):
    """受取口のPayPay内部ID。取れなければ None(見分けない)。"""
    now = time.time()
    if _owner_id_state["id"] and now - _owner_id_state["at"] < OWNER_ID_CHECK_SECONDS:
        return _owner_id_state["id"]
    try:
        external = pp.get_profile().external_user_id
    except Exception as e:
        print(f"[PAYPAY] 受取口のIDを確認できませんでした: {_detail(e)}", flush=True)
        return None
    _owner_id_state.update(at=now, id=external)
    return external


def is_self_link(pp: PayPay, info) -> bool:
    """受取口が自分で送ったリンクか。分からなければ False(止めない)。"""
    sender = getattr(info, "sender_external_user_id", None)
    if not sender:
        return False
    owner = _owner_external_id(pp)
    return bool(owner) and str(sender) == str(owner)


def _wallet_note(info) -> str:
    """リンクの中身の内訳。受け取れなかった原因の切り分けに要る。"""
    emoney = int(getattr(info, "money", 0) or 0)
    light = int(getattr(info, "money_light", 0) or 0)
    return f"内訳: マネー{emoney:,}円 / マネーライト{light:,}円"


def _blocked_reason(pp: PayPay, info) -> str:
    """このリンクを受け取れない、こちら側の確かな理由。無ければ空文字。

    PayPayマネーの譲渡は、受け取る側にも本人確認が要る。未完了の口へ投げると
    受け取りは弾かれ、PayPayは送金そのものを失敗させて送り主へ差し戻す
    (送り主のアプリでは「送金（譲渡）失敗」)。投げる前に止めれば、リンクは
    開いたまま残り、お客さんはその場で取り消してすぐ払い直せる。

    送金は通るのに受け取りだけ落ちるのは、これで説明が付く。送る側は
    マネーライトで送れるので本人確認が要らない。
    """
    if is_self_link(pp, info):
        # 自分で送ったリンクは自分で受け取れない。投げても弾かれるだけなので、
        # 「保留」に化けさせずここで止める(取り消しなら通る)。
        return ("受取用アカウント自身が送ったリンクです。"
                "PayPayは自分の送金を自分で受け取れません（取り消しは可能です）")
    emoney = int(getattr(info, "money", 0) or 0)
    if emoney <= 0 or _can_hold_emoney(pp):
        return ""
    return (f"受取用アカウントの本人確認が済んでいないため、この送金に含まれる"
            f"PayPayマネー{emoney:,}円を受け取れません")


def _settle_after_post(pp: PayPay, url: str, amount: int, detail: str,
                       sender: str = "", since: float = 0.0) -> Outcome:
    """受け取りのPOSTを投げた後、リンクを見て結末を決める。

    保留対応の要。POSTはもう投げてしまっているので、選べる答えは
    RECEIVED / GONE / HELD / UNSURE の4つだけ。「失敗」は無い。

    sender / since は、リンクの状態がどうしても読めなかったときに入金履歴で
    確かめるためのもの(送り主の表示名と、投げた時刻)。
    """
    last, last_raw = None, None
    for n in range(CONFIRM_TRIES):
        status, raw = _read_status(pp, url)
        if raw is not None:
            last_raw = raw
        if status == RECEIVED:
            # 受け取れていた。応答が読めなかっただけ。
            return Outcome(RECEIVED, amount, accepted=True, attempted=True)
        if status is not None:
            last = status
        if n < CONFIRM_TRIES - 1:
            time.sleep(CONFIRM_INTERVAL)

    if last is None and last_raw is not None:
        # 読めてはいるが、知らないステータスだった。何だったかを残す。
        detail = f"{detail}（PayPayの状態: {last_raw}）"
    if last == GONE:
        # PayPayがはっきり「もう無い」と言っている。投げた受け取りが通らずに
        # 送金が差し戻された = 送り主に戻っていて入金しない。
        # 原因はPOSTを弾かれたときの応答にしか残らないので、必ずログへ出す。
        print(f"[PAYPAY] 受け取りが通らず送金が差し戻されました: {detail} url={url}",
              flush=True)
        return Outcome(GONE, accepted=True, attempted=True, returned=True,
                       detail=f"{RETURNED_NOTE}: {detail}" if detail else RETURNED_NOTE)
    if last == PENDING:
        # POSTは投げたのにリンクはまだ開いたまま = 保留(送金者の承認待ち)。
        # お客さんが「承認する」を押せば後から入るので、失敗にしてはいけない。
        return Outcome(HELD, amount, accepted=True, attempted=True, detail=detail,
                       sender=sender, posted_at=since)
    # 状態すら読めなかった。リンクからは分からないので、最後に入金履歴を見る。
    # 受け取り済みのリンクは問い合わせ自体が失敗することがあり、ここで拾えないと
    # 入金しているのに「確認できませんでした」で終わってしまう。
    if _deposit_in_history(pp, amount, since, sender):
        print(f"[PAYPAY] リンクの状態は読めませんでしたが、"
              f"入金履歴で受け取りを確認しました url={url}", flush=True)
        return Outcome(RECEIVED, amount, accepted=True, attempted=True)
    # それでも分からない。入ったかどうか分からないので、入った前提で扱う。
    return Outcome(UNSURE, amount, accepted=True, attempted=True, detail=detail,
                   sender=sender, posted_at=since)


def _attempt(creds: dict, url: str, passcode, min_amount,
             accepted_before: bool = False, accept: bool = True,
             screen=None) -> Outcome:
    """受け取りを1回試して Outcome を返す。保留でも例外は投げない。

    投げるのは受け取り以前の失敗(PayPayLoginError)だけ。呼び出し側がログインを
    立て直して同じ回をやり直せるようにするため。

    accept=False ならPOSTを投げず、リンクの状態を見るだけ。一度投げた後に催促
    しても意味がないので、見張りが「確認だけの回」に使う。
    """
    pp = _client(
        access_token=creds["access_token"],
        device_uuid=creds.get("device_uuid"),
        client_uuid=creds.get("client_uuid"),
    )
    try:
        info = pp.link_check(url)
    except PayPayLoginError:
        raise
    except PayPayError as e:
        # リンク情報すら読めない。保留中はここで弾かれるので、
        # 「まだ受け取れない」として次の回に見る。
        # ただし受け取り済みのリンクも同じように読めなくなる。投げた後のこれは
        # 「入っているのに保留に見える」かもしれないので、印を付けて渡す
        # (見張り側が入金履歴との突合を急がせるのに使う)。
        return Outcome(PENDING, accepted=accepted_before, detail=_detail(e),
                       unreadable=True)

    amount = int(info.amount or 0)
    raw_status = (info.raw.get("payload") or {}).get("orderStatus")
    status = _classify(raw_status)

    if status == RECEIVED:
        if accepted_before:
            # こちらが投げた受け取りが通っていた。これはこの注文の入金。
            return Outcome(RECEIVED, amount, accepted=True)
        # 投げた記録が無いのに受け取り済み。他所で受け取られたようにも見えるが、
        # 記録が残る前に落ちた可能性もあるので、入金済みかもしれない扱いにする
        return Outcome(TAKEN, amount, detail="すでに受け取り済みのリンクです")

    if status == GONE:
        if accepted_before:
            # 受け取りは投げてある。それでもリンクが閉じている = こちらの
            # 受け取りが通らず、送金は送り主へ戻された。辞退・キャンセルと
            # 一緒くたにすると、原因がお客さん側にあるように読めてしまう。
            return Outcome(GONE, amount, accepted=True, returned=True,
                           detail=RETURNED_NOTE)
        return Outcome(GONE, amount, returned=True,
                       detail="辞退・キャンセル・期限切れのリンクです")

    if status != PENDING:
        # 未知のステータス。決めつけずに次の回で見る。何だったかは残す
        # (残さないと、同じことが起きても振り分けを直しようがない)。
        print(f"[PAYPAY] 知らないorderStatus: {raw_status!r} url={url}", flush=True)
        return Outcome(PENDING, amount, accepted=accepted_before,
                       detail=f"リンクの状態を判別できませんでした"
                              f"（PayPayの状態: {raw_status}）")

    # --- ここから下は「まだ受け取れる」リンク ---
    if min_amount and amount < int(min_amount):
        return Outcome(GONE, amount, accepted=accepted_before,
                       detail=f"金額が不足しています"
                              f"(必要: {int(min_amount):,}円 / リンク: {amount:,}円)")
    if info.has_password and not passcode:
        return Outcome(GONE, amount, accepted=accepted_before,
                       detail="このリンクにはパスワードが設定されています")

    if not accept:
        # 状態を見るだけの回。まだ受け取れる = まだ承認されていない。
        return Outcome(PENDING, amount, accepted=accepted_before)

    # 受け取れないと分かっている中身には手を出さない。投げてから弾かれると、
    # PayPayが送金ごと失敗させて送り主へ差し戻してしまう。
    blocked = _blocked_reason(pp, info)
    if blocked:
        print(f"[PAYPAY] 受け取りを投げずに断りました: {blocked}"
              f" / {_wallet_note(info)} url={url}", flush=True)
        return Outcome(GONE, amount, accepted=accepted_before, blocked=True,
                       detail=blocked)

    # 安全確認。送金元が分かるのはここが最後で、この次はもう後戻りできない。
    # 受け取ってから返すと、こちらの残高と履歴に一度入れて送り返すことになる。
    # ここで断れば、リンクは開いたまま送り主の手元に残る(返金が要らない)。
    if screen is not None:
        refused = screen(info)
        if refused:
            print(f"[PAYPAY] 安全確認で受け取りませんでした: {refused} url={url}",
                  flush=True)
            return Outcome(GONE, amount, accepted=accepted_before, blocked=True,
                           detail=refused)

    # --- ここから後戻りできない。投げたら結末は _settle_after_post が決める ---
    # ここで投げ直してはいけない。投げるたびに送金者のPayPayアプリへ
    # 「〇〇さんへの送金が保留になっています（承認する / キャンセル）」が出る。
    # 立て続けに出すと、お客さんはどれを押せばいいのか分からなくなり、
    # キャンセルを選ばれる。投げ直しは見張り側が間隔を空けて行う。
    return _post_receive(pp, url, passcode, info, amount)


def _post_receive(pp: PayPay, url: str, passcode, info, amount: int) -> Outcome:
    """受け取りを1回だけPOSTして、結末を決める。"""
    posted_at = time.time()
    try:
        pp.link_receive(url, passcode=passcode, link_info=info.raw)
    except Exception as e:
        # 弾かれた理由はこの応答にしか出ない。保留に入ったのか、PayPayに受け取り
        # そのものを拒まれたのかは、後からこの文言でしか切り分けられない。
        detail = _detail(e)
        print(f"[PAYPAY] 受け取りのPOSTが通りませんでした: {detail}"
              f" / {_wallet_note(info)} url={url}", flush=True)
        return _settle_after_post(pp, url, amount, detail,
                                  sender=getattr(info, "sender_name", "") or "",
                                  since=posted_at)
    # 受け取れた。この入金を台帳に「使用済み」として記録し、後で別注文の履歴照合が
    # 同じ入金をこの額の受け取りに当ててしまうのを防ぐ。記録できなくても受け取り
    # 自体は成立しているので、失敗にはしない(best-effort)。
    #
    # 履歴の取得はPayPayへの往復がもう1回要る。お客さんはこの戻りを待って
    # 商品を受け取るので、往復は裏のスレッドに任せて先に戻す。台帳の読み書きは
    # _CLAIM_LOCK で直列になるので、裏で書いても照合と衝突しない。
    _claim_in_background(pp, amount, posted_at,
                         getattr(info, "sender_name", "") or "")
    return Outcome(RECEIVED, amount, accepted=True, attempted=True)


def _claim_in_background(pp: PayPay, amount: int, since: float, sender: str):
    """受け取れた入金の「使用済み」記録を、受け取りの戻りを待たせずに付ける。"""
    def run():
        try:
            _claim_deposit(pp, amount, since, sender)
        except Exception as e:
            print(f"[PAYPAY] 入金の使用済み記録に失敗しました: {_detail(e)}", flush=True)

    try:
        threading.Thread(target=run, name="paypay-claim-deposit", daemon=True).start()
    except Exception:
        # スレッドを起こせないときは、その場で付けてから戻る(遅くはなるが落とさない)。
        run()


def _use_form_content_type(pp: PayPay):
    """トークン更新用に Content-Type をフォーム形式へ直す。

    PayPay(access_token=...) で生成すると headers に大文字小文字違いの
    Content-Type が両方入り、requests 側では後勝ちで application/json になる。
    一方 token_refresh() はフォーム形式(data=)でPOSTするため、そのままだと
    PayPay に C0001 'Malformed header value.' で弾かれてトークン更新が
    永久に失敗する。送信前にキーを1つへ正規化しておく。
    """
    for k in [k for k in pp.headers if k.lower() == "content-type"]:
        del pp.headers[k]
    pp.headers["Content-Type"] = "application/x-www-form-urlencoded"


def _salvage_rotated(creds: dict, pp: PayPay):
    """更新の途中で落ちたときに、PayPayが発行済みのトークンを拾う。

    アクセストークンが入れ替わっていれば PayPay は更新を受け付けている。
    新しいリフレッシュトークンまで読めていればそのまま保存し、読めていなければ
    捨てる(None)。使用済みのトークンを次回に投げ直すのが一番まずいので、
    「無い」状態にして再ログインを促すほうが安全。
    アクセストークンが元のままなら更新は成立していないので None を返す。
    """
    new_access = getattr(pp, "access_token", None)
    if not new_access or new_access == creds.get("access_token"):
        return None

    new_refresh = getattr(pp, "refresh_token", None)
    salvaged = dict(creds)
    salvaged["access_token"] = new_access
    salvaged["refresh_token"] = new_refresh if new_refresh and new_refresh != creds.get("refresh_token") else None
    salvaged["refreshed_at"] = time.time()
    return salvaged


def _refresh_sync(creds: dict, attempts: int = 3) -> dict:
    """トークンを更新して新しい認証情報を返す。

    失効(PayPayLoginError)は TokenExpiredError → 再ログインが必要。
    結果が確認できなかったときは RefreshUnsafeError(以後このトークンは使わない)。
    それ以外の失敗は RefreshFailedError(どちらも再ログインは不要)。

    再試行するのは「接続すら確立できなかった」ときだけにする。PayPay が何か
    応答を返した後や応答が壊れていた場合は、更新自体は成立していてトークンが
    入れ替わっている可能性がある。そこで同じリフレッシュトークンを投げ直すと
    使い回しとみなされ、セッションごと失効(S1003 Refresh Token is revoke)する。
    """
    if not creds.get("refresh_token"):
        raise TokenExpiredError("リフレッシュトークンがありません")

    if creds.get("refresh_pending"):
        # 前回の更新が、結果を確認できないまま終わっている(応答が壊れていた・
        # 途中でプロセスが落ちた等)。PayPayが既に入れ替えていた場合、同じものを
        # 投げ直した瞬間にセッションごと失効する。使わないほうが確実に損が小さい。
        raise RefreshUnsafeError(
            "前回のトークン更新の結果が確認できていないため、このリフレッシュトークンは使いません")

    last_err = None
    for i in range(max(1, attempts)):
        pp = _client(
            access_token=creds["access_token"],
            device_uuid=creds.get("device_uuid"),
            client_uuid=creds.get("client_uuid"),
        )
        _use_form_content_type(pp)
        try:
            pp.token_refresh(creds["refresh_token"])
        except PayPayLoginError as e:
            # リフレッシュトークン自体が失効。リトライしても無駄。
            journal("revoked", detail=str(e.args[0] if e.args else e)[:200])
            raise TokenExpiredError(e.args[0] if e.args else str(e))
        except requests.exceptions.ConnectionError as e:
            # PayPayに届いていないので、同じトークンで投げ直しても二重使用にならない
            last_err = e
            if i < attempts - 1:
                time.sleep(2 ** i)
            continue
        except PayPayError as e:
            # PayPayがヘッダ付きで「失敗」を返した = 新しいトークンは発行されて
            # いない。このリフレッシュトークンは未使用のままなので温存する。
            journal("refresh_failed", detail=str(e.args[0] if e.args else e)[:200])
            raise RefreshFailedError(e)
        except (PayPayNetWorkError, OSError, ValueError) as e:
            # 応答が壊れている / 読めない → 入れ替わったかどうか分からない
            journal("refresh_unknown", detail=str(e)[:200], token=_tail(creds["refresh_token"]))
            raise RefreshUnsafeError(e)
        except Exception as e:
            # 応答の形が想定と違って読めなかった(payload に想定のキーが無い等)。
            # 新しいアクセストークンが手元に載っていれば、PayPay は更新を受け付けて
            # いる(=古いリフレッシュトークンは使用済み)。それを保存せずに捨てると、
            # 次の更新で使用済みのトークンを投げ直して使い回しとみなされ、
            # セッションごと失効(S1003)する。取れた分だけ必ず拾って保存する。
            salvaged = _salvage_rotated(creds, pp)
            if salvaged is None:
                journal("refresh_unknown", detail=str(e)[:200], token=_tail(creds["refresh_token"]))
                raise RefreshUnsafeError(e)
            journal("refresh_salvaged", token=_tail(creds["refresh_token"]),
                    new_token=_tail(salvaged.get("refresh_token")))
            return salvaged

        new = dict(creds)
        new["access_token"] = pp.access_token
        new["refresh_token"] = pp.refresh_token
        new["refreshed_at"] = time.time()
        journal("refresh_ok", token=_tail(creds["refresh_token"]), new_token=_tail(new["refresh_token"]))
        return new

    journal("refresh_failed", detail=f"接続できませんでした: {last_err}"[:200])
    raise RefreshFailedError(last_err)


def _is_stale(creds: dict, hours: float = STALE_AFTER_HOURS) -> bool:
    """最後の更新から hours 時間以上経っていれば True。"""
    last = creds.get("refreshed_at") or creds.get("logged_in_at") or 0
    return (time.time() - float(last)) >= hours * 3600


# トークン更新の同時実行を防ぐ。定期更新・決済直前の更新・生存確認からの復帰が
# 重なると、同じリフレッシュトークンを2回使ってしまい PayPay 側で使い回しと
# みなされてセッションごと失効する。
_refresh_lock = asyncio.Lock()


def _refreshed_at(creds: dict) -> float:
    return float(creds.get("refreshed_at") or creds.get("logged_in_at") or 0)


REFRESH_LOCK_FILE = data_path("paypay_refresh.lock")
FILE_LOCK_TIMEOUT = 60


def _refresh_guarded(held: float) -> dict:
    """ファイルロックの中でトークンを更新する(同期・スレッドで動かす)。

    ロックを取れた時点でディスクを読み直し、待っている間に別のプロセスや
    別経路が更新していたら、そのトークンをそのまま使う。

    更新に出る前に「今このトークンを使っている」印をディスクに残す。応答を
    受け取る前にプロセスが落ちても、印が残っていれば次回そのトークンを投げ直さずに
    済む(投げ直すとセッションごと失効する)。結果が確定したら印は消す。
    """
    try:
        with cross_process_lock(REFRESH_LOCK_FILE, FILE_LOCK_TIMEOUT):
            data = load_paypay_data()
            key, current = _resolve_owner(data)
            if not current:
                raise NotRegisteredError("PayPay アカウントが登録されていません")
            if _refreshed_at(current) > held:
                # 待っている間に誰かが更新済み。古いトークンは投げ直さない。
                return current

            if current.get("refresh_token") and not current.get("refresh_pending"):
                _save_creds(key, dict(current, refresh_pending={
                    "at": time.time(), "token": _tail(current.get("refresh_token"))}))

            try:
                new_creds = _refresh_sync(current)
            except RefreshUnsafeError:
                # 使ったかどうか分からない → 印を残したまま(=二度と使わない)
                raise
            except Exception:
                # 使われていないと確定した(PayPayが失敗を返した / 届かなかった)
                _save_creds(key, current)
                raise

            new_creds.pop("refresh_pending", None)
            _save_creds(key, new_creds)
            return new_creds
    except LockTimeout as e:
        raise RefreshFailedError(e)


async def _refresh_locked(creds: dict) -> dict:
    """ロックを取ってトークンを更新し、新しい認証情報を返す。

    プロセス内(asyncio.Lock)とプロセス間(ファイルロック)の二段構えで、
    同じリフレッシュトークンが二度使われないようにする。
    """
    held = _refreshed_at(creds)
    async with _refresh_lock:
        return await asyncio.to_thread(_refresh_guarded, held)


async def refresh_tokens(force: bool = False) -> dict:
    """共有アカウントのトークンを更新して保存する。

    force=False なら STALE_AFTER_HOURS 未満の場合は何もしない。
    戻り値: {"refreshed": bool, "refreshed_at": float}
    失効時は TokenExpiredError、一時失敗は RefreshFailedError。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("PayPay アカウントが登録されていません")
    if not force and not _is_stale(creds):
        return {"refreshed": False, "refreshed_at": creds.get("refreshed_at")}

    new_creds = await _refresh_locked(creds)
    return {
        "refreshed": _refreshed_at(new_creds) > _refreshed_at(creds),
        "refreshed_at": new_creds.get("refreshed_at"),
    }


# ---- 自動再ログイン(端末UUIDでの入り直し) ----

# 一度断られた後、次に自動ログインを試すまでの間隔。生存確認は1時間前後で回るので、
# 間隔を置かないとパスワード誤りのまま延々とサインインを叩き続けることになり、
# PayPay側でアカウントを止められかねない。断られた理由は人が直すしかないので、
# ここは長めに空ける(人が押す再ログインボタンからは待たずに試せる)。
RELOGIN_RETRY_HOURS = 6

_relogin_lock = asyncio.Lock()


def _relogin_guarded(held: float, force: bool = False) -> dict:
    """ファイルロックの中で端末UUIDでのログインをやり直す(同期・スレッドで動かす)。

    ロックを取れた時点でディスクを読み直し、待っている間に別のプロセスや別経路が
    入り直していたら、そのトークンをそのまま使う。トークン更新と同じロックを使う
    ので、更新と再ログインが同時に走ることもない。
    """
    try:
        with cross_process_lock(REFRESH_LOCK_FILE, FILE_LOCK_TIMEOUT):
            data = load_paypay_data()
            key, current = _resolve_owner(data)
            if not current:
                raise NotRegisteredError("PayPay アカウントが登録されていません")
            if _refreshed_at(current) > held:
                # 待っている間に誰かが直していた
                return current

            denied_at = float(current.get("relogin_denied_at") or 0)
            if not force and denied_at and (time.time() - denied_at) < RELOGIN_RETRY_HOURS * 3600:
                raise ReloginUnavailableError(
                    f"自動ログインが断られたばかりなので、{RELOGIN_RETRY_HOURS}時間は試し直しません"
                    "（同じ資格情報で叩き続けるとPayPay側で止められるため）")

            try:
                pp = _device_login_sync(current.get("phone"), current.get("password"),
                                        current.get("device_uuid"), current.get("client_uuid"))
            except ReloginUnavailableError as e:
                # 断られた記録を残して、しばらく試し直さないようにする
                _save_creds(key, dict(current, relogin_denied_at=time.time()))
                journal("relogin_denied", detail=str(e)[:200])
                raise
            now = time.time()
            new = dict(current)
            new["access_token"] = pp.access_token
            new["refresh_token"] = pp.refresh_token
            new["client_uuid"] = pp.client_uuid
            new["device_uuid"] = pp.device_uuid
            new["logged_in_at"] = now
            new["refreshed_at"] = now
            # 新しいセッションなので、古いリフレッシュトークンに付いていた
            # 「結果不明」の印は無効になる(残すと次の更新が永久に止まる)。
            new.pop("refresh_pending", None)
            new.pop("relogin_denied_at", None)
            _save_creds(key, new)
            journal("relogin", token=_tail(pp.refresh_token))
            return new
    except LockTimeout as e:
        raise ReloginFailedError(e)


async def _relogin_locked(creds: dict, force: bool = False) -> dict:
    """ロックを取って端末UUIDでログインし直し、新しい認証情報を返す。"""
    held = _refreshed_at(creds)
    async with _relogin_lock:
        return await asyncio.to_thread(_relogin_guarded, held, force)


async def _recover(creds: dict) -> dict:
    """使えなくなったセッションを、できるところまで自動で立て直す。

    1) リフレッシュトークンで更新する
    2) それが失効・使用不可なら、保存済みの端末UUIDでログインし直す

    PayPayは1アカウント1端末なので、スマホのアプリで同じアカウントに入られると
    Bot側は必ず切られる。そのたびに人がSMSのURLを貼り直すのは現実的ではないので、
    覚えられている端末で入り直すところまでBotがやる。
    どちらもできないときだけ TokenExpiredError(SMS認証からの再登録が必要)。
    """
    try:
        return await _refresh_locked(creds)
    except (TokenExpiredError, RefreshUnsafeError) as e:
        reason = e
    # 更新では戻せない。端末UUIDで入り直す(SMS認証は要らない)。
    try:
        return await _relogin_locked(creds)
    except ReloginUnavailableError as e:
        journal("relogin_unavailable", detail=str(e)[:200])
        raise TokenExpiredError(reason.args[0] if reason.args else str(reason))


async def recover_session() -> dict:
    """切れた(または更新できない)セッションを自動で立て直す。

    戻り値: {"how": "refreshed"|"relogged", "refreshed_at": float}
    人手が要るときは TokenExpiredError、一時的な失敗は RefreshFailedError。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("PayPay アカウントが登録されていません")

    new_creds = await _recover(creds)
    relogged = float(new_creds.get("logged_in_at") or 0) > float(creds.get("logged_in_at") or 0)
    return {
        "how": "relogged" if relogged else "refreshed",
        "refreshed_at": new_creds.get("refreshed_at"),
    }


async def relogin(force: bool = False) -> dict:
    """保存済みの端末UUIDでログインし直す(SMS認証なし)。

    force=True で、直前に断られていても試し直す(人が操作したときだけ使う)。
    戻り値: {"relogged": bool, "refreshed_at": float}
    端末を忘れられていれば ReloginUnavailableError、一時的な失敗は ReloginFailedError。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("PayPay アカウントが登録されていません")

    new_creds = await _relogin_locked(creds, force)
    return {
        "relogged": _refreshed_at(new_creds) > _refreshed_at(creds),
        "refreshed_at": new_creds.get("refreshed_at"),
    }


async def keep_alive() -> bool:
    """PayPayアプリを開いたのと同じリクエストを投げてセッションを維持・確認する。

    トークンを更新しない(リフレッシュトークンを消費しない)ので、短い間隔で
    呼んでも失効リスクは増えない。放置されたセッションはPayPay側で切られる
    ため、これを回し続けること自体が延命になる。

    alive() が叩くサービス状態の取得はログインが要らず、セッションが切れていても
    S0000 が返る。それだけを見ると、残高も取れない(=受取もできない)状態を
    ずっと「生きている」と読んでしまう。ログインが必要な取得まで通して初めて
    生存とみなす。

    戻り値: True=生存 / False=通信エラーなどで判定できず。
    アクセストークンが無効なら PayPayLoginError(呼び出し側でトークン更新を試す)。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("PayPay アカウントが登録されていません")

    def _do():
        pp = _client(
            access_token=creds["access_token"],
            device_uuid=creds.get("device_uuid"),
            client_uuid=creds.get("client_uuid"),
        )
        pp.alive()
        # ログインが要る取得(プロフィール)まで通るかどうかで、アクセストークンが
        # 本当に生きているかを確かめる。切れていれば S0001 → PayPayLoginError。
        pp.get_profile()

    try:
        await asyncio.to_thread(_do)
        return True
    except PayPayLoginError:
        journal("access_token_dead")
        raise
    except (PayPayError, PayPayNetWorkError, OSError, ValueError):
        # 通信断・WAF・PayPay側の一時エラー。切れたとは判断しない。
        return False


def owner_login_info():
    """保存済みの電話番号・パスワードを返す(再ログイン用)。無ければ (None, None)。"""
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return None, None
    return creds.get("phone"), creds.get("password")


def token_status() -> dict:
    """現在のPayPayセッション状態(登録有無・最終ログイン/更新時刻)を返す。"""
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return {"registered": False}
    return {
        "registered": True,
        "phone": creds.get("phone"),
        "logged_in_at": creds.get("logged_in_at"),
        "refreshed_at": creds.get("refreshed_at"),
        "has_refresh_token": bool(creds.get("refresh_token")),
        # 前回の更新の結果が確認できていない = このトークンはもう使えない
        "refresh_unsafe": bool(creds.get("refresh_pending")),
        # 切られてもBotだけで入り直せるか(電話番号・パスワード・端末UUIDが揃っているか)
        "can_relogin": bool(creds.get("phone") and creds.get("password")
                            and creds.get("device_uuid")),
        # 直近で自動ログインを断られている(人手での再ログインが要る)
        "relogin_denied_at": creds.get("relogin_denied_at"),
        "stale": _is_stale(creds),
        # 送金系を通す経路。データセンターIP直結だと送金だけ弾かれやすい。
        "proxied": bool(_proxy()),
    }


async def receive_payment(owner_id=None, url: str = None, passcode: str = None, min_amount: int = None,
                          on_pending=None, wait_seconds: int = PENDING_WAIT_SECONDS,
                          poll_interval: int = POLL_INTERVAL_START, state: dict = None,
                          screen=None) -> int:
    """登録済みの共有PayPayアカウントで PayPay リンクを受け取り、受取金額を返す。

    すぐに決着しない(保留・承認待ち)場合は on_pending(deadline) を1回だけ呼び、
    wait_seconds まで確認を続けて、承認され次第受け取って金額を返す。
    deadline は承認期限の UNIX 時刻(float)で、待ち時間の表示に使う。

    投げる例外:
      LinkRejected     … そのリンクでは受け取れない(お金は動いていない)
      LinkAlreadyTaken … すでに受け取られていた(こちらが受け取った可能性あり)
      ReceiveUnsure    … 投げたが結果を確認できない(入金の可能性あり)
      PendingTimeout   … 待ち時間内に決着しなかった。**.accepted が True なら
                          受け取りは投げてある = あとから入金する可能性がある**
      NotRegisteredError / TokenExpiredError / PayPayError … 受け取り以前の失敗

    state を渡すと state["accepted"] に「受け取りを投げたか」が残る。
    これが True の注文は捨ててはいけない。捨てると残高だけ増えて何も渡らない。

    screen(info) を渡すと、受け取りを投げる直前(送金元が分かっていて、まだ
    お金が動いていない時点)で呼ばれる。文字列を返すとその回は受け取らずに
    LinkRejected になる。安全確認はここに挟む。
    """
    state = state if state is not None else {}
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("受取先の PayPay アカウントが登録されていません")

    # ここで先回りして更新はしない。アクセストークンは長寿命なので受取のたびに
    # 回す意味がなく、買われるたびに失効の機会を増やすだけになる。実際に切れて
    # いれば下の PayPayLoginError で拾って更新し、受け取り直す。

    deadline = time.time() + max(0, wait_seconds)
    notified = False
    refreshes = 0
    held = False
    reposts = 0          # 保留に入った後で投げ直した回数
    next_repost = 0.0    # 次に投げ直してよい時刻
    wait = max(1, poll_interval)
    last_history = 0.0   # 最後に入金履歴を見た時刻
    while True:
        # 保留に入った後は毎回は投げない。投げるたびに送金者のアプリへ承認の
        # 催促が出るので、乱発するとキャンセルを選ばれる。かといって投げないままだと、
        # 承認されてもこちらが投げ直すまで入らない場合に画面が完了できない。
        # 間隔を空けて数回だけ投げ直す。
        accept = True
        if held:
            accept = reposts < HELD_RETRY_LIMIT and time.time() >= next_repost
        try:
            out = await asyncio.to_thread(_attempt, creds, url, passcode, min_amount,
                                          bool(state.get("accepted")), accept,
                                          screen)
        except TokenExpiredError:
            raise
        except PayPayLoginError:
            # 受け取りを投げる前に切れていた。立て直して同じ回をやり直す。
            if refreshes >= 2:
                raise
            refreshes += 1
            try:
                # 更新 → ダメなら端末UUIDでの再ログイン、の順に自動で立て直す
                creds = await _recover(creds)
            except RefreshFailedError:
                raise PayPayError(
                    "PayPayとの通信が不安定でトークンを更新できませんでした。"
                    "少し時間をおいてからもう一度お試しください。")
            continue

        # 投げた事実は何よりも先に残す。以降どう転んでも呼び出し側がこれを見て
        # 「捨ててはいけない注文」だと分かるようにする。
        if out.accepted:
            state["accepted"] = True
        if out.attempted:
            # 入金履歴で確かめるときの手掛かり(金額・送り主・投げた時刻)を残す
            if out.amount:
                state["amount"] = int(out.amount)
            if out.sender:
                state["sender"] = out.sender
            if out.posted_at and not state.get("posted_at"):
                state["posted_at"] = float(out.posted_at)
        if held and out.attempted:
            # 保留に入ってから投げ直した。次はもっと間隔を空ける(催促を減らす)。
            reposts += 1
            next_repost = time.time() + min(
                HELD_RETRY_SECONDS * HELD_RETRY_BACKOFF ** (reposts - 1),
                HELD_RETRY_MAX_SECONDS)
        if out.attempted and out.detail:
            # 弾かれた理由を呼び出し側へ渡す。ここで落とすと、管理者には
            # 「受け取れなかった」しか届かず、原因が分からないまま同じことが
            # 繰り返される。
            state["reject_detail"] = out.detail

        if out.state == RECEIVED:
            return int(out.amount)
        if out.state == TAKEN:
            raise LinkAlreadyTaken(out.detail or "すでに受け取り済みのリンクです")
        if out.state == UNSURE:
            raise ReceiveUnsure(out.detail)
        if out.state == GONE:
            rejected = LinkRejected(out.detail or "このリンクでは受け取れません")
            # こちら側の都合で断ったのか(受取口の設定)を呼び出し側へ渡す。
            # お客さんには直せないので、管理者に知らせる必要がある。
            rejected.blocked = bool(out.blocked)
            raise rejected
        if out.state == HELD and not held:
            # ここからは保留。次に投げ直してよい時刻を決めて、それまでは
            # 状態を見るだけにする。
            held = True
            state["held"] = True     # 呼び出し側の通知の文面(保留なのか断られたのか)に使う
            next_repost = time.time() + HELD_RETRY_SECONDS

        if (state.get("accepted") and out.unreadable
                and time.time() - last_history >= HISTORY_RECHECK_SECONDS):
            # 受け取りを投げた後にリンクが読めなくなった。受け取り済みのリンクはこう
            # 見えることがあるので、入金履歴で確かめる。載っていれば、それがこの受け取り。
            # ここで拾わないと、入っているのに期限まで待たせた末に見張りへ回ることになる。
            last_history = time.time()
            try:
                landed = await asyncio.to_thread(_deposit_landed, creds, state)
            except Exception as e:
                landed = False
                print(f"[PAYPAY] 入金履歴の確認に失敗しました: {_detail(e)}", flush=True)
            if landed:
                print(f"[PAYPAY] リンクは読めませんでしたが、入金履歴で受け取りを確認しました"
                      f" url={url}", flush=True)
                return int(state["amount"])

        # PENDING / HELD … まだ決着していない。案内は1回だけ出して期限まで待つ。
        if on_pending and not notified:
            notified = True
            try:
                await on_pending(deadline)
            except Exception:
                pass
        if time.time() >= deadline:
            raise PendingTimeout(accepted=bool(state.get("accepted")))

        # 期限までは必ずもう一度確認する。間隔は少しずつ伸ばしつつ毎回ゆらがせる。
        remaining = deadline - time.time()
        await asyncio.sleep(max(1.0, min(wait * random.uniform(0.85, 1.15), remaining)))
        wait = min(wait * POLL_BACKOFF, POLL_INTERVAL_MAX)


# 見張り(link_orders)から使う1回分の受け取り。支払い画面が閉じた後でも、
# 承認され次第きちんと受け取って商品を渡せるようにするための入口。


def _flat(node, limit: int = 12) -> str:
    """入れ子を「キー=値」の一行にする(診断で中身をそのまま見せるため)。

    どこかに承認待ちを表す項目があるなら、まず目で見つけられるようにする。
    要約すると、探しているものが落ちる。
    """
    if not isinstance(node, dict):
        return ""
    parts = []
    for key, value in list(node.items())[:limit]:
        if isinstance(value, dict):
            parts.append(f"{key}{{{','.join(list(value)[:6])}}}")
        elif isinstance(value, list):
            parts.append(f"{key}[{len(value)}]")
        else:
            parts.append(f"{key}={value}")
    return " / ".join(parts)


def _diagnose_sync(creds: dict, url: str, passcode) -> dict:
    """受け取りを1回だけ試して、PayPayが返したものをそのまま持ち帰る。

    保留の待ちも投げ直しもしない。人が原因を見るための入口なので、握りつぶさず
    生の例外(error)を入れて返す。呼び出し側が _paypay_err で開く。
    """
    report = {"proxied": bool(_proxy()), "url": url}
    pp = _client(access_token=creds["access_token"],
                 device_uuid=creds.get("device_uuid"),
                 client_uuid=creds.get("client_uuid"))
    try:
        bal = pp.get_balance()
        report["balance"] = bal.all_balance
        report["money_light"] = bal.money_light
        report["wallet"] = emoney_wallet_state(bal)
    except Exception as e:
        report["balance_error"] = _detail(e)

    try:
        info = pp.link_check(url)
    except Exception as e:
        report.update(stage="link_check", error=e)
        return report

    report.update(
        amount=int(info.amount or 0),
        link_emoney=int(getattr(info, "money", 0) or 0),
        link_light=int(getattr(info, "money_light", 0) or 0),
        has_password=bool(info.has_password),
        sender=getattr(info, "sender_name", "") or "",
        # 自分で送ったリンクは自分で受け取れない。これに気づかないと、
        # 断られたコードを本来の原因だと読み違える。
        self_link=is_self_link(pp, info),
        status=(info.raw.get("payload") or {}).get("orderStatus"),
        # PayPayはリンクの状態を2か所で返す。こちらの判定に使っているのは
        # orderStatus だけで、message.data.status のほうは一度も見ていない。
        # 承認待ちのような状態がどこかに出るとしたらこちらなので、中身を
        # そのまま並べて、目で確かめられるようにする。
        message_status=getattr(info, "status", None),
        pending_info=_flat((info.raw.get("payload") or {}).get("pendingP2PInfo")),
        message_data=_flat((((info.raw.get("payload") or {}).get("message")
                             or {}).get("data"))))
    if _classify(report["status"]) != PENDING:
        report["stage"] = "status"
        return report

    try:
        pp.link_receive(url, passcode=passcode, link_info=info.raw)
        report["stage"] = "received"
    except Exception as e:
        report.update(stage="receive", error=e)

    # 投げた後の状態。差し戻されたのか、保留のままなのかはここに出る。
    time.sleep(CONFIRM_INTERVAL)
    report["after"] = _read_status(pp, url)[1]
    return report


async def diagnose_link(url: str, *, passcode: str = None) -> dict:
    """受け取りが通らない原因を、その場で1回試して確かめる。"""
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("受取先の PayPay アカウントが登録されていません")
    return await asyncio.to_thread(_diagnose_sync, creds, url, passcode)


async def collect_link(url: str, *, passcode: str = None, min_amount: int = None,
                       accepted_before: bool = False, accept: bool = True) -> Outcome:
    """リンクを1回だけ見て、受け取れる状態なら受け取る(見張り用)。

    例外は投げず、必ず Outcome を返す。見張りループを例外で止めないため。
    accepted_before に「過去に受け取りを投げたか」を渡すと、受取済みのリンクを
    この注文の入金として扱う(投げていないなら TAKEN にして管理者に確認させる)。
    accept=False なら受け取りは投げず、状態の確認だけを行う。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        return Outcome(ERROR, accepted=accepted_before,
                       detail="受取先のPayPayアカウントが登録されていません")

    for attempt in range(2):
        try:
            return await asyncio.to_thread(_attempt, creds, url, passcode, min_amount,
                                           accepted_before, accept)
        except PayPayLoginError as e:
            if attempt == 0:
                try:
                    creds = await _recover(creds)
                    continue
                except Exception:
                    pass
            return Outcome(ERROR, accepted=accepted_before,
                           detail=f"ログインが切れています: {_detail(e)}")
        except Exception as e:
            return Outcome(ERROR, accepted=accepted_before, detail=_detail(e))
    return Outcome(ERROR, accepted=accepted_before, detail="受け取りを確認できませんでした")


# ---- 共有アカウントでの各種操作(残高/プロフィール/リンク作成など) ----

def _op_sync(creds: dict, op):
    pp = _client(
        access_token=creds["access_token"],
        device_uuid=creds.get("device_uuid"),
        client_uuid=creds.get("client_uuid"),
    )
    return op(pp)


async def run_owner_op(op):
    """登録済みの共有PayPayアカウントで op(pp) を実行する。

    op は同期の PayPay メソッドを呼ぶ関数(例: lambda pp: pp.get_balance())。
    トークン切れは refresh_token で自動更新して一度だけ再試行。未登録は NotRegisteredError。
    """
    data = load_paypay_data()
    key, creds = _resolve_owner(data)
    if not creds:
        raise NotRegisteredError("PayPay アカウントが登録されていません")
    try:
        return await asyncio.to_thread(_op_sync, creds, op)
    except TokenExpiredError:
        raise
    except PayPayLoginError:
        try:
            # 更新 → ダメなら端末UUIDでの再ログイン、の順に自動で立て直す
            new_creds = await _recover(creds)
        except RefreshFailedError:
            raise PayPayError(
                "PayPayとの通信が不安定でトークンを更新できませんでした。"
                "少し時間をおいてからもう一度お試しください。")
        return await asyncio.to_thread(_op_sync, new_creds, op)


def signout_owner() -> bool:
    """登録済みPayPayアカウントの情報を削除(サインアウト)する。"""
    data = load_paypay_data()
    removed = False
    for k in list(data.keys()):
        if k == OWNER_KEY or (isinstance(data.get(k), dict) and data[k].get("access_token")):
            del data[k]
            removed = True
    if removed:
        save_paypay_data(data)
    return removed
