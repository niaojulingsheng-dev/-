"""支払い方法(PayPay / Kyash)をひとつの入口にまとめる層。

代行(main.py)と自販機(Cogs/shop.py)は、どちらもここだけを見れば支払いを
扱えるようにする。値段は円のまま共通で、方法による上乗せは一切しない。

支払いはリンク方式(PayPay / Kyash) … お客さんが送金リンクを貼り、その場で受け取り確定。
"""
import asyncio
import logging
import re
import time
from typing import NamedTuple

import discord
from discord import ui

import kyash_async
import paypay_async
import risk
import support
from utils import ADMIN_USER_IDS
from kyash_mobile import KyashError, KyashLoginError, KyashNetWorkError
from kyash_mobile import error_message as kyash_error_message
from paypay_mobile import PayPayError, PayPayLoginError, PayPayNetWorkError

log = logging.getLogger(__name__)

PAYPAY = "paypay"
KYASH = "kyash"
# 0円商品・無料利用券。支払いそのものが発生しないので選択肢には出さない。
FREE = "free"

LINK_KIND = "link"
NO_PAYMENT_KIND = "none"


class Method(NamedTuple):
    id: str
    label: str
    emoji: str
    kind: str
    placeholder: str      # リンク入力欄のプレースホルダ
    hint: str             # 支払い方法を選ぶときの説明


METHODS = {
    PAYPAY: Method(PAYPAY, "PayPay", "<:PayPay:1548718125594185892>", LINK_KIND,
                   "https://pay.paypay.ne.jp/...", "送金リンクを貼る"),
    KYASH: Method(KYASH, "Kyash", "<:Kyash:1548718147807215646>", LINK_KIND,
                  "https://kyash.me/payments/...", "送金リンクを貼る"),
    FREE: Method(FREE, "無料", "🎁", NO_PAYMENT_KIND, "", ""),
}

# 支払い方法の選択画面に出す順番(無料は選ばせるものではないので入れない)
ORDER = (PAYPAY, KYASH)


def _down_text(label: str, reason: str = "受け取りの準備ができていません") -> str:
    """支払い口が使えないことを、お客さんの言葉で伝える。

    原因はこちら側にあり、お客さんにできることは無い。「管理者に連絡して」と
    だけ書くとDMが飛んでくるので、行き先はチケットに寄せる。
    """
    return (f"ただいま**{label}でのお支払いをご利用いただけません**（運営側の{reason}）。\n"
            "**お代はいただいていません。** 他の支払い方法をお試しいただくか、"
            + support.contact_line())


class PaymentError(Exception):
    """支払いを確認できなかった(お客さんに見せる文言を持つ)。

    watchable … このリンクを後追いで見張る意味があるか(承認待ち・一時的な不調)。
    accepted  … 受け取りのリクエストを投げた後か(入金済みの可能性がある)。
    どちらも購入側が「注文を捨てるか、見張りに引き継ぐか」を決めるのに使う。
    """
    watchable = False
    accepted = False


class PaymentNotRegistered(PaymentError):
    """運営側の受取アカウントが未登録・未設定。"""


class PaymentAuthError(PaymentError):
    """運営側のログインが切れている。"""


class PaymentRejected(PaymentError):
    """そのリンクではもう受け取れない(金額不足・受取済み・キャンセル済みなど)。

    待っても変わらないので見張りには回さない。
    """


class PaymentPending(PaymentError):
    """保留(承認待ち)のまま待ち時間が終わった。入金はまだ発生していない。

    お客さんが後から承認することは珍しくない。ここで注文を捨てると、承認された
    お金だけがこちらに入って商品が渡らない事故になるため、見張りへ引き継ぐ。
    """
    watchable = True


class PaymentUnsure(PaymentError):
    """受け取れたかどうか確認できなかった(入金済みの可能性がある)。

    受け取りのリクエストは投げた時点でお金が動く。応答が読めなかっただけの
    ときは「失敗」と言い切れないので、お客さんを二重払いさせないよう別扱いに
    して、管理者に確認してもらう。
    """
    watchable = True
    accepted = True


def method(method_id: str) -> Method:
    return METHODS.get(method_id) or METHODS[PAYPAY]


def method_label(method_id: str) -> str:
    return method(method_id).label


FREE_TICKET_LABEL = "無料利用券"
# 管理者が動作確認するための「全商品0円」。お客さんの購入と混ざらないよう、
# ログにはこの名前で残す(売上には入れない)。代行・ツムツムで同じ名前を使う。
ADMIN_FREE_LABEL = "管理者テスト(0円)"


def is_available(method_id: str) -> bool:
    """その支払い方法が今すぐ使えるか(受取先が登録・設定済みか)。"""
    try:
        if method_id == PAYPAY:
            return bool(paypay_async.token_status().get("registered"))
        if method_id == KYASH:
            return kyash_async.is_registered()
    except Exception:
        return False
    return False


def available_methods() -> list:
    return [METHODS[m] for m in ORDER if is_available(m)]


# 取り違え検出用: その支払い方法で「出てきてはいけない」相手側の名前
_OTHER_SERVICE = {PAYPAY: "kyash", KYASH: "paypay"}


# PayPayの送金リンクは https://pay.paypay.ne.jp/<受け取りコード> の形。
# 受け取りコードは英数字のランダム(実物の例: pGVDLMVxiULvpZ8z = 16文字)で、
# パスはコード1つだけ。お客さんは「[PayPay] 受け取りリンクが届きました……」と
# 案内文ごと貼ってくるので、文中からでも拾えるようにする。
#
# ここは送金リンクの形「だけ」を厳密に通す。形の違うもの(請求リンク・
# qr.paypay.ne.jp のQR・ただの文字列)をコード扱いで受け取りに行くと、
# 不明なエラーで落ちて「保留(承認待ち)」として見張りに載ってしまい、
# お客さんは決着しない注文を待たされ、自販機は在庫を取り置いたままになる。
#   ・ドメインの直前に英数字等を許さない(似せたサブドメインを弾く)
#   ・コードの直後に / や英数字を許さない(深いパス・長すぎる列を弾く)
#   ・長さは12〜24(実物は16。形式が多少変わっても拾えるだけの幅)
_PAYPAY_SEND_LINK = re.compile(
    r"(?<![0-9A-Za-z.-])pay\.paypay\.ne\.jp/([0-9A-Za-z]{12,24})(?![0-9A-Za-z/])",
    re.IGNORECASE)
# 受け取りコードだけを貼られた場合。
_PAYPAY_CODE_ONLY = re.compile(r"^[0-9A-Za-z]{12,24}$")


def _looks_like_paypay_code(code: str) -> bool:
    """受け取りコードらしいランダムさがあるか。

    実物のコードは大文字・小文字・数字の混ざったランダム。長さが合うだけの
    単語(「yoroshiku」など)や数字だけの列(注文番号など)をコード扱いすると、
    でたらめなコードで受け取りに行って不明なエラー → 保留、になる。
    「数字を含む、または大文字と小文字が混ざる」英字入りだけを通すと、
    単語はほぼ全部落ち、本物のランダムなコードを誤って弾く確率は
    16文字なら約100万分の1しかない。
    """
    has_digit = any(c.isdigit() for c in code)
    has_upper = any(c.isupper() for c in code)
    has_lower = any(c.islower() for c in code)
    return (has_upper or has_lower) and (has_digit or (has_upper and has_lower))


def paypay_send_code(text: str) -> str:
    """貼られた文字列からPayPayの送金リンクの受け取りコードを取り出す。

    取り出せなければ空文字。案内文ごと貼られても拾える一方で、送金リンクの
    形をしていないもの(請求リンク・QR・単語や番号)は一切拾わない。ここで
    弾いたぶんは受け取りに行かないので、お代は動かず、保留にも載らない。
    """
    text = (text or "").strip()
    if not text:
        return ""
    found = _PAYPAY_SEND_LINK.search(text)
    if found:
        code = found.group(1)
        return code if _looks_like_paypay_code(code) else ""
    # URLの体裁が無いものは、コードそのものらしいときだけ通す。
    if "/" not in text and _PAYPAY_CODE_ONLY.match(text) \
            and _looks_like_paypay_code(text):
        return text
    return ""


# Kyashの送金リンク(前後に案内文やスペースが付いていても本体だけ拾う)。
_KYASH_LINK = re.compile(r"(?:https?://)?kyash\.me/payments/([0-9A-Za-z]+)", re.IGNORECASE)
_KYASH_SCHEME = re.compile(r"kyash://\S+", re.IGNORECASE)


def kyash_link_code(text: str) -> str:
    """貼られた文字列からKyashの送金リンク(正規のURL)を取り出す。無ければ空文字。

    コードだけ・ID だけを貼られたときは、それ自体がリンクなのでそのまま返す。"""
    text = (text or "").strip()
    if not text:
        return ""
    found = _KYASH_LINK.search(text)
    if found:
        return f"https://kyash.me/payments/{found.group(1)}"
    scheme = _KYASH_SCHEME.search(text)
    if scheme:
        return scheme.group(0)
    # 区切りの無い1語ならコード/IDとして通す(looks_like_link と同じ扱い)。
    if "/" not in text and not re.search(r"\s", text):
        return text
    return ""


def clean_link(method_id: str, text: str) -> str:
    """貼られた文字列から、その支払い方法の送金リンクだけを取り出して正規の形で返す。

    共有・コピーで前後に付く案内文(「[PayPay] ポチ袋が届きました…」等)やスペース・
    改行が入っていても、リンク本体だけにする。これをしないと、余分な文字ごと
    受け取りコードとしてPayPay/Kyashへ送ってしまい、でたらめなコードでの受け取りに
    なって保留・エラーになる(毎回手で貼り直す羽目になっていた)。

    取り出せなければ元の文字列(strip のみ)を返し、受け取れるかは looks_like_link が
    判定する(お代は動かない)。"""
    text = (text or "").strip()
    if method_id == PAYPAY:
        code = paypay_send_code(text)
        return f"https://pay.paypay.ne.jp/{code}" if code else text
    if method_id == KYASH:
        return kyash_link_code(text) or text
    return text


def looks_like_link(method_id: str, url: str) -> bool:
    """貼られたリンクがその支払い方法のものらしいか(取り違えを早めに弾く)。

    PayPayは形まで見る。請求リンク(「送ってもらう」で作るリンク)を貼られると
    PayPayは受け取りを断るが、こちらからは通信不良と見分けが付かないので、
    投げてしまうと「保留(承認待ち)」として見張りに載る。お客さんは承認の
    案内を見せられたまま、いつまでも決着しない注文を待つことになる。
    受け取れない形はここで返す(お代は動いていない)。

    Kyashはコード/IDだけでも受け取れるので、区切りの無い文字列は通す。
    """
    text = (url or "").strip()
    if not text or _OTHER_SERVICE.get(method_id, "\0") in text.lower():
        return False
    if method_id == PAYPAY:
        return bool(paypay_send_code(text))
    if method_id == KYASH:
        low = text.lower()
        if "/" not in low:      # コード・IDだけを貼った場合
            return True
        return "kyash.me" in low or low.startswith("kyash://")
    return True


def _bad_link_text(method_id: str) -> str:
    """受け取れない形のリンクを貼られたときの文言。

    呼び出し側がコードブロックに入れて出すので、装飾は付けない。
    """
    m = method(method_id)
    if method_id == PAYPAY:
        return ("PayPayの送金リンクではないようです。"
                f"{m.placeholder} の形式で貼ってください。"
                "（PayPayアプリの「送る」で作ったリンクです。"
                "「送ってもらう」で作る請求リンクでは受け取れません）")
    return f"{m.label}のリンクではないようです。{m.placeholder} の形式で貼ってください。"


def error_text(e: Exception, limit: int = 300) -> str:
    """決済ライブラリの例外から、そのまま見せられる文言を作る。"""
    raw = e.args[0] if getattr(e, "args", None) else str(e)
    if isinstance(raw, dict):
        header = raw.get("header") or {}
        payload = raw.get("payload") or {}
        msg = (payload.get("message") if isinstance(payload.get("message"), str) else None) \
            or header.get("resultMessage") or header.get("resultCode")
        if msg:
            return str(msg)[:limit]
        return kyash_error_message(e, limit)
    return str(raw)[:limit]


# ---- 受取先が死んでいるときの通知 ----

# 同じ理由で何通も飛ばさないよう、方法ごとにこの間隔だけ間引く。
ALERT_INTERVAL_SECONDS = 1800
_last_alert = {}


async def alert_admins(client, method_id: str, detail: str):
    """お客さんが受取側の不調に当たったことを、その場で管理者へ知らせる。

    生存確認の巡回でも気付けるが、最大で30〜60分あく。実際に支払いが1件
    止まっているので、待たずに知らせて復旧を促す(定期通知とは別系統)。
    """
    if client is None:
        return
    now = time.time()
    if now - _last_alert.get(method_id, 0) < ALERT_INTERVAL_SECONDS:
        return
    _last_alert[method_id] = now

    m = method(method_id)
    embed = discord.Embed(
        title=f"🚨 {m.label}の支払いが受け取れませんでした",
        description=("お客さんが支払おうとして失敗しました。**今この瞬間、売上が止まっています。**\n"
                     f"`/{method_id}_status` から復旧してください。"),
        color=0xff3333,
    )
    if detail:
        embed.add_field(name="内容", value=f"```{detail[:300]}```", inline=False)
    embed.set_footer(text=f"同じ通知は{ALERT_INTERVAL_SECONDS // 60}分に1回までです")
    for uid in ADMIN_USER_IDS:
        try:
            user = client.get_user(uid) or await client.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue


async def alert_receive_blocked(client, method_id: str, url: str, detail: str,
                                held: bool = False):
    """PayPayが受け取りを通さなかったことを、理由ごと管理者へ届ける。

    受け取りのPOSTが弾かれると、PayPayは送金そのものを失敗させて送り主へ
    差し戻すことがある(送り主のアプリでは「送金（譲渡）失敗」)。理由は
    その応答にしか残らないので、コンテナのログを見に行かなくても分かるように
    そのまま送る。同じリンクで何度も送らないよう、1リンク1回に絞る。

    held は「弾かれたがリンクは開いたまま」= 保留(送金者の承認待ち)。お金は差し
    戻されておらず、承認されれば見張りが受け取ってお渡しする。差し戻しと同じ文面で
    知らせると、実際には届いている購入が「失敗した」ように読めてしまう。
    """
    if client is None or not detail:
        return
    key = f"blocked:{url}"
    if key in _blocked_reported:
        return
    _blocked_reported.add(key)
    if len(_blocked_reported) > 200:
        _blocked_reported.clear()

    m = method(method_id)
    if held:
        embed = discord.Embed(
            title=f"⏳ {m.label}が受け取りを保留にしました（お客さんの承認待ち）",
            description=("受け取りのリクエストを通さず、送金者の承認待ちになりました。"
                         "お金は差し戻されていません。お客さんには承認を押すよう案内済みで、"
                         "**承認され次第、見張りが自動で受け取ってお渡しします**"
                         "（入金済みなら入金履歴からも拾います）。対応は不要です。\n"
                         "保留が続くようなら、下の文言が手掛かりです。`/paypay_status` の"
                         "「受け取りを診断」で少額のリンクを試すと、同じものを再現できます。"),
            color=0xffaa00,
        )
    else:
        embed = discord.Embed(
            title=f"⚠️ {m.label}が受け取りを通しませんでした",
            description=("受け取りのリクエストがPayPayに断られました。"
                         "**そのまま送金が失敗して送り主へ差し戻されることがあります**"
                         "（送り主のアプリでは「送金（譲渡）失敗」）。\n"
                         "下の文言が原因そのものです。`/paypay_status` の"
                         "「受け取りを診断」で少額のリンクを試すと、同じものを"
                         "その場で再現できます。"),
            color=0xff3333,
        )
    embed.add_field(name="PayPayの応答", value=f"```{str(detail)[:900]}```", inline=False)
    if url:
        embed.add_field(name="リンク", value=f"`{str(url)[:200]}`", inline=False)
    for uid in ADMIN_USER_IDS:
        try:
            user = client.get_user(uid) or await client.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue


# 同じリンクで何度も知らせないための控え(プロセス内だけ)
_blocked_reported = set()


async def alert_receive_unsure(client, method_id: str, url: str, amount, detail: str):
    """受け取れたか確認できなかったことを、間引かずに管理者へ知らせる。

    受け取りのリクエストは投げた時点でお金が動くので、応答が読めなかった場合は
    入金済みかもしれない。放置するとお客さんは商品を受け取れず、こちらは残高だけ
    増える。1件ごとに必ず知らせる(こればかりは間引いてはいけない)。
    """
    if client is None:
        return
    m = method(method_id)
    embed = discord.Embed(
        title=f"⚠️ {m.label}の受け取り結果が確認できませんでした",
        description=("受け取りのリクエストは送信済みです。**入金されている可能性があります。**\n"
                     "残高と履歴を確認して、入っていればお客さんへ手動でお渡ししてください。"),
        color=0xff3333,
    )
    if amount:
        embed.add_field(name="想定金額", value=f"{int(amount):,}円", inline=True)
    if url:
        embed.add_field(name="リンク", value=f"`{str(url)[:200]}`", inline=False)
    if detail:
        embed.add_field(name="内容", value=f"```{detail[:300]}```", inline=False)
    for uid in ADMIN_USER_IDS:
        try:
            user = client.get_user(uid) or await client.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue


# ---- リンク方式の受け取り ----

def _fail(exc: PaymentError, *, watchable: bool = None, accepted: bool = False) -> PaymentError:
    """例外に「見張りに回せるか / お金が動いた可能性があるか」を付けて返す。"""
    if watchable is not None:
        exc.watchable = watchable
    if accepted:
        exc.accepted = True
    return exc


async def _tell(interaction, text: str):
    """支払い画面の返事。deferの前でも後でも同じように出せるようにする。"""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)
    except discord.HTTPException as e:
        log.warning("支払い画面への返事に失敗: %s", e)


async def hold_link_for(interaction, kind: str, url: str, attempt: str = None):
    """受け取りを投げる前に、そのリンクを今の画面だけに握らせる。

    握れたら控え番号を返す。握れなかったときは案内まで済ませて None を返すので、
    呼び出し側はそのまま引き下がること(お金は動いていない)。

    同じリンクを見張りと支払い画面、あるいは支払い画面どうしが同時に受け取ると、
    入金1回でお渡しが2回走る。ツムツム代行では、それでコインを2回入れてしまい、
    お客さんのアカウントを危険にさらした。受け取りの前に必ずここを通す。

    握った札は link_orders.release_link() で必ず返すこと(呼び出し側の finally)。
    """
    # link_orders はこのモジュールを読むので、循環インポートを避けてここで読む。
    import link_orders
    import payment_attempts

    try:
        return await link_orders.hold_link(url, kind=kind, user_id=interaction.user.id)
    except link_orders.LinkBusy as e:
        text = str(e)
    except link_orders.LinkOrderError as e:
        # 二重お渡しを見分けられない状態では受け取らない。お金が動いていない
        # うちに引き下がるほうが、二重にお渡しするより軽い。
        log.warning("リンクの札を取れませんでした: %s", e)
        text = ("ただいま混み合っています。少し時間をおいてから、もう一度お試しください。\n"
                "**お代はいただいていません。**")
    if attempt:
        # dropped にすると突合が「入金の持ち主かもしれない」と拾ってしまう。
        # ここは受け取りを投げていない = お金は動いていないので rejected。
        await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, text[:300])
    await _tell(interaction, text)
    return None


# ---- 安全確認(不正・資金洗浄) ----

_bg_tasks = set()                   # 裏で走らせているタスク(途中で GC に消されないよう持っておく)


def _after_receive_later(*args):
    """_after_receive を裏で走らせる。

    結び付きの台帳は支払いのたびに丸ごと読み書きする。受け取れた直後にそれを
    待つと、その分だけお渡しが遅れる。記録はお客さんには見えず、失敗しても
    支払いは通っているので、お渡しを先に進める。
    """
    task = asyncio.create_task(_after_receive(*args))
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)


async def _after_receive(client, method_id: str, url: str, buyer, paid,
                         kind: str, state: dict):
    """誰がどの決済アカウントで払ったかを覚える。判定はこの積み重ねで決まる。

    通った支払いは通知しない。ここで失敗しても支払いは通っている。
    """
    if buyer is None:
        return
    sender_id, sender_name = (state or {}).get("risk_sender") or ("", "")
    try:
        # 結び付きの台帳は支払いのたびに丸ごと読み書きする。受け取れた直後の
        # この書き込みでイベントループを止めない(お渡しはこの後に続く)。
        await asyncio.to_thread(
            risk.remember, buyer.id, method=method_id, sender_id=sender_id,
            sender_name=sender_name, link=url, amount=int(paid or 0))
    except Exception as e:
        log.warning("risk.remember failed: %s", e)


async def alert_risk(client, buyer, verdict, *, method_id: str = "",
                     sender_name: str = "", sender_id: str = "", amount: int = 0,
                     kind: str = ""):
    """断ったことを管理者へ届ける。誤検知はこの1通からしか気付けない。"""
    if client is None:
        return
    embed = discord.Embed(
        title="🚫 支払いを受け取りませんでした（安全確認）",
        description=("お金は動いていません。リンクは送り主の手元に残っています"
                     "（送り主はアプリから取り消して戻せます）。\n"
                     "**誤検知だと思ったら、下の解除コマンドで戻してください。**"),
        color=0xff3333,
    )
    who = getattr(buyer, "mention", None) or str(getattr(buyer, "id", buyer))
    embed.add_field(name="買った人",
                    value=f"{who}\n`{getattr(buyer, 'id', buyer)}`", inline=True)
    embed.add_field(name="内容", value=f"{kind or '取引'} / {amount:,}円", inline=True)
    if sender_id or sender_name:
        embed.add_field(
            name="送金元",
            value=f"{sender_name or '（名前なし）'}\n`{sender_id or '不明'}`",
            inline=False)
    embed.add_field(name="断った理由", value=verdict.reason or "（不明）",
                    inline=False)
    embed.add_field(
        name="解除",
        value=(f"`/unblock discord {getattr(buyer, 'id', '')}`"
               + (f"\n`/unblock {method_id} {sender_id}`" if sender_id else "")
               + "\n※ Discordと送金元は別々に載るので、両方戻してください。"),
        inline=False)
    for uid in ADMIN_USER_IDS:
        try:
            user = client.get_user(uid) or await client.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue



def _sender_of(method_id: str, info) -> tuple:
    """送金元の (ID, 表示名)。PayPayは externalId、Kyashは publicId。

    読めないことがあるのでその場合は空で返す。読めないだけでは断らない。
    """
    if method_id == KYASH:
        return (str(getattr(info, "public_id", "") or ""),
                str(getattr(info, "sender_name", "") or ""))
    return (str(getattr(info, "sender_external_user_id", "") or ""),
            str(getattr(info, "sender_name", "") or ""))


def _risk_screen(method_id: str, url: str, buyer, min_amount, kind: str,
                 state: dict):
    """受け取り直前の確認。断るなら理由を返す。

    受け取りのスレッドから同期で呼ばれるので、中では通信しない。
    """
    if buyer is None:
        return None

    def screen(info):
        sender_id, sender_name = _sender_of(method_id, info)
        verdict = risk.screen_payment(buyer.id, method=method_id,
                                      sender_id=sender_id,
                                      sender_name=sender_name, link=url)
        # 判定と、その根拠になった送金元は呼び出し側へ渡す(通知に使う)。
        if state is not None:
            state["risk"] = verdict
            state["risk_sender"] = (sender_id, sender_name)
        if not risk.enforce(verdict, buyer.id, method=method_id,
                            sender_id=sender_id, sender_name=sender_name,
                            amount=int(min_amount or 0), kind=kind, link=url):
            return None
        return risk.decline_notice()

    return screen


async def _alert_if_declined(client, buyer, state: dict, method_id: str,
                             amount, kind: str) -> bool:
    """断った支払いなら管理者へ知らせる。戻り値は断ったかどうか。"""
    verdict = (state or {}).get("risk")
    if verdict is None or not verdict.blocked:
        return False
    sender_id, sender_name = (state or {}).get("risk_sender") or ("", "")
    await alert_risk(client, buyer, verdict, method_id=method_id,
                     sender_name=sender_name, sender_id=sender_id,
                     amount=int(amount or 0), kind=kind)
    return True


async def receive_link_payment(method_id: str, url: str, *, passcode: str = None,
                               min_amount: int = None, on_pending=None, client=None,
                               state: dict = None, buyer=None, kind: str = "") -> int:
    """PayPay / Kyash の送金リンクを受け取り、受取金額(円)を返す。

    どの支払い方法でも例外の型は同じ(PaymentError系)にそろえるので、
    呼び出し側は方法を意識せずに書ける。client を渡すと、受取先が未登録・
    ログイン切れだったときに管理者へその場で通知する。
    state を渡すと、受け取りのPOSTを投げたかどうかが state["accepted"] に入る。

    buyer に買った人(discord.User/Member)を渡すと、受け取りを投げる直前に
    安全確認(risk)を通す。代行・自販機のどれもここに集まるので、確認は
    ここ1か所だけに置く。
    """
    m = method(method_id)
    # 判定の置き場は先に用意する。Kyashでも安全確認の結果を残せるようにする
    # (呼び出し側が state を渡していなくても、通知にはこちらの控えを使う)。
    state = state if state is not None else {}
    if m.kind != LINK_KIND:
        raise PaymentError(f"{m.label}はリンクでの支払いに対応していません。")
    if not looks_like_link(method_id, url):
        raise PaymentError(_bad_link_text(method_id))

    if method_id == KYASH:
        screen = _risk_screen(method_id, url, buyer, min_amount, kind, state)
        try:
            paid = await kyash_async.receive_payment(url=url, min_amount=min_amount,
                                                     screen=screen)
            _after_receive_later(client, method_id, url, buyer, paid, kind, state)
            return paid
        except kyash_async.NotRegisteredError:
            await alert_admins(client, method_id, "アカウントが未登録です")
            raise PaymentNotRegistered(_down_text(m.label))
        except KyashLoginError as e:
            await alert_admins(client, method_id, error_text(e))
            raise PaymentAuthError(_down_text(m.label, "ログインが切れています"))
        except (KyashError, KyashNetWorkError) as e:
            if await _alert_if_declined(client, buyer, state, method_id,
                                        min_amount, kind):
                raise PaymentRejected(str(e))
            raise PaymentError(error_text(e))
        except PaymentError:
            raise
        except Exception as e:
            # 決済ライブラリは requests の例外を包まずに投げてくることがある。
            # ここで拾わないと呼び出し側のどの except にも当たらず、Botが
            # 何も返さないまま処理が消える(お客さんから見ると「無反応」)。
            log.exception("Kyash receive failed with an unexpected error")
            raise PaymentError(f"支払い処理で想定外のエラーが起きました: {str(e)[:200]}")

    try:
        return await _receive_paypay(method_id, url, passcode, min_amount,
                                     on_pending, client, state, buyer, kind)
    except PaymentError as e:
        await _alert_if_declined(client, buyer, state, method_id, min_amount, kind)
        # PayPayが受け取りを断った理由は、この応答にしか出ない。ログを見に
        # 行かないと分からない状態だと、原因不明のまま同じことが繰り返される。
        # 決着の仕方(保留・差し戻し・結果不明)に関わらず、そのまま管理者へ送る。
        if state.get("reject_detail"):
            await alert_receive_blocked(client, method_id, url, state["reject_detail"],
                                        held=bool(state.get("held")) and not isinstance(e, PaymentRejected))
        # 最後の砦。acceptP2PSendMoneyLink を投げた後は、理由が何であれ
        # 「失敗しました」で終わらせてはいけない(あとから入金しうる)。分岐を
        # 1つ書き漏らしても取りこぼさないよう、ここで見張り行きの印を付け直す。
        #
        # ただし PaymentRejected だけは別。PayPayが「もう受け取れない」と答えた
        # 状態で、お金はこちらに入っていない(閉じたリンクなら送り主に戻っている)。
        # ここまで見張りに載せると、戻ったお金について「PayPayアプリで承認して
        # ください」と待たせたあげく、最後に二重払いの注意まで出すことになる。
        if state.get("accepted") and not isinstance(e, PaymentRejected):
            e.watchable = True
            e.accepted = True
        raise


async def _receive_paypay(method_id: str, url: str, passcode, min_amount,
                          on_pending, client, state: dict, buyer=None,
                          kind: str = "") -> int:
    """PayPayリンクの受け取り。paypay_async の例外を PaymentError 系にそろえる。"""
    try:
        paid = await paypay_async.receive_payment(
            url=url, passcode=passcode, min_amount=min_amount, on_pending=on_pending,
            state=state, screen=_risk_screen(method_id, url, buyer, min_amount,
                                             kind, state))
        _after_receive_later(client, method_id, url, buyer, paid, kind, state)
        return paid
    except paypay_async.NotRegisteredError:
        await alert_admins(client, method_id, "アカウントが未登録です")
        raise PaymentNotRegistered(_down_text(method(method_id).label))
    except PayPayLoginError as e:
        await alert_admins(client, method_id, error_text(e))
        # 受け取りを投げた後で切れた場合は入金済みかもしれないので、見張りに回す。
        raise _fail(
            PaymentAuthError(_down_text(method(method_id).label, "ログインが切れています")),
            watchable=bool(state.get("accepted")), accepted=bool(state.get("accepted")))
    except paypay_async.ReceiveUnsure as e:
        # 受け取りのPOSTは投げた時点でお金が動く。応答が読めなかっただけの場合も、
        # すでに受け取り済みだった場合も、入金済みの可能性がある。失敗と言い切らず
        # 管理者へ回して、お客さんには二重払いを止めてもらう。
        await alert_receive_unsure(client, method_id, url, min_amount, str(e))
        raise PaymentUnsure(
            "支払いの結果を確認できませんでした。**お代をいただいている可能性があります**。\n"
            "**もう一度支払わないでください。**二重払いを防ぐため、"
            + support.contact_line())
    except paypay_async.PendingTimeout as e:
        # 保留のまま待ち時間が終わっただけ。リンクは生きているので、この場で
        # 捨てずに見張りへ引き継ぐ(お客さんが後から承認しても取りこぼさない)。
        # accepted なら受け取りは送信済み = 承認された瞬間に入金する。
        raise _fail(PaymentPending("支払いがまだ承認されていません。"), watchable=True,
                    accepted=bool(getattr(e, "accepted", False) or state.get("accepted")))
    except paypay_async.LinkRejected as e:
        if state.get("accepted") or getattr(e, "blocked", False):
            # 受け取りを投げて通らなかった、または投げる前にこちらの都合で
            # 断った = 受取アカウント側の問題。お客さんには直せないし、
            # 続けば売上が止まるので、その場で知らせる(間引きは alert_admins 側)。
            await alert_admins(client, method_id, error_text(e))
        raise PaymentRejected(error_text(e))
    except (PayPayError, PayPayNetWorkError) as e:
        # 通信不良などの一時的な失敗。リンクは生きている可能性があるので見張る。
        raise _fail(PaymentError(error_text(e)), watchable=True,
                    accepted=bool(state.get("accepted")))
    except PaymentError:
        raise
    except Exception as e:
        log.exception("PayPay receive failed with an unexpected error")
        raise _fail(PaymentError(f"支払い処理で想定外のエラーが起きました: {str(e)[:200]}"),
                    watchable=True, accepted=bool(state.get("accepted")))


# ---- 支払い方法の選択 ----

_STYLES = {
    PAYPAY: discord.ButtonStyle.danger,
    KYASH: discord.ButtonStyle.primary,
}


def blocked_notice(held: dict) -> str:
    """止めている相手への文面。理由は書かず、解除の道だけ示す。"""
    return ("安全確認のため、現在このアカウントではご購入いただけません。\n"
            "**お代はいただいていません。**\n\n"
            "お心当たりがない場合は、ご購入時の状況が分かるものを添えて"
            "サポートまでご連絡ください。確認のうえ解除します。\n"
            + support.contact_line())


class MethodPicker(ui.View):
    """支払い方法を選ばせるView。押されたら on_pick(interaction, method_id) を呼ぶ。

    使える方法(受取先が登録済みのもの)だけを出す。1つしか無いときも、
    何で払うのかが分かるように同じ画面を出す。
    """

    def __init__(self, on_pick, *, timeout: float = 300, methods: list = None):
        super().__init__(timeout=timeout)
        self._on_pick = on_pick
        # methods を渡せば受取先の設定ファイルを読み直さない(呼び出し側が
        # 直前に available_methods() を呼んでいるなら、その結果を回す)。
        for m in available_methods() if methods is None else methods:
            btn = ui.Button(label=m.label, emoji=m.emoji, style=_STYLES.get(m.id, discord.ButtonStyle.secondary))
            btn.callback = self._make_cb(m.id)
            self.add_item(btn)

    def _make_cb(self, method_id: str):
        async def cb(interaction: discord.Interaction):
            # 払う前に断る。受け取ってからだと返す手間が要る。
            held = risk.is_blocked(risk.DISCORD, interaction.user.id)
            if held:
                return await interaction.response.send_message(
                    blocked_notice(held), ephemeral=True)
            await self._on_pick(interaction, method_id)
        return cb


def picker_embed(total_price: int, *, title: str = "お支払い方法を選択", note: str = None,
                 hints: bool = True, methods: list = None) -> discord.Embed:
    """hints=False で、方法ごとの説明(「送金リンクを貼る」)を出さずボタンだけにする。

    methods を渡せば available_methods() を呼び直さない(MethodPicker と同じ一覧を使う)。
    """
    methods = available_methods() if methods is None else methods
    desc = f"**{total_price:,}円**"
    if note:
        desc += f"\n{note}"
    e = discord.Embed(title=title, description=desc, color=0x00aaff)
    for m in methods if hints else ():
        e.add_field(name=f"{m.emoji} {m.label}", value=m.hint, inline=True)
    if not methods:
        e.description = "今は支払い方法がありません。管理者に連絡してください。"
        e.color = 0xff3333
    return e
