"""プロセスをまたいで処理を直列化するファイルロック。

デプロイ時に新旧のコンテナが一瞬同時に動くと、同じ認証情報で同時にトークンを
更新してしまい、決済側で使い回しとみなされてセッションごと失効することがある。
asyncio.Lock はプロセス内でしか効かないので、実ファイルの flock で守る。
PayPay と Kyash の両方から使う。
"""
import contextlib
import fcntl
import os
import time


class LockTimeout(Exception):
    """制限時間内にロックを取れなかった(他のプロセスが処理中)。"""


@contextlib.contextmanager
def cross_process_lock(path: str, timeout: int = 60):
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    deadline = time.time() + timeout
    try:
        while True:
            try:
                fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.time() >= deadline:
                    raise LockTimeout(f"他のプロセスが処理中です（{os.path.basename(path)}）")
                time.sleep(0.5)
        yield
    finally:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        finally:
            os.close(fd)
