"""Discord へ1通を、やり直しで二重にならないように送る(nonce + enforce_nonce)。

discord.py の send は 500/502/504/524 や接続切れのとき、同じ送信を内側で最大5回
やり直す。Discord 側では1回目で投稿ができているのに応答だけが落ちると、やり直しで
同じ投稿がもう1通できる(在庫追加の通知が1回の追加で2回鳴いていた正体)。
Discord の Create Message には nonce と enforce_nonce があり、同じ送り主が数分以内に
同じ nonce で送ると、新しく作らずにその投稿を返す。やり直しは同じ中身を同じ nonce で
送るので、これで何回やり直しても1通になる。

自販機のログ・在庫追加の通知(Cogs/shop.py)と、/announce(Cogs/announce.py)で使う。
"""
import json
import logging
import uuid

import discord

log = logging.getLogger(__name__)


def message_params(kw: dict, nonce: str, previous_allowed_mentions=None):
    """ch.send(**kw) と同じ中身を、Discord への1リクエストの形にして nonce を付ける。

    discord.py 2.3.2 の send には enforce_nonce を渡せないので、send が組み立てるのと
    同じ形(handle_message_parameters)を作ってから、JSON に nonce と enforce_nonce を足す。
    添付があるときは payload_json(multipart)の中に入れる。
    previous_allowed_mentions には Bot の既定のメンション設定(state.allowed_mentions)を
    渡す。send() はこれと合成して「誰を鳴らすか」を決めているので、同じにしないと
    販売ログに入る購入者のメンション等が、Bot の既定より広く鳴ってしまう。
    """
    from discord.http import handle_message_parameters
    missing = discord.utils.MISSING
    allowed = {"content", "tts", "embed", "embeds", "file", "files", "allowed_mentions"}
    unknown = set(kw) - allowed
    if unknown:
        raise TypeError(f"nonce 付きで送れない引数: {sorted(unknown)}")

    def opt(name):
        return kw[name] if kw.get(name) is not None else missing

    params = handle_message_parameters(
        content=kw.get("content", missing), tts=bool(kw.get("tts", False)),
        embed=opt("embed"), embeds=opt("embeds"), file=opt("file"), files=opt("files"),
        allowed_mentions=opt("allowed_mentions"),
        previous_allowed_mentions=previous_allowed_mentions)
    marks = {"nonce": nonce, "enforce_nonce": True}
    if params.payload is not None:
        params.payload.update(marks)
    for part in params.multipart or ():
        if part.get("name") == "payload_json":
            body = json.loads(part["value"])
            body.update(marks)
            part["value"] = json.dumps(body, separators=(",", ":"), ensure_ascii=True)
    return params


async def send_once(ch, kw: dict):
    """ch.send(**kw) と同じだが、discord.py が内側でやり直しても Discord 側で1通にまとまる
    (nonce + enforce_nonce)。ch はチャンネル(ユーザーではなく)。

    discord.py の内部の形が変わっていて組み立てられないときは、ふつうの send に戻す
    (送れないよりは、まれに二重になるほうがまし)。
    戻り値は送ったメッセージ(discord.Message)。形を作れなかったときは Discord から
    返ってきたままの dict(送れてはいる。"id" で投稿を指せる)。
    """
    nonce = uuid.uuid4().hex[:24]        # Discord の上限は25文字
    try:
        state = ch._state
        params = message_params(kw, nonce, previous_allowed_mentions=state.allowed_mentions)
        http = state.http
    except (AttributeError, TypeError) as e:
        log.warning("nonce 付きで送れないため、ふつうの送り方に戻します: %s", e)
        return await ch.send(**kw)
    with params:
        data = await http.send_message(ch.id, params=params)
    try:
        return state.create_message(channel=ch, data=data)
    except Exception:
        return data
