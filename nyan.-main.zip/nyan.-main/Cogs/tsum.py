"""ツムツム代行(自動)。

にゃんこ代行(main.py)・自販機(Cogs/shop.py)と同じ流れで動く。

    パネル → メニュー選択 → 内容の指定 → LINEログイン → 支払い → 代行 → DM

支払いは payments 層に丸ごと任せるので、受け取り先は「いつものコマンド」で
登録したアカウントそのまま(PayPayなら /paypay_login、Kyashなら /kyash_login で
登録したもの)。ここに受取先の設定は持たない。

先にLINEログインまで済ませてから支払わせるのは、にゃんこ代行が引き継ぎコードを
先に確かめるのと同じ理由。ログインできないアカウントからお代だけ受け取る事故を
作らない。

支払いが保留(PayPayの承認待ち)になっても注文は捨てない。link_orders の見張りに
渡して、承認され次第そのまま自動で代行する。そのために注文にはLINEの
リフレッシュトークンだけを預ける(メールアドレスとパスワードは保存しない)。

表示に絵文字は使わない。文字だけでも読める並びにしておく。
"""
import asyncio
import io
import json
import logging
import os
import re
import time
import uuid

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

import link_orders
import panels
import payment_attempts
import payments
import support
import tsum_api
import tsum_daiko
from datapath import data_path, read_json, write_json
from utils import ADMIN_USER_IDS, notify_payment_pending

log = logging.getLogger(__name__)

# 注文の種類。link_orders / payment_attempts で共通に使う。
KIND = "tsum"

# 保留になった支払いを見張る時間(分)。在庫を抱えないので代行と同じ既定にする。
WATCH_MINUTES = int(os.environ.get("TSUM_LINK_WATCH_MINUTES", "60"))

# 設定は main.py と同じ config.json を共有する(置き場所を増やさない)。
CONFIG_FILE = data_path("config.json")


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


def _save_config(cfg: dict):
    write_json(CONFIG_FILE, cfg)


def log_channel_id():
    """公開ログの送信先。未設定ならにゃんこ代行のログ先へ相乗りする。

    ツムツムだけ別チャンネルに出したくなったら /tsum selllog で分ける。
    何も設定しないうちから「ログがどこにも出ない」を作らないための既定。
    """
    cfg = _config()
    return cfg.get("tsum_log_channel_id") or cfg.get("log_channel_id")


def private_log_channel_id():
    cfg = _config()
    return cfg.get("tsum_private_log_channel_id") or cfg.get("daiko_private_log_channel_id")


def purchase_role_id(guild_id):
    """購入時に付けるロール。ツムツム用が無ければ代行用を使う。"""
    cfg = _config()
    for key in ("tsum_purchase_roles", "daiko_purchase_roles"):
        rid = (cfg.get(key) or {}).get(str(guild_id))
        if rid:
            return int(rid)
    return None


def set_purchase_role_id(guild_id, role_id):
    cfg = _config()
    roles = cfg.setdefault("tsum_purchase_roles", {})
    if role_id:
        roles[str(guild_id)] = int(role_id)
    else:
        roles.pop(str(guild_id), None)
    _save_config(cfg)


# --- ログ ------------------------------------------------------------------

async def resolve_channel(bot, ch_id):
    """設定されたIDからチャンネルを取り出す。キャッシュに無ければ取りに行く。"""
    if not ch_id:
        return None
    try:
        ch_id = int(ch_id)
    except (TypeError, ValueError):
        log.warning("ツムツムのログ先IDが不正です: %r", ch_id)
        return None
    ch = bot.get_channel(ch_id)
    if ch is not None:
        return ch
    try:
        return await bot.fetch_channel(ch_id)
    except Exception as e:
        log.warning("ツムツムのログ先を取得できません(%s): %s", ch_id, e)
        return None


async def _send_log(bot, ch_id, label: str, **kwargs) -> bool:
    ch = await resolve_channel(bot, ch_id)
    if ch is None:
        return False
    try:
        await ch.send(**kwargs)
        return True
    except discord.Forbidden:
        log.warning("%sを送れません(権限不足): %s", label, ch_id)
    except Exception as e:
        log.warning("%sの送信に失敗: %s", label, e)
    return False


def _dropped_lines(order) -> list:
    """支払いの前に注文から外したメニューを、お客さんに伝える文。"""
    lines = ["次のメニューは、このアカウントでは実行しても変わらないため、"
             "ご注文から外しました（そのぶんのお代はいただきません）。"]
    for label, reasons in order.dropped:
        lines.append(f"・{label}" + (f"：{' '.join(reasons)}" if reasons else ""))
    return lines


async def log_medal_probe_block(bot, user, runner, continued: bool = False,
                                title: str = None) -> bool:
    """支払いの前のメダルの確かめで、メダルを付けられなかったことを非公開ログに残す。

    メダルのお代は受け取らない(注文がメダルだけなら注文ごと止め、ほかの項目が
    あればメダルだけ外して続ける)。なぜゲーム側がメダルを受け付けなかったのかを
    後から追えるよう、そのプレイの中身を添付する。
    title を渡すと見出しを差し替える(管理者の動作確認で、イベント参加中の口に
    入る送り方が見つかったときも、同じ形で中身を残す)。
    """
    title = title or (
        "メダルの事前確認：メダルを外して、ほかの項目は続けます（メダル分のお代は受け取りません）"
        if continued else "メダルの事前確認で止めました（お代は受け取っていません）")
    embed = discord.Embed(title=title[:256], color=0xe67e22)
    embed.add_field(name="ユーザー", value=f"{user.mention} `{user}`", inline=False)
    embed.add_field(name="ツムツムのアカウント",
                    value=(runner.account_line() or "不明")[:1024], inline=False)
    body = "\n".join(runner.trace)[-950:]
    embed.add_field(name="記録", value=f"```\n{body}\n```", inline=False)
    extra = {}
    if runner.debug:
        try:
            data = json.dumps(runner.debug, ensure_ascii=False, indent=1,
                              default=str).encode("utf-8")
            extra["file"] = discord.File(io.BytesIO(data),
                                         filename=f"tsum_medal_probe_{user.id}.json")
        except Exception as e:
            log.warning("ツムツムの調査用ファイルを作れません: %s", e)
    return await _send_log(bot, private_log_channel_id(), "非公開ツムツムログ",
                           embed=embed, **extra)


async def grant_purchase_role(guild, user_id, paid_amount) -> bool:
    """購入時ロールを付ける。0円(無料券・お試し)には付けない。"""
    if int(paid_amount or 0) <= 0 or guild is None:
        return False
    role_id = purchase_role_id(guild.id)
    if not role_id:
        return False
    member = guild.get_member(int(user_id))
    if member is None:
        try:
            member = await guild.fetch_member(int(user_id))
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            member = None
    role = guild.get_role(int(role_id))
    if member is None or role is None:
        log.warning("ツムツムの購入ロールを付けられません(member=%s role=%s id=%s)",
                    member is not None, role is not None, role_id)
        return False
    if role in member.roles:
        return True
    try:
        await member.add_roles(role, reason="ツムツム代行の購入(有料)による自動付与")
        return True
    except (discord.Forbidden, discord.HTTPException) as e:
        log.warning("ツムツムの購入ロール付与に失敗: %s", e)
        return False


# --- 注文の実行 ------------------------------------------------------------

# 同じ人の二重実行を止める。ゲーム側に同時に投げると、どちらの結果も
# 信用できなくなる(残高の増減が混ざる)。
_BUSY: set = set()


class Busy(Exception):
    """その人の代行がもう走っている。"""


class TsumJob:
    """1件の注文を実際に流して、DM・ログ・売上まで面倒を見る。

    その場の支払い(Interactionが生きている)と、保留から承認された後追いの
    お渡しで同じものを使う。片方だけログが出ない、を作らないため。
    """

    def __init__(self, bot, user, keys, refresh_token, *, params=None, total_price=0,
                 paid=0, method=payments.PAYPAY, free_ticket=False,
                 guild=None, channel=None, pay_note=None, order_id=None,
                 item_prices=None, account="", tx_id=None, admin_free=False,
                 guest_id="", guest_password=""):
        self.bot = bot
        self.user = user
        self.keys = tsum_daiko.sort_keys(keys)
        self.refresh_token = refresh_token
        # 引き継ぎ番号で入るとき。代行後に新しい番号を発行してお客さんに返す。
        self.guest_id = guest_id or ""
        self.guest_password = guest_password or ""
        self.params = dict(params or {})
        self.total_price = int(total_price or 0)
        self.paid = int(paid or 0)
        self.method = method
        self.free_ticket = free_ticket
        self.admin_free = admin_free    # 管理者の動作確認(全メニュー0円)
        self.guild = guild
        self.channel = channel
        self.pay_note = pay_note        # 非公開ログ用(リンク・注文番号など)
        self.order_id = order_id
        self.item_prices = item_prices or tsum_daiko.compute_item_prices(self.keys)
        self.account = account          # ログイン時に見えたアカウント
        # 取引番号。公開ログ・非公開ログ・売上の3か所に同じものを載せて、
        # 「このログの代行はどの入金か」を後から突き合わせられるようにする。
        self.tx_id = tx_id or uuid.uuid4().hex[:16]

    # ---- 表示 ----

    def menu_lines(self) -> str:
        lines = []
        for key in self.keys:
            line = f"・{tsum_daiko.menu_label(key)}"
            note = self.key_note(key)
            if note:
                line += f"（{note}）"
            lines.append(line)
        return "\n".join(lines)

    def key_note(self, key: str) -> str:
        """そのメニューで指定された内容(数字・対象のツム)。"""
        notes = []
        tasks = tsum_daiko.menu_tasks(key)
        asked = {kind for kind, value in tasks if value is None}
        for kind, label, _limit, _label, unit in tsum_daiko.input_specs():
            if kind in asked and self.params.get(kind) is not None:
                notes.append(f"{label} {int(self.params[kind]):,}{unit}")
        if any(kind == tsum_daiko.TSUM_LEVEL for kind, _ in tasks):
            if self.params.get("tsum_id"):
                notes.append(tsum_daiko.tsum_name(int(self.params["tsum_id"])))
        return " / ".join(notes)

    def method_note(self) -> str:
        """ログに出す支払い方法。0円なら支払い自体が無いので「なし」。"""
        if self.admin_free:
            return payments.ADMIN_FREE_LABEL
        if self.free_ticket:
            return payments.FREE_TICKET_LABEL
        if self.paid <= 0:
            return "なし"
        return payments.method_label(self.method)

    def result_embed(self, outcome: dict) -> discord.Embed:
        if not outcome.get("ok"):
            title, color = "ツムツム代行 一部失敗", 0xffa500
        elif outcome.get("warning"):
            title, color = "ツムツム代行 完了(一部未完了)", 0xffa500
        else:
            title, color = "ツムツム代行 完了", 0x2f9e6e
        body = "\n\n".join(outcome.get("lines") or []) or "結果なし"
        if len(body) > 3900:
            body = body[:3900] + "\n(以下省略)"
        embed = discord.Embed(title=title, description=body, color=color)
        if outcome.get("account"):
            embed.add_field(name="アカウント", value=outcome["account"], inline=False)
        # 引き継ぎで入ったときは、返却用の新しい番号をそのまま返す。
        code = outcome.get("guest_code")
        if code:
            embed.add_field(name="引き継ぎID", value=f"`{code[0]}`", inline=True)
            embed.add_field(name="パスワード", value=f"`{code[1]}`", inline=True)
        elif outcome.get("guest_code_error"):
            embed.add_field(
                name="⚠️ 引き継ぎ番号の発行に失敗しました",
                value=("お手数ですが管理者にご連絡ください。垢はこちらで確保しています。\n"
                       + support.contact_line()), inline=False)
        embed.add_field(name="ご利用金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        return embed

    # ---- 本体 ----

    async def execute(self, on_progress=None) -> tuple:
        """代行を流して結果をDMする。戻り値 (DMできたか, 結果)。

        ログインできないときは TsumLoginError をそのまま投げる(何度やり直しても
        同じなので、呼び出し側が本人にログインし直してもらう)。
        """
        if self.user is not None and self.user.id in _BUSY:
            raise Busy("すでに処理中です")
        if self.user is not None:
            _BUSY.add(self.user.id)
        try:
            outcome = await tsum_daiko.run_menus(
                self.refresh_token, self.keys, params=self.params,
                on_progress=on_progress,
                guest_id=self.guest_id or None,
                guest_password=self.guest_password or None)
        finally:
            if self.user is not None:
                _BUSY.discard(self.user.id)

        embed = self.result_embed(outcome)
        try:
            await self.user.send(embed=embed)
            dm_ok = True
        except (discord.HTTPException, AttributeError):
            dm_ok = False

        # ここから先は代行そのものは終わっている。記録やログで失敗しても
        # 「渡せなかった」と判断させない(後追いの再試行で二重に走る)。
        await self._safe_async("売上の記録", self._record_sale)
        await self._safe_async("購入ロールの付与", grant_purchase_role,
                               self.guild, self.user.id if self.user else 0, self.paid)
        await self._safe_async("ログの送信", self.send_logs, outcome)
        return dm_ok, outcome

    def _record_sale(self):
        tsum_daiko.record_sale(self.paid, self.user.id if self.user else 0,
                               self.keys, self.item_prices, method=self.method,
                               tx_id=self.tx_id)

    def _safe(self, step, fn, *args):
        try:
            fn(*args)
        except Exception as e:
            log.exception("ツムツム代行の%sに失敗: %s", step, e)

    async def _safe_async(self, step, fn, *args):
        try:
            result = fn(*args)
            if asyncio.iscoroutine(result):
                await result
        except Exception as e:
            log.exception("ツムツム代行の%sに失敗: %s", step, e)

    # ---- ログ ----

    def order_lines(self) -> str:
        """公開ログ用の注文内容。「メニュー名-価格円」を1行ずつ。"""
        return "\n".join(f"{tsum_daiko.menu_label(k)}-{int(self.item_prices.get(k, 0)):,}円"
                         for k in self.keys) or "なし"

    async def send_logs(self, outcome: dict):
        """公開ログ(誰が何をいくらで買ったか)と非公開ログ(詳細つき)を送る。

        公開ログは他のお客さんの目にも入る。載せるのは注文内容・金額・
        取引番号だけにして、支払いリンクやアカウントの中身は出さない。
        """
        # 管理者の動作確認はお客さんの購入ではない。0円の代行が公開ログに並ぶと
        # 「無料で買えた人がいる」と読めてしまうので、公開側には出さない
        # (中身を確かめられるよう、非公開ログには管理者テストとして残す)。
        pub = None if self.admin_free else log_channel_id()
        if pub:
            embed = discord.Embed(color=0x2f9e6e)
            if self.user is not None:
                try:
                    embed.set_author(name=str(self.user),
                                     icon_url=self.user.display_avatar.url)
                except Exception:
                    embed.set_author(name=str(self.user))
            embed.add_field(name="注文内容", value=self.order_lines()[:1024], inline=False)
            embed.add_field(name="金額", value=f"¥{self.paid:,}", inline=False)
            embed.add_field(name="トランザクションID", value=self.tx_id, inline=False)
            await _send_log(self.bot, pub, "公開ツムツムログ", embed=embed)

        prv = private_log_channel_id()
        if not prv:
            return
        embed = discord.Embed(
            title="非公開ツムツム代行ログ" + ("（管理者の動作確認）" if self.admin_free else ""),
            color=0x2f9e6e, timestamp=discord.utils.utcnow())
        u = self.user
        if u is not None:
            try:
                embed.set_thumbnail(url=u.display_avatar.url)
            except Exception:
                pass
            embed.add_field(
                name="購入者",
                value=(f"{u.mention}\nユーザー名: `{u}`\n"
                       f"表示名: `{getattr(u, 'display_name', u)}`\nID: `{u.id}`"),
                inline=False)
            created = getattr(u, "created_at", None)
            if created:
                embed.add_field(name="アカウント作成",
                                value=f"<t:{int(created.timestamp())}:f>", inline=True)
            joined = getattr(u, "joined_at", None)
            if joined:
                j = int(joined.timestamp())
                embed.add_field(name="サーバー参加",
                                value=f"<t:{j}:f>（<t:{j}:R>）", inline=True)
        embed.add_field(name="利用金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        embed.add_field(name="トランザクションID", value=f"`{self.tx_id}`", inline=True)
        if self.pay_note:
            embed.add_field(name="支払い情報", value=str(self.pay_note)[:1024], inline=False)
        # LINEのメールアドレス・パスワードは預かっていないので出しようがない。
        # 出せるのは、こちらがゲームから見たアカウントだけ。
        if outcome.get("account") or self.account:
            embed.add_field(name="ツムツムのアカウント",
                            value=(outcome.get("account") or self.account)[:1024],
                            inline=False)
        embed.add_field(name="代行内容", value=self.menu_lines()[:1024], inline=False)
        embed.add_field(name="結果", value=self._result_detail(outcome)[:1024], inline=False)
        trace = outcome.get("trace") or []
        if trace:
            # 1プレイずつの入り方。コンソールを見られないので、追える形で残す。
            # 入りきらないぶんは古いほうから落ちる。黙って落とすと、消えた行が
            # 最初から無かったように見えるので、落とした行数を先頭に書く。
            body, dropped = "\n".join(trace), 0
            while len(body) > 950 and dropped < len(trace):
                dropped += 1
                body = "\n".join(trace[dropped:])
            head = f"(古い{dropped}行を省略)\n" if dropped else ""
            embed.add_field(name="プレイごとの記録",
                            value=("```\n" + head + body + "\n```"), inline=False)
        if self.guild is not None:
            place = self.guild.name
            if self.channel is not None:
                place += f" / {self.channel.mention}"
            embed.add_field(name="購入場所", value=place, inline=False)
        extra = {}
        debug = outcome.get("debug")
        if debug:
            # イベント付きのプレイが弾かれた/0枚だったときの中身。埋め込みの
            # 欄(1024字)には入らないので、ファイルで添付する。
            try:
                data = json.dumps(debug, ensure_ascii=False, indent=1,
                                  default=str).encode("utf-8")
                extra["file"] = discord.File(
                    io.BytesIO(data), filename=f"tsum_event_{self.tx_id}.json")
            except Exception as e:
                log.warning("ツムツムの調査用ファイルを作れません: %s", e)
        await _send_log(self.bot, prv, "非公開ツムツムログ", embed=embed, **extra)

    @staticmethod
    def _result_short(outcome: dict) -> str:
        lines = outcome.get("lines") or []
        ok = sum(1 for line in lines if line.startswith("[完了]"))
        return f"{ok}/{len(lines)} 完了"

    @staticmethod
    def _result_detail(outcome: dict) -> str:
        """行ごとの見出し(1行目)だけ並べる。中身はお客さんのDMにある。"""
        heads = [line.split("\n", 1)[0] for line in (outcome.get("lines") or [])]
        return "\n".join(heads) or "結果なし"

    async def send_trouble_log(self, reason: str):
        """「お代は受け取ったのに代行できなかった」ときのログ。

        成功したときしかログが出ないと、失敗はどこにも残らない。非公開ログ
        (無ければ公開ログ)と管理者DMの両方に必ず残す。
        """
        if self.paid <= 0:
            return
        embed = discord.Embed(
            title="ツムツム代行に失敗しました(支払い済み)",
            description=("支払いは受け取れましたが、代行の処理が失敗しました。\n"
                         "手動で対応するか返金してください。"),
            color=0xff3333, timestamp=discord.utils.utcnow())
        if self.user is not None:
            embed.add_field(name="購入者", value=f"{self.user.mention}（`{self.user.id}`）",
                            inline=False)
        embed.add_field(name="受取済みの金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        embed.add_field(name="トランザクションID", value=f"`{self.tx_id}`", inline=True)
        if self.pay_note:
            embed.add_field(name="支払い情報", value=str(self.pay_note)[:1024], inline=False)
        embed.add_field(name="代行内容", value=self.menu_lines()[:1024], inline=False)
        embed.add_field(name="エラー", value=f"```{str(reason)[:500]}```", inline=False)
        embed.set_footer(text="返金または手動対応が必要です")

        for ch_id in (private_log_channel_id(), log_channel_id()):
            if ch_id and await _send_log(self.bot, ch_id, "ツムツムのトラブルログ", embed=embed):
                break
        for uid in ADMIN_USER_IDS:
            try:
                admin = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await admin.send(embed=embed)
            except Exception:
                continue


# --- 画面(キャプチャ) ------------------------------------------------------

def captcha_image_file(img_data: bytes) -> discord.File:
    """画像認証の画像を、スマホのDiscordでも端まで読める形にして添付にする。

    LINEの画像は小さくて横長で、背景が透明。そのまま添付すると、スマホでは幅
    いっぱいに引き伸ばされて端が切れ、保存して開かないと全部読めなかった。
    白の上に重ね(透明を黒にすると黒い文字が沈んで真っ黒になる)、整数倍に拡大して
    (滲ませない)、縦横比が 2:1 くらいになるよう白い余白を足す(端まで画面に入る)。
    Pillow が無い・読めない画像・一色にしかならない画像は、そのまま添付する。
    """
    try:
        from PIL import Image
        src = Image.open(io.BytesIO(img_data))
        src.load()
        rgba = src.convert("RGBA")
        base = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
        base.alpha_composite(rgba)
        src = base.convert("RGB")
        width, height = src.size
        if width <= 0 or height <= 0:
            raise ValueError("empty image")
        low, high = src.convert("L").getextrema()
        if high - low < 16:
            raise ValueError("flat image after compositing")
        scale = max(1, min(4, 720 // width))
        if scale > 1:
            src = src.resize((width * scale, height * scale), Image.NEAREST)
            width, height = src.size
        margin = max(16, height // 4)
        box_w = max(width, height * 2) + margin * 2
        box_h = max(height, width // 2) + margin * 2
        canvas = Image.new("RGB", (box_w, box_h), "white")
        canvas.paste(src, ((box_w - width) // 2, (box_h - height) // 2))
        out = io.BytesIO()
        canvas.save(out, format="PNG")
        out.seek(0)
        return discord.File(fp=out, filename="captcha.png")
    except Exception as e:
        log.info("画像認証の画像を整えられませんでした(そのまま出します): %s", e)
        return discord.File(fp=io.BytesIO(img_data), filename="captcha.png")


class CaptchaModal(ui.Modal, title="画像認証"):
    code = ui.TextInput(label="画像に出ている文字を入力", placeholder="例: AB12CD",
                        required=True)

    def __init__(self):
        super().__init__(timeout=120)
        self.result = asyncio.get_running_loop().create_future()

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        if not self.result.done():
            self.result.set_result(self.code.value.strip())

    async def on_timeout(self):
        if not self.result.done():
            self.result.set_exception(TimeoutError("画像認証の入力がタイムアウトしました"))


class CaptchaView(ui.View):
    def __init__(self, modal: CaptchaModal):
        super().__init__(timeout=120)
        self.modal = modal

    @ui.button(label="文字を入力する", style=discord.ButtonStyle.primary)
    async def input_captcha(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(self.modal)

    async def on_timeout(self):
        if not self.modal.result.done():
            self.modal.result.set_exception(
                TimeoutError("画像認証の入力がタイムアウトしました"))


def make_captcha_callback(interaction: discord.Interaction):
    """LINE側が画像認証を出したとき、その画像をこの画面に出して答えをもらう。

    画像とボタンは新しいメッセージとして出す。最初の返事を編集して画像を足す形
    だと、スマホでは「文字を入力する」を押すまで画像が出なかった(編集で足した
    添付がすぐには描かれない)。答えをもらったら(時間切れでも)そのメッセージは
    消して、続きは従来どおり最初の返事に出す。
    """
    async def callback(img_data: bytes) -> str:
        modal = CaptchaModal()
        view = CaptchaView(modal)
        text = "画像認証が表示されました。ボタンから文字を入力してください。"
        shown = None
        try:
            shown = await interaction.followup.send(
                text, file=captcha_image_file(img_data), view=view,
                ephemeral=True, wait=True)
        except discord.HTTPException as e:
            log.warning("画像認証の画像を別メッセージで出せませんでした(編集で出します): %s", e)
            await interaction.edit_original_response(
                content=text, attachments=[captcha_image_file(img_data)],
                embed=None, view=view)
        try:
            captcha = await asyncio.wait_for(modal.result, timeout=120)
        except asyncio.TimeoutError as e:
            raise TimeoutError("画像認証の入力がタイムアウトしました") from e
        finally:
            await _remove_captcha_message(shown)
        await interaction.edit_original_response(
            content="ログインしています。少々お待ちください。",
            attachments=[], embed=None, view=None)
        return captcha

    return callback


async def _remove_captcha_message(shown):
    """画像認証のメッセージ(別送り)を片付ける。消せなければボタンだけ外す。

    残したままだと、お客さんはいちばん下のそのメッセージを見続けて、最初の返事に
    出る続き(支払い画面・失敗の理由)に気づかない。
    """
    if shown is None:
        return
    try:
        await shown.delete()
        return
    except discord.HTTPException as e:
        log.info("画像認証のメッセージを消せませんでした(ボタンを外します): %s", e)
    try:
        await shown.edit(content="この画像認証の受け付けは終わりました。"
                                 "続きは上のメッセージをご覧ください。", view=None)
    except discord.HTTPException:
        pass


def make_pin_callback(interaction: discord.Interaction):
    """LINEがPINコード認証を求めたとき、その数字をこの画面とDMに出す。

    LINEアプリには数字の選択肢が並ぶ。どれを押すのかはここに出す数字でしか
    分からないので、出さないまま待たせると必ず時間切れになる。
    ここを「メアパスが間違っています」で埋めてはいけない。合っているのに
    間違いだと言われて、何度も入力し直すことになる。

    この画面(エフェメラル)だけに出していたが、承認はLINEアプリでするので
    お客さんはDiscordを離れる。スマホだとその時点でこの画面が見えなくなり、
    番号を覚えていないまま選択肢を前にすることになる。DMなら切り替えても
    残るので、同じ番号をDMにも送る。DMを送れなければ、この画面にそう書く。
    """
    async def callback(pin: str):
        # LINEアプリ側は「この数字を入力」のときと「並んだ数字から選ぶ」のときが
        # あるので、どちらでも通る書き方にする。番号だけ出して操作を書かないと、
        # アプリ側の画面を前にして何をすればいいのか分からなくなる。
        embed = discord.Embed(
            title="LINEの本人確認",
            description=("ログインにLINEの本人確認が必要になりました。\n"
                         "LINEアプリにこの番号を入力する画面（または番号を選ぶ画面）が"
                         "出ているので、下の番号で承認してください。\n"
                         "承認され次第、そのまま続きへ進みます（最大3分お待ちします）。"),
            color=discord.Color.orange())
        embed.add_field(name="確認番号", value=f"**{pin}**", inline=False)
        try:
            await interaction.user.send(embed=embed)
            dm_note = ("同じ番号をDMにも送りました。LINEアプリに切り替えたあとは、"
                       "DMで番号を確認できます。")
        except (discord.HTTPException, AttributeError):
            dm_note = ("DMを送れませんでした（DM許可を確認してください）。"
                       "番号はこの画面で確認してください。")
        await interaction.edit_original_response(
            content=("LINEの本人確認が表示されました。\n"
                     f"**確認番号: {pin}**\n"
                     "LINEアプリにこの番号を入力する画面（または番号を選ぶ画面）が"
                     "出ているので、この番号で承認してください。\n"
                     "承認され次第、そのまま続きへ進みます（最大3分お待ちします）。\n"
                     f"{dm_note}"),
            attachments=[], embed=None, view=None)

    return callback


# --- 画面(注文) ------------------------------------------------------------

class TsumOrder:
    """支払いが終わるまでの下書き。画面をまたいで持ち回る。"""

    def __init__(self, bot, user, keys, *, admin_free: bool = False):
        self.bot = bot
        self.user = user
        self.keys = tsum_daiko.sort_keys(keys)
        # 管理者の動作確認。全メニュー0円で流すが、売上には入れない。
        self.admin_free = admin_free
        self.free_ticket = (not admin_free) and tsum_daiko.has_free_ticket(user.id)
        self.item_prices = tsum_daiko.compute_item_prices(self.keys)
        if admin_free or self.free_ticket:
            self.total_price = 0
        else:
            self.total_price = sum(self.item_prices.values())
        # 注文時に決まるもの。ツムはログイン後にマイツムから読む。
        self.values = {}        # {タスクの種類: 指定された数字}
        self.tsum_id = None
        self.tsum_line = ""
        self.refresh_token = ""
        # 引き継ぎ番号で入るとき。LINEの refresh_token の代わりに使う。
        self.guest_id = ""
        self.guest_password = ""
        self.account = ""
        # ログイン後に分かった「この項目は空振りになります」。支払いの前に出す。
        self.preflight_notes = []
        # 支払いの前の確かめ(TsumRunner._probe_medal)で付いたメダルの枚数
        self.medal_probed = 0
        # 支払いの前の確かめ(TsumRunner._probe_coin)で付いたコインの枚数
        self.coin_probed = 0
        # その確かめで「9/22 の gameEnd の形なら入る」と分かったか(本番で最初からその形)
        self.medal_legacy_end = False
        # 支払いの前の確認で「丸ごと空振り」と分かり、注文から外したメニューと理由。
        # [(メニュー名, [理由, ...]), ...]。お代はいただかない。
        self.dropped = []
        self.method = payments.PAYPAY
        self._done = False              # 二重実行・二重払いの防止

    def drop(self, keys, reasons: dict = None) -> list:
        """付けられないと分かったメニューを注文から外し、お代も引く。

        外さずに残すと、「この項目は実行しても変わりません」と伝えたうえで
        そのメニューのお代まで受け取ることになる(コイン2億＋メダル50万で、
        メダルを付けられないと分かっていたのにメダル分も払われた)。
        戻り値は外したメニュー名。
        """
        gone = [k for k in self.keys if k in set(keys)]
        if not gone:
            return []
        self.keys = [k for k in self.keys if k not in set(gone)]
        self.item_prices = tsum_daiko.compute_item_prices(self.keys)
        if not (self.admin_free or self.free_ticket):
            self.total_price = sum(self.item_prices.values())
        # 外したメニューのためだけに聞いた数字は持ち越さない。
        asked = {kind for kind, *_ in self.inputs()}
        self.values = {k: v for k, v in self.values.items() if k in asked}
        if tsum_daiko.MEDAL not in asked:
            self.medal_probed = 0
            self.medal_legacy_end = False
        if tsum_daiko.COIN not in asked:
            self.coin_probed = 0
        labels = [tsum_daiko.menu_label(k) for k in gone]
        self.dropped += [(tsum_daiko.menu_label(k), list((reasons or {}).get(k) or []))
                         for k in gone]
        return labels

    # ---- 指定が要るもの ----

    def inputs(self) -> list:
        """このご注文で数字を聞く項目。"""
        return tsum_daiko.needs_inputs(self.keys)

    @property
    def needs_tsum(self) -> bool:
        return tsum_daiko.needs_tsum(self.keys)

    def missing(self) -> list:
        """先に進む前に決めてもらう必要があるもの。

        対象のツムはここには入れない。アプリの『マイツム』設定をそのまま使い、
        ログインした後に読み取って確認してもらう。
        """
        return [label for kind, label, *_ in self.inputs()
                if self.values.get(kind) is None]

    def params(self) -> dict:
        """実行側へ渡す指定内容。"""
        out = {"tsum_id": int(self.tsum_id or 0)}
        out.update({kind: int(value) for kind, value in self.values.items()})
        if self.medal_probed:
            # 支払いの前の確かめで付けたメダル。本番ではこのぶんを抜いて付ける。
            out[tsum_daiko.MEDAL_PROBED] = int(self.medal_probed)
        if self.coin_probed:
            # 支払いの前の確かめで付けたコイン。本番ではこのぶんを抜いて付ける。
            out[tsum_daiko.COIN_PROBED] = int(self.coin_probed)
        if self.medal_legacy_end:
            out[tsum_daiko.MEDAL_LEGACY_END] = 1
        return out

    # ---- 表示 ----

    def summary(self) -> str:
        return tsum_daiko.summary(self.keys)

    def menu_lines(self) -> str:
        lines = []
        for key in self.keys:
            price = self.item_prices.get(key, 0)
            lines.append(f"・{tsum_daiko.menu_label(key)}"
                         + ("" if self.total_price <= 0 else f" {price:,}円"))
        return "\n".join(lines)

    def payload(self) -> dict:
        """後追いで代行し直すのに要るもの。

        LINEのメールアドレスとパスワードは入れない。入れるのはリフレッシュ
        トークンだけで、これは渡し終わった時点で消す(_scrub_token)。
        """
        return {"keys": list(self.keys), "refresh_token": self.refresh_token,
                "guest_id": self.guest_id, "guest_password": self.guest_password,
                "params": self.params(), "total_price": int(self.total_price),
                "item_prices": {k: int(v) for k, v in self.item_prices.items()},
                "account": self.account,
                "free_ticket": self.free_ticket, "admin_free": self.admin_free}

    @property
    def is_guest(self) -> bool:
        return bool(self.guest_id)

    def confirm_embed(self) -> discord.Embed:
        lines = ["ご希望のメニュー", self.menu_lines()]
        entries = self.inputs()
        if entries:
            lines.append("")
        for kind, label, limit, limit_label, unit in entries:
            value = self.values.get(kind)
            lines.append(f"{label}: "
                         + (f"{int(value):,}{unit}" if value is not None else "未指定"))
        if self.needs_tsum:
            if self.tsum_id:
                lines.append(f"対象のツム: {tsum_daiko.tsum_name(int(self.tsum_id))}")
            else:
                lines.append("対象のツム: アプリで「マイツム」に設定しているツム")
                lines.append("　上げたいツムをマイツムにしてから進んでください。"
                             "ログイン後に確認できます。")
        note = tsum_daiko.hearts_note(self.keys)
        if note:
            lines.append(note)

        lines.append("")
        if self.admin_free:
            lines.append("管理者の動作確認のため、お支払いはありません（売上にも入りません）。")
        elif self.free_ticket:
            lines.append("無料利用券が適用されるため、お支払いはありません。")
        elif self.total_price > 0:
            lines.append(f"お支払い金額: {self.total_price:,}円")
        else:
            lines.append("お支払いはありません。")

        missing = self.missing()
        if missing:
            lines.append(f"\n{'、'.join(missing)}を指定すると、LINEログインへ進めます。")
        else:
            lines.append("\n下のボタンからログインしてください。")
            lines.append("・LINE連携している垢 → 「LINEログイン」")
            lines.append("・ゲスト（LINE未連携）→ 「ゲストログインして進む」")
            lines.append("ログイン情報・番号は保存しません。")
        return discord.Embed(title="ご注文内容", description="\n".join(lines),
                             color=0x2f9e6e)


class OrderInputModal(ui.Modal, title="ご注文の内容"):
    """枚数・レベル・スコアをまとめて聞く。

    聞く項目は選んだメニューで変わる(セットのように値が決まっているものは
    聞かない)。半角の数字だけを受ける。空欄はその項目の上限。
    """

    def __init__(self, order: "TsumOrder", view: "OrderView"):
        super().__init__(timeout=600)
        self.order = order
        self.view_ref = view
        self.fields = []
        for kind, label, limit, limit_label, unit in order.inputs():
            current = order.values.get(kind)
            field = ui.TextInput(
                label=f"{label}（0〜{limit_label} / 空欄で上限）"[:45],
                required=False, max_length=13,
                default=str(current) if current is not None else None)
            self.add_item(field)
            self.fields.append((kind, label, limit, limit_label, unit, field))

    async def on_submit(self, interaction: discord.Interaction):
        picked = {}
        for kind, label, limit, limit_label, unit, field in self.fields:
            raw = field.value.strip().replace(",", "").replace("，", "")
            if raw == "":
                picked[kind] = limit
                continue
            if not raw.isdigit():
                return await interaction.response.send_message(
                    f"{label}は半角の数字で入力してください。", ephemeral=True)
            value = int(raw)
            if value > limit:
                return await interaction.response.send_message(
                    f"{label}は{limit_label}までで指定してください。", ephemeral=True)
            picked[kind] = value
        self.order.values.update(picked)
        self.view_ref.refresh()
        await interaction.response.edit_message(embed=self.order.confirm_embed(),
                                                view=self.view_ref)


class OrderView(ui.View):
    """注文内容の確認画面。指定が要るものはここで埋めてから先へ進む。"""

    def __init__(self, order: TsumOrder):
        super().__init__(timeout=600)
        self.order = order
        self.input_button = None
        if order.inputs():
            self.input_button = ui.Button(label="内容を入力",
                                          style=discord.ButtonStyle.secondary)
            self.input_button.callback = self._input
            self.add_item(self.input_button)
        self.login_button = ui.Button(label="LINEログインして進む",
                                      style=discord.ButtonStyle.success)
        self.login_button.callback = self._login
        self.add_item(self.login_button)
        self.guest_button = ui.Button(label="ゲストログインして進む",
                                      style=discord.ButtonStyle.primary)
        self.guest_button.callback = self._guest_login
        self.add_item(self.guest_button)
        self.refresh()

    def refresh(self):
        """指定が済んだものはボタンの見た目に出す。未指定なら先へ進ませない。"""
        if self.input_button is not None:
            self.input_button.label = ("入力し直す" if not self.order.missing()
                                       else "内容を入力")
        self.login_button.disabled = bool(self.order.missing())
        self.guest_button.disabled = bool(self.order.missing())

    async def _input(self, interaction: discord.Interaction):
        await interaction.response.send_modal(OrderInputModal(self.order, self))

    async def _login(self, interaction: discord.Interaction):
        if self.order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        missing = self.order.missing()
        if missing:
            return await interaction.response.send_message(
                f"{'、'.join(missing)}を指定してください。", ephemeral=True)
        await interaction.response.send_modal(TsumLoginModal(self.order))

    async def _guest_login(self, interaction: discord.Interaction):
        if self.order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        missing = self.order.missing()
        if missing:
            return await interaction.response.send_message(
                f"{'、'.join(missing)}を指定してください。", ephemeral=True)
        await interaction.response.send_modal(TsumGuestLoginModal(self.order))


class TsumMenuSelect(ui.Select):
    def __init__(self, bot, admin_free: bool = False):
        prices = tsum_daiko.load_prices()
        options = []
        # 動作確認中のメニューは管理者のパネルからしか選べない。
        for key, item in tsum_daiko.menu_items(admin=admin_free):
            price = 0 if admin_free else int(prices.get(key, tsum_daiko.default_price(key)))
            # 中身はパネルに書いてあるので、ここは名前と値段だけ。
            # (ラベルはDiscord側で100文字まで。超えると選択肢ごと弾かれる)
            options.append(discord.SelectOption(
                label=f"{item['label']}-{price:,}円"[:100], value=key))
        super().__init__(placeholder="メニューを選択（複数可）", options=options,
                         min_values=1, max_values=len(options))
        self.bot = bot
        self.admin_free = admin_free

    async def callback(self, interaction: discord.Interaction):
        order = TsumOrder(self.bot, interaction.user, self.values,
                          admin_free=self.admin_free)
        await interaction.response.edit_message(
            content=None, embed=order.confirm_embed(), view=OrderView(order))


class TsumMenuSelectView(ui.View):
    def __init__(self, bot, admin_free: bool = False):
        super().__init__(timeout=300)
        self.add_item(TsumMenuSelect(bot, admin_free=admin_free))


class TsumLoginModal(ui.Modal):
    """LINEのログイン情報。ここで受け取るだけで、どこにも保存しない。"""

    line_id = ui.TextInput(label="LINEのメールアドレス",
                           placeholder="example@example.com", required=True, max_length=200)
    password = ui.TextInput(label="LINEのパスワード",
                            style=discord.TextStyle.short, required=True, max_length=200)

    def __init__(self, order: TsumOrder):
        super().__init__(title="LINEログイン", timeout=300)
        self.order = order

    async def on_submit(self, interaction: discord.Interaction):
        order = self.order
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        if interaction.user.id in _BUSY:
            return await interaction.response.send_message(
                "すでに処理中です。終わってからもう一度お試しください。", ephemeral=True)
        # 0円で通す道は、ここでもう一度だけ管理者か確かめる。押した人にしか
        # 見えない画面から来るとはいえ、ただで通す判断は入口任せにしない。
        if order.admin_free and interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("権限がありません。",
                                                           ephemeral=True)

        await interaction.response.send_message("LINEにログインしています。",
                                                ephemeral=True)
        _BUSY.add(interaction.user.id)
        # 下見のあとは支払い画面へ移る。代行そのものは別のログインで流すので、
        # ここで張った接続はどの道を通っても閉じる(finally)。
        runner = None
        try:
            order.refresh_token = await tsum_daiko.line_login(
                self.line_id.value, self.password.value,
                captcha_callback=make_captcha_callback(interaction),
                pin_callback=make_pin_callback(interaction))
            # 支払いの前にゲーム側まで通しておく。ここで落ちるアカウントから
            # お代だけ受け取ってしまうと、返金の手間だけが残る。
            # イベント参加中の口のメダルは、管理者もお客さんも「プラスツムでプレイ」
            # で投げる(tsum_daiko の _event_medal_mode)。medal_trial は、環境変数
            # TSUM_MEDAL_EVENT_TRIAL=1 のときだけ管理者の動作確認で送り方を1つずつ
            # 試す印(tsum_daiko の _medal_event_trial)。既定では何もしない。
            runner = tsum_daiko.TsumRunner(order.refresh_token, params=order.params(),
                                           medal_trial=order.admin_free)
            await runner.open()
            order.account = runner.account_line()
            # レベルを上げる対象は、アプリで『マイツム』に設定しているツム。
            # 名前では衣装違いを見分けられないので、お客さん自身がアプリで
            # 指してくれたものをそのまま使う。支払いの前に読んで確認してもらう。
            if order.needs_tsum:
                mytsum = runner.mytsum()
                if mytsum is None:
                    return await self._fail(
                        interaction,
                        "アプリで「マイツム」に設定しているツムを確認できませんでした。\n"
                        "お代はいただいていません。レベルを上げたいツムを"
                        "マイツムに設定してから、もう一度お試しください。")
                order.tsum_id = mytsum.tsumid
                order.tsum_line = runner.mytsum_line()
            # ハートはこちらで買わない(ルビーを勝手に使わない)。足りないまま
            # 受け取ると途中で止まってしまうので、支払いの前に数えておく。
            need = tsum_daiko.required_hearts(order.keys)
            have = runner.hearts()
            if have < need:
                # 数えるのは手持ちだけ。プレゼントBOXのぶんは受け取るまで
                # プレイに使えないので、足りない理由と一緒に伝える。
                box = runner.hearts_in_box()
                extra = (f"\nプレゼントBOXに{box:,}個ありますが、アプリで"
                         "受け取るまでプレイには使えません。") if box else ""
                return await self._fail(
                    interaction,
                    f"ハートが足りません（必要 {need}個 / 今 {have}個）。{extra}\n"
                    "お代はいただいていません。ハートを用意してから、"
                    "もう一度お試しください。")
            # 「いまのほうが高い」「開催していない」など、やっても何も起きない
            # ものはここで見ておく。受け取ってから伝えるのはこちらの都合。
            # 全部が空振りなら断る。一部だけなら、お伝えしたうえでご判断いただく
            # (セット商品は中身がいくつもあり、残りには意味がある)。
            notes, dead = await runner.preflight(order.keys)
            order.medal_probed = runner.medal_probed
            order.coin_probed = runner.coin_probed
            order.medal_legacy_end = runner.medal_legacy_end
            all_dead = bool(dead) and set(dead) == set(order.keys)
            if runner.medal_block:
                # メダルを付けられない(イベント参加中、または1プレイ試して増えなかった)。
                # メダルはお代をいただく前に外す(全部空振りなら注文ごと止める)。
                # 理由を追えるよう運営側にも残す。
                await log_medal_probe_block(interaction.client, interaction.user, runner,
                                            continued=not all_dead)
            elif isinstance(runner.debug, dict) and runner.debug.get("medal_trials"):
                # 管理者の動作確認で、イベント参加中の口にメダルが入る送り方が見つかった。
                # どの送り方で・gameStart が何を返して入ったのかを、同じ形で残す。
                await log_medal_probe_block(
                    interaction.client, interaction.user, runner,
                    title="メダルの事前確認：イベント参加中の口で入る送り方が見つかりました"
                          "（以降の注文はこの送り方で投げます）")
            if all_dead:
                return await self._fail(
                    interaction,
                    "\n".join(notes) + "\nお代はいただいていません。"
                    "ご注文の内容をご確認のうえ、もう一度お試しください。")
            if dead:
                # 丸ごと空振りのメニューは注文から外す(お代もいただかない)。
                order.drop(dead, runner.notes_by_key)
            # 残すのは、セットの中身の一部だけが空振りになる文(セットの残りには意味がある)。
            order.preflight_notes = [note for key, key_notes in runner.notes_by_key.items()
                                     if key not in dead for note in key_notes]
        except TimeoutError as e:
            return await self._fail(interaction, str(e))
        except tsum_daiko.TsumLoginError as e:
            return await self._fail(
                interaction,
                f"ツムツムにログインできませんでした。\n```{str(e)[:300]}```\n"
                "時間をおいてもう一度お試しください。")
        except tsum_api.LineVerificationRequired as e:
            # メアド・パスワードは通っている。疑わせない。
            return await self._fail(
                interaction,
                f"{e}\n"
                "LINEアプリを開いたまま、もう一度お試しください。")
        except tsum_api.LineCredentialError as e:
            return await self._fail(
                interaction,
                f"LINEにログインできませんでした。\n```{str(e)[:300]}```\n"
                "メールアドレスとパスワードをご確認ください。")
        except Exception as e:
            return await self._fail(
                interaction,
                f"LINEのログインに失敗しました: {type(e).__name__}: {str(e)[:200]}\n"
                "LINEと連携せずに遊んでいる場合は、アプリでLINE連携をして"
                "からご利用ください。")
        finally:
            _BUSY.discard(interaction.user.id)
            if runner is not None:
                await runner.close()

        await self._to_payment(interaction, order)

    @staticmethod
    async def _fail(interaction: discord.Interaction, text: str):
        try:
            await interaction.edit_original_response(content=text, attachments=[],
                                                     embed=None, view=None)
        except discord.HTTPException:
            pass

    @staticmethod
    async def _to_payment(interaction: discord.Interaction, order: TsumOrder):
        """ログイン・確認できた。0円ならそのまま実行、有料なら支払い方法を選ばせる。

        LINE・ゲスト共通。ゲストは支払い前に垢を読めないぶん、マイツムや空振りの
        事前確認が入らないだけで、案内の中身はLINEと同じ。
        """
        if order.total_price <= 0:
            order._done = True
            note = "代行を実行しています。少々お待ちください。"
            if order.needs_tsum:
                note = (f"レベルを上げるツム（マイツム）: {order.tsum_line}\n" + note)
            if order.preflight_notes:
                # 0円は支払い画面を通らない。ここで出さないと、空振りする項目を
                # 誰も見ないまま実行されてしまう。
                note = "\n".join(order.preflight_notes) + "\n" + note
            if order.dropped:
                note = "\n".join(_dropped_lines(order)) + "\n" + note
            await interaction.edit_original_response(
                content=note, attachments=[], embed=None, view=None)
            return await run_now(interaction, order, paid=0,
                                 method=payments.FREE, pay_note=None)

        if not payments.available_methods():
            return await TsumLoginModal._fail(
                interaction,
                "現在ご利用いただける支払い方法がありません。\n" + support.contact_line())

        note = [order.account, "", "ご注文内容", order.menu_lines()]
        if order.dropped:
            note += [""] + _dropped_lines(order)
        if order.needs_tsum:
            note += ["", f"レベルを上げるツム（マイツム）: {order.tsum_line}",
                     "違うツムのときは、支払わずにアプリでマイツムを変えて"
                     "やり直してください。"]
        if order.preflight_notes:
            # 空振りになる項目。払う前に見てもらう(払ってから言うのでは遅い)。
            note += ["", "ご確認ください"] + order.preflight_notes + [
                "この項目は実行しても変わりません。よろしければお進みください。"]
        embed = payments.picker_embed(
            order.total_price, title="お支払い方法の選択", note="\n".join(note))
        await interaction.edit_original_response(
            content=None, attachments=[], embed=embed,
            view=payments.MethodPicker(_make_method_picker(order)))


class TsumGuestLoginModal(ui.Modal):
    """引き継ぎ番号でのゲストログイン。番号とパスワードを受け取るだけで保存しない。

    実際のログイン(垢の入れ替え)は代行の直前に一度だけ行い、それまではお客さんの
    端末をそのままにしておく。支払いの前には dryRun で番号が正しいかだけ確かめる。
    """

    migration_id = ui.TextInput(
        label="引き継ぎID", required=True, max_length=32,
        placeholder="ゲーム設定 → ゲスト → 引き継ぎ番号（8文字）")
    password = ui.TextInput(
        label="引き継ぎパスワード", style=discord.TextStyle.short,
        required=True, max_length=64)

    def __init__(self, order: TsumOrder):
        super().__init__(title="ゲストログインして進む", timeout=300)
        self.order = order

    async def on_submit(self, interaction: discord.Interaction):
        order = self.order
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        if interaction.user.id in _BUSY:
            return await interaction.response.send_message(
                "すでに処理中です。終わってからもう一度お試しください。", ephemeral=True)
        if order.admin_free and interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("権限がありません。",
                                                           ephemeral=True)

        await interaction.response.send_message("引き継ぎ番号を確認しています。",
                                                ephemeral=True)
        _BUSY.add(interaction.user.id)
        try:
            # 番号は消費しない(dryRun)。ここで当たりだけ確かめておく。
            await tsum_daiko.validate_guest(self.migration_id.value,
                                            self.password.value)
        except tsum_daiko.TsumLoginError as e:
            return await TsumLoginModal._fail(
                interaction,
                f"ゲストログインできませんでした。\n```{str(e)[:300]}```\n"
                "引き継ぎIDとパスワードをご確認ください。")
        except Exception as e:
            return await TsumLoginModal._fail(
                interaction,
                f"確認に失敗しました: {type(e).__name__}: {str(e)[:200]}\n"
                "時間をおいてもう一度お試しください。")
        finally:
            _BUSY.discard(interaction.user.id)

        order.guest_id = self.migration_id.value.strip()
        order.guest_password = self.password.value
        order.account = "ゲストログイン（アカウントは代行時に読み取り）"
        if order.needs_tsum:
            order.tsum_line = "アプリで「マイツム」に設定しているツム（代行時に読み取り）"
        # 支払い前の案内はLINEログインと共通。
        await TsumLoginModal._to_payment(interaction, order)


def _make_method_picker(order: TsumOrder):
    async def on_pick(interaction: discord.Interaction, method_id: str):
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        order.method = method_id
        return await interaction.response.send_modal(TsumPaymentModal(order, method_id))

    return on_pick


class TsumPaymentModal(ui.Modal):
    """リンク方式(PayPay / Kyash)の支払い入力。"""

    def __init__(self, order: TsumOrder, method: str):
        m = payments.method(method)
        super().__init__(title=f"お支払い（{m.label}）"[:45])
        self.order = order
        self.method = method
        self.link = ui.TextInput(
            label=f"{m.label}リンク（{order.total_price:,}円）"[:45],
            placeholder=m.placeholder, required=True)
        self.add_item(self.link)
        self.link_pw = None
        if method == payments.PAYPAY:
            self.link_pw = ui.TextInput(label="リンクのパスワード（なければ空欄）",
                                        required=False)
            self.add_item(self.link_pw)

    async def on_submit(self, interaction: discord.Interaction):
        """支払いの受け取りから代行まで。試行の記録は必ず開いて必ず閉じる。

        出口がいくつもあるので、締めは finally に置く。1つ書き漏らすと
        そこだけ「誰のものか分からない入金」に戻ってしまう。
        """
        order = self.order
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        attempt = await payment_attempts.record_async(
            KIND, interaction.user.id, amount=int(order.total_price), method=self.method,
            link=self.link.value.strip(), summary=order.summary(),
            guild_id=interaction.guild.id if interaction.guild else None,
            channel_id=interaction.channel.id if interaction.channel else None,
            payload=order.payload())
        hold = None
        try:
            # 同じリンクを見張り(または別の画面)が持っていないか先に確かめる。
            # ここを通さずに受け取ると、入金1回でコインを2回入れることになる。
            hold = await payments.hold_link_for(
                interaction, KIND, self.link.value.strip(), attempt)
            if hold is None:
                return
            await self._submit(interaction, attempt)
        finally:
            await payment_attempts.finish_async(attempt)
            await link_orders.release_link(hold)

    async def _submit(self, interaction: discord.Interaction, attempt: str):
        order = self.order
        await interaction.response.defer(ephemeral=True, thinking=True)
        passcode = (self.link_pw.value.strip() or None) if self.link_pw else None

        async def notify_pending(deadline: float):
            await notify_payment_pending(
                # 締め切りは見張りが諦める時刻。支払い画面が保留を待つ数分を
                # 見せると、過ぎた時点でもう駄目だと思わせてしまう。
                interaction, time.time() + WATCH_MINUTES * 60, amount=order.total_price,
                title="ツムツム代行のお支払いが保留中です",
                detail=f"承認され次第、自動で代行（{order.summary()}）を開始します。",
                footer="承認が遅れても、確認でき次第そのまま自動で代行します",
                ephemeral_hint="DMを確認して、「承認する」を押してください。承認され次第、代行を開始します。",
                app_name=payments.method_label(self.method))

        state = {}
        try:
            paid = await payments.receive_link_payment(
                self.method, self.link.value.strip(), passcode=passcode,
                min_amount=order.total_price, on_pending=notify_pending,
                client=interaction.client, state=state,
                buyer=interaction.user, kind="ツムツム代行")
        except payments.PaymentNotRegistered as e:
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await interaction.followup.send(str(e), ephemeral=True)
        except payments.PaymentError as e:
            # 決着しなかった。リンクがまだ生きている(保留・承認待ち・通信不良)なら
            # 注文を捨てずに見張りへ渡す。ここで捨てると、あとから承認されたお金
            # だけがこちらに入って代行が走らない事故になる。
            if getattr(e, "watchable", False) and await self._watch_pending(interaction, e):
                await payment_attempts.resolve_async(attempt, payment_attempts.WATCHING, str(e))
                return
            if getattr(e, "accepted", False):
                # 受け取りは投げてある(=あとから入金しうる)のに、見張りにも
                # 載せられなかった。ここが最後の砦。やり直しは促さない(二重払い)。
                job = self._job(interaction, paid=int(order.total_price), pay_note=None)
                await job.send_trouble_log(
                    "受け取りのリクエストは送信済みですが、見張りに載せられませんでした。"
                    f"{getattr(e, 'watch_note', '') or e} "
                    "入金されていれば、手動で代行するか返金してください。")
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.DROPPED,
                    f"受け取り送信済みだが見張りに載せられず: {getattr(e, 'watch_note', '') or e}")
                return await interaction.followup.send(
                    str(e) if isinstance(e, payments.PaymentUnsure) else
                    ("受け取りのリクエストは送信済みですが、処理を完了できませんでした。\n"
                     "**お代をいただいている可能性があります。もう一度支払わないでください。**\n"
                     "こちらで確認して対応します。\n" + support.contact_line()),
                    ephemeral=True)
            if isinstance(e, payments.PaymentAuthError):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
                return await interaction.followup.send(str(e), ephemeral=True)
            if isinstance(e, payments.PaymentPending):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, "承認されませんでした")
                return await interaction.followup.send(
                    "支払いがまだ承認されていません。PayPayアプリで承認してから、もう一度お試しください。",
                    ephemeral=True)
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await interaction.followup.send(
                f"支払いを確認できませんでした。\n```{e}```\n"
                "**お代はいただいていません。** もう一度お試しいただくか、\n"
                + support.contact_line(), ephemeral=True)

        await payment_attempts.resolve_async(attempt, payment_attempts.DELIVERED, f"{paid:,}円")
        # このリンクのお金はここで受け取った。同じリンクを持っている見張りが
        # あれば畳む(畳まないと、見張りが同じ入金でもう一度コインを入れる)。
        try:
            for closed in await link_orders.record_screen_receipt(
                    KIND, interaction.user.id, self.link.value.strip(), paid=paid,
                    method=self.method, summary=order.summary(),
                    guild_id=interaction.guild.id if interaction.guild else None,
                    channel_id=interaction.channel.id if interaction.channel else None):
                log.info("同じリンクの見張りを畳みました: %s", closed.get("id"))
        except Exception as e:
            log.warning("ツムツムの受け取り記録に失敗: %s", e)
        # 買い直しで置き去りになった見張りを畳む(渡し終わったものを
        # 「保留中」に並べ続けない)。受け取り送信済みの注文には触らない。
        try:
            for closed in await link_orders.cancel_superseded(
                    interaction.user.id, KIND, int(order.total_price)):
                log.info("ツムツムの注文を畳みました: %s", closed.get("id"))
        except Exception as e:
            log.warning("ツムツムの見張り整理に失敗: %s", e)

        try:
            await interaction.followup.send(
                f"{paid:,}円を受け取りました。代行を開始します。", ephemeral=True)
        except discord.HTTPException:
            pass
        await run_now(interaction, order, paid=paid, method=self.method,
                      pay_note=self.link.value.strip()[:200])

    def _job(self, interaction, *, paid: int, pay_note) -> TsumJob:
        order = self.order
        return TsumJob(interaction.client, interaction.user, order.keys,
                       order.refresh_token, params=order.params(),
                       total_price=order.total_price, paid=paid,
                       method=self.method, free_ticket=order.free_ticket,
                       admin_free=order.admin_free,
                       guild=interaction.guild,
                       channel=interaction.channel, pay_note=pay_note,
                       item_prices=order.item_prices, account=order.account)

    async def _watch_pending(self, interaction: discord.Interaction, error) -> bool:
        """決着しなかった支払いを見張りに引き継ぐ。引き継げたら True。

        承認が遅れただけの注文をここで捨てないためのもの。以降は見張りループが
        受け取りと代行まで面倒を見るので、この画面はもう使えないようにする。
        """
        order = self.order
        if self.method != payments.PAYPAY:
            error.watch_note = "PayPay以外は後追いの見張りに対応していません。"
            return False
        accepted = bool(getattr(error, "accepted", False))
        try:
            watched = await link_orders.create_order(
                KIND, interaction.user.id, self.link.value.strip(),
                amount_jpy=int(order.total_price), payload=order.payload(),
                method=self.method, minutes=WATCH_MINUTES,
                passcode=(self.link_pw.value.strip() or None) if self.link_pw else None,
                accepted=accepted, summary=order.summary(),
                guild_id=interaction.guild.id if interaction.guild else None,
                channel_id=interaction.channel.id if interaction.channel else None)
        except Exception as e:
            log.warning("ツムツムの見張り登録に失敗: %s", e)
            error.watch_note = f"見張りへの登録に失敗しました: {str(e)[:150]}"
            return False
        if not watched:
            error.watch_note = "見張りへの登録に失敗しました。"
            return False

        order._done = True      # 同じ内容をこの画面から走らせない(二重代行防止)
        # DMはもう送らない。保留の案内は最初の1通で出し切っていて、ここで
        # 送るのは同じことの言い直しにしかならない。受け取った側からは
        # 「何度も同じことを言われるのに進まない」に見える。
        # 投げ直しは裏で続くので、次にDMするのは完了したときだけにする。
        try:
            await interaction.followup.send(
                "承認をお待ちしています。**このまま閉じて大丈夫です。**\n"
                "承認が確認でき次第、自動で代行してDMでお知らせします。\n"
                "支払い直す必要はありません。\n"
                f"注文番号: `{watched['id']}`", ephemeral=True)
        except discord.HTTPException:
            pass
        return True


async def run_now(interaction: discord.Interaction, order: TsumOrder, *,
                  paid: int, method: str, pay_note):
    """支払いが済んだ(または0円の)注文をその場で流す。"""
    order._done = True
    job = TsumJob(interaction.client, interaction.user, order.keys, order.refresh_token,
                  params=order.params(), total_price=order.total_price, paid=paid,
                  method=method, free_ticket=order.free_ticket,
                  admin_free=order.admin_free,
                  guild=interaction.guild, channel=interaction.channel,
                  pay_note=pay_note, item_prices=order.item_prices,
                  account=order.account,
                  guest_id=order.guest_id, guest_password=order.guest_password)

    async def progress(key):
        try:
            await interaction.edit_original_response(
                content=f"{tsum_daiko.menu_label(key)} を処理しています。",
                attachments=[], embed=None, view=None)
        except discord.HTTPException:
            pass

    try:
        dm_ok, outcome = await job.execute(on_progress=progress)
    except Busy:
        return await _tell(interaction, "すでに処理中です。終わってからもう一度お試しください。")
    except tsum_daiko.TsumLoginError as e:
        await job.send_trouble_log(f"ツムツムにログインできませんでした: {e}")
        return await _tell_embed(interaction, support.trouble_embed(
            support.NEEDS_SUPPORT, "ツムツムにログインできませんでした",
            support.PAID_AND_STUCK if paid > 0 else
            "時間をおいてもう一度お試しください。", amount=paid or None,
            summary=order.summary()))
    except Exception as e:
        log.exception("ツムツム代行の実行に失敗: %s", e)
        await job.send_trouble_log(f"想定外のエラー: {type(e).__name__}: {e}")
        return await _tell_embed(interaction, support.trouble_embed(
            support.NEEDS_SUPPORT, "代行の処理に失敗しました",
            support.PAID_AND_STUCK if paid > 0 else
            "時間をおいてもう一度お試しください。", amount=paid or None,
            summary=order.summary()))

    embed = job.result_embed(outcome)
    if dm_ok:
        await _tell(interaction, "代行が完了しました。結果はDMをご確認ください。")
    else:
        await _tell_embed(interaction, embed)


async def _tell(interaction: discord.Interaction, text: str):
    try:
        await interaction.edit_original_response(content=text, attachments=[],
                                                 embed=None, view=None)
    except discord.HTTPException:
        try:
            await interaction.followup.send(text, ephemeral=True)
        except discord.HTTPException:
            pass


async def _tell_embed(interaction: discord.Interaction, embed: discord.Embed):
    try:
        await interaction.edit_original_response(content=None, attachments=[],
                                                 embed=embed, view=None)
    except discord.HTTPException:
        try:
            await interaction.followup.send(embed=embed, ephemeral=True)
        except discord.HTTPException:
            pass


# --- パネル(常設) ----------------------------------------------------------

def panel_embed() -> discord.Embed:
    prices = tsum_daiko.load_prices()
    blocks = []
    # 動作確認中(admin_only)のメニューはここには出さない。売り出すときに
    # tsum_daiko.MENUS の admin_only を外すと、このパネルにも並ぶ。
    for key, item in tsum_daiko.menu_items():
        price = int(prices.get(key, tsum_daiko.default_price(key)))
        # 「名前-価格円」+ 説明。中身がいくつもあるセット商品は「・」で縦に
        # 並べる(1行に詰めると読めない)。単品はそのまま1行で出す。
        detail = tsum_daiko.menu_detail(key)
        body = "\n".join(f"・{line}" for line in detail) \
            if len(detail) > 1 else "".join(detail)
        blocks.append(f"**{item['label']}-{price:,}円**\n" + body)
    return discord.Embed(
        title="ツムツム代行メニュー",
        description=("下のボタンからメニューを選んでご注文ください。\n\n"
                     + "\n\n".join(blocks)),
        color=0x2f9e6e)


class TsumPanelView(ui.View):
    """常設パネル。再起動をまたいで押せるよう custom_id を固定する。"""

    def __init__(self, bot=None):
        super().__init__(timeout=None)
        self.bot = bot

    @ui.button(label="注文する", style=discord.ButtonStyle.success,
               custom_id="tsum:order")
    @panels.guard
    async def order(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_message(
            "ご希望のメニューを選択してください。",
            view=TsumMenuSelectView(interaction.client), ephemeral=True)


def admin_free_panel_embed() -> discord.Embed:
    """管理者の動作確認パネル。

    代行が本当に通るかは、最後まで流してみないと分からない。価格を0円に
    直して確かめると、その間はお客さんも0円で買えてしまう。押せる人を管理者に
    限ったパネルを別に置いて、価格はそのままで確認できるようにする。
    """
    lines = [f"・{item['label']}"
             for _key, item in tsum_daiko.menu_items(admin=True)]
    return discord.Embed(
        title="【管理者用】ツムツム代行",
        description="管理者専用。**全メニュー0円**で動作確認できます。\n\n" + "\n".join(lines),
        color=0xffcc00)


class TsumAdminFreePanelView(ui.View):
    def __init__(self, bot=None):
        super().__init__(timeout=None)
        self.bot = bot

    @ui.button(label="動作確認する（全メニュー0円）", style=discord.ButtonStyle.secondary,
               custom_id="tsum:admin_free")
    @panels.guard
    async def order(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message(
                "これは管理者が動作確認するためのパネルです。"
                "ご注文は通常のパネルからお願いします。", ephemeral=True)
        await interaction.response.send_message(
            "動作確認するメニューを選択してください（0円で流します）。",
            view=TsumMenuSelectView(interaction.client, admin_free=True),
            ephemeral=True)


# --- 入金確認後の後追い実行 ------------------------------------------------

RELOGIN_PROMPT = ("お預かりしたLINEのログイン情報が使えなくなっていました"
                  "（有効期限切れ・パスワード変更など）。")


def _get_order(order: dict):
    return link_orders.get_order(order["id"])


async def _mark_order(order: dict, status: str, **fields):
    return await link_orders.mark_order(order["id"], status, **fields)


async def _clear_run_mark(order: dict):
    """「走り出した」印を戻す。ゲームに何も投げていないと分かったときだけ。"""
    payload = dict(order.get("payload") or {})
    if not payload.pop("run_started_at", None):
        return
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "paid", payload=payload)
    except Exception as e:
        log.warning("ツムツムの実行印を戻せませんでした(%s): %s", order.get("id"), e)


async def _report_blocked_rerun(bot, order: dict):
    """二重実行を止めたことを管理者に知らせる(同じ注文につき1回だけ)。

    見張りは何度か試してから諦めるので、そこまで待つと気付くのが遅れる。
    入金は受け取っている以上、止めたこと自体をすぐ人に伝える。
    """
    payload = dict(order.get("payload") or {})
    if payload.get("rerun_reported"):
        return
    payload["rerun_reported"] = True
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "paid", payload=payload)
    except Exception:
        pass
    embed = discord.Embed(
        title="ツムツム代行の二重実行を止めました",
        description=("一度始めた代行が、終わったと記録される前に中断していました。"
                     "もう一度回すとガチャを二重に消費するため、"
                     "自動での流し直しを止めています。\n"
                     "ゲーム側に反映されているかを確認して、必要なら手で流し直すか"
                     "返金してください。"),
        color=0xff3333, timestamp=discord.utils.utcnow())
    embed.add_field(name="注文番号", value=f"`{order.get('id')}`", inline=True)
    embed.add_field(name="金額",
                    value=f"{int(order.get('paid_amount') or order.get('amount_jpy') or 0):,}円",
                    inline=True)
    embed.add_field(name="購入者", value=f"<@{order.get('user_id')}>", inline=True)
    embed.add_field(name="内容", value=str(order.get("summary") or "")[:1024], inline=False)
    for ch_id in (private_log_channel_id(), log_channel_id()):
        if ch_id and await _send_log(bot, ch_id, "ツムツムの二重実行ログ", embed=embed):
            break
    for uid in ADMIN_USER_IDS:
        try:
            admin = bot.get_user(uid) or await bot.fetch_user(uid)
            await admin.send(embed=embed)
        except Exception:
            continue


async def _scrub_token(order: dict):
    """渡し終わった注文からリフレッシュトークンを落とす。

    もう使う予定が無いものを持ち続けない。注文そのものは調査用に残る。
    """
    payload = dict(order.get("payload") or {})
    if not payload.get("refresh_token") and not payload.get("guest_password"):
        return
    payload["refresh_token"] = ""
    # 引き継ぎ番号は代行で消費済み(新しい番号は本人へ渡した)。控えを残さない。
    payload["guest_id"] = ""
    payload["guest_password"] = ""
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "done", payload=payload)
    except Exception as e:
        log.warning("ツムツムの注文からトークンを消せませんでした(%s): %s",
                    order.get("id"), e)


async def offline_deliver(bot, order: dict) -> bool:
    """入金が確認できたツムツムの注文を、後追いで代行する。

    自販機と違って、ここでの「お渡し」はゲーム側の残高を動かすこと。一度通った
    注文をDMが送れなかったからと False で返すと、見張りが同じ注文をもう一度
    流してガチャを二重に回してしまう。だから代行が通った時点で必ず True にし、
    DMが送れなかったときは買った場所で声をかけるだけにする。

    False を返すのは、まだ一度も流していないと分かっているときだけ。ログイン
    できないときは NeedsCustomerInput にして、本人にログインし直してもらう。
    """
    payload = order.get("payload") or {}
    keys = list(payload.get("keys") or [])
    token = payload.get("refresh_token") or ""
    paid = int(order.get("paid_amount") or order.get("amount_jpy") or 0)
    method = order.get("method") or payments.PAYPAY

    try:
        user = bot.get_user(int(order["user_id"])) or await bot.fetch_user(int(order["user_id"]))
    except (discord.HTTPException, KeyError, TypeError, ValueError):
        return False
    guest_id = payload.get("guest_id") or ""
    guest_password = payload.get("guest_password") or ""
    if not keys:
        raise RuntimeError("注文の内容が読めませんでした（メニューが空です）")
    if not token and not guest_id:
        # 渡し終わった後にもう一度呼ばれた等。黙って通すと二重代行になる。
        await _ask_relogin(bot, order)
        raise link_orders.NeedsCustomerInput(
            "ログイン情報がありません", prompt=RELOGIN_PROMPT)

    if payload.get("run_started_at"):
        # 一度始めた注文が、終わったと記録される前に落ちた(再デプロイ等)。
        # 黙って流し直すとガチャをもう一度回すことになる(お客さんのコインが
        # 減る)ので、ここで止めて人に見てもらう。
        await _report_blocked_rerun(bot, order)
        raise RuntimeError(
            "この注文は一度代行を始めています。二重に回さないよう止めました。"
            "ゲーム側に反映されているかを確認してください。")
    if user.id in _BUSY:
        # その人の別の代行が走っている。少し置けば流せるので失敗にはしない。
        return False
    # 走り出したことを先に残す。ここを後回しにすると、上の判定が効かない。
    # 書いた後の注文を持ち直す(手元の写しのままだと、印を戻すときに
    # 「印が無い」と見えてしまい、戻し忘れる)。
    payload = {**payload, "run_started_at": time.time()}
    order = (await _mark_order(order, order.get("status") or "paid", payload=payload)
             or {**order, "payload": payload})

    guild = bot.get_guild(int(order["guild_id"])) if order.get("guild_id") else None
    channel = bot.get_channel(int(order["channel_id"])) if order.get("channel_id") else None
    note = [f"注文番号: `{order['id']}`"] if order.get("id") else []
    if order.get("txid"):
        note.append(f"LTC TXID: `{order['txid']}`")
    elif order.get("link"):
        note.append(f"{payments.method_label(method)}リンク: {str(order['link'])[:200]}")

    job = TsumJob(bot, user, keys, token, params=payload.get("params"),
                  total_price=int(payload.get("total_price") or paid), paid=paid,
                  method=method, free_ticket=bool(payload.get("free_ticket")),
                  admin_free=bool(payload.get("admin_free")),
                  guild=guild, channel=channel,
                  pay_note="\n".join(note) or None, order_id=order.get("id"),
                  item_prices=payload.get("item_prices"),
                  account=payload.get("account", ""),
                  guest_id=guest_id, guest_password=guest_password)
    try:
        dm_ok, _ = await job.execute()
    except Busy:
        # その人の別の代行が走っている。ゲームには何も投げていないので、
        # 走り出した印を戻してから引き下がる(次の巡回でそのまま流せる)。
        await _clear_run_mark(order)
        return False
    except tsum_daiko.TsumLoginError as e:
        # ログインで止まった = ゲームには何も投げていない。印を戻したうえで、
        # 本人にログインし直してもらう。見張り(linkwatch)は登録済みの入力画面で
        # 案内してくれるが、LTCの監視ループはそこまで面倒を見ないのでここで送る。
        await _clear_run_mark(order)
        if order.get("source") != "link":
            await _ask_relogin(bot, order)
        raise link_orders.NeedsCustomerInput(str(e)[:300], prompt=RELOGIN_PROMPT)

    # ここまで来たら代行は終わっている。預かったトークンは用済みなので手放す。
    await _scrub_token(order)
    if not dm_ok and channel is not None:
        try:
            await channel.send(
                f"{user.mention} ツムツム代行が完了しましたが、DMをお送りできませんでした。\n"
                "DMを開放していただくか、" + support.contact_line())
        except discord.HTTPException:
            pass
    return True


async def offline_release(bot, order: dict):
    """期限切れ・キャンセルの注文の後始末。預かったトークンを手放す。"""
    await _scrub_token(order)


async def _ask_relogin(bot, order: dict) -> bool:
    """ログインし直してもらうお願いを送る(LTC用。リンクは見張りが送る)。"""
    embed = support.trouble_embed(
        support.NEEDS_CODE, "LINEにログインし直してください",
        (RELOGIN_PROMPT + "\n下のボタンからもう一度ログインしてください。"
         "そのまま代行を続けます。\n\n"
         + support.PAID_NO_DEADLINE + "\n" + support.contact_short()),
        order_id=order.get("id"),
        amount=int(order.get("paid_amount") or order.get("amount_jpy") or 0),
        summary=order.get("summary") or "")
    view = TsumReloginView(order["id"])
    try:
        bot.add_view(view)
    except Exception:
        pass
    return await support.send_private(bot, order, embed, view)


class TsumReloginModal(ui.Modal, title="LINEログインのやり直し"):
    line_id = ui.TextInput(label="LINEのメールアドレス", required=True, max_length=200)
    password = ui.TextInput(label="LINEのパスワード", required=True, max_length=200)

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.order_id = order_id

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.send_message("LINEにログインしています。", ephemeral=True)
        order = link_orders.get_order(self.order_id)
        if not order:
            return await _tell(interaction, "この注文が見つかりませんでした。")
        if str(order.get("user_id")) != str(interaction.user.id):
            return await _tell(interaction, "この注文の購入者ではありません。")
        if order.get("status") == "done":
            return await _tell(interaction, "この注文はお渡し済みです。")

        try:
            token = await tsum_daiko.line_login(
                self.line_id.value, self.password.value,
                captcha_callback=make_captcha_callback(interaction),
                pin_callback=make_pin_callback(interaction))
        except TimeoutError as e:
            return await _tell(interaction, str(e))
        except tsum_api.LineVerificationRequired as e:
            # メアド・パスワードは通っている。疑わせない。
            return await _tell(
                interaction, f"{e}\nLINEアプリを開いたまま、もう一度お試しください。")
        except tsum_api.LineCredentialError as e:
            return await _tell(
                interaction,
                f"LINEにログインできませんでした。\n```{str(e)[:300]}```\n"
                "メールアドレスとパスワードをご確認ください。")
        except Exception as e:
            return await _tell(
                interaction,
                f"LINEのログインに失敗しました: {type(e).__name__}: {str(e)[:200]}\n"
                "もう一度お試しください。")

        payload = dict(order.get("payload") or {})
        payload["refresh_token"] = token
        # 本人が入れ直した = ここから改めて流す。走り出した印も戻す
        # (印が残っていると二重実行の防止が働いて、その場で止まってしまう)。
        payload.pop("run_started_at", None)
        payload.pop("rerun_reported", None)
        # 入れ直したので再試行の回数も戻して、すぐ流す。
        order = await _mark_order(order, "paid", payload=payload, awaiting_code=False,
                                  deliver_attempts=0, last_attempt_at=0, note="") or order
        try:
            ok = await offline_deliver(interaction.client, order)
        except link_orders.NeedsCustomerInput as e:
            await _mark_order(order, "paid", awaiting_code=True, note=str(e)[:300])
            return await _tell(interaction, f"{e.prompt}\n\nもう一度お試しください。")
        except Exception as e:
            log.exception("ツムツムのやり直しに失敗 (%s)", self.order_id)
            await _mark_order(order, "paid", note=str(e)[:300])
            return await _tell_embed(interaction, support.trouble_embed(
                support.NEEDS_SUPPORT, "処理を完了できませんでした",
                support.PAID_AND_STUCK, order_id=self.order_id))

        if ok:
            await _mark_order(order, "done", note="")
            return await _tell(interaction, "受け付けました。結果をDMでお送りします。")
        await _tell(interaction,
                    "処理は進めましたが、DMをお送りできませんでした。DM許可をご確認ください。")


class TsumReloginView(ui.View):
    """ログインし直し用の常設ボタン。

    見張り(linkwatch)は注文の種類ごとにこの画面を出す。にゃんこ代行の
    「引き継ぎコードを入れ直す」に当たるもの。
    """

    ask_title = "LINEにログインし直してください"
    ask_howto = ("下のボタンから**LINEのメールアドレスとパスワード**を"
                 "もう一度入力してください。そのまま代行を続けます。")

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.order_id = order_id
        button = ui.Button(label="LINEにログインし直す", style=discord.ButtonStyle.primary,
                           custom_id=f"tsum:relogin:{order_id}")
        button.callback = self._callback
        self.add_item(button)

    async def _callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(TsumReloginModal(self.order_id))


# --- 管理コマンド ----------------------------------------------------------

class PriceSetModal(ui.Modal, title="価格の設定"):
    price = ui.TextInput(label="価格（円）", placeholder="例: 300", required=True,
                         max_length=9)

    def __init__(self, key: str = None):
        super().__init__()
        self.key = key
        if key:
            self.title = f"{tsum_daiko.menu_label(key)} の価格"[:45]
            self.price.default = str(tsum_daiko.get_price(key))

    async def on_submit(self, interaction: discord.Interaction):
        raw = self.price.value.strip().replace(",", "")
        if not raw.isdigit():
            return await interaction.response.send_message(
                "価格は0以上の整数で入力してください。", ephemeral=True)
        prices = tsum_daiko.load_prices()
        prices[self.key] = int(raw)
        tsum_daiko.save_prices(prices)
        await interaction.response.send_message(
            f"「{tsum_daiko.menu_label(self.key)}」の価格を {int(raw):,}円 にしました。\n"
            "パネルの表示は `/tsum redisplay` で更新できます。", ephemeral=True)


class PriceSelectView(ui.View):
    def __init__(self):
        super().__init__(timeout=300)
        prices = tsum_daiko.load_prices()
        self.select = ui.Select(
            placeholder="価格を変更するメニューを選択",
            options=[discord.SelectOption(
                label=item["label"][:100], value=key,
                description=f"現在 {int(prices.get(key, tsum_daiko.default_price(key))):,}円")
                for key, item in tsum_daiko.MENUS.items()])
        self.select.callback = self._pick
        self.add_item(self.select)

    async def _pick(self, interaction: discord.Interaction):
        await interaction.response.send_modal(PriceSetModal(self.select.values[0]))


def version_status_embed(current: str, latest, res_version: str) -> discord.Embed:
    """いま使っているバージョンと、App Storeの最新版を並べる。"""
    embed = discord.Embed(title="ツムツムのゲームバージョン", color=0x00aaff)
    embed.add_field(name="使用中（アプリ）", value=f"`{current}`", inline=True)
    embed.add_field(name="使用中（リソース）", value=f"`{res_version}`", inline=True)
    if latest:
        state = "一致" if latest == current else "最新と不一致"
        embed.add_field(name="App Storeの最新版", value=f"`{latest}`（{state}）", inline=True)
        if tsum_daiko.is_newer_version(latest, current):
            embed.add_field(name="対応", value="`/tsum_version auto` で今すぐ更新できます。",
                            inline=False)
    else:
        embed.add_field(name="App Storeの最新版", value="取得できませんでした", inline=True)

    st = tsum_daiko.get_version_check_state()
    hours = tsum_daiko.VERSION_CHECK_INTERVAL_HOURS
    interval = f"{int(hours)}時間ごと" if hours == int(hours) else f"{hours}時間ごと"
    auto = f"自動チェック: {interval}"
    last = st.get("last_checked_at")
    auto += (f"\n最終チェック: <t:{int(last)}:R>" if last
             else "\n最終チェック: まだ実行されていません")
    if st.get("last_updated_at"):
        auto += (f"\n最終更新: `{st.get('last_updated_from')}` → "
                 f"`{st.get('last_updated_to')}`（<t:{int(st['last_updated_at'])}:R>）")
    embed.add_field(name="自動更新", value=auto, inline=False)
    return embed


class TsumCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        tsum_daiko.apply_versions()
        self.version_watch.start()

    def cog_unload(self):
        self.version_watch.cancel()

    tsum = app_commands.Group(name="tsum", description="ツムツム代行の管理コマンド")
    version = app_commands.Group(name="tsum_version",
                                 description="ツムツムのゲームバージョン管理")

    # ---- ゲームバージョンの自動追従 ----
    # ツムツムが更新されると古いバージョンでは弾かれ、代行が丸ごと止まる。
    # にゃんこ大戦争と同じで、App Storeを定期的に見て自動で切り替える。

    @tasks.loop(hours=tsum_daiko.VERSION_CHECK_INTERVAL_HOURS)
    async def version_watch(self):
        try:
            result = await asyncio.to_thread(tsum_daiko.check_and_update_app_version)
        except Exception as e:
            log.warning("ツムツムのバージョン確認に失敗: %s", e)
            return
        if result.get("updated"):
            await self._notify_version_update(result["before"], result["latest"])

    @version_watch.before_loop
    async def _before_version_watch(self):
        await self.bot.wait_until_ready()

    async def _notify_version_update(self, before: str, after: str):
        embed = discord.Embed(
            title="ツムツムのバージョンを自動更新しました",
            description=(f"ツムツムの更新を検知したので、代行で使うバージョンを切り替えました。\n\n"
                         f"**{before}** → **{after}**\n\n"
                         "次の代行から新しいバージョンで動きます。再デプロイは不要です。\n"
                         f"リソース側は `{tsum_daiko.get_res_version()}` を使います。"
                         "合わないときは `/tsum_version res` で指定してください。"),
            color=0x2f9e6e)
        for uid in ADMIN_USER_IDS:
            try:
                user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await user.send(embed=embed)
            except Exception:
                continue

    def _deny(self, interaction: discord.Interaction):
        return interaction.response.send_message("権限がありません。", ephemeral=True)

    @tsum.command(name="panel", description="ツムツム代行パネルを設置")
    async def panel(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.send_message("ツムツム代行パネルを設置しました。",
                                                ephemeral=True)
        await panels.put(self.bot, "tsum:panel", interaction.channel,
                         panel_embed(), TsumPanelView(self.bot))

    @tsum.command(name="test_panel",
                  description="動作確認パネルを設置（全メニュー0円）")
    async def test_panel(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.send_message("動作確認パネルを設置しました。",
                                                ephemeral=True)
        await panels.put(self.bot, "tsum:admin_free_panel", interaction.channel,
                         admin_free_panel_embed(), TsumAdminFreePanelView(self.bot))

    @tsum.command(name="redisplay", description="パネルを最新の内容に更新")
    async def redisplay(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        # 置き直すと古いパネルが上に残って、お客さんが古いほうを押してしまう。
        # 置いてあるパネルだけを、どのチャンネルにあっても探して書き換える。
        # 置いていないパネルをここで作らない。設置は /tsum panel から。
        results = {
            "代行パネル": await panels.refresh(
                self.bot, "tsum:panel", panel_embed(), TsumPanelView(self.bot),
                guild=interaction.guild),
            "動作確認パネル": await panels.refresh(
                self.bot, "tsum:admin_free_panel", admin_free_panel_embed(),
                TsumAdminFreePanelView(self.bot), guild=interaction.guild),
        }
        labels = {"updated": "更新しました", "missing": "置いていないので何もしません",
                  "failed": "更新できませんでした"}
        await interaction.followup.send(
            "\n".join(f"{k}: {labels.get(v, v)}" for k, v in results.items()),
            ephemeral=True)

    @tsum.command(name="price", description="価格を決める")
    async def price(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        prices = tsum_daiko.load_prices()
        lines = [f"・{item['label']}: "
                 f"{int(prices.get(key, tsum_daiko.default_price(key))):,}円"
                 for key, item in tsum_daiko.MENUS.items()]
        embed = discord.Embed(title="ツムツム代行の価格", description="\n".join(lines),
                              color=0x00aaff)
        embed.set_footer(text="変更したら /tsum redisplay でパネルを更新してください")
        await interaction.response.send_message(embed=embed, view=PriceSelectView(),
                                                ephemeral=True)

    @tsum.command(name="level",
                  description="レベル上げの効きかた")
    @app_commands.describe(
        vanish="ツムレベル: 1プレイで申告する消去数(省略時は今のまま)",
        rounds="ツムレベル: 始める前に確かめるハートの数(省略時は今のまま)",
        player_max="プレイヤーレベルで指定できる上限(省略時は今のまま)")
    async def level_tuning(self, interaction: discord.Interaction,
                           vanish: int = None, rounds: int = None,
                           player_max: int = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        read = lambda: (tsum_daiko.level_vanish(), tsum_daiko.level_rounds(),
                        tsum_daiko.player_level_max())
        before = read()
        if vanish is not None or rounds is not None or player_max is not None:
            tuning = tsum_daiko.load_tuning()
            if vanish is not None:
                tuning["level_vanish"] = max(
                    1, min(int(vanish), tsum_daiko.LEVEL_VANISH_MAX))
            if rounds is not None:
                tuning["level_rounds"] = max(
                    1, min(int(rounds), tsum_daiko.LEVEL_ROUNDS_MAX))
            if player_max is not None:
                tuning["player_level_max"] = max(1, min(int(player_max), 100_000))
            tsum_daiko.save_tuning(tuning)
        now = read()

        lines = [f"ツムレベル・1プレイの申告: `{before[0]:,}` → `{now[0]:,}` 個",
                 f"ツムレベル・始める前に確かめるハート: `{before[1]}` → `{now[1]}` 個"
                 "（プレイは上限に届くまで回します）",
                 f"プレイヤーレベルの指定上限: `{before[2]:,}` → `{now[2]:,}`"]
        if before != now:
            lines.append("")
            lines.append("変えたら `/tsum redisplay` でパネルの表記"
                         "（必要ハート数・指定できる上限）も更新してください。")
        if now[0] > tsum_daiko.LEVEL_VANISH_SAFE:
            lines.append("")
            lines.append(
                f"【ご確認】1プレイの申告が `{now[0]:,}` です。実際のプレイで消せるのは"
                f"多くても{tsum_daiko.LEVEL_VANISH_SAFE:,}個ほどなので、その"
                f"{now[0] / tsum_daiko.LEVEL_VANISH_SAFE:.0f}倍にあたります。\n"
                "申告60,000で流した直後に、検証用アカウントが停止されました。"
                "お客さんのアカウントで使う値としてご判断ください。")
        embed = discord.Embed(title="レベル上げの設定", color=0x00aaff,
                              description="\n".join(lines))
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @tsum.command(name="0change", description="全メニューを0円にする")
    async def all_free(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        tsum_daiko.save_prices({k: 0 for k in tsum_daiko.MENUS})
        await interaction.response.send_message(
            f"全 {len(tsum_daiko.MENUS)} メニューの価格を 0円 にしました。", ephemeral=True)

    @tsum.command(name="selllog", description="完了ログの送り先")
    @app_commands.describe(channel="ログを送信するチャンネル(省略時は今のチャンネル)")
    async def selllog(self, interaction: discord.Interaction,
                      channel: discord.TextChannel = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        target = channel or interaction.channel
        cfg = _config()
        cfg["tsum_log_channel_id"] = target.id
        _save_config(cfg)
        await interaction.response.send_message(
            f"ツムツムの公開ログを {target.mention} に設定しました。", ephemeral=True)

    @tsum.command(name="logchannel", description="非公開ログの送り先")
    @app_commands.describe(channel="管理者専用チャンネル(省略時は今のチャンネル)")
    async def logchannel(self, interaction: discord.Interaction,
                         channel: discord.TextChannel = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        target = channel or interaction.channel
        cfg = _config()
        cfg["tsum_private_log_channel_id"] = target.id
        _save_config(cfg)
        await interaction.response.send_message(
            f"ツムツムの非公開ログを {target.mention} に設定しました。\n"
            "購入者のIDや支払いリンクが送られます。管理者だけが見られるチャンネルにしてください。",
            ephemeral=True)

    @tsum.command(name="role", description="購入時に付けるロール")
    @app_commands.describe(role="付与するロール(省略で解除)")
    async def role(self, interaction: discord.Interaction, role: discord.Role = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。",
                                                           ephemeral=True)
        set_purchase_role_id(interaction.guild.id, role.id if role else None)
        await interaction.response.send_message(
            f"購入時ロールを {role.mention} に設定しました。" if role else
            "購入時ロールの設定を解除しました（以降はにゃんこ代行の設定を使います）。",
            ephemeral=True)


    @tsum.command(name="status", description="設定と売上を見る")
    async def status(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        sales = tsum_daiko.load_sales()
        today = time.time() - 86400
        embed = discord.Embed(title="ツムツム代行の状態", color=0x00aaff)
        embed.add_field(name="メニュー数", value=f"{len(tsum_daiko.MENUS)}件", inline=True)
        embed.add_field(name="合計売上",
                        value=f"{sum(int(s.get('amount', 0)) for s in sales):,}円"
                              f"（{len(sales)}件）", inline=True)
        embed.add_field(name="直近24時間",
                        value=f"{sum(int(s.get('amount', 0)) for s in sales if float(s.get('ts', 0)) >= today):,}円",
                        inline=True)
        embed.add_field(name="公開ログ",
                        value=f"<#{log_channel_id()}>" if log_channel_id() else "未設定",
                        inline=True)
        embed.add_field(name="非公開ログ",
                        value=f"<#{private_log_channel_id()}>" if private_log_channel_id() else "未設定",
                        inline=True)
        embed.add_field(name="ゲームバージョン",
                        value=f"アプリ `{tsum_daiko.get_app_version()}` / "
                              f"リソース `{tsum_daiko.get_res_version()}`", inline=False)
        # 効きかたを左右する設定。コンソールを見られないところから運用するので、
        # 「いまいくつで動いているか」はここから読めるようにしておく。
        embed.add_field(name="ツムレベルの設定",
                        value=f"1プレイの申告 `{tsum_daiko.level_vanish():,}`個 / "
                              f"始める前に確かめるハート `{tsum_daiko.level_rounds()}`個"
                              "（上限に届くまで回す）\n"
                              f"変更: `/tsum level`",
                        inline=False)
        embed.add_field(name="上限の設定",
                        value=f"コイン `{tsum_daiko.COIN_MAX:,}` / "
                              f"プレイヤーレベル `{tsum_daiko.player_level_max()}` / "
                              f"スコア `{tsum_daiko.SCORE_MAX:,}`",
                        inline=False)
        methods = payments.available_methods()
        embed.add_field(name="使える支払い方法",
                        value=" / ".join(m.label for m in methods) or "なし", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    @tsum.command(name="tsum_ids",
                  description="覚えたツムの一覧")
    async def tsum_ids(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        learned = tsum_daiko.load_learned_tsums()
        bundled = len(tsum_daiko.load_tsum_master()) - len(learned)
        embed = discord.Embed(title="覚えたツム", color=0x00aaff)
        embed.add_field(
            name="表の件数",
            value=f"同梱 {bundled:,}件 ＋ 覚えたぶん {len(learned):,}件",
            inline=False)
        if not learned:
            embed.description = ("まだありません。代行を1回動かすと、お客さんの"
                                 "持ち物から知らないツムを拾って覚えます。")
            return await interaction.response.send_message(embed=embed, ephemeral=True)

        lines = []
        for tsum_id, entry in sorted(learned.items())[:40]:
            when = int(entry.get("learned_at") or 0)
            limit = entry.get("limitlv_seen")
            lines.append(f"`{tsum_id}`"
                         + (f"（上限{limit}まで確認）" if limit else "")
                         + (f" <t:{when}:R>" if when else ""))
        embed.add_field(name="ID", value="\n".join(lines)[:1024], inline=False)
        embed.add_field(
            name="名前を付けるには",
            value=("これらはIDでしか指定できません。日本語名で選べるようにするには、"
                   "`tsum_names_ja.json` の `_by_id` にIDと名前を足してください。\n"
                   "覚えたことで、IDを指定した注文はもう断られません。"),
            inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ---- バージョン管理 ----

    @version.command(name="show", description="いまのバージョンを見る")
    async def version_show(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        latest = await asyncio.to_thread(tsum_daiko.fetch_latest_app_version)
        await interaction.followup.send(
            embed=version_status_embed(tsum_daiko.get_app_version(), latest,
                                       tsum_daiko.get_res_version()),
            ephemeral=True)

    @version.command(name="auto", description="いますぐ最新に合わせる")
    async def version_auto(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await asyncio.to_thread(tsum_daiko.check_and_update_app_version)
        if result.get("latest") is None:
            return await interaction.followup.send(
                "App Storeの最新版を取得できませんでした。時間をおいてお試しください。",
                ephemeral=True)
        if result.get("updated"):
            text = (f"アプリのバージョンを `{result['before']}` → `{result['latest']}` に"
                    f"更新しました。リソース側は `{tsum_daiko.get_res_version()}` を使います。")
        else:
            text = f"すでに最新です（`{result['current']}`）。"
        await interaction.followup.send(text, ephemeral=True)

    @version.command(name="set", description="アプリのバージョンを手で決める")
    @app_commands.describe(version="例: 12.8.3")
    async def version_set(self, interaction: discord.Interaction, version: str):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        version = version.strip()
        if not re.fullmatch(r"\d+(\.\d+){1,3}", version):
            return await interaction.response.send_message(
                "バージョンは `12.8.3` のように数字とドットで入力してください。", ephemeral=True)
        tsum_daiko.set_app_version(version)
        await interaction.response.send_message(
            f"アプリのバージョンを `{version}` にしました（リソースは "
            f"`{tsum_daiko.get_res_version()}`）。次の代行から反映されます。",
            ephemeral=True)

    @version.command(name="res", description="リソースのバージョンを手で決める")
    @app_commands.describe(version="例: 12.8.0")
    async def version_res(self, interaction: discord.Interaction, version: str):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        version = version.strip()
        if not re.fullmatch(r"\d+(\.\d+){1,3}", version):
            return await interaction.response.send_message(
                "バージョンは `12.8.0` のように数字とドットで入力してください。", ephemeral=True)
        tsum_daiko.set_res_version(version)
        await interaction.response.send_message(
            f"リソースのバージョンを `{version}` にしました。次の代行から反映されます。",
            ephemeral=True)


async def setup(bot):
    # 再起動後もパネルのボタンが効くように登録し直す。
    bot.add_view(TsumPanelView(bot))
    bot.add_view(TsumAdminFreePanelView(bot))
    # 保留から遅れて承認された送金リンクの入金が確認できたら、後追いで代行する。
    link_orders.register_handler(
        KIND, lambda order: offline_deliver(bot, order),
        on_expire=lambda order: offline_release(bot, order),
        retry_view=TsumReloginView)
    await bot.add_cog(TsumCog(bot))
