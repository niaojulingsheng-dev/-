"""保留になった送金リンクの見張り。

支払い画面が閉じた後に承認された分をきちんと受け取り、代行・商品のお渡しまで
自動で片付ける。受け取れたのに渡せなかった注文は、必ず記録と管理者通知を残す
(「残高だけ増えてログが流れない」を作らないため)。
"""
import asyncio
import logging
import os
import time

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

import link_orders
import payment_attempts
import payments
import reconcile
import support
from datapath import data_path, read_json, write_json
from utils import ADMIN_USER_IDS

log = logging.getLogger(__name__)


# ---- 管理者通知の on/off ----
#
# 通知は「お金が危ないとき」と「そうでないとき」で価値がまったく違う。
#
#   危ない  … 受け取ったのに渡せていない / 入金したのか確認できない
#   危なくない … お客さんが承認しなかった（お金は動いていない）
#              自分でチャージした入金が注文に紐づかない
#
# 危なくないほうは日常的に起きるので、毎回DMが飛ぶと、本当に見るべき通知が
# その中に埋もれる。切れるようにするのはこちらだけ。危ないほうは切れない。
# 「うるさいから全部切る」を選べるようにすると、いちばん知りたい事故が
# 黙って通り過ぎるため。
NOTIFY_FILE = data_path("notify.json")

# 管理者DMの on/off。既定は切。入金の無い通知なので、切っても
# お客さんへの案内と、入金があったときのお渡しには影響しない。
NOTIFY_DEFAULTS = {"pending_expired": False}


def notify_settings() -> dict:
    """管理者通知の on/off。保存が無い項目は既定に落とす。"""
    saved = read_json(NOTIFY_FILE, {})
    if not isinstance(saved, dict):
        saved = {}
    return {key: bool(saved.get(key, default))
            for key, default in NOTIFY_DEFAULTS.items()}


def notify_enabled(key: str) -> bool:
    return notify_settings().get(key, True)


def set_notify(key: str, on: bool) -> dict:
    saved = read_json(NOTIFY_FILE, {})
    if not isinstance(saved, dict):
        saved = {}
    saved[key] = bool(on)
    write_json(NOTIFY_FILE, saved)
    return notify_settings()


# お渡しに数分かかる種類。ここに入っているものだけ、受け取れた時点で
# 「いま進めています」を送る。すぐ終わるものは完了の知らせ1通で足りる。
_SLOW_DELIVERY_KINDS = {"tsum", "daiko"}

# お渡しに失敗したときの再試行。原因はたいていDM拒否なので、間隔を伸ばしながら
# しばらくねばり、それでも駄目なときだけ管理者に知らせる。
MAX_DELIVER_ATTEMPTS = 10
RETRY_BASE_SECONDS = 60
RETRY_MAX_SECONDS = 1800

PURGE_INTERVAL_HOURS = 24
# 入金突合の間隔(分)。見つけた入金はその場で決着させてお渡しまで進めるので、
# 監視だけでなく「リンクの状態が読めないときの受け取り確認」も兼ねる。
# お客さんの待ち時間に直結するので短めに。
RECONCILE_INTERVAL_MINUTES = int(os.environ.get("RECONCILE_INTERVAL_MINUTES", "5"))
# ただし「受け取りは投げたのにリンクが読めない」注文があるときは待たない。
# その注文にとっては入金履歴が唯一の答えで、定期実行まで待たせた分がそのまま
# お客さんの待ち時間になる。とはいえ巡回のたびに履歴を叩くと足跡が増えるので、
# 急ぐときの下限をここで決める。
UNREADABLE_RECONCILE_SECONDS = 90

# 入れ直しのお願いは、止まったと分かった時点で1回だけ送る。催促はしない。
# ボタンには期限が無く、いつ押してもその注文がそのまま完了するため、
# 何度も急かす意味がない(急かされるほうも気分が悪い)。
# 届かなかったときだけ、購入した場所での呼びかけ→管理者への通知と降りていく。


class CodeRetryModal(ui.Modal, title="引き継ぎ情報の入れ直し"):
    """新しい引き継ぎコードを受け取って、その場で代行を走らせる。"""

    tc = ui.TextInput(label="引継ぎコード", placeholder="例: 000000000", required=True)
    pin = ui.TextInput(label="認証番号 (PIN 4桁)", min_length=4, max_length=4, required=True)

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.order_id = order_id

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        order = link_orders.get_order(self.order_id)
        if not order:
            return await interaction.followup.send("この注文が見つかりませんでした。", ephemeral=True)
        if order.get("status") == link_orders.DONE:
            return await interaction.followup.send("この注文はお渡し済みです。", ephemeral=True)
        if str(order.get("user_id")) != str(interaction.user.id):
            return await interaction.followup.send("この注文の購入者ではありません。", ephemeral=True)

        payload = dict(order.get("payload") or {})
        # 預かりセーブは手放す。残すとお渡し側がそちらを優先してしまい、
        # 入れ直してもらったコードが使われないまま同じ失敗を繰り返す。
        stale = payload.pop("save_file", None)
        payload.pop("save_pw", None)
        payload["tc"] = self.tc.value.strip()
        payload["pin"] = self.pin.value.strip()
        if stale:
            try:
                import main
                main.drop_stashed({"save_file": stale})
            except Exception as e:
                log.warning("古い預かりセーブを消せませんでした (%s): %s", self.order_id, e)
        # 入れ直したので再試行の回数もリセットして、すぐ流す
        order = await link_orders.mark_order(
            self.order_id, link_orders.PAID, payload=payload, awaiting_code=False,
            deliver_attempts=0, last_attempt_at=0, note="") or order

        handler = link_orders.get_handler(order.get("kind"))
        if handler is None:
            return await interaction.followup.send(
                "お渡し処理が見つかりませんでした。\n" + support.contact_line(),
                ephemeral=True)
        try:
            ok = await handler(order)
        except link_orders.NeedsCustomerInput as e:
            await link_orders.mark_order(self.order_id, link_orders.PAID,
                                         awaiting_code=True, note=str(e)[:300])
            return await interaction.followup.send(
                f"{e.prompt}\n\nもう一度お試しください。", ephemeral=True)
        except Exception as e:
            log.exception("code retry delivery failed (%s)", self.order_id)
            await link_orders.mark_order(self.order_id, link_orders.PAID, note=str(e)[:300])
            # 生のエラーはお客さんには出さない。読めないうえ不安にさせるだけで、
            # 調べるのに要る情報は注文のメモと管理者通知に残っている。
            return await interaction.followup.send(
                embed=support.trouble_embed(
                    support.NEEDS_SUPPORT, "処理を完了できませんでした",
                    support.PAID_AND_STUCK, order_id=self.order_id),
                ephemeral=True)

        if ok:
            await link_orders.mark_order(self.order_id, link_orders.DONE, note="")
            return await interaction.followup.send(
                "受け付けました。完了内容をDMでお送りします。", ephemeral=True)
        await interaction.followup.send(
            "処理は進めましたが、DMをお送りできませんでした。DM許可をご確認ください。",
            ephemeral=True)


class CodeRetryButton(ui.Button):
    """注文番号を custom_id に埋めたボタン。"""

    def __init__(self, order_id: str):
        super().__init__(label="引き継ぎコードを入れ直す",
                         style=discord.ButtonStyle.primary,
                         custom_id=f"lo:code:{order_id}")
        self.order_id = order_id

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(CodeRetryModal(self.order_id))


class CodeRetryView(ui.View):
    """再起動をまたいでも押せるよう、timeout なしで custom_id を固定する。

    注文ごとに登録し直す必要があるので、起動時に入れ直し待ちの注文を拾って
    add_view しておく(_register_pending_views)。
    """

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.add_item(CodeRetryButton(order_id))


class LinkWatchCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._last_purge = 0.0
        self._last_reconcile = 0.0
        # サービスごとの最終突合時刻(method -> epoch)
        self._recon_last = {}
        self._last_run = 0.0
        self._last_error = ""
        self.watch_links.start()

    def cog_unload(self):
        self.watch_links.cancel()

    @tasks.loop(seconds=link_orders.POLL_INTERVAL_SECONDS)
    async def watch_links(self):
        """見張りの1周。ここから例外を1つも外に出さない。

        discord.py の tasks は、本体から例外が漏れるとループごと止まって二度と
        回らない。止まれば受け取りの確認もお渡しも全部停止して、入金だけが
        溜まり続ける——しかも止まったこと自体がどこにも出ない。
        """
        self._last_run = time.time()
        try:
            await self._tick()
            self._last_error = ""
        except Exception as e:
            self._last_error = f"{type(e).__name__}: {e}"[:300]
            log.exception("link watch tick failed: %s", e)

    @watch_links.error
    async def _watch_links_error(self, exc: BaseException):
        """ここに来た時点でループは止まっている。必ず立て直す。"""
        self._last_error = f"{type(exc).__name__}: {exc}"[:300]
        log.exception("link watch loop stopped: %s", exc)
        print(f"[LINK WATCH STOPPED] {exc}", flush=True)
        if not self.watch_links.is_running():
            self.watch_links.restart()

    def _health(self) -> str:
        """見張りが生きているかを一目で分かるようにする。

        止まっていること自体に気付けないのが一番まずいので、最後に回った時刻と
        直近で握りつぶした例外を出す。
        """
        if not self.watch_links.is_running():
            return f"🚨 **止まっています**\n{self._last_error or '理由不明'}"
        if not self._last_run:
            return "⏳ まだ1周もしていません"
        gap = time.time() - self._last_run
        mark = "✅" if gap < link_orders.POLL_INTERVAL_SECONDS * 3 else "⚠️"
        text = f"{mark} 最終巡回 <t:{int(self._last_run)}:R>"
        if self._last_error:
            text += f"\n直近のエラー: ```{self._last_error}```"
        return text

    async def _guard(self, coro, label: str = ""):
        """1件の失敗で他の注文まで巻き込まないようにする。"""
        try:
            await coro
        except Exception as e:
            log.exception("link watch step failed (%s): %s", label, e)

    async def _tick(self):
        try:
            result = await link_orders.poll_once()
        except link_orders.LinkOrderError as e:
            log.warning("link watch poll failed: %s", e)
            result = {}
        except Exception as e:
            log.exception("link watch poll error: %s", e)
            result = {}

        for order in result.get("settled", []):
            await self._guard(self._notify_received(order), order.get("id"))
            await self._guard(self._deliver(order), order.get("id"))
        for order in result.get("unsure", []):
            await self._guard(self._alert_unsure(order), order.get("id"))
        for order in result.get("expired", []):
            await self._guard(self._expire(order), order.get("id"))

        # 前回お渡しに失敗した注文の再試行(入金は受け取っているので諦めない)
        try:
            retryable = link_orders.list_orders(link_orders.PAID)
        except Exception as e:
            log.exception("link watch list failed: %s", e)
            retryable = []
        for order in retryable:
            # 入れ直し待ちの注文はここでは何もしない。お願いは1回送ってあり、
            # ボタンに期限も無いので、押されるまで静かに待つ。
            if self._ready_for_retry(order):
                await self._guard(self._deliver(order), order.get("id"))

        now = time.time()
        # リンクが読めないまま受け取りを投げてある注文は、入金履歴でしか決着が
        # 付かない。定期実行を待たせるとその分だけお客さんを待たせるので急がせる。
        urgent = (result.get("unreadable")
                  and now - self._last_reconcile > UNREADABLE_RECONCILE_SECONDS)
        if urgent or now - self._last_reconcile > RECONCILE_INTERVAL_MINUTES * 60:
            self._last_reconcile = now
            await self._guard(self._reconcile_check(), "reconcile")

        if now - self._last_purge > PURGE_INTERVAL_HOURS * 3600:
            self._last_purge = now
            try:
                await link_orders.purge_old()
                # 支払い試行の台帳は支払いのたびに読み書きするので、放っておくと
                # 際限なく伸びて支払い画面が重くなる
                await asyncio.to_thread(payment_attempts.purge_old)
                # 決着しなかった注文の預かりセーブも残るので一緒に
                import main
                await asyncio.to_thread(main.purge_stashed_saves)
            except Exception:
                pass

    @watch_links.before_loop
    async def _before_watch(self):
        await self.bot.wait_until_ready()
        self._register_pending_views()

    def _register_pending_views(self):
        """入れ直し待ちの注文のボタンを、再起動後も押せるようにする。

        custom_id 付きのViewは、起動のたびに登録し直さないと反応しない。
        登録漏れがあると、お客さんがボタンを押しても無反応のまま
        代行が止まる(入金だけ残る)。
        """
        try:
            pending = [o for o in link_orders.list_orders(link_orders.PAID)
                       if o.get("awaiting_code")]
        except Exception as e:
            log.exception("pending view registration failed: %s", e)
            return
        for order in pending:
            try:
                self.bot.add_view(self._retry_view(order))
            except Exception as e:
                log.warning("add_view failed (%s): %s", order.get("id"), e)

    @staticmethod
    def _ready_for_retry(order: dict) -> bool:
        if order.get("awaiting_code"):
            # お客さんの入れ直し待ち。同じ内容で叩き直しても意味がない。
            return False
        attempts = int(order.get("deliver_attempts") or 0)
        if attempts >= MAX_DELIVER_ATTEMPTS:
            return False
        if attempts == 0:
            return True
        wait = min(RETRY_BASE_SECONDS * 2 ** (attempts - 1), RETRY_MAX_SECONDS)
        return time.time() - float(order.get("last_attempt_at") or 0) >= wait

    async def _fetch_user(self, order: dict):
        try:
            uid = int(order["user_id"])
        except (KeyError, TypeError, ValueError):
            return None
        try:
            return self.bot.get_user(uid) or await self.bot.fetch_user(uid)
        except discord.HTTPException:
            return None

    def _amount(self, order: dict) -> int:
        return int(order.get("paid_amount") or order.get("amount_jpy") or 0)

    async def _notify_received(self, order: dict):
        """承認を確認したことを、お渡しの前に一度だけ伝える。

        お渡しがすぐ終わるものは、この直後に完了の知らせが続く。同じことを
        2通に分けても読む手間が増えるだけなので、そのときは送らない。
        時間のかかる代行だけ「受け取れました、いま進めています」を出す
        （何も言わずに数分黙ると、通っていないと思われる）。
        """
        if not _SLOW_DELIVERY_KINDS or order.get("kind") not in _SLOW_DELIVERY_KINDS:
            return
        user = await self._fetch_user(order)
        if user is None:
            return
        embed = discord.Embed(
            title="✅ お支払いを確認しました",
            description=("保留になっていたお支払いの承認を確認しました。\n"
                         "このまま自動で進めます。少しお待ちください。"),
            color=0x00cc66,
        )
        embed.add_field(name="金額", value=f"{self._amount(order):,}円", inline=True)
        embed.add_field(name="支払い方法",
                        value=payments.method_label(order.get("method")), inline=True)
        if order.get("summary"):
            embed.add_field(name="内容", value=str(order["summary"])[:1024], inline=False)
        try:
            await user.send(embed=embed)
        except discord.HTTPException:
            pass

    async def _deliver(self, order: dict):
        handler = link_orders.get_handler(order.get("kind"))
        if handler is None:
            log.error("link handler not registered: %s", order.get("kind"))
            return

        attempts = int(order.get("deliver_attempts") or 0) + 1
        await link_orders.mark_order(order["id"], link_orders.PAID,
                                     deliver_attempts=attempts, last_attempt_at=time.time())
        try:
            ok = await handler(order)
            note = ""
        except link_orders.NeedsCustomerInput as e:
            # やり直しても結果は変わらない。再試行を止めて本人に頼む。
            log.warning("link delivery needs input (%s): %s", order.get("id"), e)
            await link_orders.mark_order(order["id"], link_orders.PAID,
                                         awaiting_code=True, note=str(e)[:300])
            await self._ask_customer(order, e.prompt)
            return
        except Exception as e:
            log.exception("link delivery failed (%s): %s", order.get("id"), e)
            # 切り詰めすぎると「どの段階で・どんな応答で」落ちたかが消える
            ok, note = False, str(e)[:500]

        if ok:
            await link_orders.mark_order(order["id"], link_orders.DONE, note="")
            return
        if ok is None:
            # まだ始められない(その人の別の代行が実行中・サーバに拒まれた直後・版を合わせ中)。
            # 何も試していないので失敗には数えず、次の巡回でまた見る(理由は処理側がメモに残す)。
            await link_orders.mark_order(order["id"], link_orders.PAID,
                                         deliver_attempts=attempts - 1,
                                         last_attempt_at=time.time())
            return

        if attempts >= MAX_DELIVER_ATTEMPTS:
            await link_orders.mark_order(order["id"], link_orders.FAILED, note=note)
            await self._alert_failed(order, note)
            await self._tell_customer_stuck(order)
            return

        await link_orders.mark_order(order["id"], link_orders.PAID, note=note)
        if not note and not order.get("nudged"):
            await self._nudge_open_dm(order)

    async def _tell_customer_stuck(self, order: dict, detail: str = ""):
        """こちらで調べないと直せない止まり方を、本人にだけ伝える。

        生のエラーは出さない。お客さんにできることは何も無いので、
        「お代は受け取っている」「こちらで対応する」「連絡はチケットへ」の
        3点だけを伝える。届かなければ管理者に知らせる。
        """
        embed = support.trouble_embed(
            support.NEEDS_SUPPORT, "ご注文の処理が完了できませんでした",
            (detail or support.PAID_AND_STUCK),
            order_id=order.get("id"), amount=self._amount(order),
            summary=order.get("summary") or "")
        if not await support.send_private(self.bot, order, embed):
            await self._alert_admins(
                title="⚠️ お客さんに連絡できませんでした",
                description=("お渡しできなかったことを届けられませんでした"
                             "（DMもチャンネルも不可）。\n"
                             "**入金は受け取っています。**手動で連絡してください。"),
                order=order)

    @staticmethod
    def _retry_view(order: dict):
        """その注文の「入れ直し」画面を作る。種類ごとの登録が無ければ既定。"""
        factory = link_orders.get_retry_view(order.get("kind"))
        if factory is None:
            return CodeRetryView(order["id"])
        try:
            return factory(order["id"])
        except Exception as e:
            log.warning("入れ直し画面を作れませんでした (%s): %s", order.get("kind"), e)
            return CodeRetryView(order["id"])

    async def _ask_customer(self, order: dict, prompt: str) -> bool:
        """入れ直しのお願いを1回だけ送る。届いたら True。

        ここで黙ると、入金だけ済んで代行が永久に走らないまま終わる。
        ボタンに期限は無く、いつ押してもその注文がそのまま完了するので、
        催促はしない。届かなかったときだけ管理者に知らせる。

        何を入れ直してもらうかは注文の種類で違う(にゃんこ代行は引き継ぎコード、
        ツムツムはLINEのログイン)。画面は種類ごとに登録されたものを使い、
        登録が無ければ引き継ぎコードの入れ直しにする。
        """
        view = self._retry_view(order)
        embed = support.trouble_embed(
            support.NEEDS_CODE, getattr(view, "ask_title", "引き継ぎコードを入れ直してください"),
            (prompt + "\n"
             + getattr(view, "ask_howto",
                       "下のボタンから**最新の引き継ぎコードとPIN**を入力してください。"
                       "そのまま代行を続けます。")
             + "\n\n"
             + support.PAID_NO_DEADLINE + "\n"
             + support.contact_short()),
            order_id=order.get("id"), amount=self._amount(order),
            summary=order.get("summary") or "")
        # 送るたびに登録しておく(再起動をまたいでも押せるように)
        try:
            self.bot.add_view(view)
        except Exception:
            pass

        ok = await support.send_private(self.bot, order, embed, view)
        if not ok:
            await self._alert_admins(
                title="⚠️ お客さんに連絡できませんでした",
                description=("入れ直しのお願いを届けられませんでした（DMもチャンネルも不可）。\n"
                             "**入金は受け取っています。**手動で連絡してください。"),
                order=order)
        await link_orders.mark_order(
            order["id"], order.get("status") or link_orders.PAID,
            asked_at=time.time(), ask_ok=ok,
            ask_count=int(order.get("ask_count") or 0) + 1,
            ask_prompt=prompt[:500])
        return ok

    async def _nudge_open_dm(self, order: dict):
        """DMが送れないときに、購入した場所で一度だけ開放を促す(中身は出さない)。"""
        await link_orders.mark_order(order["id"], link_orders.PAID, nudged=True)
        channel = self.bot.get_channel(int(order["channel_id"])) if order.get("channel_id") else None
        if channel is None:
            return
        try:
            await channel.send(
                f"<@{order['user_id']}> お支払いを確認しましたが、DMをお送りできませんでした。\n"
                "**このサーバーからのDMを許可**していただければ、そのまま自動でお渡しします。")
        except discord.HTTPException:
            pass

    async def _expire(self, order: dict):
        """承認されないまま打ち切った注文の後始末。"""
        on_expire = link_orders.get_expire_handler(order.get("kind"))
        if on_expire is not None:
            try:
                await on_expire(order)
            except Exception as e:
                log.exception("link expire cleanup failed (%s): %s", order.get("id"), e)

        # returned は「PayPayがリンクを閉じた」印。お金は送り主に戻っていて、
        # こちらの残高は動いていない。受け取りを投げた後でも同じなので、
        # 入金済みの疑いとは分けて扱う(混ぜると、戻ったお金について
        # 二重払いの注意を出すことになる)。
        returned = bool(order.get("returned"))
        # link_open は「打ち切った時点でリンクがまだ開いていた」印。誰も受け取って
        # いないので、お金は送り主のリンクの中にある。受け取りを投げた後でも、
        # こちらの残高には入っていない。
        open_link = bool(order.get("link_open")) and not returned
        if returned and order.get("accepted"):
            # 受け取りは投げたのに通らなかった。入金は無いので、知らせるかどうかは
            # 設定に従う（既定は切）。お客さんへの案内はこの下で必ず出す。
            await self._alert_pending_expired(
                title="⚠️ 送金が承認されず、送り主に戻りました",
                description=("受け取りは投げましたが、保留の案内で「キャンセル」を"
                             "押されたか、承認されないまま終わりました。"
                             "**入金はありません**"
                             "（送り主のアプリには「送金（譲渡）失敗」と出ます）。\n"
                             "お客さんには払い直しをお願いしてあります。これが続くなら、"
                             "承認の案内が届いていないか読まれていない可能性があります。"),
                order=order)
        elif open_link and order.get("accepted"):
            # 投げたが通らず、リンクは開いたまま期限が来た。お金は動いていないので、
            # これも設定に従う（既定は切）。
            await self._alert_pending_expired(
                title="⚠️ 承認されないまま期限が来ました",
                description=("受け取りは投げましたが、お客さんが「承認する」を"
                             "押さないまま期限が来ました。リンクは開いたままです。\n"
                             "**入金はありません**（お金は送り主のリンクの中にあります）。\n"
                             "承認の案内が届いていない可能性もあります。"),
                order=order)
        elif order.get("accepted"):
            # 受け取りを投げた後の打ち切り = 入金済みの可能性がある。必ず知らせる
            await self._alert_admins(
                title="⚠️ 受け取りを投げたリンクを見張り切れませんでした",
                description=("受け取りのリクエストは送信済みです。**入金されている可能性があります。**\n"
                             "残高と履歴を確認して、入っていればお客さんへ手動でお渡しするか返金してください。"),
                order=order)

        user = await self._fetch_user(order)
        if user is None:
            return
        if returned:
            embed = discord.Embed(
                title="お支払いが承認されませんでした",
                description=("PayPayアプリの「承認する」が押されなかったため"
                             "（またはキャンセルされたため）、送金は成立せず"
                             "**お金はお客さまに戻っています**。\n"
                             "**お代はいただいていません。**\n"
                             "もう一度お手続きのうえ、PayPayアプリに出る"
                             "**「承認する」**を押してください。"),
                color=0xffaa00,
            )
        elif open_link:
            embed = discord.Embed(
                title="お支払いの承認が確認できませんでした",
                description=("PayPayアプリの「承認する」が押されないまま期限が来たため、"
                             "この注文の見張りを終了しました。\n"
                             "**お代はいただいていません。**お金はまだリンクの中に"
                             "あります（PayPayアプリから取り消せます）。\n"
                             "お手数ですが、もう一度お手続きください。"),
                color=0xffaa00,
            )
        else:
            embed = discord.Embed(
                title="お支払いの受け取りを確認できませんでした",
                description=("決着しないまま期限が来たため、この注文の見張りを"
                             "終了しました。\n"
                             "リンクがまだ有効であればもう一度お手続きください。"),
                color=0xffaa00,
            )
        embed.add_field(name="金額", value=f"{int(order.get('amount_jpy') or 0):,}円", inline=True)
        if order.get("summary"):
            embed.add_field(name="内容", value=str(order["summary"])[:1024], inline=False)
        if order.get("accepted") and not returned and not open_link:
            embed.description += ("\n\n**受け取り処理は送信済みです。**もう一度支払う前に"
                                  "管理者へご連絡ください（二重払いを防ぐため）。")
        try:
            await user.send(embed=embed)
        except discord.HTTPException:
            pass

    async def _alert_pending_expired(self, **kwargs):
        """承認されずに終わった保留の通知。入金が無いので、切ってあれば出さない。

        ここを _alert_admins と分けているのは、切れる通知と切れない通知を
        呼び出し側で取り違えないようにするため。入金の可能性がある打ち切りは
        _alert_admins のままなので、設定に関わらず必ず届く。
        """
        if not notify_enabled("pending_expired"):
            return False
        return await self._alert_admins(**kwargs)

    async def _alert_unsure(self, order: dict):
        await self._alert_admins(
            title="⚠️ 受け取り結果が確認できません",
            description=("受け取りのリクエストは送信済みです。**入金されている可能性があります。**\n"
                         "見張りは続けていますが、残高と履歴も確認してください。"),
            order=order)

    async def _alert_failed(self, order: dict, note: str):
        await self._alert_admins(
            title="🚨 受け取り済みなのにお渡しできませんでした",
            description=("お支払いは受け取れましたが、お渡しに何度も失敗しました。\n"
                         "手動で対応するか返金してください。"),
            order=order, note=note)

    async def _alert_admins(self, *, title: str, description: str, order: dict, note: str = ""):
        embed = discord.Embed(title=title, description=description, color=0xff3333,
                              timestamp=discord.utils.utcnow())
        embed.add_field(name="注文番号", value=f"`{order.get('id')}`", inline=True)
        embed.add_field(name="種類", value=str(order.get("kind")), inline=True)
        embed.add_field(name="金額", value=f"{self._amount(order):,}円", inline=True)
        embed.add_field(name="購入者", value=f"<@{order.get('user_id')}>（`{order.get('user_id')}`）",
                        inline=False)
        if order.get("summary"):
            embed.add_field(name="内容", value=str(order["summary"])[:1024], inline=False)
        if order.get("link"):
            embed.add_field(name="リンク", value=f"`{str(order['link'])[:200]}`", inline=False)
        detail = note or order.get("note")
        if detail:
            embed.add_field(name="内容(詳細)", value=f"```{str(detail)[:300]}```", inline=False)
        return await self._dm_admins(embed, f"{title} / 注文 {order.get('id')}")

    async def _dm_admins(self, embed: discord.Embed, summary: str) -> bool:
        """管理者全員にDMして、1人でも届いたら True。

        誰にも届かないまま黙って諦めると、まさに「ログにも来ない」状態になる。
        コンテナのログには必ず残し、通知済み扱いにもしない。
        """
        delivered = 0
        for uid in ADMIN_USER_IDS:
            try:
                user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await user.send(embed=embed)
                delivered += 1
            except Exception as e:
                log.warning("admin DM failed (%s): %s", uid, e)
        if not delivered:
            print(f"[ALERT UNDELIVERED] 管理者の誰にもDMできませんでした: {summary}", flush=True)
        return delivered > 0

    # ---- 入金突合(残高だけ増えた分を見つける) ----

    async def _reconcile_check(self):
        """入金履歴と、こちらの注文記録を突き合わせる（PayPay・Kyash）。

        見張りをすり抜けた分も、Botが止まっていた間に入った分も、最後はここで
        引っかかる。紐づかない入金が出たら、その1件について1回だけ知らせる。
        """
        now = time.time()
        for source in reconcile.active_sources():
            # サービスごとに間隔を分ける。受け取りがその場で確定するKyashを
            # 5分おきに叩いても、足跡が増えるだけ。
            if now - self._recon_last.get(source.method, 0) < source.interval:
                continue
            self._recon_last[source.method] = now
            try:
                await self._reconcile_source(source)
            except reconcile.ReconcileError as e:
                log.warning("%s の入金突合に失敗: %s", source.label, e)
            except Exception as e:
                log.exception("%s の入金突合でエラー: %s", source.label, e)

    async def _reconcile_source(self, source):
        """入金履歴を見て、受け取れているのに止まっている注文をお渡しする。

        リンクの状態が読めずに watching のまま止まった注文にとっては、
        これが最後の経路になる。
        """
        result = await reconcile.run(source=source)
        await self._settle_confirmed(result["undelivered"])

    async def _settle_confirmed(self, undelivered: list):
        """入金履歴で受け取りが確認できた注文を決着させ、そのままお渡しする。

        リンクの状態からは受け取りを確認できないことがあり、その注文は入金済み
        なのに watching のまま止まる。履歴を正として決着させることで、
        お渡し・売上記録・購入ロールまで通常どおり自動で走る。
        """
        for entry, record in undelivered:
            try:
                if record.get("source") == "order" and record.get("order_id"):
                    watched = link_orders.get_order(record["order_id"]) or {}
                    if link_orders.held_order(watched):
                        # そのリンクは支払い画面が受け取っている最中。ここで
                        # 決着させると同じ入金で2回渡すことになる。次の突合へ回す。
                        log.info("支払い画面が受け取り中のため決着を見送りました: %s",
                                 record.get("order_id"))
                        continue
                    # 入金履歴は「同額」というだけで、この注文のものとは限らない。
                    # リンクを読み直して、本当にこの注文に入っているときだけ渡す。
                    # まだ未承認・キャンセルのままなら、入ったのは別の注文のお金。
                    if not await link_orders.deposit_belongs_to_order(watched):
                        log.info("入金がこの注文のものと確認できず、決着を見送りました: %s",
                                 record.get("order_id"))
                        continue
                    order = await link_orders.settle_from_history(
                        record["order_id"], int(entry["amount"]), entry["key"])
                elif record.get("source") == "attempt":
                    order = await self._revive_attempt(record, entry)
                else:
                    continue
            except link_orders.LinkOrderError as e:
                log.warning("入金履歴からの決着に失敗 (%s): %s", record.get("detail"), e)
                continue
            if not order:
                continue      # すでに決着済み / その入金は別の注文で使い済み
            log.warning("入金履歴で受け取りを確認: %s (%s円)",
                        order.get("id"), entry["amount"])
            await self._notify_received(order)
            await self._deliver(order)

    async def _revive_attempt(self, record: dict, entry: dict):
        """見張りにすら載らなかった注文を、支払い試行の控えから作り直す。

        支払い画面が途中で落ちた・在庫を取り置けなかった等で、注文がどこにも
        残らないまま入金だけ届くことがある。控えには誰が何を買おうとしたかが
        残っているので、入金を確認できた時点で注文を起こし直す。
        """
        attempt = next((a for a in payment_attempts.orphans()
                        if a.get("id") == record.get("attempt_id")), None)
        if not attempt or not attempt.get("payload"):
            return None      # 渡し直すのに必要な内容が残っていない(手動対応)
        link = attempt.get("link") or ""
        if not link or link_orders.link_blocks_revival(link):
            # そのリンクの注文はもう作られていて、見張り中か渡し済み。作り直すと
            # 二重お渡しになる。例外は、支払い画面が受け取りはしたが渡す前に
            # 止まった記録(渡した印が無い)だけで、それは下で渡し直す。
            return None
        if link_orders.held_link(link):
            # 支払い画面がまさに受け取っている最中。そちらが渡すので触らない。
            return None
        # 入金履歴は「同額」というだけで、この試行のお金とは限らない。リンクを
        # 読み直して、取り消し(GONE)・未承認(PENDING)のままなら、入ったのは別の
        # 注文のお金。ここで起こし直すと、払っていない人に代行・商品が渡る。
        if not await link_orders.deposit_belongs_to_order({
                "link": link, "accepted": True,
                "amount_jpy": int(attempt.get("amount") or entry["amount"])}):
            log.info("入金がこの試行のものと確認できず、起こし直しを見送りました: %s",
                     attempt.get("id"))
            return None

        order = await link_orders.create_order(
            attempt["kind"], attempt["user_id"], link,
            amount_jpy=int(attempt.get("amount") or entry["amount"]),
            payload=attempt["payload"], method=attempt.get("method"),
            accepted=True, summary=attempt.get("summary") or "",
            guild_id=attempt.get("guild_id"), channel_id=attempt.get("channel_id"))
        if not order or order.get("reused"):
            return None
        await payment_attempts.resolve_async(
            attempt["id"], payment_attempts.WATCHING,
            f"入金を確認したので注文 {order['id']} として起こし直しました")
        # 渡す前に止まった画面側の記録には、どの注文で渡し直すかを書いて席を譲らせる
        # (同じリンクをもう一度渡し直しの候補にしない)。
        for stuck in link_orders.undelivered_screen_records(link):
            try:
                await link_orders.mark_order(
                    stuck["id"], link_orders.DONE, superseded_by=order["id"],
                    note=f"お渡し前に止まったため、注文 {order['id']} として渡し直します")
            except Exception as e:
                log.warning("画面側の記録 %s を更新できませんでした: %s", stuck.get("id"), e)
        return await link_orders.settle_from_history(
            order["id"], int(entry["amount"]), entry["key"])

    # ---- 管理者向け: いま見張っている支払いの一覧 ----

    @staticmethod
    def _has_stashed_save(order: dict) -> bool:
        """お客さんの手を借りずにやり直せるか(セーブを預かってあるか)。

        引き継ぎコードは一度使うと消えるので、預かりが無ければ入れ直しを
        お願いするしかない。あるなら不具合を直した後そのまま流せる。
        """
        payload = order.get("payload") or {}
        return bool(payload.get("save_file"))

    async def _force_deliver(self, order: dict) -> str:
        """自動で流れなかった注文を手で流す。失敗したら理由をそのまま返す。"""
        oid = order["id"]
        if order.get("status") == link_orders.DONE:
            return "この注文はすでにお渡し済みです。"
        if order.get("awaiting_code"):
            # 残したまま成功すると「まだ入れ直し待ち」に見えて催促が飛び続ける
            order = await link_orders.mark_order(
                oid, order.get("status") or link_orders.PAID,
                awaiting_code=False, deliver_attempts=0) or order

        settled = await link_orders.settle_from_history(
            oid, int(order.get("paid_amount") or order.get("amount_jpy") or 0),
            f"manual:{int(time.time())}")
        order = settled or link_orders.get_order(oid)

        handler = link_orders.get_handler(order.get("kind"))
        if handler is None:
            return f"`{order.get('kind')}` のお渡し処理が登録されていません。"
        try:
            ok = await handler(order)
            note = "" if ok else "お渡し処理が False を返しました（DMを送れない等）"
        except link_orders.NeedsCustomerInput as e:
            await link_orders.mark_order(oid, link_orders.PAID,
                                         awaiting_code=True, note=str(e)[:300])
            await self._ask_customer(order, e.prompt)
            return (f"お客さんの入れ直しが必要です。入力用のボタンを送りました。\n```{e}```")
        except Exception as e:
            ok, note = False, f"{type(e).__name__}: {e}"[:800]
            log.exception("force deliver failed (%s)", oid)

        if ok:
            await link_orders.mark_order(oid, link_orders.DONE, note="")
            return (f"`{oid}` をお渡ししました（{self._amount(order):,}円 / "
                    f"<@{order.get('user_id')}>）。")
        if ok is None:
            current = link_orders.get_order(oid) or order
            return (f"`{oid}` はまだ始められません（その人の別の代行が実行中か、サーバに"
                    f"拒まれた直後です）。次の巡回で自動で流します。\n```{current.get('note') or ''}```")
        return f"`{oid}` をお渡しできませんでした。\n```{note}```"

    def _order_embed(self, order: dict) -> discord.Embed:
        embed = discord.Embed(title=f"注文 `{order.get('id')}`",
                              description=str(order.get("summary") or order.get("kind")),
                              color=0x00aaff)
        embed.add_field(name="状態", value=str(order.get("status")), inline=True)
        embed.add_field(name="金額", value=f"{self._amount(order):,}円", inline=True)
        embed.add_field(name="受け取り送信済み",
                        value="はい" if order.get("accepted") else "いいえ", inline=True)
        embed.add_field(name="購入者", value=f"<@{order.get('user_id')}>", inline=False)
        embed.add_field(name="リンク", value=f"`{str(order.get('link'))[:200]}`", inline=False)
        embed.add_field(name="期限", value=f"<t:{int(float(order.get('expires_at') or 0))}:R>", inline=True)
        if order.get("note"):
            embed.add_field(name="メモ", value=f"```{str(order['note'])[:300]}```", inline=False)
        return embed


async def setup(bot):
    await bot.add_cog(LinkWatchCog(bot))
