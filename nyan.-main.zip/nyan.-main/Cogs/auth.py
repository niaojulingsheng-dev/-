"""認証(OAuth2) & メンバーバックアップの管理コマンド (/auth)。

認証パネルの「認証する」ボタンから identify + guilds.join を許可してもらい、
トークンを保存する。/auth restore で全員をサーバーへ再参加させられる。
"""
import asyncio

import discord
from discord import app_commands, ui
from discord.ext import commands

from utils import ADMIN_USER_IDS
import auth_backup as ab


def _is_admin(interaction: discord.Interaction) -> bool:
    return interaction.user.id in ADMIN_USER_IDS


def auth_panel_embed(title: str, description: str) -> discord.Embed:
    return discord.Embed(title=title, description=description, color=0x5865F2)


def auth_panel_view(guild_id) -> ui.View:
    """『認証する』リンクボタン(DiscordのOAuth2認可URL)を載せたView。
    URLボタンはインタラクションを発生させないため、再起動後もそのまま機能する。"""
    v = ui.View(timeout=None)
    v.add_item(ui.Button(label="here", style=discord.ButtonStyle.link,
                         url=ab.authorize_url(guild_id), emoji="✅"))
    return v


class AuthCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    auth = app_commands.Group(name="auth", description="認証・メンバーバックアップ(管理者用)")

    async def _deny(self, interaction):
        await interaction.response.send_message("権限がありません。", ephemeral=True)

    @auth.command(name="setrole", description="認証で付けるロール")
    @app_commands.describe(role="付与するロール(省略で解除)")
    async def setrole(self, interaction: discord.Interaction, role: discord.Role = None):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        if role is not None:
            me = interaction.guild.me
            if role >= me.top_role:
                return await interaction.response.send_message(
                    "そのロールはBotより上位のため付与できません。Botのロールを上に移動してください。", ephemeral=True)
        ab.set_role_id(interaction.guild.id, role.id if role else None)
        if role:
            await interaction.response.send_message(f"認証ロールを {role.mention} に設定しました。", ephemeral=True)
        else:
            await interaction.response.send_message("認証ロールを解除しました。", ephemeral=True)

    @auth.command(name="panel", description="認証パネルを設置")
    @app_commands.describe(title="パネルのタイトル", description="説明文")
    async def panel(self, interaction: discord.Interaction,
                    title: str = "✅ 認証", description: str = None):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        if not ab.is_configured():
            return await interaction.response.send_message(
                "OAuth2の設定が未完了です。環境変数 `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET` / "
                "`OAUTH_REDIRECT_URI` を設定してから実行してください。", ephemeral=True)
        desc = description or (
            "下のボタンから認証してください。\n"
            "認証するとこのサーバーのメンバーとして登録され、"
            "万一の際もサーバーへ復帰できるようになります。"
        )
        await interaction.response.send_message("認証パネルを設置しました。", ephemeral=True)
        await interaction.channel.send(
            embed=auth_panel_embed(title, desc),
            view=auth_panel_view(interaction.guild.id),
        )

    @auth.command(name="count", description="認証済みの人数")
    async def count(self, interaction: discord.Interaction):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        await interaction.response.send_message(
            f"認証済みユーザー: **{ab.count_tokens()}人**", ephemeral=True)

    @auth.command(name="check", description="認証状態を見る")
    @app_commands.describe(user_id="対象ユーザーのID")
    async def check(self, interaction: discord.Interaction, user_id: str):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        uid = user_id.strip().strip("<@!>")
        entry = ab.load_tokens().get(uid)
        if not entry:
            return await interaction.response.send_message(
                f"<@{uid}> は認証データがありません。", ephemeral=True)
        import time as _t
        exp = float(entry.get("expires_at", 0) or 0)
        state = "有効" if exp > _t.time() else "期限切れ(復元時にリフレッシュ試行)"
        has_refresh = "あり" if entry.get("refresh_token") else "なし"
        e = discord.Embed(title="認証データ", color=0x5865F2)
        e.add_field(name="ユーザー", value=f"<@{uid}>（`{uid}`）", inline=False)
        e.add_field(name="ユーザー名", value=f"`{entry.get('username','不明')}`", inline=True)
        e.add_field(name="トークン状態", value=state, inline=True)
        e.add_field(name="リフレッシュトークン", value=has_refresh, inline=True)
        if exp:
            e.add_field(name="有効期限", value=f"<t:{int(exp)}:f>（<t:{int(exp)}:R>）", inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)

    @auth.command(name="delete", description="認証データを消す")
    @app_commands.describe(user_id="対象ユーザーのID")
    async def delete(self, interaction: discord.Interaction, user_id: str):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        uid = user_id.strip().strip("<@!>")
        if ab.delete_token(uid):
            await interaction.response.send_message(f"<@{uid}> の認証データを削除しました。", ephemeral=True)
        else:
            await interaction.response.send_message(f"<@{uid}> の認証データはありません。", ephemeral=True)

    @auth.command(name="restore", description="認証済みを全員呼び戻す")
    async def restore(self, interaction: discord.Interaction):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        total = ab.count_tokens()
        if total == 0:
            return await interaction.response.send_message("認証済みユーザーがいません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await asyncio.to_thread(ab.restore_all, interaction.guild.id)
        e = discord.Embed(title="メンバーバックアップ復元 完了", color=0x00ff88)
        e.add_field(name="対象", value=f"{result['total']}人", inline=False)
        e.add_field(name="追加", value=f"{result['added']}人", inline=True)
        e.add_field(name="既に参加済み", value=f"{result['already']}人", inline=True)
        e.add_field(name="失効/取消", value=f"{result['expired']}人", inline=True)
        e.add_field(name="失敗", value=f"{result['failed']}人", inline=True)
        await interaction.followup.send(embed=e, ephemeral=True)

    @auth.command(name="restore_one", description="指定の1人を呼び戻す")
    @app_commands.describe(user_id="対象ユーザーのID")
    async def restore_one(self, interaction: discord.Interaction, user_id: str):
        if not _is_admin(interaction):
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        uid = user_id.strip().strip("<@!>")
        if uid not in ab.load_tokens():
            return await interaction.response.send_message(f"<@{uid}> の認証データがありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await asyncio.to_thread(ab.restore_all, interaction.guild.id, uid)
        if result["added"]:
            msg = f"<@{uid}> をサーバーに追加しました。"
        elif result["already"]:
            msg = f"<@{uid}> は既に参加済みです。"
        elif result["expired"]:
            msg = f"<@{uid}> のトークンが失効しています(再認証が必要)。"
        else:
            msg = f"<@{uid}> の追加に失敗しました。"
        await interaction.followup.send(msg, ephemeral=True)


async def setup(bot):
    await bot.add_cog(AuthCog(bot))
