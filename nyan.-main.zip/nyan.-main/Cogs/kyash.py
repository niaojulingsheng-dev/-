import asyncio
import logging
import os
import random
from datetime import datetime, timezone

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

import history_view
import kyash_async
import usage_report
import reconcile
from kyash_mobile import KyashError, KyashLoginError, KyashNetWorkError, error_message
from kyash_mobile.app_version import get_app_version, version_source
from utils import ADMIN_USER_IDS, is_allowed

log = logging.getLogger(__name__)

# ワンタイムコード待ちの Kyash オブジェクト。user_id -> {"ky","email","password"}
PENDING_LOGINS = {}

# 失効したまま放置されないよう、再ログインするまで一定間隔で通知し直す。
EXPIRY_RENOTIFY_HOURS = 6
# 生存確認をきっかり同じ時刻に走らせると機械的なので、毎回この範囲でずらす。
KEEP_ALIVE_JITTER_SECONDS = 900


def _is_admin(interaction) -> bool:
    return interaction.user.id in ADMIN_USER_IDS


def _err(e) -> str:
    return error_message(e)


def _mask(email: str) -> str:
    """メールアドレスを伏せて表示する(admin@example.com → a***n@example.com)。"""
    if not email or "@" not in email:
        return email or "未登録"
    name, domain = email.split("@", 1)
    if len(name) <= 2:
        return f"{name[0]}***@{domain}"
    return f"{name[0]}***{name[-1]}@{domain}"


class OtpModal(ui.Modal, title="Kyashのワンタイムコード入力"):
    code = ui.TextInput(label="ワンタイムコード", placeholder="SMS/メールで届いた数字", required=True, max_length=10)

    def __init__(self, session: dict, cog=None):
        super().__init__(timeout=600)
        self.session = session
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        s = self.session
        try:
            await kyash_async.complete_login(s["ky"], self.code.value.strip(), s["email"], s["password"])
        except (KyashLoginError, KyashError, KyashNetWorkError) as e:
            embed = discord.Embed(
                title="Kyash認証エラー",
                description=("コードが正しくないか、有効期限が切れています。\n"
                             f"`/kyash` からやり直してください。\n```{_err(e)}```"),
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)

        PENDING_LOGINS.pop(str(interaction.user.id), None)
        if self.cog is not None:
            self.cog._on_healthy()
        embed = discord.Embed(
            title="Kyash登録完了",
            description=("Kyashアカウントの登録が完了しました。\n"
                         "このアカウントで代行・自販機の支払いを自動受取します。\n"
                         "この端末は覚えられたので、次回以降はコード無しで入り直せます。"),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


class OtpView(ui.View):
    def __init__(self, cog=None):
        super().__init__(timeout=600)
        self.cog = cog

    @ui.button(label="コードを入力", style=discord.ButtonStyle.primary, emoji="🔑")
    async def enter_code(self, interaction: discord.Interaction, button: ui.Button):
        session = PENDING_LOGINS.get(str(interaction.user.id))
        if not session:
            return await interaction.response.send_message(
                "認証セッションの有効期限が切れました。もう一度 `/kyash` を実行してください。", ephemeral=True)
        await interaction.response.send_modal(OtpModal(session, self.cog))


class KyashReloginView(ui.View):
    """失効通知DMに付ける「再ログインを開始」ボタン(永続View)。

    保存済みのメールアドレス・パスワードでログインし直すところまでBotがやる。
    端末が覚えられていればその場で完了し、忘れられていたときだけコード入力になる。
    """

    def __init__(self, cog=None):
        super().__init__(timeout=None)
        self.cog = cog

    @ui.button(label="再ログインを開始", style=discord.ButtonStyle.primary, emoji="🔑",
               custom_id="kyash:relogin")
    async def relogin(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみ実行できます。", ephemeral=True)

        email, password = kyash_async.owner_login_info()
        if not email or not password:
            return await interaction.response.send_message(
                "保存されたログイン情報がありません。`/kyash` から登録してください。", ephemeral=True)

        await interaction.response.defer(ephemeral=True)
        try:
            ky, otp_required = await kyash_async.start_login(email, password)
        except KyashLoginError as e:
            return await interaction.followup.send(
                "ログインできませんでした。パスワードが変更されている可能性があります。\n"
                f"`/kyash` からやり直してください。\n```{_err(e)}```", ephemeral=True)
        except (KyashError, KyashNetWorkError) as e:
            return await interaction.followup.send(
                "Kyashとの通信に失敗しました。少し時間をおいてからもう一度押してください。\n"
                f"```{_err(e)}```", ephemeral=True)

        if not otp_required:
            if self.cog is not None:
                self.cog._on_healthy()
            return await interaction.followup.send("✅ 再ログインが完了しました。", ephemeral=True)

        PENDING_LOGINS[str(interaction.user.id)] = {"ky": ky, "email": email, "password": password}
        embed = discord.Embed(
            title="ワンタイムコードを送信しました",
            description=(f"`{_mask(email)}` 宛にコードを送りました。\n"
                         "届いたコードを下のボタンから入力すれば復旧します。"),
            color=discord.Color.blurple(),
        )
        await interaction.followup.send(embed=embed, view=OtpView(self.cog), ephemeral=True)


class KyashCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(KyashReloginView(self))
        self._expiry_notified_at = 0.0
        self._last_alive = 0.0
        self.keep_alive_loop.start()

    def cog_unload(self):
        self.keep_alive_loop.cancel()

    # ---- 生存確認(切れていたら自動で入り直す) ----

    @tasks.loop(minutes=kyash_async.KEEP_ALIVE_INTERVAL_MINUTES)
    async def keep_alive_loop(self):
        await asyncio.sleep(random.uniform(0, KEEP_ALIVE_JITTER_SECONDS))
        try:
            ok = await kyash_async.keep_alive()
        except kyash_async.NotRegisteredError:
            return
        except KyashLoginError:
            # トークンが無効。保存済みの端末UUIDで入り直せるか試す。
            try:
                await kyash_async.relogin(force=True)
            except kyash_async.NotRegisteredError:
                return
            except kyash_async.OtpRequiredError as e:
                log.warning("Kyash session expired: %s", _err(e))
                await self._notify_expired(_err(e))
                return
            except Exception as e:
                log.warning("Kyash relogin failed: %s", e)
                return
            self._on_healthy()
            log.info("Kyash session revived by relogin")
            return
        except Exception as e:
            log.exception("Kyash keep-alive error: %s", e)
            return

        if ok:
            self._last_alive = datetime.now(timezone.utc).timestamp()
            self._on_healthy()
        # 期限が近づいてきたら、切れる前に自分から入り直しておく
        try:
            await kyash_async.relogin()
        except kyash_async.OtpRequiredError as e:
            # まだ生きているが、次に切れたら手動対応が必要になるので今のうちに知らせる
            log.warning("Kyash proactive relogin needs OTP: %s", _err(e))
            await self._notify_expired(_err(e), still_alive=True)
        except Exception as e:
            log.debug("Kyash proactive relogin skipped: %s", e)

    @keep_alive_loop.before_loop
    async def _before_keep_alive(self):
        await self.bot.wait_until_ready()

    def _on_healthy(self):
        self._expiry_notified_at = 0.0

    async def _dm_admins(self, embed: discord.Embed, view: ui.View = None):
        for uid in ADMIN_USER_IDS:
            try:
                user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                if view is not None:
                    await user.send(embed=embed, view=view)
                else:
                    await user.send(embed=embed)
            except Exception:
                continue

    async def _notify_expired(self, detail: str = "", still_alive: bool = False):
        """再ログインが必要になったことを管理者にDMする。

        still_alive=True は「まだ受取はできるが、延命の入り直しにコードが要る」状態。
        """
        now = datetime.now(timezone.utc).timestamp()
        if self._expiry_notified_at and now - self._expiry_notified_at < EXPIRY_RENOTIFY_HOURS * 3600:
            return
        self._expiry_notified_at = now
        embed = discord.Embed(
            title=("⚠️ Kyashの再ログインが必要です" if still_alive else "⚠️ Kyashのログインが切れました"),
            description=(("セッションの延命に失敗しました。今はまだ受取できますが、"
                          "このままだと切れます。\n\n"
                          if still_alive else
                          "自動での入り直しができませんでした。ワンタイムコードでの再ログインが必要です。\n\n") +
                         "下の **再ログインを開始** を押すと、登録済みのアドレスにコードが届きます。\n\n"
                         "**Kyash払いの自動受取だけが止まります**"
                         "（PayPayでの支払いは影響を受けません）。"),
            color=(0xffaa00 if still_alive else 0xff3333),
        )
        if detail:
            embed.add_field(name="Kyashの応答", value=f"```{detail[:300]}```", inline=False)
        embed.set_footer(text=f"再登録されるまで{EXPIRY_RENOTIFY_HOURS}時間ごとに通知します")
        await self._dm_admins(embed, view=KyashReloginView(self))

    # ---- 登録 ----

    @app_commands.command(name="kyash", description="Kyashを登録")
    @is_allowed()
    @app_commands.describe(email="Kyashのメールアドレス", password="パスワード")
    async def kyash_register(self, interaction: discord.Interaction, email: str, password: str):
        await interaction.response.defer(ephemeral=True)
        try:
            ky, otp_required = await kyash_async.start_login(email, password)
        except KyashLoginError as e:
            embed = discord.Embed(
                title="Kyashログインエラー",
                description=("メールアドレス・パスワードが正しいか確認してください。\n"
                             f"```{_err(e)}```"),
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)
        except KyashNetWorkError:
            embed = discord.Embed(
                title="Kyash接続エラー",
                description="Kyashに接続できませんでした。時間をおいてからもう一度お試しください。",
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="Kyashログイン処理エラー",
                description=f"ログイン処理中にエラーが発生しました。\n```{str(e)[:500]}```",
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)

        if not otp_required:
            self._on_healthy()
            return await interaction.followup.send(
                "✅ Kyashアカウントの登録が完了しました（この端末は登録済みでした）。", ephemeral=True)

        PENDING_LOGINS[str(interaction.user.id)] = {"ky": ky, "email": email, "password": password}
        embed = discord.Embed(
            title="ワンタイムコード認証",
            description=("Kyashからワンタイムコードが届きます（SMSまたはメール）。\n"
                         "届いたコードを下のボタンから入力してください。"),
            color=discord.Color.blue(),
        )
        await interaction.followup.send(embed=embed, view=OtpView(self), ephemeral=True)

    # ---- 操作系(登録済みの共有アカウントで実行) ----

    async def _guard(self, interaction):
        if not _is_admin(interaction):
            await interaction.response.send_message("権限がありません。", ephemeral=True)
            return False
        return True

    async def status_embed(self) -> discord.Embed:
        """セッション状態と残高をまとめたEmbedを作る。残高が取れなくても状態は出す。"""
        st = kyash_async.session_status()
        e = discord.Embed(title="Kyashの状態", color=discord.Color.blue())
        e.add_field(name="アカウント", value=f"`{_mask(st.get('email'))}`", inline=False)

        try:
            wallet = await kyash_async.run_owner_op(lambda ky: ky.get_wallet())
            e.add_field(
                name="残高",
                value=(f"**{wallet.all_balance:,}円**\n"
                       f"マネー {wallet.money:,}円 / バリュー {wallet.value:,}円\n"
                       f"ポイント {wallet.point:,}pt"),
                inline=False)
        except (kyash_async.NotRegisteredError, KyashLoginError, KyashError, KyashNetWorkError) as ex:
            e.add_field(name="残高", value=f"取得できませんでした\n```{_err(ex)[:200]}```", inline=False)

        for label, ts in (("最終ログイン", st.get("logged_in_at")), ("最終更新", st.get("refreshed_at"))):
            e.add_field(name=label,
                        value=(f"<t:{int(ts)}:f>（<t:{int(ts)}:R>）" if ts else "記録なし"), inline=False)
        e.add_field(name="自動入り直し", value=f"{kyash_async.RELOGIN_AFTER_DAYS}日ごと", inline=True)
        e.add_field(name="生存確認", value=f"{kyash_async.KEEP_ALIVE_INTERVAL_MINUTES}分ごと", inline=True)
        e.add_field(name="名乗るアプリ版", value=f"{get_app_version()}（{version_source()}）", inline=True)
        if self._last_alive:
            e.add_field(name="最終生存確認", value=f"<t:{int(self._last_alive)}:R>", inline=True)
        if st.get("stale"):
            e.add_field(name="⚠️", value="そろそろ入り直す時期です（下のボタン）", inline=False)
        return e

    @app_commands.command(
        name="kyash_status",
        description="Kyashの残高・履歴・操作")
    async def kyash_status(self, interaction: discord.Interaction):
        if not await self._guard(interaction): return
        if not kyash_async.is_registered():
            return await interaction.response.send_message(
                "Kyashアカウントは未登録です。`/kyash` で登録してください。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        await interaction.followup.send(embed=await self.status_embed(),
                                        view=SessionActionView(self), ephemeral=True)


# ---- 取引履歴 ----

# 読み方(候補キー・種別の表)は突合と共有する。別々に持つと、画面では入金に
# 見えるのに突合では対象外、といった食い違いが出る。
KYASH_KEYS = reconcile.KYASH_KEYS

# 突合での扱い → 履歴表示での向き
_WAYS = {"incoming": history_view.IN, "outgoing": history_view.OUT,
         "self": history_view.SELF}


# 入りと出で言い方が変わるもの。送金リンクは送る側も受け取る側も transfer
# なので、「送金」とだけ書くと受け取りまで送金に見えてしまう。
_INCOMING_LABELS = {"送金": "受け取り", "出金": "入金"}


def _kind_label(entry: dict) -> str:
    """取引の見出し。知らない種別はそのまま出す(黙って隠さない)。"""
    rule = reconcile.kyash_kind_rule(entry)
    if not rule:
        return entry.get("type") or "取引"
    label = rule[0]
    if _direction(entry) == history_view.IN:
        return _INCOMING_LABELS.get(label, label)
    return label


def _direction(entry: dict) -> str:
    """入り・出・自分の入り。

    符号があるので向きは基本それで決まる。種別を見るのはチャージや失効など、
    お客さんとのやりとりではない動きを分ける分だけ。
    """
    rule = reconcile.kyash_kind_rule(entry)
    if rule and rule[1] in _WAYS:
        return _WAYS[rule[1]]
    return history_view.by_amount_sign(entry)


def history_embed(entries: list, balance=None) -> discord.Embed:
    return history_view.render(entries, title="Kyashの取引履歴", balance=balance,
                               direction=_direction, kind_label=_kind_label)


# 履歴の見出し → 利用レポートの内訳。Kyashの種別は KYASH_KIND_RULES が
# すでに日本語の見出しにしてくれるので、それを入り・出で言い分けるだけ。
_REPORT_LABELS = {
    ("送金", usage_report.OUT): "送金した額",
    ("受け取り", usage_report.IN): "受け取り額",
    ("支払い", usage_report.OUT): "支払い額",
    ("出金", usage_report.OUT): "銀行口座への出金額",
    ("入金", usage_report.IN): "入金額",
    ("チャージ", usage_report.IN): "チャージ額",
    ("還元", usage_report.IN): "還元・ポイント",
    ("返金", usage_report.IN): "返金額",
}


def _report_bucket(entry: dict):
    """1件を (向き, 見出し) に振り分ける。数えないものは向きに None。

    請求を出しただけ・期限切れは残高が動かないので数えない。
    知らない種別は落とさず「その他」に入れる(落とすと合計が合わなくなる)。
    """
    kind = (entry.get("type") or "").upper()
    if "REQUEST" in kind or "EXPIRY" in kind:
        return None, ""
    if reconcile.looks_dead(entry):
        return None, ""
    amount = entry.get("amount")
    if not amount:
        return None, ""
    # Kyashは金額に符号が付く(出ていく分がマイナス)ので、向きはこれで決まる。
    way = usage_report.OUT if amount < 0 else usage_report.IN
    label = _kind_label(entry)
    known = _REPORT_LABELS.get((label, way))
    if known:
        return way, known
    # 知らない種別も落とさない(落とすと内訳の合計と総額が合わなくなる)。
    # 何が読めていないのか分かるように、Kyash側の種別をそのまま添える。
    side = "出金" if way == usage_report.OUT else "入金"
    return way, f"その他の{side}（{kind}）" if kind else f"その他の{side}"


# レポート用に取る履歴の件数。一覧の20件では月の合計に足りない。
REPORT_HISTORY_SIZE = int(os.environ.get("KYASH_REPORT_HISTORY_SIZE", "200"))


def report_view(entries: list, fetched: int = 0) -> usage_report.ReportView:
    oldest = min((e.get("ts") or 0) for e in entries) if entries else 0
    return usage_report.ReportView(entries, bucket=_report_bucket,
                                   title="Kyash 利用レポート",
                                   fetched=fetched, oldest_ts=oldest)


class HistoryView(ui.View):
    """取引履歴に添えるボタン。月ごとの合計はここから開く。"""

    def __init__(self):
        super().__init__(timeout=300)

    @ui.button(label="利用レポート（月ごとの入出金）",
               style=discord.ButtonStyle.primary, emoji="📊")
    async def report(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。",
                                                           ephemeral=True)
        await interaction.response.defer(ephemeral=True)

        def fetch(ky):
            wallet = ky.get_wallet()
            return ky.get_history(wallet_uuid=wallet.uuid,
                                  limit=REPORT_HISTORY_SIZE)

        try:
            items = await kyash_async.run_owner_op(fetch)
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "利用レポートを作れませんでした。", e)

        entries = [reconcile.normalize_entry(x, KYASH_KEYS,
                                             source=reconcile.KYASH_SOURCE.method)
                   for x in items if isinstance(x, dict)]
        if not entries:
            return await interaction.followup.send(
                "集計できる取引がありませんでした。", ephemeral=True)
        view = report_view(entries, fetched=len(entries))
        await interaction.followup.send(embed=view.embed(), view=view,
                                        ephemeral=True)


# ---- 操作の入力欄 ----

async def _reply_error(interaction: discord.Interaction, what: str, e):
    """操作に失敗したときの返事。未登録と失効はやることが違うので分ける。"""
    if isinstance(e, kyash_async.NotRegisteredError):
        text = "Kyashアカウントが未登録です。`/kyash` で登録してください。"
    elif isinstance(e, KyashLoginError):
        text = ("Kyashのログインが切れています。下の「今すぐログインし直す」を試して、"
                f"駄目なら `/kyash` で再登録してください。\n```{_err(e)}```")
    else:
        text = f"{what}\n```{_err(e)}```"
    await interaction.followup.send(text, ephemeral=True)


def _parse_amount(raw: str):
    """入力された金額を数値にする。読めなければ None。"""
    text = (raw or "").strip().replace(",", "").replace("円", "")
    if not text.isdigit():
        return None
    value = int(text)
    return value if value > 0 else None


class SendLinkModal(ui.Modal, title="送金リンクを作る"):
    """Kyash残高から送金リンクを作る。受け取られるまでは取り消せる。"""

    amount_input = ui.TextInput(label="金額", placeholder="例: 10000", required=True)
    message_input = ui.TextInput(
        label="メッセージ（任意）",
        placeholder="相手のKyashに一緒に表示されます",
        required=False, max_length=100)

    def __init__(self, cog=None):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        amount = _parse_amount(self.amount_input.value)
        if amount is None:
            return await interaction.followup.send("金額は1円以上の数字で入れてください。", ephemeral=True)
        message = self.message_input.value.strip()

        try:
            link = await kyash_async.run_owner_op(
                lambda ky: ky.create_link(amount, message=message))
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "送金リンクを作れませんでした。", e)

        embed = discord.Embed(
            title="送金リンクを作りました",
            description=f"**{amount:,}円**\n{link.link}",
            color=discord.Color.green(),
        )
        if message:
            embed.add_field(name="メッセージ", value=message[:200], inline=False)
        embed.set_footer(text="受け取られるまでは「送金を取り消す」で戻せます")
        await interaction.followup.send(embed=embed, ephemeral=True)


class ClaimLinkModal(ui.Modal, title="請求リンクを作る"):
    """相手に払ってもらうためのリンク(Kyashの「リクエスト」)を作る。"""

    amount_input = ui.TextInput(label="請求金額", placeholder="例: 1000", required=True)
    message_input = ui.TextInput(
        label="メッセージ（任意）",
        placeholder="何の代金かを書いておくと親切です",
        required=False, max_length=100)

    def __init__(self, cog=None):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        amount = _parse_amount(self.amount_input.value)
        if amount is None:
            return await interaction.followup.send("請求金額は1円以上の数字で入れてください。", ephemeral=True)
        message = self.message_input.value.strip()

        try:
            link = await kyash_async.run_owner_op(
                lambda ky: ky.create_link(amount, message=message, is_claim=True))
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "請求リンクを作れませんでした。", e)

        embed = discord.Embed(
            title="請求リンクを作りました",
            description=(f"**{amount:,}円**\n{link.link}\n\n"
                         "このリンクを相手に渡すと、この受取用アカウントへ支払えます。"),
            color=discord.Color.blue(),
        )
        if message:
            embed.add_field(name="メッセージ", value=message[:200], inline=False)
        await interaction.followup.send(embed=embed, ephemeral=True)


class ReceiveLinkModal(ui.Modal, title="送金リンクから受け取る"):
    link_input = ui.TextInput(
        label="Kyashの送金リンク",
        placeholder="https://kyash.me/payments/...",
        required=True,
    )

    def __init__(self, cog=None):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        link = self.link_input.value.strip()
        if not link:
            return await interaction.followup.send("リンクを入れてください。", ephemeral=True)
        try:
            amount = await kyash_async.receive_payment(url=link)
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "受け取れませんでした。", e)
        await interaction.followup.send(f"✅ **{amount:,}円** を受け取りました。", ephemeral=True)


class CancelLinkModal(ui.Modal, title="送金を取り消す"):
    """まだ受け取られていない送金リンクを取り消して、残高に戻す。"""

    link_input = ui.TextInput(
        label="Kyashの送金リンク",
        placeholder="https://kyash.me/payments/...",
        required=True,
    )

    def __init__(self, cog=None):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        url = self.link_input.value.strip()
        if not url:
            return await interaction.followup.send("リンクを入れてください。", ephemeral=True)

        def cancel(ky):
            # 先に中身を見てから取り消す。いくら戻したのかを結果に出せる。
            info = ky.link_check(url)
            ky.link_cancel(link_uuid=info.uuid)
            return info

        try:
            info = await kyash_async.run_owner_op(cancel)
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(
                interaction,
                "取り消せませんでした。\n"
                "（すでに受け取られている・取り消し済み・このアカウントが作ったリンクでは"
                "ない、のいずれかだと取り消せません）", e)

        embed = discord.Embed(
            title="送金を取り消しました",
            description=(f"**{int(info.amount):,}円** を残高に戻しました。\n`{url}`"
                         if info.amount else f"取り消しました。\n`{url}`"),
            color=discord.Color.orange(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


class InspectLinkModal(ui.Modal, title="リンクを調べる"):
    """受け取らずにリンクの中身だけ見る。

    お客さんが貼ったものが請求リンクなのか、もう受け取られた後なのかを、
    お金を動かさずに確かめられる。
    """

    link_input = ui.TextInput(
        label="Kyashのリンク",
        placeholder="https://kyash.me/payments/...",
        required=True,
    )

    def __init__(self, cog=None):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        url = self.link_input.value.strip()
        if not url:
            return await interaction.followup.send("リンクを入れてください。", ephemeral=True)
        try:
            info = await kyash_async.run_owner_op(lambda ky: ky.link_check(url))
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(
                interaction,
                "リンクを確認できませんでした。\n"
                "（受け取り済み・取り消し済みのリンクもここに来ます）", e)

        embed = discord.Embed(
            title="リンクの中身",
            description=("**送金リンク**（このアカウントで受け取れます）"
                         if info.is_send_link else
                         "**請求リンク**（受け取れません。相手に送金リンクを作り直してもらってください）"),
            color=discord.Color.green() if info.is_send_link else 0xffaa00,
        )
        embed.add_field(name="金額",
                        value=(f"**{int(info.amount):,}円**" if info.amount else "読み取れませんでした"),
                        inline=True)
        if info.sender_name:
            embed.add_field(name="作った人", value=str(info.sender_name)[:64], inline=True)
        embed.set_footer(text="ここでは受け取っていません（お金は動いていません）")
        await interaction.followup.send(embed=embed, ephemeral=True)


class SessionActionView(ui.View):
    """状態表示に付ける操作ボタン。上段がお金の出し入れ、下段が確認と整備。

    たまにしか使わない操作なので、専用コマンドを増やさずここに集める。
    サインアウトは戻せないので、もう一段確認を挟む。
    """

    def __init__(self, cog: "KyashCog"):
        super().__init__(timeout=300)
        self.cog = cog

    # --- 1段目: お金の出し入れ ---

    @ui.button(label="送金リンクを作る", style=discord.ButtonStyle.success, emoji="💸", row=0)
    async def send_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(SendLinkModal(self.cog))

    @ui.button(label="請求リンクを作る", style=discord.ButtonStyle.success, emoji="🧾", row=0)
    async def claim_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(ClaimLinkModal(self.cog))

    @ui.button(label="受け取る", style=discord.ButtonStyle.success, emoji="📥", row=0)
    async def receive_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(ReceiveLinkModal(self.cog))

    @ui.button(label="送金を取り消す", style=discord.ButtonStyle.secondary, emoji="↩️", row=0)
    async def cancel_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(CancelLinkModal(self.cog))

    @ui.button(label="リンクを調べる", style=discord.ButtonStyle.secondary, emoji="🔍", row=0)
    async def inspect_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(InspectLinkModal(self.cog))

    # --- 2段目: 確認・メンテナンス ---

    @ui.button(label="取引履歴", style=discord.ButtonStyle.primary, emoji="📜", row=1)
    async def history(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)

        def fetch(ky):
            # 財布は残高と履歴の両方に要るので、1回だけ引いて使い回す
            wallet = ky.get_wallet()
            return wallet, ky.get_history(wallet_uuid=wallet.uuid, limit=20)

        try:
            wallet, items = await kyash_async.run_owner_op(fetch)
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "取引履歴を取得できませんでした。", e)

        entries = [reconcile.normalize_entry(x, KYASH_KEYS,
                                             source=reconcile.KYASH_SOURCE.method)
                   for x in items if isinstance(x, dict)]
        await interaction.followup.send(
            embed=history_embed(entries, wallet.all_balance),
            view=HistoryView(), ephemeral=True)

    @ui.button(label="アカウント情報", style=discord.ButtonStyle.primary, emoji="👤", row=1)
    async def profile(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            prof = await kyash_async.run_owner_op(lambda ky: ky.get_profile())
        except (kyash_async.NotRegisteredError, KyashLoginError,
                KyashError, KyashNetWorkError) as e:
            return await _reply_error(interaction, "取得できませんでした。", e)

        embed = discord.Embed(title="受取用アカウント", color=discord.Color.blurple())
        embed.add_field(name="ユーザー名", value=f"`{prof.username or '—'}`", inline=True)
        name = f"{prof.last_name} {prof.first_name}".strip()
        if name:
            embed.add_field(name="本人確認の氏名", value=name, inline=True)
        embed.add_field(name="本人確認（eKYC）",
                        value="済み" if prof.is_kyc else "**未完了**", inline=True)
        if prof.phone:
            embed.add_field(name="電話番号", value=f"`{prof.phone}`", inline=True)
        if prof.icon:
            embed.set_thumbnail(url=prof.icon)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @ui.button(label="今すぐログインし直す", style=discord.ButtonStyle.secondary, emoji="🔄", row=1)
    async def relogin(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            result = await kyash_async.relogin(force=True)
        except kyash_async.NotRegisteredError:
            return await interaction.followup.send(
                "Kyashアカウントが未登録です。`/kyash` で登録してください。", ephemeral=True)
        except kyash_async.OtpRequiredError as e:
            return await interaction.followup.send(
                "❌ 自動では入り直せませんでした。`/kyash` からワンタイムコードで再登録してください。\n"
                f"```{_err(e)}```", ephemeral=True)
        except kyash_async.ReloginFailedError as e:
            return await interaction.followup.send(
                f"⚠️ 一時的に失敗しました（再登録は不要です）。\n```{str(e)[:300]}```", ephemeral=True)
        self.cog._on_healthy()
        ts = int(result.get("refreshed_at") or 0)
        await interaction.followup.send(
            f"✅ ログインし直しました。（<t:{ts}:f>）" if ts else "✅ ログインし直しました。", ephemeral=True)

    @ui.button(label="サインアウト", style=discord.ButtonStyle.danger, emoji="🚪", row=1)
    async def signout(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)

        async def confirm(inter: discord.Interaction):
            removed = kyash_async.signout_owner()
            await inter.response.edit_message(
                content=("Kyashアカウントをサインアウトしました。`/kyash` で登録し直せます。"
                         if removed else "登録済みのKyashアカウントはありません。"),
                view=None)

        view = ui.View(timeout=60)
        btn = ui.Button(label="サインアウトする", style=discord.ButtonStyle.danger)
        btn.callback = confirm
        view.add_item(btn)
        await interaction.response.send_message(
            "Kyashの認証情報を削除します。よろしいですか？\n（削除すると、再登録するまでKyash払いの自動受取が止まります）",
            view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(KyashCog(bot))
