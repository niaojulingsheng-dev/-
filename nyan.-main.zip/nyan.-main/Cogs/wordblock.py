"""ワードブロック(NGワード自動削除)。

/word_block settings で設定パネルを開き、以下を変更できる:
  - NGワードの追加・削除・一覧
  - 検知時のタイムアウト時間
  - 監視しない(許可)ロール
NGワードを含むメッセージは自動削除し、タイムアウトが設定されていれば投稿者を
タイムアウトする。
"""
from datetime import timedelta

import discord
from discord import app_commands, ui
from discord.ext import commands

from utils import ADMIN_USER_IDS
from datapath import data_path, read_json, write_json

WORDBLOCK_FILE = data_path("wordblock.json")  # {guild_id: {"words":[], "timeout":int, "allowed_roles":[]}}


def _load_raw() -> dict:
    return read_json(WORDBLOCK_FILE, {})


def save_words(data: dict):
    write_json(WORDBLOCK_FILE, data)


def _normalize(entry) -> dict:
    """旧形式(ワードのリスト)を新形式(dict)に変換する。"""
    if isinstance(entry, list):
        return {"words": entry, "timeout": 0, "allowed_roles": []}
    if isinstance(entry, dict):
        return {
            "words": entry.get("words", []),
            "timeout": int(entry.get("timeout", 0) or 0),
            "allowed_roles": entry.get("allowed_roles", []),
        }
    return {"words": [], "timeout": 0, "allowed_roles": []}


def guild_conf(guild_id) -> dict:
    return _normalize(_load_raw().get(str(guild_id)))


def update_conf(guild_id, **changes):
    data = _load_raw()
    entry = _normalize(data.get(str(guild_id)))
    entry.update(changes)
    data[str(guild_id)] = entry
    save_words(data)
    return entry


def settings_embed(guild: discord.Guild, conf: dict) -> discord.Embed:
    e = discord.Embed(title="🚫 ワードブロック設定", color=0xff5555)
    words = conf["words"]
    e.add_field(
        name=f"NGワード（{len(words)}件）",
        value=("、".join(words)[:1024] if words else "なし"),
        inline=False,
    )
    to = conf["timeout"]
    e.add_field(name="タイムアウト時間", value=(f"{to}秒" if to else "なし（削除のみ）"), inline=True)
    rl = conf["allowed_roles"]
    e.add_field(name="許可ロール（監視しない）",
                value=("、".join(f"<@&{r}>" for r in rl) if rl else "なし"), inline=False)
    e.set_footer(text="ボタンから設定を変更できます。")
    return e


class AddWordModal(ui.Modal, title="NGワードを追加"):
    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id
        self.field = ui.TextInput(label="追加するワード(改行で複数可)",
                                  style=discord.TextStyle.paragraph, required=True)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        conf = guild_conf(self.guild_id)
        words = list(conf["words"])
        added = 0
        for w in self.field.value.splitlines():
            w = w.strip()
            if w and w not in words:
                words.append(w)
                added += 1
        update_conf(self.guild_id, words=words)
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=settings_embed(interaction.guild, conf), view=WordBlockPanel(self.guild_id))


class TimeoutModal(ui.Modal, title="タイムアウト時間の設定"):
    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id
        conf = guild_conf(guild_id)
        self.field = ui.TextInput(label="秒数(0=削除のみ / 最大2419200=28日)",
                                  default=str(conf["timeout"]), required=True, max_length=7)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            to = max(0, min(int(self.field.value.strip()), 2419200))
        except ValueError:
            return await interaction.response.send_message("数値で入力してください。", ephemeral=True)
        update_conf(self.guild_id, timeout=to)
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=settings_embed(interaction.guild, conf), view=WordBlockPanel(self.guild_id))


class RemoveWordSelect(ui.Select):
    def __init__(self, guild_id, words):
        self.guild_id = guild_id
        options = [discord.SelectOption(label=w[:100], value=w[:100]) for w in words[:25]]
        super().__init__(placeholder="削除するワードを選択(複数可)",
                         min_values=1, max_values=len(options), options=options)

    async def callback(self, interaction: discord.Interaction):
        conf = guild_conf(self.guild_id)
        remaining = [w for w in conf["words"] if w[:100] not in self.values]
        update_conf(self.guild_id, words=remaining)
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=settings_embed(interaction.guild, conf), view=WordBlockPanel(self.guild_id))


class WordBlockPanel(ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=300)
        self.guild_id = guild_id
        conf = guild_conf(guild_id)

        role_sel = ui.RoleSelect(placeholder="許可ロール(監視しない)を選択", min_values=0, max_values=25)
        role_sel.callback = self._role_cb
        self.add_item(role_sel)

        add_btn = ui.Button(label="ワード追加", style=discord.ButtonStyle.success, row=1)
        add_btn.callback = self._add_cb
        self.add_item(add_btn)

        rm_btn = ui.Button(label="ワード削除", style=discord.ButtonStyle.danger, row=1,
                           disabled=not conf["words"])
        rm_btn.callback = self._remove_cb
        self.add_item(rm_btn)

        to_btn = ui.Button(label="タイムアウト時間", style=discord.ButtonStyle.primary, row=1)
        to_btn.callback = self._timeout_cb
        self.add_item(to_btn)

    async def _add_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(AddWordModal(self.guild_id))

    async def _timeout_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(TimeoutModal(self.guild_id))

    async def _remove_cb(self, interaction: discord.Interaction):
        conf = guild_conf(self.guild_id)
        if not conf["words"]:
            return await interaction.response.send_message("削除できるワードがありません。", ephemeral=True)
        v = ui.View(timeout=120)
        v.add_item(RemoveWordSelect(self.guild_id, conf["words"]))
        await interaction.response.send_message("削除するワードを選択してください。", view=v, ephemeral=True)

    async def _role_cb(self, interaction: discord.Interaction):
        sel = interaction.data.get("values", [])
        update_conf(self.guild_id, allowed_roles=[int(x) for x in sel])
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=settings_embed(interaction.guild, conf), view=WordBlockPanel(self.guild_id))


class WordBlockCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    word_block = app_commands.Group(name="word_block", description="ワードブロック(NGワード自動削除)")

    @word_block.command(name="settings", description="NGワードの設定")
    async def settings(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_messages:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        conf = guild_conf(interaction.guild.id)
        await interaction.response.send_message(
            embed=settings_embed(interaction.guild, conf),
            view=WordBlockPanel(interaction.guild.id), ephemeral=True)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None:
            return
        if message.author.id in ADMIN_USER_IDS:
            return
        content = message.content or ""
        if not content:
            return
        conf = guild_conf(message.guild.id)
        if not conf["words"]:
            return
        # 許可ロール保持者は対象外
        if isinstance(message.author, discord.Member):
            if {r.id for r in message.author.roles} & set(conf["allowed_roles"]):
                return
        if not any(w and w in content for w in conf["words"]):
            return
        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass
        to = conf["timeout"]
        if to and isinstance(message.author, discord.Member):
            try:
                await message.author.timeout(timedelta(seconds=to), reason="ワードブロック")
            except (discord.Forbidden, discord.HTTPException):
                pass


async def setup(bot):
    await bot.add_cog(WordBlockCog(bot))
