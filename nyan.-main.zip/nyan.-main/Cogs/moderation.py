"""サーバー管理・安全機能(モデレーション)コマンド。

- /purge            指定した数のメッセージを消去
- /nuke             チャンネルを複製して元を削除(全メッセージ消去)
- /automod          AutoMod(サーバー安全機能)をオン
- /automod_advanced AutoMod の詳細設定(監視しないチャンネル/ロール・しきい値)
- /automod_invalid  AutoMod をまとめてオフ
"""
import time
from collections import defaultdict, deque
from datetime import timedelta

import discord
from discord import app_commands, ui
from discord.ext import commands

from utils import ADMIN_USER_IDS
from datapath import data_path, read_json, write_json

AUTOMOD_FILE = data_path("automod.json")  # {guild_id: {...}}

DEFAULTS = {
    "enabled": False,
    "block_mass_mention": True,
    "mention_threshold": 5,
    "block_spam": True,
    "spam_count": 5,
    "spam_interval": 5,
    "timeout": 0,            # 違反者のタイムアウト秒数(0=削除のみ)
    "exempt_channels": [],
    "exempt_roles": [],
}


def load_automod() -> dict:
    return read_json(AUTOMOD_FILE, {})


def save_automod(data: dict):
    write_json(AUTOMOD_FILE, data)


def guild_conf(guild_id) -> dict:
    """ギルドのAutoMod設定(未設定項目はデフォルトで補完)。"""
    conf = dict(DEFAULTS)
    conf.update(load_automod().get(str(guild_id), {}))
    return conf


def update_conf(guild_id, **changes):
    data = load_automod()
    entry = data.setdefault(str(guild_id), {})
    entry.update(changes)
    save_automod(data)
    return entry


def _is_staff(member: discord.Member) -> bool:
    """管理者・モデレーターは監視対象外。"""
    if member.id in ADMIN_USER_IDS:
        return True
    p = member.guild_permissions
    return p.administrator or p.manage_guild or p.manage_messages


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # スパム検出用: {(guild_id, user_id): deque[timestamps]}
        self._msg_times = defaultdict(lambda: deque(maxlen=15))

    # ---------- メッセージ削除 ----------

    @app_commands.command(name="purge", description="メッセージを消す")
    @app_commands.describe(count="消去する件数(1〜1000)")
    async def purge(self, interaction: discord.Interaction, count: int):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_messages:
            return await interaction.response.send_message("権限がありません(メッセージの管理が必要)。", ephemeral=True)
        if interaction.guild is None or not isinstance(interaction.channel, (discord.TextChannel, discord.Thread)):
            return await interaction.response.send_message("テキストチャンネルで実行してください。", ephemeral=True)
        count = max(1, min(count, 1000))
        await interaction.response.defer(ephemeral=True, thinking=True)
        try:
            deleted = await interaction.channel.purge(limit=count)
        except discord.Forbidden:
            return await interaction.followup.send("メッセージを削除する権限がありません。", ephemeral=True)
        except discord.HTTPException as e:
            return await interaction.followup.send(f"削除に失敗しました: {e}", ephemeral=True)
        await interaction.followup.send(f"{len(deleted)}件のメッセージを消去しました。", ephemeral=True)

    # ---------- チャンネル再作成(nuke) ----------

    @app_commands.command(name="nuke", description="チャンネルを作り直す")
    async def nuke(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_channels:
            return await interaction.response.send_message("権限がありません(チャンネルの管理が必要)。", ephemeral=True)
        if interaction.guild is None or not isinstance(interaction.channel, discord.TextChannel):
            return await interaction.response.send_message("テキストチャンネルで実行してください。", ephemeral=True)

        channel = interaction.channel

        async def do_nuke(inter: discord.Interaction):
            try:
                new_ch = await channel.clone(reason=f"nuke by {inter.user}")
                await new_ch.edit(position=channel.position)
                await channel.delete(reason=f"nuke by {inter.user}")
            except discord.Forbidden:
                return await inter.response.edit_message(
                    content="チャンネルを再作成する権限がありません。", view=None)
            except discord.HTTPException as e:
                return await inter.response.edit_message(content=f"失敗しました: {e}", view=None)
            try:
                await new_ch.send(f"💥 このチャンネルは {inter.user.mention} によって再作成されました。")
            except discord.HTTPException:
                pass

        v = ui.View(timeout=60)
        btn = ui.Button(label="実行する(復元不可)", style=discord.ButtonStyle.danger)
        btn.callback = do_nuke
        v.add_item(btn)
        await interaction.response.send_message(
            f"⚠️ {channel.mention} を削除し、同じ設定の新しいチャンネルを作成します。\n"
            f"このチャンネルの**全メッセージが消え、復元できません**。よろしいですか？",
            view=v, ephemeral=True)

    # ---------- AutoMod ----------

    @app_commands.command(name="automod", description="AutoMod を入れる")
    async def automod(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        update_conf(interaction.guild.id, enabled=True)
        conf = guild_conf(interaction.guild.id)
        await interaction.response.send_message(embed=automod_status_embed(conf, interaction.guild), ephemeral=True)

    @app_commands.command(name="automod_invalid", description="AutoMod を切る")
    async def automod_invalid(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        update_conf(interaction.guild.id, enabled=False)
        await interaction.response.send_message("AutoMod（サーバー安全機能）をオフにしました。", ephemeral=True)

    @app_commands.command(name="automod_advanced", description="AutoMod の細かい設定")
    async def automod_advanced(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS and not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。", ephemeral=True)
        conf = guild_conf(interaction.guild.id)
        await interaction.response.send_message(
            embed=automod_status_embed(conf, interaction.guild),
            view=AutoModPanel(interaction.guild.id), ephemeral=True)

    # ---------- 監視ロジック ----------

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or message.guild is None:
            return
        if not isinstance(message.author, discord.Member):
            return
        conf = guild_conf(message.guild.id)
        if not conf["enabled"]:
            return
        if _is_staff(message.author):
            return
        if message.channel.id in conf.get("exempt_channels", []):
            return
        author_role_ids = {r.id for r in message.author.roles}
        if author_role_ids & set(conf.get("exempt_roles", [])):
            return

        reason = None
        if conf["block_mass_mention"] and len(message.mentions) + len(message.role_mentions) >= conf["mention_threshold"]:
            reason = "大量メンション"
        elif conf["block_spam"] and self._is_spam(message, conf):
            reason = "連投スパム"

        if not reason:
            return

        try:
            await message.delete()
        except (discord.Forbidden, discord.NotFound):
            pass

        timeout_sec = int(conf.get("timeout", 0) or 0)
        if timeout_sec > 0:
            try:
                await message.author.timeout(timedelta(seconds=timeout_sec), reason=f"AutoMod: {reason}")
            except (discord.Forbidden, discord.HTTPException):
                pass
        try:
            await message.channel.send(
                f"🛡️ {message.author.mention} のメッセージを削除しました（{reason}）。",
                delete_after=5)
        except discord.HTTPException:
            pass

    def _is_spam(self, message: discord.Message, conf: dict) -> bool:
        key = (message.guild.id, message.author.id)
        dq = self._msg_times[key]
        now = time.time()
        dq.append(now)
        interval = conf["spam_interval"]
        recent = [t for t in dq if now - t <= interval]
        return len(recent) >= conf["spam_count"]


# ---------- AutoMod 詳細設定パネル ----------

def _onoff(v: bool) -> str:
    return "🟢 ON" if v else "🔴 OFF"


def automod_status_embed(conf: dict, guild: discord.Guild) -> discord.Embed:
    e = discord.Embed(
        title="🛡️ AutoMod（サーバー安全機能）",
        color=0x00cc88 if conf["enabled"] else 0x888888,
    )
    e.add_field(name="状態", value=_onoff(conf["enabled"]), inline=False)
    e.add_field(name="大量メンション遮断",
                value=f"{_onoff(conf['block_mass_mention'])}（{conf['mention_threshold']}件以上）", inline=True)
    e.add_field(name="連投スパム遮断",
                value=f"{_onoff(conf['block_spam'])}（{conf['spam_interval']}秒で{conf['spam_count']}件）", inline=True)
    to = conf.get("timeout", 0)
    e.add_field(name="違反者のタイムアウト",
                value=(f"{to}秒" if to else "なし（削除のみ）"), inline=False)
    ch = conf.get("exempt_channels", [])
    rl = conf.get("exempt_roles", [])
    e.add_field(name="監視しないチャンネル",
                value=("、".join(f"<#{c}>" for c in ch) if ch else "なし"), inline=False)
    e.add_field(name="監視しないロール",
                value=("、".join(f"<@&{r}>" for r in rl) if rl else "なし"), inline=False)
    return e


class ThresholdModal(ui.Modal, title="しきい値設定"):
    def __init__(self, guild_id):
        super().__init__()
        self.guild_id = guild_id
        conf = guild_conf(guild_id)
        self.mention = ui.TextInput(label="大量メンションの件数(この数以上で遮断)",
                                    default=str(conf["mention_threshold"]), required=True, max_length=3)
        self.spam_count = ui.TextInput(label="スパム判定の件数",
                                       default=str(conf["spam_count"]), required=True, max_length=3)
        self.spam_interval = ui.TextInput(label="スパム判定の秒数",
                                          default=str(conf["spam_interval"]), required=True, max_length=4)
        self.timeout_sec = ui.TextInput(label="違反者のタイムアウト秒数(0=削除のみ)",
                                        default=str(conf.get("timeout", 0)), required=True, max_length=7)
        for it in (self.mention, self.spam_count, self.spam_interval, self.timeout_sec):
            self.add_item(it)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            mention = max(2, int(self.mention.value.strip()))
            sc = max(2, int(self.spam_count.value.strip()))
            si = max(1, int(self.spam_interval.value.strip()))
            to = max(0, min(int(self.timeout_sec.value.strip()), 2419200))  # 上限28日
        except ValueError:
            return await interaction.response.send_message("数値で入力してください。", ephemeral=True)
        update_conf(self.guild_id, mention_threshold=mention, spam_count=sc,
                    spam_interval=si, timeout=to)
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=automod_status_embed(conf, interaction.guild), view=AutoModPanel(self.guild_id))


class AutoModPanel(ui.View):
    def __init__(self, guild_id):
        super().__init__(timeout=300)
        self.guild_id = guild_id
        conf = guild_conf(guild_id)

        ch_sel = ui.ChannelSelect(placeholder="監視しないチャンネルを選択(複数可)",
                                  channel_types=[discord.ChannelType.text],
                                  min_values=0, max_values=25)
        ch_sel.callback = self._ch_cb
        self.add_item(ch_sel)

        role_sel = ui.RoleSelect(placeholder="監視しないロールを選択(複数可)", min_values=0, max_values=25)
        role_sel.callback = self._role_cb
        self.add_item(role_sel)

        self._add_toggle("有効", "enabled", conf["enabled"], discord.ButtonStyle.success)
        self._add_toggle("大量メンション", "block_mass_mention", conf["block_mass_mention"], discord.ButtonStyle.secondary)
        self._add_toggle("連投スパム", "block_spam", conf["block_spam"], discord.ButtonStyle.secondary)

        thr = ui.Button(label="しきい値設定", style=discord.ButtonStyle.primary, row=4)
        thr.callback = self._threshold_cb
        self.add_item(thr)

    def _add_toggle(self, label, key, state, on_style):
        btn = ui.Button(label=f"{label}: {'ON' if state else 'OFF'}",
                        style=on_style if state else discord.ButtonStyle.secondary, row=3)

        async def cb(interaction: discord.Interaction):
            conf = guild_conf(self.guild_id)
            update_conf(self.guild_id, **{key: not conf[key]})
            new_conf = guild_conf(self.guild_id)
            await interaction.response.edit_message(
                embed=automod_status_embed(new_conf, interaction.guild), view=AutoModPanel(self.guild_id))

        btn.callback = cb
        self.add_item(btn)

    async def _ch_cb(self, interaction: discord.Interaction):
        sel = interaction.data.get("values", [])
        update_conf(self.guild_id, exempt_channels=[int(x) for x in sel])
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=automod_status_embed(conf, interaction.guild), view=AutoModPanel(self.guild_id))

    async def _role_cb(self, interaction: discord.Interaction):
        sel = interaction.data.get("values", [])
        update_conf(self.guild_id, exempt_roles=[int(x) for x in sel])
        conf = guild_conf(self.guild_id)
        await interaction.response.edit_message(
            embed=automod_status_embed(conf, interaction.guild), view=AutoModPanel(self.guild_id))

    async def _threshold_cb(self, interaction: discord.Interaction):
        await interaction.response.send_modal(ThresholdModal(self.guild_id))


async def setup(bot):
    await bot.add_cog(Moderation(bot))
