"""/announce: Bot からお知らせを送る(管理者だけ)。

使い方
1. /announce を実行すると、入力フォームが開く
2. メッセージ・画像(任意)・送り先チャンネルのリンクを入れて送信
3. 実際に送られる見た目のプレビューが出る(本人にだけ見える)。「この内容で送信」で送る
→ 送ったあとは「送信を取り消す」で消せる。

書式はそのまま反映する。**太字**・# 見出し・> 引用・||ネタバレ|| などの Discord の書式は
送る文にそのまま残る。フォームでは @ や # の候補が出ないので、@名前・#チャンネル名・
:サーバー絵文字: は、送り先のサーバーで名前を探して本物のメンション・チャンネル・絵文字に
直す(コードブロックと URL の中は直さない)。

送り先をリンクで受けるのは、Bot がいるサーバーならどこへでも送れるようにするため
(チャンネルを選ぶメニューは、実行したサーバーのチャンネルしか出せない)。
送れるのは、実行した人が入っていて、自分でも書き込めるチャンネルだけ。

フォームのファイル添付(Label の中の File Upload)は discord.py 2.3.2 にまだ無いので、
形式確認のフォーム(Cogs/shop.py の XFormatModal)と同じく、出す中身(to_components)と
送られた値の読み取り(_refresh)だけを Discord の形のまま書く。
"""
import io
import re
import traceback

import discord
from discord import app_commands, ui
from discord.ext import commands

import panels
from send_once import send_once
from utils import ADMIN_USER_IDS

# 添付をまとめて受け取る上限(バイト)。Bot が送れる大きさもおおむねこのくらいまで。
MAX_ATTACH_BYTES = 25 * 1024 * 1024
# フォームで付けられるファイルの数(Discord の1通の上限と同じ)。
MAX_FILES = 10
# フォームに書ける文字数。
TEXT_LIMIT = 4000
# Bot が1通で送れる文字数。長いときは改行の所で分けて送る。
CONTENT_LIMIT = 2000
# プレビューのボタンを押せる時間(秒)。画面を書き換えられるのは15分までなので、その手前で閉じる。
PREVIEW_SECONDS = 14 * 60
# 入力フォームを開いたまま待てる時間(秒)。
FORM_SECONDS = 60 * 60

# https://discord.com/channels/<サーバー>/<チャンネル>[/<メッセージ>]
_LINK = re.compile(r"https?://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/channels/"
                   r"(@me|\d{15,21})/(\d{15,21})(?:/\d{15,21})?")
_MENTION = re.compile(r"<#(\d{15,21})>")
_BARE_ID = re.compile(r"^\s*(\d{15,21})\s*$")

# 送るときは書いたとおりに鳴らす(@everyone・ロール・ユーザー)。画面の表示では誰も鳴らさない。
LOUD = discord.AllowedMentions(everyone=True, users=True, roles=True)
QUIET = discord.AllowedMentions.none()


# ---------- 送り先 ----------

def find_targets(text: str) -> list:
    """貼られた文からチャンネルを拾う。[(サーバーID か "@me" か None, チャンネルID)]。

    リンク(メッセージのリンクでもチャンネルとして扱う)・<#ID>・ID だけ、を読む。
    同じチャンネルは1つにまとめる。
    """
    text = text or ""
    found = [(m.group(1), int(m.group(2))) for m in _LINK.finditer(text)]
    found += [(None, int(m.group(1))) for m in _MENTION.finditer(text)]
    if not found:
        m = _BARE_ID.match(text)
        if m:
            found.append((None, int(m.group(1))))
    seen, out = set(), []
    for gid, cid in found:
        if cid not in seen:
            seen.add(cid)
            out.append((gid, cid))
    return out


def where(channel) -> str:
    guild = getattr(channel, "guild", None)
    return f"#{getattr(channel, 'name', '?')}（{guild.name if guild else '?'}）"


def channel_url(channel) -> str:
    return f"https://discord.com/channels/{channel.guild.id}/{channel.id}"


def _can_post(channel, perms: discord.Permissions) -> bool:
    if isinstance(channel, discord.Thread):
        return perms.view_channel and perms.send_messages_in_threads
    return perms.view_channel and perms.send_messages


def find_by_name(text: str, guild):
    """リンクの代わりにチャンネル名が書かれたとき、実行したサーバーから探す。(チャンネル, "") か (None, 理由)。

    同じ名前がちょうど1つならそれ。無ければ名前の一部が合うものがちょうど1つならそれ
    (送る前にプレビューで送り先を見せるので、取り違えてもそこで気づける)。
    """
    how = "チャンネルを長押し／右クリック →「リンクをコピー」で貼ってください。"
    name = (text or "").strip().lstrip("#＃").strip()
    if not name:
        return None, "送り先のリンクを入れてください。" + how
    if guild is None:
        return None, "チャンネルのリンクが見つかりませんでした。" + how
    every = list(guild.channels) + list(guild.threads)
    low = name.lower()
    for hits in ([c for c in every if c.name.lower() == low],
                 [c for c in every if low in c.name.lower()]):
        postable = [c for c in hits if isinstance(c, discord.abc.Messageable)]
        if len(postable) == 1:
            return postable[0], ""
        if len(postable) > 1:
            names = "、".join(f"#{c.name}" for c in postable[:5])
            return None, f"「{name}」に合うチャンネルが{len(postable)}個あります（{names}…）。" + how
        if hits:
            return hits[0], ""        # フォーラムやカテゴリ → 下で「送れない」と伝える
    return None, f"「{name}」というチャンネルが {guild.name} に見つかりませんでした。" + how


async def resolve_target(bot, user, text: str, has_files: bool, home_guild=None):
    """入れてもらった送り先(リンク・チャンネル名)から送り先を決める。(チャンネル, "") か (None, 理由)。"""
    targets = find_targets(text)
    if len(targets) > 1:
        return None, "送り先が2つ以上あります。1つだけ入れてください。"
    if not targets:
        channel, error = find_by_name(text, home_guild)
        if error:
            return None, error
    else:
        gid, cid = targets[0]
        if gid == "@me":
            return None, "DMには送れません。サーバーのチャンネルのリンクを貼ってください。"
        channel = bot.get_channel(cid)
        if channel is None:
            try:
                channel = await bot.fetch_channel(cid)
            except discord.NotFound:
                return None, "そのチャンネルが見つかりません（消されたか、Botが入っていないサーバーのチャンネルです）。"
            except discord.Forbidden:
                return None, "Botがそのチャンネルを見られません（Botが入っていないサーバーか、閲覧の権限がありません）。"
            except discord.HTTPException:
                return None, "チャンネルを確認できませんでした。少し待ってもう一度お試しください。"
    guild = getattr(channel, "guild", None)
    if guild is None:
        return None, "DMには送れません。サーバーのチャンネルのリンクを貼ってください。"
    if isinstance(channel, discord.ForumChannel):
        return None, (f"{where(channel)} はフォーラムなので直接は送れません。"
                      "送りたい投稿（スレッド）のリンクを貼ってください。")
    if not isinstance(channel, discord.abc.Messageable):
        return None, f"{where(channel)} にはメッセージを送れません（カテゴリなど）。チャンネルのリンクを貼ってください。"
    member = guild.get_member(user.id)
    if member is None:
        try:
            member = await guild.fetch_member(user.id)
        except discord.NotFound:
            return None, f"あなたが入っていないサーバー（{guild.name}）には送れません。"
        except discord.HTTPException:
            return None, "サーバーのメンバーを確認できませんでした。少し待ってもう一度お試しください。"
    try:
        mine = channel.permissions_for(member)
        bots = channel.permissions_for(guild.me)
    except Exception:            # スレッドの親チャンネルが見つからない等
        return None, f"{where(channel)} の権限を確認できませんでした。"
    if not _can_post(channel, mine):
        return None, f"あなた自身が {where(channel)} に書き込めないため、送れません。"
    if not _can_post(channel, bots):
        return None, f"Botに {where(channel)} への送信の権限がありません。"
    if has_files and not bots.attach_files:
        return None, f"Botに {where(channel)} でファイルを送る権限がありません。"
    return channel, ""


# ---------- 書式(@名前・#チャンネル名・:絵文字: を本物に直す) ----------

# 直さない所: コードブロック・インラインコード・URL・すでに Discord の書式になっている所
_KEEP = re.compile(
    r"```.*?```"
    r"|`[^`\n]+`"
    r"|https?://[^\s<>]+"
    r"|<(?:@[!&]?\d+|#\d+|a?:\w+:\d+|t:-?\d+(?::[tTdDfFR])?|/[^<>\n]+:\d+|id:\w+)>",
    re.S)
# 名前の続きになる英数字。「@tanaka123」を tanaka で切らない、「foo@bar.com」を直さない。
_ASCII_NAME = re.compile(r"[A-Za-z0-9_.\-]")
_EMOJI_NAME = re.compile(r":([A-Za-z0-9_]{2,32}):")
_LOUD_WORD = re.compile(r"(everyone|here)(?![A-Za-z0-9_])")


def _name_index(pairs):
    """[(名前, もの)] → ({小文字の名前: {もの}}, {頭の1文字: [名前(長い順)]})。1文字の名前は使わない。"""
    table = {}
    for name, obj in pairs:
        name = (name or "").strip().lower()
        if len(name) >= 2:
            table.setdefault(name, set()).add(obj)
    index = {}
    for name in sorted(table, key=len, reverse=True):
        index.setdefault(name[0], []).append(name)
    return table, index


def _longest(text: str, start: int, table: dict, index: dict):
    """text[start:] の頭に来る、いちばん長い名前。(長さ, {もの}) か None。"""
    for name in index.get(text[start:start + 1].lower(), ()):
        end = start + len(name)
        if text[start:end].lower() != name:
            continue
        if end < len(text) and _ASCII_NAME.match(text[end]) and _ASCII_NAME.match(name[-1]):
            continue              # 英数字の名前の途中で切れている
        return len(name), table[name]
    return None


class Converter:
    """フォームに書かれた @名前・#チャンネル名・:絵文字: を、送り先のサーバーで探して直す。

    同じ名前が2つ以上あるときは直さずに知らせる(違う人を鳴らさない)。
    直したもの(done)と注意(warnings)はプレビューに出す。
    """

    def __init__(self, bot, channel):
        guild = channel.guild
        self.bot = bot
        self.guild = guild
        people = []
        for m in guild.members:
            people += [(m.name, m), (getattr(m, "global_name", None), m), (m.nick, m)]
        people += [(r.name, r) for r in guild.roles if not r.is_default()]
        self.people = _name_index(people)
        self.channels = _name_index([(c.name, c) for c in list(guild.channels) + list(guild.threads)])
        try:
            perms = channel.permissions_for(guild.me)
            self.can_ping_all = perms.mention_everyone
            self.external_ok = perms.use_external_emojis
        except Exception:
            self.can_ping_all = self.external_ok = True
        self.done = []
        self.warnings = []

    def convert(self, text: str) -> str:
        keep = {m.start(): m.end() for m in _KEEP.finditer(text)}
        out, i = [], 0
        while i < len(text):
            if i in keep:
                out.append(text[i:keep[i]])
                i = keep[i]
                continue
            ch, prev = text[i], (text[i - 1] if i else "")
            step = None
            if prev != "\\":              # \@ などは書いたまま
                if ch in "@＠" and not _ASCII_NAME.match(prev or " "):
                    step = self._at(text, i)
                elif ch in "#＃" and not (_ASCII_NAME.match(prev or " ") or prev in ("&", "#", "＃")):
                    step = self._hash(text, i)
                elif ch == ":":
                    step = self._emoji(text, i)
            if step:
                piece, i = step
                out.append(piece)
                continue
            out.append(ch)
            i += 1
        return "".join(out)

    def _pick(self, text, i, sign, tables, what):
        hit = _longest(text, i + 1, *tables)
        if hit is None:
            return None, None
        length, objs = hit
        name = text[i + 1:i + 1 + length]
        end = i + 1 + length
        if len(objs) > 1:
            self.warnings.append(f"「{sign}{name}」は同じ名前の{what}が{len(objs)}つあるため、そのままにしました")
            return None, (text[i:end], end)
        return next(iter(objs)), (name, end)

    def _at(self, text, i):
        m = _LOUD_WORD.match(text, i + 1)
        if m:
            return "@" + m.group(1), m.end()
        obj, got = self._pick(text, i, "@", self.people, "人・ロール")
        if obj is None:
            return got
        name, end = got
        if isinstance(obj, discord.Role) and not (obj.mentionable or self.can_ping_all):
            self.warnings.append(f"「@{name}」はBotからは通知できないロールです"
                                 "（ロールの設定で「このロールに対して@mentionを許可する」をオンにしてください）")
        self.done.append(f"@{name}")
        return obj.mention, end

    def _hash(self, text, i):
        nxt = text[i + 1:i + 2]
        if not nxt or nxt.isspace() or nxt in "#＃":
            return None               # 「# 見出し」「## 見出し」は書式のまま
        obj, got = self._pick(text, i, "#", self.channels, "チャンネル")
        if obj is None:
            return got
        name, end = got
        self.done.append(f"#{name}")
        return obj.mention, end

    def _emoji(self, text, i):
        m = _EMOJI_NAME.match(text, i)
        if not m:
            return None
        name = m.group(1)
        emoji, note = self._find_emoji(name)
        if emoji is None:
            if note:
                self.warnings.append(note)
            return None
        self.done.append(f":{name}:")
        return str(emoji), m.end()

    def _find_emoji(self, name: str):
        def pick(emojis):
            exact = [e for e in emojis if e.name == name]
            return [e for e in (exact or [e for e in emojis if e.name.lower() == name.lower()])
                    if e.is_usable()]
        local = pick(self.guild.emojis)
        if local:
            return local[0], ""
        others = pick([e for e in self.bot.emojis if e.guild_id != self.guild.id])
        if others:
            if not self.external_ok:
                return None, (f"「:{name}:」は別のサーバーの絵文字で、Botに「外部の絵文字を使用する」"
                              "権限が無いため、文字のままにしました")
            return others[0], ""
        if any(c.isalpha() for c in name):
            return None, (f"「:{name}:」という絵文字が見つからないため、文字のままにしました"
                          "（ふつうの絵文字は、そのまま入力してください）")
        return None, ""


# ---------- 送る中身 ----------

def _fit(text: str, limit: int) -> int:
    """先頭から何文字までなら limit に収まるか(Discord と同じく UTF-16 で数える)。"""
    units = 0
    for i, ch in enumerate(text):
        units += 2 if ord(ch) > 0xFFFF else 1
        if units > limit:
            return i
    return len(text)


def split_content(text: str, limit: int = CONTENT_LIMIT) -> list:
    """長い本文を、Bot が1通で送れる長さごとに、なるべく改行の所で分ける。"""
    text = text or ""
    parts = []
    while _fit(text, limit) < len(text):
        n = _fit(text, limit)
        cut = text.rfind("\n", 0, n + 1)
        if cut <= 0:
            cut = n
        head, text = text[:cut], text[cut:].lstrip("\n")
        if head.strip():
            parts.append(head)
    if text.strip():
        parts.append(text)
    return parts


def make_files(files: list) -> list:
    """discord.File は送ると閉じるので、送るたび(プレビューにも)作る。"""
    return [discord.File(io.BytesIO(data), filename=name, spoiler=spoiler, description=desc)
            for name, data, spoiler, desc in files]


async def read_attachments(atts: list):
    """フォームに付けられたファイルを読む。([(ファイル名, 中身, ネタバレ, 説明)], "") か (None, 理由)。"""
    total = sum(a.size or 0 for a in atts)
    if total > MAX_ATTACH_BYTES:
        return None, (f"画像・ファイルが大きすぎます（合計 {total / 1024 / 1024:.1f}MB／"
                      f"{MAX_ATTACH_BYTES // 1024 // 1024}MBまで）。小さくしてもう一度付けてください。")
    files = []
    for a in atts:
        try:
            data = await a.read()
        except discord.HTTPException:
            return None, f"「{a.filename}」を読み込めませんでした。もう一度付けてください。"
        files.append((a.filename, data, a.is_spoiler(), a.description))
    return files, ""


class Draft:
    """フォームに入れてもらったもの(書いたままの文・添付・送り先)。直すときはこれをフォームに戻す。"""

    def __init__(self, text: str = "", files: list = None, link: str = ""):
        self.text = text or ""
        self.files = files or []      # [(ファイル名, 中身, ネタバレ, 説明)]
        self.link = link or ""


def _pings_everyone(content: str) -> bool:
    return bool(re.search(r"@(everyone|here)(?![A-Za-z0-9_])", _KEEP.sub("", content)))


class Plan:
    """送る準備ができたもの: 送り先と、送り先のサーバーに合わせて直した本文。"""

    def __init__(self, bot, channel, draft: Draft):
        conv = Converter(bot, channel)
        self.channel = channel
        self.draft = draft
        self.content = conv.convert(draft.text)
        self.parts = split_content(self.content) or [""]
        self.converted = list(dict.fromkeys(conv.done))
        self.warnings = list(dict.fromkeys(conv.warnings))
        if _pings_everyone(self.content) and not conv.can_ping_all:
            self.warnings.append("Botに @everyone の権限が無いため、@everyone / @here の通知は飛びません")


# ---------- 送る・取り消す ----------

def _message_id(sent) -> int:
    """send_once の戻り(Message か、形を作れなかったときの dict)から投稿のID。"""
    return sent.id if hasattr(sent, "id") else int(sent["id"])


async def _delete(channel, sent) -> bool:
    """送った投稿を消す。もう無いときも消えたものとする。"""
    try:
        await channel.get_partial_message(_message_id(sent)).delete()
        return True
    except discord.NotFound:
        return True
    except discord.HTTPException:
        return False


async def deliver(channel, parts: list, files: list):
    """送り先へ送る。([送った投稿], "") か ([], 理由)。

    discord.py のやり直しで二重にならないように送る(send_once)。長い本文は分けて送り、
    添付は最後の1通に付ける。途中で失敗したら、送れた分は消す(半端なお知らせを残さない)。
    """
    sent = []
    try:
        for i, part in enumerate(parts):
            kw = {"allowed_mentions": LOUD}
            if part:
                kw["content"] = part
            if i == len(parts) - 1 and files:
                kw["files"] = make_files(files)
            sent.append(await send_once(channel, kw))
        return sent, ""
    except discord.Forbidden:
        reason = "Botに送信の権限がありません"
    except discord.HTTPException as e:
        if e.status == 413 or e.code == 40005:
            reason = "画像・ファイルが大きすぎて送れませんでした（Botが送れる上限を超えています）"
        else:
            reason = f"Discordが受け付けませんでした（{e.status} {(e.text or '')[:100]}）"
    for m in sent:
        await _delete(channel, m)
    return [], reason


def preview_embed(plan: Plan, notice: str = "") -> discord.Embed:
    lines = [f"**送り先:** {where(plan.channel)}", channel_url(plan.channel)]
    if len(plan.parts) > 1:
        lines.append(f"長いので **{len(plan.parts)}通** に分けて送ります（ここに出ているのは1通目）。")
    if plan.draft.files:
        lines.append(f"📎 画像・ファイル {len(plan.draft.files)}件")
    if plan.converted:
        lines.append("✨ 本物に直したもの: " + "、".join(plan.converted)[:800])
    lines += [f"⚠️ {w}" for w in plan.warnings[:10]]
    if notice:
        lines.append(notice)
    e = discord.Embed(title="📣 送信前の確認", description="\n".join(lines)[:4000], color=0x5865F2)
    e.set_footer(text="本文と画像が、実際に送られる内容です（この確認はあなたにだけ見えています）")
    return e


def done_text(plan: Plan, sent: list) -> str:
    ch = plan.channel
    lines = [f"✅ **{where(ch)}** に送信しました。",
             f"https://discord.com/channels/{ch.guild.id}/{ch.id}/{_message_id(sent[0])}"]
    if len(sent) > 1:
        lines.append(f"（長いので {len(sent)}通に分けて送りました）")
    lines.append("間違えたときは「送信を取り消す」で消せます。")
    return "\n".join(lines)


async def _edit(interaction: discord.Interaction, **kw) -> bool:
    try:
        await interaction.edit_original_response(allowed_mentions=QUIET, **kw)
        return True
    except discord.HTTPException as e:
        print(f"[ANNOUNCE] 画面を書き換えられませんでした: {e}", flush=True)
        return False


class UndoView(ui.View):
    """送ったあとの「送信を取り消す」。Bot を再起動するまで押せる。"""

    def __init__(self, user_id: int, channel, sent: list):
        super().__init__(timeout=None)
        self.user_id = user_id
        self.channel = channel
        self.sent = sent

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.user_id

    @ui.button(label="送信を取り消す", style=discord.ButtonStyle.danger)
    async def undo(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        failed = 0
        for m in self.sent:
            if not await _delete(self.channel, m):
                failed += 1
        self.stop()
        print(f"[ANNOUNCE] 取り消し {interaction.user} ({interaction.user.id}) → "
              f"{where(self.channel)} 消せなかった {failed}通", flush=True)
        if failed:
            text = (f"⚠️ {where(self.channel)} に送ったお知らせのうち {failed}通を消せませんでした。"
                    "お手数ですが手で消してください。")
        else:
            text = f"🗑️ {where(self.channel)} に送ったお知らせを取り消しました。"
        await _edit(interaction, content=text, view=None)


class _OwnedView(ui.View):
    """プレビュー・やり直しの画面の共通部分(押せるのは本人だけ・時間が経ったら閉じる)。"""

    def __init__(self, bot, user_id: int, draft: Draft):
        super().__init__(timeout=PREVIEW_SECONDS)
        self.bot = bot
        self.user_id = user_id
        self.draft = draft
        self.busy = False
        self.screen = None           # この画面を描いた interaction(時間切れで閉じるのに使う)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.user_id

    async def on_timeout(self):
        self.draft = None             # 画像などを手放す
        if self.screen is not None:
            await _edit(self.screen, content="⌛ 時間が経ったので終わりにしました。送るときはもう一度 `/announce` からどうぞ。",
                        embed=None, attachments=[], view=None)

    async def _reopen(self, interaction: discord.Interaction):
        if self.busy or self.draft is None:
            return await interaction.response.defer()
        await open_form(interaction, self.bot, self.draft, opened_from=self)

    async def _quit(self, interaction: discord.Interaction):
        if self.busy:
            return await interaction.response.defer()
        self.stop()
        self.draft = None
        await interaction.response.edit_message(content="やめました。", embed=None, attachments=[], view=None)


class PreviewView(_OwnedView):
    """送信前の確認。「この内容で送信」「内容を直す」「やめる」。"""

    def __init__(self, bot, user_id: int, plan: Plan):
        super().__init__(bot, user_id, plan.draft)
        self.plan = plan

    async def on_timeout(self):
        self.plan = None
        await super().on_timeout()

    @ui.button(label="この内容で送信", style=discord.ButtonStyle.success)
    async def send(self, interaction: discord.Interaction, button: ui.Button):
        if self.busy or self.plan is None:
            return await interaction.response.defer()
        self.busy = True              # 2回押されても1回しか送らない
        await interaction.response.defer()
        plan = self.plan
        sent, error = await deliver(plan.channel, plan.parts, plan.draft.files)
        if error:
            self.busy = False
            self.screen = interaction
            await _edit(interaction, embed=preview_embed(plan, f"❌ 送れませんでした: {error}"), view=self)
            return
        self.stop()
        self.plan = self.draft = None
        print(f"[ANNOUNCE] {interaction.user} ({interaction.user.id}) → {where(plan.channel)} "
              f"{plan.channel.id} {len(sent)}通", flush=True)
        await _edit(interaction, content=done_text(plan, sent), embed=None, attachments=[],
                    view=UndoView(self.user_id, plan.channel, sent))

    @ui.button(label="内容を直す", style=discord.ButtonStyle.primary)
    async def fix(self, interaction: discord.Interaction, button: ui.Button):
        await self._reopen(interaction)

    @ui.button(label="やめる", style=discord.ButtonStyle.secondary)
    async def quit(self, interaction: discord.Interaction, button: ui.Button):
        await self._quit(interaction)


class RetryView(_OwnedView):
    """入れてもらった内容に問題があったとき。「入力し直す」(前の内容が入った状態で開く)「やめる」。"""

    @ui.button(label="入力し直す", style=discord.ButtonStyle.primary)
    async def again(self, interaction: discord.Interaction, button: ui.Button):
        await self._reopen(interaction)

    @ui.button(label="やめる", style=discord.ButtonStyle.secondary)
    async def quit(self, interaction: discord.Interaction, button: ui.Button):
        await self._quit(interaction)


# ---------- 入力フォーム ----------

class AnnounceForm(ui.Modal, title="お知らせを送る"):
    """メッセージ・画像・送り先を入れてもらうフォーム。直すときは前の内容を入れて開く
    (画像は付け直したときだけ差し替え、付けなければ前のまま)。"""

    TEXT_ID = "announce_text"
    FILE_ID = "announce_files"
    LINK_ID = "announce_link"

    def __init__(self, bot, draft: Draft = None, with_file: bool = True, opened_from=None):
        # 開いたまま放っておかれたら1時間で手放す(直すときは前の画像を持っているので)
        super().__init__(timeout=FORM_SECONDS)
        self.bot = bot
        self.draft = draft or Draft()
        self.with_file = with_file
        # このフォームを開いた確認の画面。書き換えたら止める(古い画面の時間切れで、
        # 新しい確認の画面を「時間が経った」に書き換えないように)
        self.opened_from = opened_from
        self.text = self.draft.text
        self.link = self.draft.link
        self.new_files = []           # 今回付けられたファイル(discord.Attachment)

    def to_components(self):
        text = {"type": 4, "custom_id": self.TEXT_ID, "style": 2, "required": False,
                "max_length": TEXT_LIMIT, "placeholder": "例）**新商品入荷！** @everyone #お知らせ もチェック"}
        link = {"type": 4, "custom_id": self.LINK_ID, "style": 1, "required": True,
                "max_length": 300, "placeholder": "https://discord.com/channels/…"}
        if self.draft.text:
            text["value"] = self.draft.text[:TEXT_LIMIT]
        if self.draft.link:
            link["value"] = self.draft.link[:300]
        if not self.with_file:
            # ファイル添付つきを Discord に断られたときの予備(文字だけ)
            return [{"type": 1, "components": [{**text, "label": "メッセージ"}]},
                    {"type": 1, "components": [{**link, "label": "送り先チャンネルのリンク"}]}]
        kept = len(self.draft.files)
        file_note = (f"いまの{kept}件をそのまま使います。差し替えるときだけ付けてください"
                     "（外すときは /announce からやり直し）" if kept
                     else "付けた画像・ファイルはメッセージと一緒に送ります")
        # type 18 = Label(見出しと説明)、4 = 文字の入力、19 = ファイルの添付
        return [
            {"type": 18, "label": "メッセージ",
             "description": "**太字**・# 見出し・@名前・#チャンネル名・:サーバー絵文字: もそのまま反映されます",
             "component": text},
            {"type": 18, "label": f"画像・ファイル（任意・{MAX_FILES}個まで）", "description": file_note,
             "component": {"type": 19, "custom_id": self.FILE_ID, "required": False,
                           "min_values": 0, "max_values": MAX_FILES}},
            {"type": 18, "label": "送り先チャンネルのリンク",
             "description": "チャンネルを長押し／右クリック →「リンクをコピー」。このサーバーならチャンネル名でも可",
             "component": link},
        ]

    def _refresh(self, interaction: discord.Interaction, components) -> None:
        # 送られた値は Label の中に入って届く: {"type": 18, "component": {"custom_id": …}}。
        # ファイルは ID だけが来て、中身の情報は resolved.attachments にある。
        resolved = ((interaction.data or {}).get("resolved") or {}).get("attachments") or {}
        for comp in components:
            if comp.get("type") == 1:
                self._refresh(interaction, comp.get("components") or [])
                continue
            inner = comp.get("component") or comp
            cid = inner.get("custom_id")
            if cid == self.TEXT_ID:
                self.text = inner.get("value") or ""
            elif cid == self.LINK_ID:
                self.link = inner.get("value") or ""
            elif cid == self.FILE_ID:
                self.new_files = [discord.Attachment(data={**resolved[i], "id": i}, state=interaction._state)
                                  for i in inner.get("values") or [] if i in resolved]

    async def on_submit(self, interaction: discord.Interaction):
        await handle_form(self.bot, interaction, self)

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        print(f"[ANNOUNCE ERROR]\n{''.join(traceback.format_exception(error))}", flush=True)
        await panels.apologize(interaction, "うまく処理できませんでした。もう一度 `/announce` からお試しください。")


async def open_form(interaction: discord.Interaction, bot, draft: Draft, opened_from=None):
    try:
        await interaction.response.send_modal(AnnounceForm(bot, draft, opened_from=opened_from))
    except discord.HTTPException as e:
        # ファイル添付つきのフォームを Discord に断られたら、文字だけのフォームを出す
        print(f"[ANNOUNCE] ファイル添付つきのフォームを出せませんでした: {e}", flush=True)
        await interaction.response.send_modal(
            AnnounceForm(bot, draft, with_file=False, opened_from=opened_from))


async def handle_form(bot, interaction: discord.Interaction, form: AnnounceForm):
    """フォームが送られたら、中身と送り先を確かめてプレビューを出す(問題があれば理由とやり直し)。"""
    if interaction.user.id not in ADMIN_USER_IDS:
        return await interaction.response.send_message("権限がありません。", ephemeral=True)
    if interaction.message is not None:
        await interaction.response.defer()          # 確認の画面から開いた → その画面を書き換える
    else:
        await interaction.response.defer(ephemeral=True, thinking=True)
    if form.opened_from is not None:
        form.opened_from.stop()                     # 古い画面は、ここで書き換えるので止める
    files, error = form.draft.files, ""
    if form.new_files:
        got, error = await read_attachments(form.new_files)
        files = got if got is not None else files
    draft = Draft(form.text, files, form.link)
    if not error and not draft.text.strip() and not draft.files:
        error = "メッセージを入力するか、画像・ファイルを付けてください。"
    channel = None
    if not error:
        channel, error = await resolve_target(bot, interaction.user, draft.link, bool(draft.files),
                                              interaction.guild)
    if error:
        view = RetryView(bot, interaction.user.id, draft)
        view.screen = interaction
        await _edit(interaction, content=f"⚠️ {error}", embed=None, attachments=[], view=view)
        return
    plan = Plan(bot, channel, draft)
    view = PreviewView(bot, interaction.user.id, plan)
    view.screen = interaction
    shown = {"content": plan.parts[0] or None, "embed": preview_embed(plan), "view": view}
    if await _edit(interaction, attachments=make_files(draft.files), **shown):
        return
    # 画像を載せられなかった等 → 画像なしで確認を出す(送るときは付ける)
    if draft.files:
        shown["embed"] = preview_embed(plan, "（確認の画面には画像を載せられませんでした。送るときは付けます）")
    await _edit(interaction, attachments=[], **shown)


class Announce(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="announce", description="Botからお知らせを送る（フォームで内容と送り先を入力）")
    async def announce(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await open_form(interaction, self.bot, Draft())


async def setup(bot):
    await bot.add_cog(Announce(bot))
