import discord
from discord import app_commands, ui
from discord.ext import commands, tasks
import asyncio
import json
import logging
import os
import io
import random
import re
import threading
import time
import uuid

import link_orders
import panels
import payment_attempts
import payments
import support
import x_check
# ログ・通知は discord.py のやり直しで二重にならないように送る(nonce)。/announce と共通。
from send_once import send_once as _send_once
from utils import ADMIN_USER_IDS, notify_payment_pending
from datapath import data_path, read_json, write_json

log = logging.getLogger(__name__)

VENDING_FILE = data_path("vending_data.json")
STOCK_DIR = data_path("stock_files")
MAX_SLOTS = 25
# 1回に買える個数の上限
MAX_QTY = 50

# 保留になった支払いを見張る時間(分)。代行と違って在庫を取り置いたまま待つので、
# 他のお客さんを待たせないよう短めにする(期限が来たら在庫は戻す)。
WATCH_MINUTES = int(os.environ.get("SHOP_LINK_WATCH_MINUTES", "120"))

# 自販機売上 [{"ts","machine_id","machine_name","product_id","product_name","amount","qty","user_id",
#              "method","order_id"}]
SHOP_SALES_FILE = data_path("shop_sales.json")

# 売上と在庫はどちらも「読んで・直して・書く」。支払い画面はこれらをスレッドに
# 逃がして呼ぶ(イベントループを止めないため)ので、同時に走っても片方の書き込みが
# 消えないようプロセス内で直列にする。在庫は特に、2人が同時に買ったときに同じ
# レコードを2回渡さないための砦でもある。
_sales_lock = threading.Lock()
_stock_lock = threading.Lock()


def load_shop_sales() -> list:
    return read_json(SHOP_SALES_FILE, [])


def record_shop_sale(machine_id, machine, product, qty, amount, user_id, method=payments.PAYPAY,
                     order_id: str = None):
    """売上を1件残す。order_id は販売ログ・お客さんへの案内と同じ注文番号。"""
    if amount <= 0:
        return
    with _sales_lock:
        data = load_shop_sales()
        data.append({
            "ts": time.time(),
            "machine_id": machine_id,
            "machine_name": machine.get("name"),
            "product_id": product.get("product_id"),
            "product_name": product.get("name"),
            "amount": int(amount), "qty": int(qty), "user_id": str(user_id),
            "method": method,
            "order_id": order_id or None,
        })
        write_json(SHOP_SALES_FILE, data)


async def record_shop_sale_async(*args, **kwargs):
    """record_shop_sale をスレッドで。売上ファイルは消さないので年々伸び、
    書き込みのたびに丸ごと書き直す。支払い画面でイベントループを止めない。"""
    await asyncio.to_thread(record_shop_sale, *args, **kwargs)


def load_vending() -> dict:
    return read_json(VENDING_FILE, {})


def save_vending(data: dict):
    write_json(VENDING_FILE, data)


# Discord のコードブロックの囲み(``` や ```txt)だけの行
_FENCE_LINE = re.compile(r"^\s*```[\w+#-]*\s*$")
# ```txt のように囲みに付く言語名(中身の1行目と取り違えないよう、よく使うものだけ)
_FENCE_LANGS = {"txt", "text", "plaintext", "md", "markdown", "json", "csv", "ini", "yaml",
                "yml", "js", "py", "sh", "bash", "diff", "css", "html", "xml", "sql", "ansi"}


def code_block_texts(text: str):
    """``` で囲まれた部分の中身のリスト。囲みが無ければ(``` が1つ以下なら) None。

    届いたメッセージを丸ごと貼られたときに、囲みの外の案内文を在庫として数えない
    ために使う。```txt のような言語名は外す。
    """
    parts = (text or "").split("```")
    if len(parts) < 3:
        return None
    blocks = []
    for block in parts[1::2]:
        first, nl, rest = block.partition("\n")
        blocks.append(rest if nl and first.strip().lower() in _FENCE_LANGS else block)
    return blocks


def parse_stock_records(text: str) -> list:
    """在庫テキストを『1商品 = 1レコード』のリストに分解する。

    - テキスト中に空行があれば「空行区切り」とみなし、複数行を1商品として扱う
      （例: アカウント情報のように 3 行で 1 セットの商品）。
    - 空行が無ければ従来通り「1行 = 1商品」。
    これにより既存の1行1個の在庫はそのまま動き、空行を入れた時だけ複数行商品になる。
    - ``` だけの行(Discord のコードブロックの囲み)は商品として数えない。届いた
      メッセージをそのまま貼られても、囲みが1件にならないように。
    """
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    text = "\n".join(ln for ln in text.split("\n") if not _FENCE_LINE.match(ln))
    if "\n\n" in text:
        records = []
        for block in re.split(r"\n[ \t]*\n", text):
            # レコード内の空行は落として前後を整える(空行は区切り専用)
            lines = [ln for ln in block.split("\n") if ln.strip() != ""]
            if lines:
                records.append("\n".join(lines))
        return records
    return [ln for ln in text.split("\n") if ln.strip() != ""]


def read_stock_records(path: str) -> list:
    """在庫ファイルを読み、レコードのリストを返す(無ければ空リスト)。

    新形式は JSON 配列で保存する(複数行商品でも境界が曖昧にならない)。
    旧形式(プレーンテキストの在庫ファイル)は parse_stock_records で分解する。
    """
    if not path or not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = f.read()
    except OSError:
        return []
    stripped = raw.strip()
    if not stripped:
        return []
    if stripped[0] == "[":  # 新形式(JSON)
        try:
            data = json.loads(stripped)
            if isinstance(data, list):
                return [str(x).strip("\n") for x in data if str(x).strip()]
        except (json.JSONDecodeError, ValueError):
            pass
    return parse_stock_records(raw)  # 旧形式(プレーンテキスト)


def write_stock_records(path: str, records: list):
    """レコード群を JSON 配列として保存する(改行を含む商品も復元可能)。

    在庫は商品そのものなので、書き込みの途中で落ちて壊れると売り物が消える。
    書き切ってから差し替える write_json を使う。
    """
    clean = [str(r).strip("\n") for r in records if str(r).strip()]
    write_json(path, clean)


def is_owner(user_id, machine: dict) -> bool:
    return int(user_id) in ADMIN_USER_IDS or str(user_id) == str(machine.get("owner_id"))


async def fetch_member(guild, user_id):
    """メンバーを取り出す。キャッシュに無ければAPIに取りに行く。

    get_member はキャッシュ頼りで、再起動直後やLTCのように後から処理する場面では
    None になりやすい。そのまま諦めるとロールが「たまに付かない」挙動になる。
    """
    if guild is None:
        return None
    try:
        uid = int(user_id)
    except (TypeError, ValueError):
        return None
    member = guild.get_member(uid)
    if member is not None:
        return member
    try:
        return await guild.fetch_member(uid)
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        return None


async def grant_purchase_role_in(guild, user_id, role_id, paid_amount) -> bool:
    """ロール付与の本体。LTCのように後から(Interaction無しで)渡す場合もここを使う。"""
    if not role_id or int(paid_amount or 0) <= 0:
        return False
    if guild is None:
        return False
    member = await fetch_member(guild, user_id)
    role = guild.get_role(int(role_id))
    if member is None or role is None:
        print(f"[SHOP ROLE] 付与できません(member={member is not None} / role={role is not None} "
              f"/ role_id={role_id})", flush=True)
        return False
    if role in member.roles:
        return True
    try:
        await member.add_roles(role, reason="商品購入(有料)による自動付与")
        return True
    except (discord.Forbidden, discord.HTTPException) as e:
        # Botのロールが対象より下・権限不足など。黙って落とすと原因が追えない。
        print(f"[SHOP ROLE] 付与に失敗({role.name} → {member}): {e}", flush=True)
        return False


def get_owned_machine(user_id, machine_id: str):
    """machine_id の自販機を返す。所有者/管理者でなければ None。"""
    data = load_vending()
    m = data.get(machine_id)
    if not m or not is_owner(user_id, m):
        return None, data
    return m, data


# 在庫ファイル -> ((inode, 更新時刻, サイズ), 件数)。stock_count が使う
_count_cache = {}


def stock_count(product: dict):
    """在庫の件数。在庫ファイルが前に数えたときのままなら、その数を使う。

    在庫数はパネル・商品一覧・個数の上限など、押されるたびに何度も見る。毎回ファイルを
    丸ごと読んで JSON を解くと、1件が大きく数も多い在庫(X垢など)ほど重く、その間は
    Bot 全体が止まる。在庫の書き込みは毎回ファイルを差し替える(write_json)ので、
    inode・更新時刻・サイズが同じなら中身も同じ。
    """
    if product.get("infinite"):
        return "∞"
    path = product.get("stock_file")
    if not path:
        return 0
    try:
        st = os.stat(path)
    except OSError:
        return 0                        # ファイルが無い = 在庫なし(read_stock_records と同じ)
    mark = (st.st_ino, st.st_mtime_ns, st.st_size)
    hit = _count_cache.get(path)
    if hit and hit[0] == mark:
        return hit[1]
    n = len(read_stock_records(path))
    _count_cache[path] = (mark, n)
    return n


# ---------- お客さんに見せる在庫数(取り置き中の分を含む) ----------
#
# 支払いが保留(承認待ち)で見張りに回った注文は、その分の在庫を取り置く(在庫ファイル
# から抜く)。承認されればそのまま渡し、期限切れ・キャンセル・買い直しなら在庫へ戻す。
# 手元の在庫だけを見せると、保留で 13→11 に減り、戻しで 11→13 に増えて見える。
# 売れてもいない・足してもいないのに数が動くので、お客さんから見ると分からない。
# 見せる数は「手元の在庫＋取り置き中」にする。これなら、実際に売れたとき(お渡し)と
# 在庫を足したときにしか動かない。購入できるかの判定は手元の在庫で行い、足りない
# ときは「◯個は別のお客様の支払い確認中」と理由を添える。

_reserved_cache = {"mark": None, "counts": {}}


def reserved_counts() -> dict:
    """取り置き中(見張り中でまだ渡しても戻してもいない)の在庫数 {product_id: 個数}。

    注文の台帳(link_orders.json)が前に見たときのままなら、前に数えた結果を使う。
    受け取れた(paid)・渡した(done)注文の在庫は売れたものなので数えない。期限切れで
    まだ戻していない分は、これから在庫に戻るので数える(戻った瞬間に増えて見えないように)。
    """
    try:
        st = os.stat(link_orders.ORDER_FILE)
    except OSError:
        return {}
    mark = (st.st_ino, st.st_mtime_ns, st.st_size)
    if _reserved_cache["mark"] == mark:
        return _reserved_cache["counts"]
    counts = {}
    try:
        orders = link_orders.load_store()["orders"].values()
    except Exception as e:
        log.warning("取り置き中の在庫を数えられませんでした: %s", e)
        return _reserved_cache["counts"]
    for order in orders:
        if order.get("kind") not in ("shop", "tgshop"):
            continue
        if order.get("status") not in (link_orders.WATCHING, link_orders.EXPIRED):
            continue
        if not holds_stock(order):
            continue
        payload = order.get("payload") or {}
        pid = str(payload.get("product_id") or "")
        if pid:
            counts[pid] = counts.get(pid, 0) + len(payload.get("records") or [])
    _reserved_cache.update(mark=mark, counts=counts)
    return counts


def reserved_count(product: dict) -> int:
    """その商品の取り置き中の在庫数。"""
    if product.get("infinite"):
        return 0
    return reserved_counts().get(str(product.get("product_id") or ""), 0)


def shown_stock(product: dict):
    """お客さんに見せる在庫数(手元の在庫＋取り置き中)。無限在庫は ∞。"""
    if product.get("infinite"):
        return "∞"
    return stock_count(product) + reserved_count(product)


def admin_stock_text(product: dict) -> str:
    """運営向けの在庫数。取り置き中があれば、見せている数とのずれが分かるように添える。"""
    if product.get("infinite"):
        return "∞"
    held = reserved_count(product)
    return f"{stock_count(product)}個" + (f"（ほかに取り置き中 {held}個）" if held else "")


def availability_note(product: dict) -> str:
    """見せている在庫数より今すぐ買える数が少ないときの説明。取り置きが無ければ空。"""
    if product.get("infinite"):
        return ""
    held = reserved_count(product)
    if held <= 0:
        return ""
    have = stock_count(product)
    return (f"在庫 {have + held}個のうち {held}個は別のお客様の支払い確認中です"
            f"（今すぐ購入できるのは {have}個）。確認が終わると購入できるようになることがあります。")


async def machine_autocomplete(interaction: discord.Interaction, current: str):
    data = load_vending()
    uid = str(interaction.user.id)
    out = []
    for mid, m in data.items():
        if int(interaction.user.id) in ADMIN_USER_IDS or m.get("owner_id") == uid:
            name = m.get("name", "無名")
            if current.lower() in name.lower() or current in mid:
                out.append(app_commands.Choice(name=f"{name}", value=mid))
    return out[:25]


# ---------- 購入 ----------

# 購入で渡す在庫を選ぶ乱数。OS の乱数源を使い、次に何が出るかを外から読めないようにする。
_stock_rng = random.SystemRandom()


def take_stock(product: dict, qty: int):
    """在庫を qty 個だけ取り出して返す(在庫ファイルからは減らす)。足りなければ None。

    どれを渡すかは在庫全体からランダムに選ぶ(順番もランダム)。以前は先頭から順に
    渡していたので、入れた順にそのまま出ていた(古いものから・補充分は最後)。
    無限在庫は同じ内容を qty 個返すだけで、ファイルは触らない。
    読んでから書くまでをロックで守る。ここが割り込まれると、同時に買った
    2人に同じレコードを渡すことになる。
    """
    if product.get("infinite"):
        return [product.get("infinite_content", "") for _ in range(qty)]
    path = product.get("stock_file")
    with _stock_lock:
        records = read_stock_records(path)
        if len(records) < qty:
            return None
        # 位置で選ぶ(同じ内容の在庫が複数あっても、選んだ分だけを正しく減らす)。
        picked = _stock_rng.sample(range(len(records)), qty)
        chosen = set(picked)
        write_stock_records(path, [r for i, r in enumerate(records) if i not in chosen])
        return [records[i] for i in picked]


def pull_stock(product: dict, limit: int) -> list:
    """在庫を最大 limit 個、あるだけ取り出す(管理者の引き出し用)。無ければ空。

    購入(take_stock)と同じく、どれを取り出すかは在庫全体からランダムに選ぶ(順番も
    ランダム)。以前は先頭から順に取り出していた。
    """
    path = product.get("stock_file")
    with _stock_lock:
        records = read_stock_records(path)
        n = min(limit, len(records))
        if n <= 0:
            return []
        # 位置で選ぶ(同じ内容の在庫が複数あっても、選んだ分だけを正しく減らす)。
        picked = _stock_rng.sample(range(len(records)), n)
        chosen = set(picked)
        write_stock_records(path, [r for i, r in enumerate(records) if i not in chosen])
        return [records[i] for i in picked]


async def take_stock_async(product: dict, qty: int):
    """take_stock をスレッドで(お渡しの途中でイベントループを止めない)。"""
    return await asyncio.to_thread(take_stock, product, qty)


def remove_stock_records(product: dict, to_remove: list) -> list:
    """在庫から to_remove に一致するレコードだけを取り除き、取り除いたものを返す。

    凍結したX垢(や年代に合わない垢)だけを在庫から抜くのに使う。無限在庫は対象外。
    購入と同時でも崩れないよう、読んでから書くまでをロックの中で行う。チェックは時間がかかるので、
    その間に売れた分は現在の在庫に居ないだけ。いま在庫に残っている一致分だけを消す
    (同じ内容が複数あるときは要求された個数だけ)。
    """
    if product.get("infinite") or not to_remove:
        return []
    path = product.get("stock_file")
    from collections import Counter
    want = Counter(to_remove)
    removed, kept = [], []
    with _stock_lock:
        for rec in read_stock_records(path):
            if want.get(rec, 0) > 0:
                want[rec] -= 1
                removed.append(rec)
            else:
                kept.append(rec)
        if removed:
            write_stock_records(path, kept)
    return removed


def _drop_headers(records: list):
    """仕入れファイルの見出し行(「Username----Password----…」のような形式の説明)を除く。
    見出しを垢として確認したり、cleaned_accounts.txt に入れたりしないように。
    (残り, 除いた行数) を返す。"""
    kept = [r for r in records if not x_check.header_labels(r)]
    return kept, len(records) - len(kept)


def _subtract_records(all_records: list, removed: list) -> list:
    """all_records から removed の分だけ取り除いた残りを返す(順番・重複・個数を保つ)。

    クリーニングで「取り除いた分を抜いた、きれいなファイル」を作るのに使う。チェックの
    上限を超えて見ていないレコードは removed に入らないので、そのまま残る。
    """
    from collections import Counter
    rm = Counter(removed)
    kept = []
    for r in all_records:
        if rm.get(r, 0) > 0:
            rm[r] -= 1
        else:
            kept.append(r)
    return kept


def return_stock(product: dict, records: list):
    """取り置いた在庫を戻す(LTCの支払い期限切れなど)。"""
    if not records or product.get("infinite"):
        return
    _append_stock(product, records)


async def return_stock_async(product: dict, records: list):
    """return_stock をスレッドで(在庫ファイルの書き込みでイベントループを止めない)。"""
    await asyncio.to_thread(return_stock, product, records)


async def append_stock_async(product: dict, records: list):
    """_append_stock をスレッドで。長い在庫の貼り付けを足すあいだ、他の購入を止めない。"""
    await asyncio.to_thread(_append_stock, product, records)


# fetch で取りに行ったチャンネルの控え {channel_id: channel}。
# fetch_channel はキャッシュに入れてくれないので、入れておかないと
# ログを送るたびに同じチャンネルを取りに行く(販売のたびに往復が1つ増える)。
_fetched_channels = {}

def _http_reason(e: discord.HTTPException) -> str:
    text = (getattr(e, "text", "") or "").strip() or str(e)
    return f"HTTP {getattr(e, 'status', '?')}: {text}"[:200]


async def _channel_for_log(bot, ch_id):
    """設定されたIDからチャンネルを取り出す。(チャンネル, 取れなかった理由)。

    get_channel はキャッシュにある分しか返さないので、再起動直後や、
    そのチャンネルをまだ一度も触っていないときは None になる。ログが
    「設定してあるのに一通も流れない」原因になるため、fetch まで試す。
    理由は管理者に見せる文なので、何をすれば直るかが分かる言い方にする。
    """
    if not ch_id:
        return None, "送り先が設定されていません"
    try:
        ch_id = int(ch_id)
    except (TypeError, ValueError):
        return None, f"チャンネルIDが不正です: {ch_id!r}"
    ch = bot.get_channel(ch_id) or _fetched_channels.get(ch_id)
    if ch is None:
        try:
            ch = await bot.fetch_channel(ch_id)
        except discord.NotFound:
            return None, "チャンネルが見つかりません（消されたか、IDが違います）"
        except discord.Forbidden:
            return None, "Botがそのチャンネルを見られません（閲覧権限が無いか、サーバーから抜けています）"
        except Exception as e:
            return None, f"チャンネルを取得できませんでした: {type(e).__name__}: {str(e)[:120]}"
        _fetched_channels[ch_id] = ch
    if not hasattr(ch, "send"):
        return None, f"メッセージを送れない種類のチャンネルです（{type(ch).__name__}）"
    return ch, ""


async def _send_log(bot, ch_id, label: str, make_payload) -> str:
    """ログを1通送る。送れたら空文字、送れなければ理由(管理者に見せる文)を返す。

    make_payload() は送るたびに呼ぶ。添付ファイル(長い在庫の .txt)は一度送ると
    閉じられて使い回せないので、送り先を変えて出し直すときは作り直しが要る。
    ここでは送り直さない(通信の切れ目や 5xx は discord.py が内側で何度か
    やり直していて、それでも駄目だったものを同じ所へもう一度投げても、
    届かないか、届いていたものが二重になるかのどちらか)。落ちても購入処理は止めない。
    送るときは nonce を付けて、discord.py のやり直しで同じ投稿が2通にならないようにする
    (_send_once)。
    """
    ch, reason = await _channel_for_log(bot, ch_id)
    if ch is None:
        print(f"[SHOP LOG ERROR] {label}を送れません({ch_id}): {reason}", flush=True)
        return reason
    try:
        await _send_once(ch, make_payload())
        return ""
    except discord.Forbidden as e:
        reason = f"権限不足（{_http_reason(e)}）"
    except discord.HTTPException as e:
        reason = f"Discordが受け付けませんでした（{_http_reason(e)}）"
    except Exception as e:
        reason = f"{type(e).__name__}: {str(e)[:200]}"
    print(f"[SHOP LOG ERROR] {label}の送信に失敗: #{getattr(ch, 'name', ch_id)} / {reason}", flush=True)
    return reason


async def _dm_admins(bot, make_payload) -> int:
    """管理者全員にDMして、届いた人数を返す。make_payload() は1人ごとに呼ぶ(添付は使い回せない)。"""
    delivered = 0
    for uid in ADMIN_USER_IDS:
        try:
            user = bot.get_user(uid) or await bot.fetch_user(uid)
            await user.send(**make_payload())
            delivered += 1
        except Exception as e:
            log.warning("管理者DMに失敗 (%s): %s", uid, e)
    return delivered


async def _tell_admins_log_failed(bot, machine, failures: list, make_payload,
                                  plain_text: str = None):
    """送れなかったログを、理由つきで管理者のDMに届ける。

    販売ログは「誰に・何を渡したか」の唯一の控え(在庫はもう取り出してある)。
    これまでは送れなくてもコンテナのログに1行出るだけで、管理者から見ると
    「在庫だけ減って販売ログが来ない」状態になり、原因も中身も追えなかった。
    送り先が壊れていても、内容と「なぜ送れなかったか」は必ず人の目に届ける。

    failures は [(ログの名前, 送り先のチャンネルID, 理由), ...]。
    make_payload(prefix) は本文の先頭に付ける文を受け取る(在庫が長いときは
    stock_payload が .txt に逃がすので、先頭文を足しても上限を越えない)。
    plain_text は、管理者の誰にも届かなかったときにコンテナのログへ残す中身
    (添付に逃がした在庫は Discord 用の本文には載っていないので、別に渡す)。
    """
    lines = [f"⚠️ **{label}を送れませんでした**（自販機「{(machine or {}).get('name') or '不明'}」"
             f" / 送り先 <#{ch_id}>）\n理由: `{str(reason)[:300]}`"
             for label, ch_id, reason in failures]
    head = ("\n".join(lines) + "\n"
            "送り先の設定(`/shop logchannel` `/shop selllog`)とBotの権限(チャンネルを見る・"
            "メッセージを送信・ファイルを添付)を確認してください。送るはずだった内容:\n")
    if await _dm_admins(bot, lambda: make_payload(prefix=head)):
        return
    # 管理者の誰にも届かない。中身を失わない最後の手段としてコンテナのログに残す。
    body = plain_text
    if body is None:
        try:
            body = make_payload().get("content") or ""
        except Exception:
            body = ""
    print(f"[SHOP LOG UNDELIVERED] {head}{body}", flush=True)


async def _log_or_tell_admins(bot, machine, ch_id, label: str, make_payload,
                              plain_text: str = None) -> bool:
    """ログを1通送る。送れなければ、同じ内容を理由つきで管理者のDMに届ける。"""
    reason = await _send_log(bot, ch_id, label, make_payload)
    if not reason:
        return True
    await _tell_admins_log_failed(bot, machine, [(label, ch_id, reason)], make_payload,
                                  plain_text=plain_text)
    return False


def _with_prefix(payload: dict, prefix: str = "") -> dict:
    """在庫を含まないログ(embed だけ)に、先頭文があれば本文として付ける。"""
    if prefix:
        return {**payload, "content": prefix.rstrip("\n")}
    return dict(payload)


def purchase_log_embeds(buyer, product_name, qty, paid, method, txid: str = None,
                        order_id: str = None, note: str = None, route: str = "Discord"):
    """販売ログの embed。(公開ログ, 非公開ログ)。note は非公開ログに添える備考。
    route は購入経路(Discord / Telegram)。非公開ログの一番下に出す。"""
    label = payments.method_label(method)
    # 自販機の販売ログは赤。代行(ツム・にゃんこ・ぷに)のログは青系なので、色で見分ける。
    pub = discord.Embed(title="販売ログ", color=0xff3333, timestamp=discord.utils.utcnow())
    pub.add_field(name="購入者", value=buyer.mention, inline=True)
    pub.add_field(name="商品", value=product_name, inline=True)
    pub.add_field(name="数量", value=f"{qty}個", inline=True)
    pub.add_field(name="金額", value=f"{paid:,}円", inline=True)
    pub.add_field(name="支払い方法", value=label, inline=True)
    try:
        pub.set_thumbnail(url=buyer.display_avatar.url)
    except Exception:
        pass

    prv = discord.Embed(title="非公開販売ログ", color=0xb71c1c, timestamp=discord.utils.utcnow())
    prv.add_field(name="購入者", value=f"{buyer.mention}（`{buyer.id}`）", inline=False)
    prv.add_field(name="商品", value=product_name, inline=True)
    prv.add_field(name="数量", value=f"{qty}個", inline=True)
    prv.add_field(name="金額", value=f"{paid:,}円", inline=True)
    prv.add_field(name="支払い方法", value=label, inline=True)
    if order_id:
        # お客さんへの案内・売上の記録と同じ番号。問い合わせはこの番号で
        # 突き合わせる(保留を挟んだ注文なら見張りにも同じ番号で残る)。
        prv.add_field(name="注文番号", value=f"`{order_id}`", inline=True)
    if txid:
        prv.add_field(name="入金TXID", value=f"`{txid}`", inline=False)
    if note:
        prv.add_field(name="備考", value=str(note)[:1024], inline=False)
    # 一番下に経路(Discord / Telegram)を出す。どちらで売れたか一目で分かるように。
    prv.add_field(name="経路", value=str(route or "Discord"), inline=False)
    return pub, prv


async def send_purchase_logs(bot, machine, buyer, product_name, qty, paid, stock_text, method,
                             txid: str = None, order_id: str = None, note: str = None,
                             route: str = "Discord"):
    """販売ログを送る。公開ログは在庫内容なし、非公開ログは在庫内容つき。

    2通は互いに関係が無いので同時に送る(順に送ると往復が2回ぶん並ぶ)。
    送れなかったものがあれば、管理者に1通だけDMする(非公開ログが送れなければ
    在庫つきの非公開ログを、公開ログだけ送れなければ公開ログを添える)。
    """
    pub_embed, prv_embed = purchase_log_embeds(buyer, product_name, qty, paid, method,
                                               txid=txid, order_id=order_id, note=note,
                                               route=route)

    def pub_payload(prefix=""):
        return _with_prefix({"embed": pub_embed}, prefix)

    def prv_payload(prefix=""):
        return {**stock_payload(stock_text, prefix=prefix), "embed": prv_embed}

    sends = []
    pub_id = machine.get("sell_log_channel_id")
    if pub_id:
        sends.append(("公開販売ログ", pub_id, pub_payload, None))
    prv_id = machine.get("private_log_channel_id")
    if prv_id:
        sends.append(("非公開販売ログ", prv_id, prv_payload, stock_text))
    if not sends:
        return
    reasons = await asyncio.gather(*(_send_log(bot, ch_id, label, make)
                                     for label, ch_id, make, _ in sends))
    failed = [(label, ch_id, reason) for (label, ch_id, _, _), reason in zip(sends, reasons)
              if reason]
    if not failed:
        return
    # 非公開ログが落ちていればそちら(在庫つき)を添える。公開ログだけなら公開ログを。
    _, _, make, plain = next(((label, ch_id, make, plain) for label, ch_id, make, plain in sends
                              if label == "非公開販売ログ" and any(f[0] == label for f in failed)),
                             next(s for s in sends if any(f[0] == s[0] for f in failed)))
    await _tell_admins_log_failed(bot, machine, failed, make, plain_text=plain)


async def send_trouble_log(bot, machine, buyer, *, title: str, detail: str,
                           paid: int = 0, method: str = None, product_name: str = None,
                           qty: int = None, order_id: str = None):
    """「お金は受け取ったのに渡せなかった」ときのログ。

    どこにも残さないと、管理者から見ると「残高だけ増えてログが流れていない」
    状態になり、誰に何を渡し損ねたのかが分からない。非公開ログ(無ければ
    公開ログ)と管理者DMの両方に必ず残す。
    """
    e = discord.Embed(title=title, description=detail, color=0xff3333,
                      timestamp=discord.utils.utcnow())
    if buyer is not None:
        e.add_field(name="購入者", value=f"{buyer.mention}（`{buyer.id}`）", inline=False)
    if product_name:
        e.add_field(name="商品", value=product_name, inline=True)
    if qty is not None:
        e.add_field(name="数量", value=f"{qty}個", inline=True)
    if paid:
        e.add_field(name="受取済みの金額", value=f"{paid:,}円", inline=True)
    if method:
        e.add_field(name="支払い方法", value=payments.method_label(method), inline=True)
    if machine:
        e.add_field(name="自販機", value=str(machine.get("name") or "不明"), inline=True)
    if order_id:
        e.add_field(name="注文番号", value=f"`{order_id}`", inline=True)
    e.set_footer(text="返金または手渡しの対応が必要です")

    sent = False
    for ch_id in (machine.get("private_log_channel_id") if machine else None,
                  machine.get("sell_log_channel_id") if machine else None):
        if ch_id and not await _send_log(bot, ch_id, "トラブルログ", lambda: {"embed": e}):
            sent = True
            break
    # ログ先が未設定・送信不能でも管理者には必ず届くようにする
    for uid in ADMIN_USER_IDS:
        try:
            user = bot.get_user(uid) or await bot.fetch_user(uid)
            await user.send(embed=e)
            sent = True
        except Exception:
            continue
    if not sent:
        print(f"[SHOP TROUBLE] {title} / {detail}", flush=True)


# Discord の本文の上限。コードブロックに入れた在庫がこれを超えるときはファイルで渡す。
MESSAGE_LIMIT = 2000

# X垢チェックのモード→見出しの語。
_X_KIND = {"frozen": "凍結", "age": "年代"}
# 凍結の取り除きに付けられる「年代」(売っている作成年の上限)。「2007〜2018年」で売る
# なら 2018 にすると、混ざっていた2019年以降の垢も取り除く。Xの垢は2006年から。
_X_YEAR_HELP = "この年より後に作られた垢も取り除く（例: 2018 → 2019年以降を取り除く）"
_XYear = app_commands.Range[int, 2006, 2100]


def stock_payload(stock_text: str, prefix: str = "") -> dict:
    """在庫を DM やログに載せるときの引数。短ければコードブロック、長ければ .txt を添付。

    1件が600字ある在庫(X垢など)を数個まとめて買われると本文の上限を超え、送れずに
    落ちる。在庫は取ったあとなので、お客さんに何も届かないまま終わっていた。
    """
    body = f"{prefix}```\n{stock_text}\n```"
    if len(body) <= MESSAGE_LIMIT:
        return {"content": body}
    return {"content": f"{prefix}在庫は添付のファイルをご確認ください。",
            "file": discord.File(io.BytesIO(stock_text.encode("utf-8")), filename="stock.txt")}


def purchase_dm_embed(product_name, qty, paid, method, order_id: str = None) -> discord.Embed:
    title = "お受け取りありがとうございます" if paid <= 0 else "ご購入ありがとうございます"
    e = discord.Embed(title=title, color=discord.Color.green())
    e.add_field(name="商品", value=product_name, inline=True)
    e.add_field(name="購入数", value=f"{qty}個", inline=True)
    e.add_field(name="支払金額", value=f"{paid:,}円", inline=True)
    e.add_field(name="支払い方法", value=payments.method_label(method), inline=True)
    if order_id:
        # 問い合わせのときにこの番号を言ってもらえば、販売ログ・売上・見張りの
        # どれからでも同じ注文に辿り着ける。
        e.set_footer(text=f"注文番号 {order_id}（お問い合わせの際はこの番号をお伝えください）")
    return e


async def _deliver_purchase_dm(user, stock_text: str, embed) -> tuple:
    """購入した在庫をお客さんのDMへ送る。(送れたか, 本当にDMを送れないか)。

    DM許可済みでも、一時的なDiscordのエラーや(まれに)Embedが弾かれて送れないことが
    ある。これまではそれらを全部「DM拒否」と同じ扱いにして、その場(購入画面)に中身を
    出していたため、「DM許可してるのに届かない」が起きていた。

    ・本当にDMを送れない(Forbidden=DM拒否・ブロック・サーバーのDM設定オフ)ときだけ
      (False, True) を返す。この場合だけ画面に「DM許可を確認してください」と出す。
    ・それ以外の失敗(429/5xx など一時的・または Embed 起因)は数回やり直す。やり直しても
      駄目なら、Embed を外して本文(在庫)だけでも送ってみる(Embedが原因でも在庫は届く)。
      それでも駄目なら (False, False)。
    失敗した理由は必ずログに残す(次に同じことが起きたとき原因を追えるように)。
    """
    # 1周目は Embed つき、2周目は Embed 無し(Embed が弾かれても在庫だけは届ける)。
    for extra in ({"embed": embed}, {}):
        for attempt in range(3):
            try:
                await user.send(**stock_payload(stock_text), **extra)
                return True, False
            except discord.Forbidden as e:
                log.warning("購入DMを送れません(Forbidden code=%s): %s",
                            getattr(e, "code", None), e)
                return False, True
            except discord.HTTPException as e:
                status = getattr(e, "status", 0)
                log.warning("購入DM送信に失敗 (%d/3, status=%s code=%s): %s",
                            attempt + 1, status, getattr(e, "code", None), e)
                # 400系(長さ・Embed不正など)はやり直しても同じ。Embed 無しの周へ回す。
                if 400 <= status < 500 and status != 429:
                    break
                await asyncio.sleep(0.5 * (attempt + 1))   # 429/5xx は少し待ってやり直す
    return False, False


def order_number_line(order_id: str) -> str:
    """お渡しの案内に添える「注文番号: `LP-…`」。番号が無ければ空。"""
    return f"\n注文番号: `{order_id}`" if order_id else ""


async def _reply(interaction, content: str = None, **kwargs) -> bool:
    """購入画面(エフェメラル)に1通返す。送れたら True。

    送れなくても例外は上げない。呼び出し側はその結果で「届いたか」を決める。
    """
    try:
        if content is not None:
            kwargs["content"] = content
        await interaction.followup.send(ephemeral=True, **kwargs)
        return True
    except discord.HTTPException as e:
        log.warning("購入画面への返事に失敗: %s", e)
        return False


async def _mark_screen_delivery(order_id: str, delivered: bool, note: str = None, **fields):
    """支払い画面で受け取った注文に「渡した / 渡せていない」を書く。番号が無ければ何もしない。

    書けなくてもお渡しは止めない(印が無いままなら、入金突合が渡し直しの候補に
    するだけで、二重には渡さない)。fields は同じ書き込みで残す項目。
    """
    if not order_id:
        return
    try:
        await link_orders.mark_screen_delivery(order_id, delivered, note, **fields)
    except Exception as e:
        log.warning("注文 %s のお渡し印を書けませんでした: %s", order_id, e)


async def _mark_logged(order_id: str):
    """注文に「売上・販売ログまで済んだ」印を立てる。

    お渡しの印(delivered)と記録のあいだで Bot が落ちると、在庫は減りお金も入って
    いるのに売上も販売ログも無い購入ができる。印が無いまま残った注文は、起動時と
    定期の見回り(ShopCog.sweep)が記録を流し直す。
    """
    if not order_id:
        return
    try:
        await link_orders.mark_order(order_id, link_orders.DONE, logged=True)
    except Exception as e:
        log.warning("注文 %s の記録済みの印を書けませんでした: %s", order_id, e)


def handed_payload(machine_id: str, product: dict, qty: int, paid: int, method: str,
                   records: list, role_id=None) -> dict:
    """渡した内容を注文に残すための payload。見回りが記録を流し直すのに使う。

    鍵は records ではなく handed にする。records は「取り置いていて、戻すかもしれない
    在庫」の意味で読まれる(holds_stock)。渡し終えた中身は戻す対象ではない。
    """
    return {"machine_id": machine_id, "product_id": product.get("product_id"),
            "product_name": product.get("name"), "qty": int(qty), "paid": int(paid),
            "method": method, "role_id": role_id, "handed": list(records)}


async def _report_after_delivery_failure(bot, machine, step: str, error: Exception, *,
                                         product_name, qty, paid, user, method,
                                         order_id, stock_text):
    """お渡し後の記録(売上・ロール・販売ログ)が落ちたことを管理者に届ける。

    商品はもう渡っている。ここで黙ると、売上に無い・販売ログに無い購入が
    できあがり、在庫の数と記録が合わなくなった理由を誰も追えない。
    """
    head = (f"⚠️ **お渡し後の{step}に失敗しました**（自販機「{(machine or {}).get('name') or '不明'}」）\n"
            f"{product_name} ×{qty} / {int(paid):,}円 / {payments.method_label(method)} / "
            f"購入者 {getattr(user, 'mention', user)}（`{getattr(user, 'id', '?')}`）"
            + (f" / 注文番号 `{order_id}`" if order_id else "") + "\n"
            f"理由: `{type(error).__name__}: {str(error)[:200]}`\n")
    if step == "販売ログの送信":
        # 販売ログが流れていないなら、渡した中身をここで残す(他に控えが無い)。
        def make():
            return stock_payload(stock_text, prefix=head + "お渡しした内容:\n")
        plain = f"お渡しした内容:\n{stock_text}"
    else:
        def make():
            return {"content": head}
        plain = ""
    if not await _dm_admins(bot, make):
        print(f"[SHOP LOG UNDELIVERED] {head}{plain}", flush=True)


async def after_delivery(bot, machine_id: str, machine: dict, product: dict, product_name: str,
                         qty: int, paid: int, user, method: str, stock_text: str, *,
                         guild=None, role_id=None, order_id: str = None, txid: str = None,
                         sale=None, log_note: str = None, route: str = "Discord"):
    """商品がお客さんの手元に渡った後の記録(売上・購入ロール・販売ログ)。

    3つは互いに関係が無いので同時に走らせる。順に待つと、Discordへの往復が
    3〜4回ぶん縦に並んで、その分だけお客さんの画面も次のお客さんも待つ。
    どれか1つが失敗しても他は止めず、理由はログに残す(商品はもう渡っているので、
    ここで例外を上げて「渡せなかった」扱いにしてはいけない)。

    sale に先に走らせておいた売上の記録(Task)を渡せば、それを待つ。
    """
    sale_product = product or {"product_id": None, "name": product_name}
    if sale is None:
        sale = record_shop_sale_async(
            machine_id, machine, sale_product, qty, paid, user.id, method, order_id=order_id)
    steps = (
        ("売上の記録", sale),
        ("購入ロールの付与", grant_purchase_role_in(guild, user.id, role_id, paid)),
        ("販売ログの送信", send_purchase_logs(
            bot, machine, user, product_name, qty, paid, stock_text, method,
            txid=txid, order_id=order_id, note=log_note, route=route)),
    )
    results = await asyncio.gather(*(run for _, run in steps), return_exceptions=True)
    for (step, _), result in zip(steps, results):
        if isinstance(result, Exception):
            log.error("お渡し後の%sに失敗 (%s): %s", step, order_id or product_name, result,
                      exc_info=(type(result), result, result.__traceback__))
            # コンテナのログは管理者からは見えない。落ちた記録は必ず人に届ける。
            try:
                await _report_after_delivery_failure(
                    bot, machine, step, result, product_name=product_name, qty=qty,
                    paid=paid, user=user, method=method, order_id=order_id,
                    stock_text=stock_text)
            except Exception as e:
                log.error("お渡し後の失敗を管理者に知らせられませんでした: %s", e)


# ---------- まとめ買い値下げ ----------
# 商品の "bulk" に [{"qty": 10, "off": 200}, ...] の形で持つ(10個以上なら1個あたり200円引き)。
# 段はいくつでも付けられる。同じ個数を付け直すと置き換わる。

def bulk_tiers(product: dict) -> list:
    """まとめ買い値下げ [(個数, 1個あたりの値引き額), ...] を個数の昇順で。読めない行は飛ばす。"""
    tiers = []
    for t in product.get("bulk") or []:
        try:
            qty, off = int(t["qty"]), int(t["off"])
        except (TypeError, ValueError, KeyError):
            continue
        if qty >= 2 and off >= 1:
            tiers.append((qty, off))
    return sorted(tiers)


def set_bulk_tier(product: dict, qty: int, off: int) -> None:
    """「qty個以上なら1個 off円引き」を足す。同じ個数があれば置き換える。"""
    tiers = [t for t in bulk_tiers(product) if t[0] != qty] + [(qty, off)]
    product["bulk"] = [{"qty": n, "off": o} for n, o in sorted(tiers)]


def remove_bulk_tier(product: dict, qty: int) -> bool:
    """その個数の段を消す。あったら True。"""
    before = bulk_tiers(product)
    tiers = [t for t in before if t[0] != qty]
    product["bulk"] = [{"qty": n, "off": o} for n, o in tiers]
    return len(tiers) != len(before)


def bulk_off(product: dict, qty: int) -> int:
    """qty 個買うときの1個あたりの値引き額。届いている段のうちいちばん大きいもの。無ければ 0。

    値引き額が単価以上の段(あとで単価を下げたとき)は、タダで渡さないよう使わない。
    """
    unit = int(product.get("price") or 0)
    offs = [off for n, off in bulk_tiers(product) if n <= qty and off < unit]
    return max(offs) if offs else 0


def bulk_text(product: dict) -> str:
    """パネルに出す「まとめ買い: 5個以上 1個 300円 / 10個以上 1個 150円」。無ければ空。"""
    unit = int(product.get("price") or 0)
    parts = [f"{n}個以上 1個 {unit - off:,}円" for n, off in bulk_tiers(product) if off < unit]
    return "まとめ買い: " + " / ".join(parts) if parts else ""


def product_total(product: dict, qty: int) -> tuple:
    """qty 個の金額 (支払う額, 値下げ前の額, 1個あたりの値引き額)。

    10個以上で200円引きの商品を12個なら (350-200)×12。段に届かない個数は定価のまま。
    """
    unit = int(product.get("price") or 0)
    off = bulk_off(product, qty)
    return (unit - off) * qty, unit * qty, off


def _current_product(machine_id: str, product_id: str):
    """いまの自販機と商品を読み直す。(machine, product, 断る文)。見つかれば断る文は空。"""
    machine = load_vending().get(machine_id)
    if not machine:
        return None, None, "自販機が見つかりません。"
    product = next((p for p in machine.get("products", []) if p["product_id"] == product_id), None)
    if not product:
        return machine, None, "商品が見つかりません。"
    return machine, product, ""


def _short_stock(product: dict, qty: int) -> str:
    """在庫が足りなければ断る文。足りていれば空。"""
    if product.get("infinite"):
        return ""
    available = stock_count(product)
    if available < qty:
        note = availability_note(product)
        if note:
            return f"在庫が不足しています（購入: {qty}個）。{note}"
        return f"在庫が不足しています（在庫: {available}個 / 購入: {qty}個）。"
    return ""


_bg_tasks = set()                   # 裏で走らせているタスク(途中で GC に消されないよう持っておく)


def _open_dm_early(user):
    """支払いを確かめるあいだに、お渡しに使う DM の窓口を開けておく。

    初めて DM を送る相手には、送る前に窓口を作る往復が1回要る。受け取りの確認と
    並べて済ませておけば、お渡しの DM がその1往復ぶん早く届く。失敗しても、
    お渡しのときに作り直すだけ。
    """
    if getattr(user, "dm_channel", None) is not None:
        return

    async def run():
        try:
            await user.create_dm()
        except discord.HTTPException:
            pass
    task = asyncio.create_task(run())
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)


class QuantityModal(ui.Modal):
    """購入数を聞く。決まったら、その数ぶんの金額で支払い方法を選んでもらう。"""

    def __init__(self, machine_id: str, product: dict, bot: commands.Bot):
        super().__init__(title=product.get("name", "購入数")[:45])
        self.machine_id = machine_id
        self.product = product
        self.bot = bot
        self.qty = ui.TextInput(label=f"購入数（1〜{MAX_QTY}）", placeholder="1", default="1",
                                required=True, max_length=len(str(MAX_QTY)))
        self.add_item(self.qty)

    async def on_submit(self, interaction: discord.Interaction):
        try:
            qty = int(self.qty.value.strip())
        except ValueError:
            return await interaction.response.send_message(
                "購入数は整数で入力してください。", ephemeral=True)
        if not 1 <= qty <= MAX_QTY:
            return await interaction.response.send_message(
                f"購入数は1〜{MAX_QTY}で入力してください。", ephemeral=True)
        machine, product, err = _current_product(self.machine_id, self.product["product_id"])
        err = err or _short_stock(product, qty)
        if err:
            return await interaction.response.send_message(err, ephemeral=True)

        total, regular, off = product_total(product, qty)
        if total <= 0:
            # 0円の商品は支払いが無いので、そのまま渡す
            await interaction.response.defer(ephemeral=True, thinking=True)
            buy = PurchaseModal(self.machine_id, product, self.bot, payments.FREE, qty)
            return await buy.checkout(interaction)

        # 使える支払い方法は1回だけ調べる(受取先の設定ファイルを読む)。
        # 画面と押しボタンに同じ一覧を渡して、ここで3回読み直さない。
        methods = payments.available_methods()
        if not methods:
            return await interaction.response.send_message(
                "現在ご利用いただける支払い方法がありません。\n" + support.contact_line(),
                ephemeral=True)

        async def on_pick(inter: discord.Interaction, method_id: str):
            await inter.response.send_modal(
                PurchaseModal(self.machine_id, product, self.bot, method_id, qty))

        # まとめ買い値下げが効いていれば、1個あたりいくら引いたかを金額の下に添える
        note = (f"まとめ買い値下げで1個あたり {off:,}円引き（通常 {regular:,}円）"
                if off else None)
        await interaction.response.send_message(
            embed=payments.picker_embed(total, title=f"「{product['name']}」のお支払い方法",
                                        note=note, hints=False, methods=methods),
            view=payments.MethodPicker(on_pick, methods=methods), ephemeral=True)


class PurchaseModal(ui.Modal):
    """支払いリンクを受け取ってお渡しまで進める。購入数は QuantityModal で決まっている。

    0円の商品(method=FREE)は送らずに checkout だけ使う。
    """

    def __init__(self, machine_id: str, product: dict, bot: commands.Bot, method: str, qty: int):
        m = payments.method(method)
        title = "商品を受け取る" if method == payments.FREE else f"{m.label}で支払う"
        super().__init__(title=title[:45])
        self.machine_id = machine_id
        self.product = product
        self.bot = bot
        self.method = method
        self.qty = int(qty)
        self.link = None
        self.link_pw = None
        if m.kind == payments.LINK_KIND:
            self.link = ui.TextInput(label=f"{m.label}リンク", placeholder=m.placeholder, required=True)
            self.add_item(self.link)
            if method == payments.PAYPAY:
                self.link_pw = ui.TextInput(label="PayPayリンクパスワード（なしなら空欄）", required=False)
                self.add_item(self.link_pw)

    def _clean_link(self) -> str:
        """貼られたリンクを正規の形にして返す(前後の案内文・スペース・改行を除く)。

        共有・コピーで前後に文字が付いたまま送られると、余分な文字ごと受け取りコードに
        なって保留・エラーになっていた。受け取り・取り置き・記録のすべてで同じ整えた
        リンクを使うよう、一度だけ整えて覚える。"""
        if getattr(self, "_clean_link_cache", None) is None:
            raw = self.link.value if self.link else ""
            self._clean_link_cache = payments.clean_link(self.method, raw)
        return self._clean_link_cache

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        await self.checkout(interaction)

    async def checkout(self, interaction: discord.Interaction):
        """在庫を確かめ直して、支払いからお渡しまで(interaction は defer 済み)。"""
        _open_dm_early(interaction.user)
        qty = self.qty
        machine, product, err = _current_product(self.machine_id, self.product["product_id"])
        # 個数を決めてからリンクを貼るまでのあいだに売り切れることがある
        err = err or _short_stock(product, qty)
        if err:
            return await interaction.followup.send(err, ephemeral=True)

        total, _, _ = product_total(product, qty)
        if total <= 0:
            # 価格を後から変えられても総額で判断する
            return await self._hand_over(interaction, machine, product, qty, 0, payments.FREE)
        await self._pay_by_link(interaction, machine, product, qty, total)

    # ---- 在庫を渡す(支払い済み / 0円商品で共通) ----

    async def _hand_over(self, interaction, machine, product, qty, paid, method,
                         order_id: str = None) -> bool:
        """在庫を取ってお客さんに渡し、画面に完了を返す。記録はその後ろで。

        お客さんが待っているのは「DMが届く」と「画面に完了が出る」の2つだけ。
        売上・ロール・販売ログはお客さんには見えないので、完了を返してから
        まとめて(同時に)流す。前は4〜5回の往復を順に待たせてから完了を出していた。
        order_id は支払い画面が受け取った注文の番号(0円のお渡しには無い)。
        戻り値は、商品がお客さんの手元に届いたか。
        """
        delivered = await take_stock_async(product, qty)
        if delivered is None:
            # 支払い済みならここは事故。売上だけ立って何も渡していない状態なので、
            # お客さんへの案内とは別に、必ず記録と管理者通知を残す。
            if paid > 0:
                await record_shop_sale_async(self.machine_id, machine, product, qty, paid,
                                             interaction.user.id, method, order_id=order_id)
                await asyncio.gather(
                    send_trouble_log(
                        self.bot, machine, interaction.user,
                        title="お渡しできませんでした（支払い済み）",
                        detail=("支払いは受け取れましたが、在庫が足りず商品を渡せませんでした。\n"
                                "在庫を追加して手渡しするか、返金してください。"),
                        paid=paid, method=method, product_name=product.get("name"), qty=qty,
                        order_id=order_id),
                    _mark_screen_delivery(
                        order_id, False, "在庫不足でお渡しできませんでした（手渡しか返金が必要です）"))
                await interaction.followup.send(
                    embed=support.trouble_embed(
                        support.NEEDS_SUPPORT, "在庫が不足していてお渡しできませんでした",
                        support.PAID_AND_STUCK, amount=paid, order_id=order_id,
                        summary=f"{product.get('name')} ×{qty}"),
                    ephemeral=True)
                return False
            await interaction.followup.send("在庫が不足しています。もう一度お試しください。", ephemeral=True)
            return False

        # 複数個渡す場合は商品(レコード)ごとに空行で区切る
        stock_text = "\n\n".join(delivered)
        # DMで渡す。一時的な失敗はやり直し、Embedが弾かれても在庫だけは送る。
        # 本当にDMを送れないときだけ dm_forbidden が立つ(そのときだけ画面に出す)。
        dm_ok, dm_forbidden = await _deliver_purchase_dm(
            interaction.user, stock_text,
            purchase_dm_embed(product["name"], qty, paid, method, order_id=order_id))

        # 先にお客さんへ完了を返す。ここから後ろはお客さんには見えない。
        # 商品が手元に届いた時点で、注文の「渡した」印を立てる(渡す前に落ちた
        # 注文と見分けるため。印が無い注文は入金突合が渡し直せる)。
        number = order_number_line(order_id)
        # 渡した中身を注文にも残し、「記録はまだ」の印(logged=False)を立てる。
        # ここから下の記録(売上・販売ログ)の前に Bot が落ちても、見回りが同じ内容で
        # 記録を流し直せる(在庫が減ってお金も入っているのにログが無い、を作らない)。
        marks = {"payload": handed_payload(self.machine_id, product, qty, paid, method, delivered,
                                           role_id=machine.get("purchase_role_id")),
                 "logged": False}
        if dm_ok:
            # DMで届いている。画面への返事と印は同時に。
            await asyncio.gather(
                _reply(interaction, f"「{product['name']}」をお渡ししました。DMをご確認ください。{number}"),
                _mark_screen_delivery(order_id, True, **marks))
            handed = True
        else:
            # DMに送れなかった。この画面に出せたときだけ「渡した」になる。本当にDM拒否
            # (dm_forbidden)なら許可を促し、一時的な失敗なら時間をおいて届く場合がある旨を出す。
            # どちらでも、生の在庫は『X垢 形式確認』に貼ると項目ごとに分かれて読めると案内する
            # (ユーザーID・パスワード・2段階認証キー等がひと目で分かる)。
            reason = ("DMの受け取りを許可してください" if dm_forbidden
                      else "一時的に送れませんでした。時間をおくと届く場合があります")
            handed = await _reply(interaction, **stock_payload(
                stock_text,
                prefix=f"「{product['name']}」をお渡ししましたが、DMを送信できませんでした"
                       f"（{reason}）。{number}\n"
                       "この内容を『X垢 形式確認』パネルに貼ると、ユーザーID・パスワード・"
                       "2段階認証キーなど項目ごとに分かれて表示できます。\n内容:\n"))
            if handed:
                await _mark_screen_delivery(order_id, True, **marks)
            else:
                # DMも画面も送れなかった。在庫はもう取ってあり、中身は非公開ログに
                # 載るので、人に手渡ししてもらう。黙って終えると「売上だけ立って
                # 届いていない」が誰にも見えない。
                await asyncio.gather(
                    send_trouble_log(
                        self.bot, machine, interaction.user,
                        title="お渡しできませんでした（DMも画面も送れず）",
                        detail=("支払いは受け取り、在庫も取り出しましたが、DMにも購入画面にも"
                                "送れませんでした。\n中身は非公開販売ログに載っています。"
                                "手渡ししてください。"),
                        paid=paid, method=method, product_name=product.get("name"), qty=qty,
                        order_id=order_id),
                    _mark_screen_delivery(
                        order_id, False, "DMも画面も送れず、お渡しできていません（手渡しが必要です）",
                        **marks))

        # 売上・購入ロール(実際に支払いがあった有料購入のみ / 0円は付与しない)・
        # 販売ログを同時に。売上は在庫が出た時点で立てる(届かなかった分も、
        # 非公開ログの中身で手渡しする前提で売上に数える)。
        await after_delivery(self.bot, self.machine_id, machine, product, product["name"],
                             qty, paid, interaction.user, method, stock_text,
                             guild=interaction.guild, role_id=machine.get("purchase_role_id"),
                             order_id=order_id)
        await _mark_logged(order_id)
        return handed

    # ---- リンク方式(PayPay / Kyash): その場で受け取って即お渡し ----

    async def _pay_by_link(self, interaction, machine, product, qty, total):
        """支払いの受け取りからお渡しまで。試行の記録を必ず開いて必ず閉じる。

        出口がいくつもあるので、記録の締めは finally に置く。1つ書き漏らすと
        そこだけ「誰のものか分からない入金」に戻ってしまう。
        """
        attempt = await payment_attempts.record_async(
            "shop", interaction.user.id, amount=int(total), method=self.method,
            link=self._clean_link(), summary=f"{product.get('name')} ×{qty}個",
            guild_id=interaction.guild.id if interaction.guild else None,
            channel_id=interaction.channel.id if interaction.channel else None,
            # 入金だけ確認できたときに、この内容でそのまま渡し直せるようにする。
            # 在庫はまだ取っていないので released を立てておく(お渡し時に取る)。
            payload={
                "machine_id": self.machine_id,
                "product_id": product["product_id"],
                "product_name": product["name"],
                "qty": qty,
                "records": [],
                "released": True,
                "role_id": machine.get("purchase_role_id"),
            })
        hold = None
        try:
            # 同じリンクを見張り(または別の画面)が持っていないか先に確かめる。
            # ここを通さずに受け取ると、入金1回で商品を2回渡すことになる。
            hold = await payments.hold_link_for(
                interaction, "shop", self._clean_link(), attempt)
            if hold is None:
                return
            await self._run_link_payment(interaction, machine, product, qty, total, attempt)
        finally:
            await payment_attempts.finish_async(attempt)
            await link_orders.release_link(hold)

    async def _run_link_payment(self, interaction, machine, product, qty, total, attempt):
        passcode = (self.link_pw.value.strip() or None) if self.link_pw else None

        async def notify_pending(deadline: float):
            await notify_payment_pending(
                # 締め切りは見張りが諦める時刻。支払い画面が保留を待つ数分を
                # 見せると、過ぎた時点でもう駄目だと思わせてしまう。
                interaction, time.time() + WATCH_MINUTES * 60, amount=total,
                title="⏳ 商品のお支払いが保留中です",
                detail=f"承認され次第、「{product['name']}」×{qty}個を自動でDMにお渡しします。",
                footer="承認が遅れても、確認でき次第そのまま自動でお渡しします",
                ephemeral_hint="DMを確認して、「承認する」を押してください。承認され次第、商品をDMでお渡しします。",
                app_name=payments.method_label(self.method),
            )

        state = {}
        try:
            paid = await payments.receive_link_payment(
                self.method, self._clean_link(), passcode=passcode,
                min_amount=total, on_pending=notify_pending, client=self.bot, state=state,
                buyer=interaction.user, kind="自販機",
            )
        except payments.PaymentNotRegistered as e:
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await interaction.followup.send(str(e), ephemeral=True)
        except payments.PaymentError as e:
            # 支払いが決着しなかった。リンクがまだ生きている(保留・承認待ち・
            # 通信不良)なら注文を捨てずに見張りへ渡す。ここで捨てると、あとから
            # 承認されたお金だけがこちらに入って商品が渡らない事故になる。
            if getattr(e, "watchable", False) and await self._watch_pending(
                    interaction, machine, product, qty, total, e):
                await payment_attempts.resolve_async(attempt, payment_attempts.WATCHING, str(e))
                return
            if getattr(e, "accepted", False):
                # 受け取りは投げてある(=あとから入金しうる)のに、見張りにも
                # 載せられなかった。ここが最後の砦。やり直しは促さない(二重払い)。
                await send_trouble_log(
                    self.bot, machine, interaction.user,
                    title="受け取り済みかもしれない支払いを引き継げませんでした",
                    detail=("受け取りのリクエストは送信済みですが、見張りに載せられませんでした。\n"
                            f"{getattr(e, 'watch_note', '') or str(e)}\n"
                            "入金されていれば、手動でお渡しするか返金してください。"),
                    paid=total, method=self.method,
                    product_name=product.get("name"), qty=qty)
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.DROPPED,
                    f"受け取り送信済みだが見張りに載せられず: {getattr(e, 'watch_note', '') or e}")
                return await interaction.followup.send(
                    str(e) if isinstance(e, payments.PaymentUnsure) else
                    ("受け取りのリクエストは送信済みですが、処理を完了できませんでした。\n"
                     "**お代をいただいている可能性があります。もう一度支払わないでください。**\n"
                     "こちらで確認して対応します。\n" + support.contact_line()),
                    ephemeral=True)
            if isinstance(e, payments.PaymentAuthError):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
                return await interaction.followup.send(str(e), ephemeral=True)
            if isinstance(e, payments.PaymentPending):
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.REJECTED, "承認されませんでした")
                return await interaction.followup.send(
                    "支払いがまだ承認されていません。PayPayアプリで承認してから、もう一度お試しください。",
                    ephemeral=True)
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            # 理由はそのまま出す(リンク違い・金額不足など、本人が直せるものが
            # 多い)。ただしお代は動いていないので、そう書いて不安を残さない。
            return await interaction.followup.send(
                f"支払いを確認できませんでした。\n```{e}```\n"
                "**お代はいただいていません。** もう一度お試しいただくか、\n"
                + support.contact_line(), ephemeral=True)

        # このリンクのお金はここで受け取った。決着済みの注文として先に書き、
        # その番号をこの購入の注文番号にする(お客さんへの案内・販売ログ・売上で
        # 同じ番号を使う)。同じリンクを持っている見張りがあれば一緒に畳む
        # (畳まないと、見張りが同じ入金でもう一度商品を渡す)。
        #
        # 前はお渡しの後に書いていたので、保留を挟んで見張りから渡した注文にだけ
        # 番号が付き、その場で受け取った注文の販売ログには番号が無かった。
        #
        # 記録は「受け取った・お渡し中」として書く(delivered=False)。渡し終えた
        # 時点で _hand_over が印を立てる。先に「お渡しまで完了」と書いてしまうと、
        # 渡す前に落ちた注文が入金突合から「渡し済み」に見えて、受け取ったお金
        # だけが残る。own_record は、期限切れになった前の注文(別の商品・別の人の
        # こともある)の番号を使い回さず、この購入の番号を必ず新しく振るため。
        order_id = None
        try:
            settled = await link_orders.settle_on_screen(
                "shop", interaction.user.id, self._clean_link(), paid=paid,
                method=self.method, summary=f"{product.get('name')} ×{qty}個",
                guild_id=interaction.guild.id if interaction.guild else None,
                channel_id=interaction.channel.id if interaction.channel else None,
                delivered=False, own_record=True)
            order_id = (settled.get("record") or {}).get("id")
            for closed in settled.get("closed") or []:
                log.info("同じリンクの見張りを畳みました: %s", closed.get("id"))
                # 畳んだ注文が在庫を取り置いたままなら、ここで戻す。戻さないと、
                # この購入で在庫をもう一度取るので、取り置いた分だけ在庫が消える
                # (販売ログは1回分しか流れないのに、在庫は2回分減る)。
                await release_closed_order(self.bot, closed)
        except Exception as e:
            # 番号が無くてもお渡しは止めない(お代は受け取っている)。
            log.warning("shop の受け取り記録に失敗: %s", e)

        # 在庫の払い出し(二重購入対策で _hand_over 側でもう一度在庫を確認する)
        try:
            handed = await self._hand_over(interaction, machine, product, qty, paid, self.method,
                                           order_id=order_id)
        except Exception as e:
            # お代は受け取ったのに、お渡しの途中で落ちた(在庫ファイルが書けない等)。
            # 黙って落とすと、お客さんは画面が固まったまま、管理者には何も届かない。
            # 試行は dropped に戻す(渡せていなければ、入金突合が同じ内容で渡し直す。
            # 渡し終えた後なら注文の印が立っているので、渡し直しはしない)。
            log.exception("お渡しの途中で失敗 (%s)", order_id or product.get("name"))
            await payment_attempts.resolve_async(
                attempt, payment_attempts.DROPPED,
                f"お渡しの途中で失敗: {type(e).__name__}: {str(e)[:150]}"
                + (f" / 注文 {order_id}" if order_id else ""))
            await send_trouble_log(
                self.bot, machine, interaction.user,
                title="お渡しの途中でエラーが起きました（支払い済み）",
                detail=(f"```{type(e).__name__}: {str(e)[:300]}```\n"
                        "渡せていなければ、入金突合（数分おき）が同じ内容で自動で渡し直します。"
                        "手で渡す前に注文の状態を確認してください。"),
                paid=paid, method=self.method, product_name=product.get("name"), qty=qty,
                order_id=order_id)
            try:
                await interaction.followup.send(
                    embed=support.trouble_embed(
                        support.NEEDS_SUPPORT, "処理を完了できませんでした",
                        support.PAID_AND_STUCK, amount=paid, order_id=order_id,
                        summary=f"{product.get('name')} ×{qty}"),
                    ephemeral=True)
            except discord.HTTPException:
                pass
            return
        await payment_attempts.resolve_async(
            attempt, payment_attempts.DELIVERED,
            f"{paid:,}円" + (f" / 注文 {order_id}" if order_id else "")
            + ("" if handed else " / 渡せていません（要対応）"))
        # 買い直しで置き去りになった見張りを畳む(渡し終わったものを
        # 「保留中」に並べ続けない)。受け取り送信済みの注文には触らない。
        try:
            for closed in await link_orders.cancel_superseded(
                    interaction.user.id, "shop", int(total), keep_id=order_id):
                log.info("shop order superseded: %s", closed.get("id"))
                # 取り消した見張りの取り置きを戻す(見張りに載せた時点で在庫は
                # 取ってある。畳むだけでは、その分が減ったまま戻らない)。
                await release_closed_order(self.bot, closed)
        except Exception as e:
            log.warning("shop order superseded cleanup failed: %s", e)

    async def _watch_pending(self, interaction, machine, product, qty, total, error) -> bool:
        """決着しなかった支払いを見張りに引き継ぐ。引き継げたら True。

        承認が遅れただけの注文をここで捨てないためのもの。LTCと同じように在庫を
        取り置いてから登録し、承認され次第そのままDMでお渡しする。
        """
        if self.method != payments.PAYPAY:
            error.watch_note = "PayPay以外は後追いの見張りに対応していません。"
            return False
        accepted = bool(getattr(error, "accepted", False))
        reserved = await take_stock_async(product, qty)
        if reserved is None:
            # 在庫が無いなら見張っても渡せない。理由だけ呼び出し側へ渡して、
            # 記録と案内はそちらに任せる(同じ事故で通知が二重に飛ばないように)。
            error.watch_note = "在庫が無いため取り置きできませんでした。"
            return False

        payload = {
            "machine_id": self.machine_id,
            "product_id": product["product_id"],
            "product_name": product["name"],
            "qty": qty,
            "records": reserved,
            "role_id": machine.get("purchase_role_id"),
        }
        try:
            order = await link_orders.create_order(
                "shop", interaction.user.id, self._clean_link(),
                amount_jpy=int(total), payload=payload, method=self.method,
                minutes=WATCH_MINUTES,
                passcode=(self.link_pw.value.strip() or None) if self.link_pw else None,
                accepted=accepted, summary=f"{product['name']} ×{qty}個",
                guild_id=interaction.guild.id if interaction.guild else None,
                channel_id=interaction.channel.id if interaction.channel else None,
            )
        except Exception as e:
            await return_stock_async(product, reserved)   # 取り置きを戻す
            log.warning("link watch register failed: %s", e)
            error.watch_note = f"見張りへの登録に失敗しました: {str(e)[:150]}"
            return False
        if not order:
            await return_stock_async(product, reserved)
            error.watch_note = "見張りへの登録に失敗しました。"
            return False
        if order.get("reused"):
            # 同じリンクを既に見張っていた(この注文の取り置きは不要なので戻す)
            await return_stock_async(product, reserved)

        # DMはもう送らない。保留の案内は最初の1通で出し切っていて、ここで
        # 送るのは同じことの言い直しにしかならない。投げ直しは裏で続くので、
        # 次にDMするのは商品をお渡しするときだけにする。
        try:
            await interaction.followup.send(
                "⏳ 承認をお待ちしています。**このまま閉じて大丈夫です。**\n"
                "承認が確認でき次第、自動でDMにお渡しします。\n"
                "支払い直す必要はありません。\n"
                f"注文番号: `{order['id']}`", ephemeral=True)
        except discord.HTTPException:
            pass
        if not order.get("reused"):
            # 取り置き(保留)は裏で処理する。承認され次第そのまま自動でお渡しして
            # 販売ログを流すので、承認待ちの通知はDiscordのログには出さない(ノイズに
            # なるため)。追跡用に内部ログ(標準出力)だけ残す。
            log.info("取り置き(保留)開始: 注文 %s %s ×%s %s %s円",
                     order.get("id"), product["name"], qty,
                     payments.method_label(self.method), int(total))
        return True

class ProductBuySelect(ui.Select):
    def __init__(self, machine_id: str, products: list, bot: commands.Bot):
        self.machine_id = machine_id
        self.bot = bot
        options = []
        for p in products:
            desc = f"{int(p['price']):,}円"
            if bulk_text(p):
                desc += "・まとめ買い値下げあり"
            try:
                options.append(discord.SelectOption(label=p["name"][:100], value=p["product_id"],
                                                    description=desc[:100], emoji=p.get("emoji") or None))
            except Exception:
                options.append(discord.SelectOption(label=p["name"][:100], value=p["product_id"], description=desc[:100]))
        if not options:
            options = [discord.SelectOption(label="商品がありません", value="none")]
        super().__init__(placeholder="購入する商品を選択", options=options)

    async def callback(self, interaction: discord.Interaction):
        if self.values[0] == "none":
            return await interaction.response.send_message("商品がありません。", ephemeral=True)
        data = load_vending()
        machine = data.get(self.machine_id, {})
        product = next((p for p in machine.get("products", []) if p["product_id"] == self.values[0]), None)
        if not product:
            return await interaction.response.send_message("商品が見つかりません。", ephemeral=True)

        # 在庫が切れている商品は、ここで止める。個数を入れて支払い方法まで
        # 選ばせてから「在庫が足りません」では、お客さんに無駄な操作をさせる
        # ことになる(お金を払う直前まで進んでしまう)。
        if not product.get("infinite") and stock_count(product) <= 0:
            return await interaction.response.send_message(
                "現在在庫がありません。", ephemeral=True)

        # 商品 → 購入数 → 支払い方法 → リンク の順。金額は購入数が決まってから出す。
        await interaction.response.send_modal(QuantityModal(self.machine_id, product, self.bot))


# ---------- X垢の形式確認(Discord のパネルと Telegram の /format で共通) ----------

# 形式確認で読むファイルの上限。届く在庫のファイルは小さい。これより大きいものは読まない
FORMAT_MAX_FILE_BYTES = 2 * 1024 * 1024


def decode_format_file(data: bytes):
    """形式確認に付けられたファイルの中身を文字にする。テキストでなければ None。"""
    if b"\x00" in data[:4096]:
        return None
    return data.decode("utf-8-sig", errors="replace")


def format_records(raw: str):
    """貼られた文字・ファイル1つ分を、1垢ずつのレコードに分ける → (レコード, 見出し)。"""
    # 届いたメッセージを丸ごと貼られたら(在庫は ``` で囲んで届く)、囲みの中だけを読む。
    # 囲みや、その外の案内文を1件として数えないように。
    texts = code_block_texts(raw) or [raw or ""]
    records = [r for t in texts for r in parse_stock_records(t)]
    # 先頭が「Username----Password----…」のような形式の説明(見出し)なら、それに沿って読む
    header = None
    if records:
        first, _, rest = records[0].partition("\n")
        header = x_check.header_labels(first)
        if header:
            records = ([rest] if rest.strip() else []) + records[1:]
    return records, header


def format_breakdown(*sources: str) -> str:
    """貼られた文字・ファイルの中身(いくつでも)を、1垢ずつ項目名つきにする。

    1つずつ別々に分ける(1行1垢のファイルと貼り付けを、空行区切りの1つとして
    まとめて読まないように)。形式の説明だけを貼り、ファイルを付けたときは、
    その説明の並びでファイルの中を読む。
    """
    parsed = [format_records(raw) for raw in sources if (raw or "").strip()]
    default = next((h for recs, h in parsed if h and not recs), None)
    items = [(rec, header or default) for recs, header in parsed for rec in recs]
    if not items:
        return ("形式の説明として読み取りました:\n" + " / ".join(default)) if default else ""
    blocks = []
    for n, (rec, header) in enumerate(items, 1):
        fields = x_check.label_fields(rec, header=header)
        body = ("\n".join(f"{label}: {value}" for label, value in fields)
                if fields else "（区切りを読み取れません）")
        blocks.append((f"【{n}件目】\n" if len(items) > 1 else "") + body)
    return "\n\n".join(blocks)


class XFormatModal(ui.Modal, title="形式確認"):
    """購入したアカウント情報を貼るか、届いたファイルを付けてもらい、項目ごとに分けて
    本人のDMへ送る。まとめ買いで在庫がファイル(stock.txt)で届いた人のために、ファイルも
    付けられる(どちらも任意。両方でもよい)。

    モーダルのファイル添付(Label の中の File Upload)は、使っている discord.py 2.3.2 には
    まだ無い。そこで、出すモーダルの中身(to_components)と、送信された値の読み取り
    (_refresh)だけを Discord の形のままここに書く。discord.py を上げたら
    ui.Label / ui.FileUpload に置き換える。
    """

    TEXT_ID = "xformat_text"
    FILE_ID = "xformat_file"
    MAX_FILES = 10

    def __init__(self, with_file: bool = True):
        super().__init__()
        self.with_file = with_file
        self.raw_text = ""
        self.files = []                 # 付けられたファイル(discord.Attachment)

    def to_components(self):
        if not self.with_file:
            # これまでの形(貼り付けだけ)。ファイル添付つきを Discord に断られたときの予備
            return [{"type": 1, "components": [
                {"type": 4, "custom_id": self.TEXT_ID, "label": "アカウント情報", "style": 2,
                 "required": True, "max_length": 4000,
                 "placeholder": "購入時に送られた内容をそのまま貼り付け"}]}]
        # type 18 = Label(見出しと説明)、4 = 文字の入力、19 = ファイルの添付
        return [
            {"type": 18, "label": "アカウント情報（貼り付け）",
             "description": "購入時に届いた内容をそのまま貼り付け。ファイルで届いた場合は下で付けてください",
             "component": {"type": 4, "custom_id": self.TEXT_ID, "style": 2, "required": False,
                           "max_length": 4000, "placeholder": "購入時に送られた内容をそのまま貼り付け"}},
            {"type": 18, "label": "ファイル（まとめ買いで届いたもの）",
             "description": "stock.txt など、届いたテキストファイルを付けてください（複数可）",
             "component": {"type": 19, "custom_id": self.FILE_ID, "required": False,
                           "min_values": 0, "max_values": self.MAX_FILES}},
        ]

    def _refresh(self, interaction: discord.Interaction, components) -> None:
        # 送信された値は Label の中に入って届く: {"type": 18, "component": {"custom_id": …}}。
        # ファイルは ID だけが来て、中身の情報は resolved.attachments にある。
        resolved = ((interaction.data or {}).get("resolved") or {}).get("attachments") or {}
        for comp in components:
            if comp.get("type") == 1:
                self._refresh(interaction, comp.get("components") or [])
                continue
            inner = comp.get("component") or comp
            if inner.get("custom_id") == self.TEXT_ID:
                self.raw_text = inner.get("value") or ""
            elif inner.get("custom_id") == self.FILE_ID:
                self.files = [discord.Attachment(data={**resolved[i], "id": i}, state=interaction._state)
                              for i in inner.get("values") or [] if i in resolved]

    @staticmethod
    def _payload(text: str, head: str) -> dict:
        """短ければコードブロック、長ければ x_format.txt を添付(届いた stock.txt と紛れないよう別名)。"""
        body = f"{head}```\n{text}\n```"
        if len(body) <= MESSAGE_LIMIT:
            return {"content": body}
        return {"content": f"{head}長いので、結果を添付の x_format.txt にまとめました。",
                "file": discord.File(io.BytesIO(text.encode("utf-8")), filename="x_format.txt")}

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        if not self.raw_text.strip() and not self.files:
            return await interaction.followup.send(
                "アカウント情報を貼るか、届いたファイルを付けてください。", ephemeral=True)
        sources, notes = [self.raw_text], []
        for att in self.files:
            if att.size > FORMAT_MAX_FILE_BYTES:
                notes.append(f"⚠️「{att.filename}」は大きすぎるため読みませんでした。")
                continue
            try:
                content = decode_format_file(await att.read())
            except discord.HTTPException:
                notes.append(f"⚠️「{att.filename}」を読み込めませんでした。")
                continue
            if content is None:
                notes.append(f"⚠️「{att.filename}」はテキストファイルではないため読みませんでした。")
                continue
            sources.append(content)
        text = format_breakdown(*sources)
        note = "".join(f"{n}\n" for n in notes)
        if not text:
            return await interaction.followup.send(
                note + "読み取れませんでした。購入時の内容をそのまま貼るか、届いたファイルを付けてください。",
                ephemeral=True)
        count = text.count("件目】")
        head = "X垢 形式確認" + (f"（{count}件）" if count else "") + "\n" + note
        try:
            await interaction.user.send(**self._payload(text, head))
            await interaction.followup.send("DMに送りました。", ephemeral=True)
        except discord.Forbidden:
            # DMを閉じている → この場に本人だけに出す(添付は作り直す。1度使った File は再送できない)。
            await interaction.followup.send(
                **self._payload(text, "DMを送れないため、ここに表示します。\n" + head), ephemeral=True)


class XFormatView(ui.View):
    """常設のX垢 形式確認パネル。custom_idで再起動後も動作。"""

    def __init__(self):
        super().__init__(timeout=None)
        b = ui.Button(label="形式を確認する", style=discord.ButtonStyle.primary, custom_id="xformat_check")
        b.callback = self._open
        self.add_item(b)

    @panels.guard
    async def _open(self, interaction: discord.Interaction):
        try:
            await interaction.response.send_modal(XFormatModal())
        except discord.HTTPException as e:
            # ファイル添付つきのフォームを Discord に断られたら、貼り付けだけのフォームを出す
            # (ボタンを押しても何も出ない、にしない)
            log.warning("形式確認: ファイル添付つきのフォームを出せませんでした: %s", e)
            await interaction.response.send_modal(XFormatModal(with_file=False))


def xformat_embed() -> discord.Embed:
    return discord.Embed(title="X垢 形式確認",
                         description="購入したアカウント情報を貼ると、形式がわかるように項目ごとに分けてDMに送信します。\n"
                                     "まとめ買いでファイルが届いた場合は、そのファイルを付けて確認できます。",
                         color=discord.Color.blurple())


class ShopPanelView(ui.View):
    """常設の自販機パネル(購入/在庫確認ボタン)。custom_idで再起動後も動作。"""
    def __init__(self, machine_id: str, bot: commands.Bot):
        super().__init__(timeout=None)
        self.machine_id = machine_id
        self.bot = bot
        buy = ui.Button(label="購入する", style=discord.ButtonStyle.success, custom_id=f"shop_buy_{machine_id}")
        buy.callback = self._buy
        self.add_item(buy)
        stock = ui.Button(label="在庫確認", style=discord.ButtonStyle.secondary, custom_id=f"shop_stock_{machine_id}")
        stock.callback = self._stock
        self.add_item(stock)

    @panels.guard
    async def _buy(self, interaction: discord.Interaction):
        data = load_vending()
        machine = data.get(self.machine_id)
        if not machine:
            return await interaction.response.send_message("自販機が見つかりません。", ephemeral=True)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("現在販売中の商品はありません。", ephemeral=True)
        v = ui.View(timeout=180)
        v.add_item(ProductBuySelect(self.machine_id, products, self.bot))
        await interaction.response.send_message("購入する商品を選択してください。", view=v, ephemeral=True)

    @panels.guard
    async def _stock(self, interaction: discord.Interaction):
        data = load_vending()
        machine = data.get(self.machine_id)
        if not machine:
            return await interaction.response.send_message("自販機が見つかりません。", ephemeral=True)
        products = machine.get("products", [])
        # 色は上の自販機パネル(panel_embed)と揃える。
        e = discord.Embed(title="在庫情報", color=discord.Color.red())
        if not products:
            e.description = "商品が登録されていません。"
        else:
            for p in products:
                if p.get("infinite"):
                    value = "在庫: ∞"
                else:
                    # 在庫が無いときも「売り切れ」ではなく 0個 と出す。
                    # 数で並んでいるほうが、補充の要るものがひと目で分かる。
                    value = f"在庫: {shown_stock(p)}個"
                e.add_field(name=p["name"], value=value, inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)


def panel_embed(machine: dict) -> discord.Embed:
    panel = machine.get("panel", {})
    e = discord.Embed(
        title=panel.get("title") or machine.get("name", "自販機"),
        description=panel.get("description") or "購入したい商品を下のボタンから選んでください。",
        color=discord.Color.red(),
    )
    for p in machine.get("products", []):
        # パネルは常設メッセージで販売後も更新されないため、在庫数は載せない
        # (在庫は「在庫確認」ボタンから最新の値を確認する)
        price = f"**金額: {int(p['price']):,}円**"
        if bulk_text(p):
            price += f"\n{bulk_text(p)}"
        desc = (p.get("description") or "").strip()
        e.add_field(name=f"{p.get('emoji') or ''} {p['name']}".strip(),
                    value=f"{desc}\n{price}" if desc else price, inline=False)
    if panel.get("image"):
        e.set_image(url=panel["image"])
    return e


async def refresh_panel(bot, machine_id: str, machine: dict, guild=None) -> str:
    """置いてある自販機パネルを、その場で最新の内容に書き換える。

    商品・価格・説明を変えてもパネルは常設メッセージのままなので、放っておくと
    古い内容が並び続ける。置き直すと古いパネルが上に残って、お客さんが古いほうを
    押してしまうので、いま置いてあるメッセージだけを書き換える。
    置いていないときは何もしない(設置は /shop panel から)。

    戻り値 "updated" / "missing" / "failed"
    """
    return await panels.refresh(bot, f"shop:{machine_id}", panel_embed(machine),
                                ShopPanelView(machine_id, bot), guild=guild)


async def panel_note(bot, machine_id: str, machine: dict, guild=None) -> str:
    """パネルを書き換えて、返信に足す一文を返す。

    商品をいじったあとに自分で更新コマンドを叩かせると、直し忘れたパネルが
    そのまま売り場に残る。いじったその場で書き換えて、結果だけ伝える。
    """
    return {
        "updated": "\nパネルも最新の内容に更新しました。",
        "missing": "\n（パネルはまだ設置されていません。`/shop panel` で設置できます）",
        "failed": "\n（パネルを更新できませんでした。`/shop redisplay` をお試しください）",
    }.get(await refresh_panel(bot, machine_id, machine, guild), "")


# 廃止した「在庫追加希望」の受付先の設定。ボタンを外し終えたら消す。
_OLD_REQUEST_KEY = "restock_request_channel_id"


async def drop_request_buttons(bot) -> int:
    """廃止した「在庫追加希望」ボタンが残っているパネルを書き換える(起動後に1回)。

    置いてあるパネルは常設メッセージなので、機能を消しても書き換えるまでは
    ボタンが残り、押すと「インタラクションに失敗しました」になる。受付先を
    設定していた自販機(=ボタンが出ていた)のパネルだけ書き換え、使わなくなった
    設定も消す。書き換えに失敗したときは設定を残し、次の起動でやり直す。

    戻り値 書き換えたパネルの数。
    """
    fixed = 0
    for mid, machine in load_vending().items():
        if _OLD_REQUEST_KEY not in machine:
            continue
        if machine.get(_OLD_REQUEST_KEY):
            result = await refresh_panel(bot, mid, machine)
            if result == "failed":
                log.warning("自販機 %s: 在庫追加希望ボタンの残ったパネルを書き換えられませんでした"
                            "(次の起動でやり直します)", mid)
                continue
            fixed += result == "updated"
        # 書き換えを待つあいだに設定が変わっていてもよいように、読み直してから消す。
        data = load_vending()
        if _OLD_REQUEST_KEY in data.get(mid, {}):
            del data[mid][_OLD_REQUEST_KEY]
            save_vending(data)
    return fixed


# ---------- 補助View(商品選択) ----------

class ProductActionSelect(ui.Select):
    def __init__(self, products: list, placeholder: str, callback):
        options = [discord.SelectOption(label=p["name"][:100], value=p["product_id"],
                                        description=f"{int(p['price']):,}円 / 在庫{stock_count(p)}"[:100])
                   for p in products]
        super().__init__(placeholder=placeholder, options=options or [discord.SelectOption(label="なし", value="none")])
        self._cb = callback

    async def callback(self, interaction: discord.Interaction):
        await self._cb(interaction, self.values[0])


def select_view(products: list, placeholder: str, callback) -> ui.View:
    v = ui.View(timeout=180)
    v.add_item(ProductActionSelect(products, placeholder, callback))
    return v


def choice_view(choices: list, placeholder: str, callback) -> ui.View:
    """(表示, 値) の一覧から1つ選ばせる。選んだら callback(interaction, 値)。"""
    select = ui.Select(placeholder=placeholder,
                       options=[discord.SelectOption(label=str(label)[:100], value=str(value))
                                for label, value in choices])

    async def on_pick(interaction: discord.Interaction):
        await callback(interaction, select.values[0])

    select.callback = on_pick
    v = ui.View(timeout=180)
    v.add_item(select)
    return v


class TelegramPickSelect(ui.Select):
    """Telegramの自販機に出す商品を選ぶ複数選択。選んだ商品だけ telegram フラグを立てる。

    在庫は Discord と共有のまま。「どれを Telegram に並べるか」だけをここで決める。
    画面に出した商品だけを更新する(25件を超える分や、管理外の自販機の商品は触らない)。
    """

    def __init__(self, entries: list):
        # entries: [(machine_id, machine_name, product, enabled)]
        options = []
        for mid, mname, p, enabled in entries[:25]:
            desc = f"{mname} / {int(p.get('price') or 0):,}円"
            options.append(discord.SelectOption(
                label=str(p.get("name"))[:100],
                value=f"{mid}:{p['product_id']}"[:100],
                description=desc[:100], default=bool(enabled)))
        disabled = not options
        if not options:
            options = [discord.SelectOption(label="商品がありません", value="none")]
        super().__init__(
            placeholder="Telegramで売る商品を選ぶ（複数可・外すと出しません）",
            min_values=0, max_values=len(options), options=options, disabled=disabled)

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        shown = [o.value for o in self.options if o.value != "none"]
        chosen = set(self.values)
        data = load_vending()
        on_names = []
        for key in shown:
            mid, pid = key.split(":", 1)
            product = _find_product(data.get(mid) or {}, pid)
            if not product:
                continue
            product["telegram"] = key in chosen
            if key in chosen:
                on_names.append(str(product.get("name")))
        save_vending(data)
        if on_names:
            msg = ("Telegramの自販機を更新しました。\n出す商品: "
                   + "、".join(on_names[:40]) + ("…" if len(on_names) > 40 else ""))
        else:
            msg = "Telegramに出す商品を0件にしました（Telegramの一覧は空になります）。"
        await interaction.followup.send(msg, ephemeral=True)


def telegram_pick_view(entries: list) -> ui.View:
    v = ui.View(timeout=180)
    v.add_item(TelegramPickSelect(entries))
    return v


class TelegramIntroModal(ui.Modal, title="Telegramの説明文"):
    """Telegramの /start で出る案内文を編集する。文はそのまま表示される。"""

    def __init__(self, current: str):
        super().__init__()
        self.field = ui.TextInput(
            label="説明文（/start で出る案内）", style=discord.TextStyle.paragraph,
            required=True, max_length=3000, default=(current or "")[:3000])
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        import telegram_shop
        telegram_shop.set_intro(self.field.value)
        await interaction.response.send_message(
            "Telegramの説明文を更新しました。Telegramで /start か「更新」を押すと反映されます。",
            ephemeral=True)


# ---------- 在庫/商品編集モーダル ----------

class StockPasteModal(ui.Modal, title="在庫を追加"):
    def __init__(self, machine_id, product_id, infinite):
        super().__init__()
        self.machine_id = machine_id
        self.product_id = product_id
        self.infinite = infinite
        label = "在庫内容（無限）" if infinite else "在庫（1行1個 / 空行区切りで複数行商品）"
        self.field = ui.TextInput(label=label, style=discord.TextStyle.paragraph, required=True)
        self.add_item(self.field)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        data = load_vending()
        machine = data.get(self.machine_id)
        product = next((p for p in machine.get("products", []) if p["product_id"] == self.product_id), None) if machine else None
        if not product:
            return await interaction.followup.send("商品が見つかりません。", ephemeral=True)
        if self.infinite:
            product["infinite"] = True
            product["infinite_content"] = self.field.value.strip()
            save_vending(data)
            return await interaction.followup.send(f"「{product['name']}」を**無限在庫**に設定しました。", ephemeral=True)
        records = parse_stock_records(self.field.value)
        if not records:
            return await interaction.followup.send("在庫が入力されていません。", ephemeral=True)
        await append_stock_async(product, records)
        tg_note = await notify_restock(interaction.client, machine, product, len(records))
        await interaction.followup.send(f"「{product['name']}」に {len(records)}個 追加しました（在庫: {admin_stock_text(product)}）。{tg_note}", ephemeral=True)


def _append_stock(product: dict, records: list):
    os.makedirs(STOCK_DIR, exist_ok=True)
    path = product["stock_file"]
    with _stock_lock:
        existing = read_stock_records(path)
        write_stock_records(path, existing + list(records))


# 同じ在庫追加の通知が二重に出るのを防ぐための、直近に知らせた内容の控え。
# 確定ボタンの二度押しや、Discord が同じ操作を二重に届けたときに、@everyone 付きの
# お知らせが1回の追加で2回鳴いていた。同じ(自販機・商品・個数)を短い間に続けて
# 知らせようとしたら、2回目は送らない(在庫はもう追加済みなので、止めるのは通知だけ)。
_RESTOCK_NOTIFY_DEDUP_SECONDS = 15
_last_restock_notify: dict = {}


def _restock_notify_is_dup(machine, product, added) -> bool:
    """直近 _RESTOCK_NOTIFY_DEDUP_SECONDS 秒に同じ内容を知らせていたら True。"""
    key = (str((machine or {}).get("name") or ""),
           str((product or {}).get("product_id") or (product or {}).get("name") or ""),
           int(added or 0))
    now = time.monotonic()
    last = _last_restock_notify.get(key, 0.0)
    _last_restock_notify[key] = now
    # 控えが際限なく溜まらないように、古いものはたまに捨てる。
    if len(_last_restock_notify) > 200:
        for k, t in list(_last_restock_notify.items()):
            if now - t > 300:
                _last_restock_notify.pop(k, None)
    return (now - last) < _RESTOCK_NOTIFY_DEDUP_SECONDS


async def notify_restock(client, machine, product, added) -> str:
    """在庫追加の通知。Discord(送り先が設定されていれば)は @everyone を付けて、商品と数を
    1行で出す。Telegram に出している商品なら、Telegram の利用者全員にも知らせる。

    Telegram に知らせたときは、管理者への返信に足す一言を返す(無ければ空文字)。"""
    note = ""
    if _restock_notify_is_dup(machine, product, added):
        # 同じ追加の通知が直前に出ている。二重に鳴らさないためここで止める。
        log.info("在庫追加の通知が重複したため2回目を止めました: %s ×%s",
                 (product or {}).get("name"), added)
        return note
    try:
        import telegram_shop
        sent_to = telegram_shop.notify_restock(product, added)
        if sent_to:
            note = f"\nTelegramの{sent_to}人にもお知らせを送ります。"
    except Exception as e:
        log.warning("Telegram への在庫追加のお知らせに失敗: %s", e)
    ch_id = machine.get("restock_notify_channel_id")
    # オフにしてあるときは送らない(送り先の設定は残したまま)。
    if not ch_id or machine.get("restock_notify_enabled") is False:
        return note
    e = discord.Embed(title="在庫追加",
                      description=f"・{product.get('name', '商品')} **{added}個**",
                      color=discord.Color.red(), timestamp=discord.utils.utcnow())
    # Bot の既定のままだと @everyone が文字として出るだけで鳴らないことがあるので、明示する。
    await _send_log(client, ch_id, "在庫追加通知",
                    lambda: {"content": "@everyone", "embed": e,
                             "allowed_mentions": discord.AllowedMentions(everyone=True)})
    return note


# ---------- 在庫の貼り付け(チャンネルで受け取る) ----------
# モーダルは4,000字までしか入らず、長い在庫が入り切らなかった。かわりに、コマンドを
# 打ったチャンネルに貼ってもらい、確定を押すまで何通でも読む。長い貼り付けは Discord が
# .txt にして送ってくるので、添付もそのまま読む。読んだメッセージは消す。

# 貼り付けを受け付ける時間(秒)。
RESTOCK_WAIT_SECONDS = 600
# 受け付け中の (user_id, channel_id)。同じ人が同じ所で二重に始めない。
_restock_collecting = set()


class RestockCollectView(ui.View):
    """貼ってもらうあいだの「確定 / やめる」。押した結果を decision に入れる。

    confirm_label で確定ボタンの文言を変えられる(在庫追加は「追加を確定」、
    X垢チェックは「確認する」)。"""

    def __init__(self, user_id: int, confirm_label: str = "追加を確定"):
        super().__init__(timeout=RESTOCK_WAIT_SECONDS + 60)
        self.user_id = user_id
        self.decision = asyncio.get_running_loop().create_future()
        self.confirm.label = confirm_label

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        return interaction.user.id == self.user_id

    def _decide(self, value: bool):
        if not self.decision.done():
            self.decision.set_result(value)

    @ui.button(label="追加を確定", style=discord.ButtonStyle.success)
    async def confirm(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        self._decide(True)

    @ui.button(label="やめる", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.defer()
        self._decide(False)


async def collect_pasted_text(bot, interaction: discord.Interaction, prompt: str,
                              confirm_label: str = "確認する"):
    """このチャンネルに貼られた文字と .txt 添付を、確定を押すまで何通でも集めて1つの
    文字列にして返す。「やめる」なら None。何も貼られずに終わったら None(案内も出す)。

    在庫追加の collect_restock と同じ受け取り方(本人の発言と .txt を読み、読んだら消す)。
    進み具合は最初のエフェメラル応答を書き換えて見せる。戻ったあと、呼び出し側が同じ
    応答を続けて書き換えてよい(view は外してある)。
    """
    user, channel = interaction.user, interaction.channel
    key = (user.id, channel.id)
    if key in _restock_collecting:
        await interaction.response.send_message(
            "いま別の貼り付けを受け付け中です。先にそちらを確定するか、やめてください。",
            ephemeral=True)
        return None
    _restock_collecting.add(key)
    view = RestockCollectView(user.id, confirm_label=confirm_label)

    def status(n):
        return f"{prompt}\n\nここまで **{n}件**"

    await interaction.response.send_message(status(0), view=view, ephemeral=True)
    chunks, undeleted = [], 0
    deadline = time.monotonic() + RESTOCK_WAIT_SECONDS

    def mine(m):
        return m.author.id == user.id and m.channel.id == channel.id

    def count():
        return sum(len(parse_stock_records(t)) for t in chunks)

    confirmed = None
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            waiter = asyncio.ensure_future(bot.wait_for("message", check=mine))
            done, _ = await asyncio.wait({waiter, view.decision}, timeout=remaining,
                                         return_when=asyncio.FIRST_COMPLETED)
            if waiter in done:
                msg = waiter.result()
                texts = [msg.content] if (msg.content or "").strip() else []
                for a in msg.attachments:
                    if a.filename.lower().endswith(".txt"):
                        try:
                            texts.append((await a.read()).decode("utf-8", errors="replace"))
                        except Exception:
                            pass
                chunks.extend(t for t in texts if t.strip())
                try:
                    await msg.delete()
                except Exception:
                    undeleted += 1
                try:
                    await interaction.edit_original_response(content=status(count()), view=view)
                except Exception:
                    pass
            else:
                waiter.cancel()
            if view.decision.done():
                confirmed = view.decision.result()
                break
    finally:
        _restock_collecting.discard(key)
        view.stop()

    note = (f"\n⚠️ 貼られたメッセージ {undeleted}通を消せませんでした（権限不足）。手で消してください。"
            if undeleted else "")
    if confirmed is False:
        try:
            await interaction.edit_original_response(content="やめました。" + note, view=None)
        except Exception:
            pass
        return None
    combined = "\n\n".join(chunks).strip()
    if not combined:
        try:
            await interaction.edit_original_response(
                content="X垢が貼られませんでした。もう一度お試しください。" + note, view=None)
        except Exception:
            pass
        return None
    try:
        await interaction.edit_original_response(content="確認を始めます…" + note, view=None)
    except Exception:
        pass
    return combined


def _restock_prompt(n: int, infinite: bool) -> str:
    what = "在庫の中身" if infinite else "在庫"
    unit = "通" if infinite else "個"
    return (f"{what}を**このチャンネルに貼ってください**。何通に分けても、.txt の添付でも構いません"
            "（長い貼り付けは Discord が .txt にして送るので、そのままで大丈夫です）。\n"
            f"貼り終えたら「追加を確定」を押してください（{RESTOCK_WAIT_SECONDS // 60}分以内）。"
            f"貼ったメッセージはこちらで消します。\n\nここまで **{n}{unit}**")


async def collect_restock(bot, interaction: discord.Interaction, machine_id: str,
                          product_id: str, infinite: bool):
    """このチャンネルに貼られた在庫を、確定を押すまで何通でも受け取って足す。

    本人がこのチャンネルに送ったメッセージと .txt の添付を全部読む。確定を押さずに
    時間切れになったときは、貼られた分をそのまま足す(メッセージはもう消していて、
    捨てると貼り直しになる)。「やめる」なら足さない。
    """
    user, channel = interaction.user, interaction.channel
    key = (user.id, channel.id)
    if key in _restock_collecting:
        return await interaction.response.send_message(
            "いま別の在庫を受け付け中です。先にそちらを確定するか、やめてください。", ephemeral=True)
    _restock_collecting.add(key)
    view = RestockCollectView(user.id)
    await interaction.response.send_message(_restock_prompt(0, infinite), view=view, ephemeral=True)
    chunks, undeleted = [], 0
    deadline = time.monotonic() + RESTOCK_WAIT_SECONDS

    def mine(m):
        return m.author.id == user.id and m.channel.id == channel.id

    def count():
        return len(chunks) if infinite else sum(len(parse_stock_records(t)) for t in chunks)

    confirmed = None     # True=確定 / False=やめる / None=時間切れ
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            waiter = asyncio.ensure_future(bot.wait_for("message", check=mine))
            done, _ = await asyncio.wait({waiter, view.decision}, timeout=remaining,
                                         return_when=asyncio.FIRST_COMPLETED)
            if waiter in done:
                msg = waiter.result()
                texts = [msg.content] if (msg.content or "").strip() else []
                for a in msg.attachments:
                    if a.filename.lower().endswith(".txt"):
                        try:
                            texts.append((await a.read()).decode("utf-8", errors="replace"))
                        except Exception:
                            pass
                chunks.extend(t for t in texts if t.strip())
                try:
                    await msg.delete()
                except Exception:
                    undeleted += 1
                try:
                    await interaction.edit_original_response(
                        content=_restock_prompt(count(), infinite), view=view)
                except Exception:
                    pass
            else:
                waiter.cancel()
            if view.decision.done():
                confirmed = view.decision.result()
                break
    finally:
        _restock_collecting.discard(key)
        view.stop()

    note = (f"\n⚠️ 貼られたメッセージ {undeleted}通を消せませんでした（権限不足）。手で消してください。"
            if undeleted else "")

    async def finish(text: str):
        try:
            await interaction.edit_original_response(content=text + note, view=None)
        except Exception:
            pass

    if confirmed is False:
        return await finish("やめました。貼られた在庫は追加していません。")
    data = load_vending()
    machine = data.get(machine_id)
    product = _find_product(machine, product_id)
    if not product:
        return await finish("商品が見つかりません。")
    if infinite:
        content = "\n".join(t.strip() for t in chunks).strip()
        if not content:
            return await finish("在庫の中身が貼られませんでした。")
        product["infinite"] = True
        product["infinite_content"] = content
        save_vending(data)
        return await finish(f"「{product['name']}」を**無限在庫**に設定しました。")
    records = [r for t in chunks for r in parse_stock_records(t)]
    if not records:
        return await finish("在庫が貼られませんでした。")
    await append_stock_async(product, records)
    save_vending(data)
    tg_note = await notify_restock(bot, machine, product, len(records))
    when = "" if confirmed else "（時間切れのため、貼られた分で確定しました）"
    await finish(f"「{product['name']}」に {len(records)}個 追加しました"
                 f"（在庫: {admin_stock_text(product)}）。{when}{tg_note}")


class EditProductModal(ui.Modal, title="商品情報を変更"):
    def __init__(self, machine_id, product):
        super().__init__()
        self.machine_id = machine_id
        self.product_id = product["product_id"]
        self.name = ui.TextInput(label="商品名", default=product.get("name"), required=True)
        self.desc = ui.TextInput(label="説明", default=product.get("description", ""), style=discord.TextStyle.paragraph, required=False)
        self.price = ui.TextInput(label="価格(円)", default=str(product.get("price", 0)), required=True)
        self.emoji = ui.TextInput(label="絵文字（任意）", default=product.get("emoji") or "", required=False)
        for it in (self.name, self.desc, self.price, self.emoji):
            self.add_item(it)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            price = int(self.price.value.strip())
        except ValueError:
            return await interaction.followup.send("価格は整数で入力してください。", ephemeral=True)
        data = load_vending()
        machine = data.get(self.machine_id)
        product = next((p for p in machine.get("products", []) if p["product_id"] == self.product_id), None) if machine else None
        if not product:
            return await interaction.followup.send("商品が見つかりません。", ephemeral=True)
        product["name"] = self.name.value.strip()
        product["description"] = self.desc.value.strip()
        product["price"] = price
        product["emoji"] = self.emoji.value.strip() or None
        save_vending(data)
        # 名前・価格はパネルに出ている。直したらパネルもその場で合わせる。
        note = await panel_note(interaction.client, self.machine_id, machine,
                                interaction.guild)
        await interaction.followup.send(
            f"「{product['name']}」の情報を更新しました。{note}", ephemeral=True)


class BulkDiscountModal(ui.Modal, title="まとめ買い値下げ"):
    """「n個以上なら1個あたりx円引き」を1つ足す。同じ個数を入れ直すと置き換わる。"""

    def __init__(self, machine_id, product):
        super().__init__()
        self.machine_id = machine_id
        self.product_id = product["product_id"]
        unit = int(product.get("price") or 0)
        self.qty = ui.TextInput(label=f"個数（2〜{MAX_QTY}）", placeholder="10", required=True,
                                max_length=len(str(MAX_QTY)))
        self.off = ui.TextInput(label="1個あたりの値引き額(円)",
                                placeholder=f"例: 200（この商品は1個 {unit:,}円）"[:100],
                                required=True, max_length=9)
        self.add_item(self.qty)
        self.add_item(self.off)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            qty, off = int(self.qty.value.strip()), int(self.off.value.strip())
        except ValueError:
            return await interaction.followup.send("個数と値引き額は整数で入力してください。", ephemeral=True)
        if not 2 <= qty <= MAX_QTY:
            return await interaction.followup.send(
                f"個数は2〜{MAX_QTY}で入力してください（1回に買えるのは{MAX_QTY}個までです）。",
                ephemeral=True)
        data = load_vending()
        machine = data.get(self.machine_id)
        product = _find_product(machine, self.product_id)
        if not product:
            return await interaction.followup.send("商品が見つかりません。", ephemeral=True)
        unit = int(product.get("price") or 0)
        if not 1 <= off < unit:
            return await interaction.followup.send(
                f"値引き額は1円以上、1個の値段（{unit:,}円）未満で入力してください。", ephemeral=True)
        set_bulk_tier(product, qty, off)
        save_vending(data)
        # 値下げはパネルに出る。足したらパネルもその場で合わせる。
        note = await panel_note(interaction.client, self.machine_id, machine, interaction.guild)
        await interaction.followup.send(
            f"「{product['name']}」に まとめ買い値下げ **{qty}個以上 1個あたり {off:,}円引き**"
            f"（1個 {unit - off:,}円 / {qty}個で {(unit - off) * qty:,}円）を追加しました。{note}",
            ephemeral=True)


# ---------- 後追いのお渡し(LTCの入金確認後 / 保留リンクの承認後) ----------

def _find_product(machine: dict, product_id: str):
    return next((p for p in (machine or {}).get("products", []) if p["product_id"] == product_id), None)


async def _mark_order(invoice: dict, status: str, **fields):
    """注文の記録を更新する(保留リンクの見張り)。"""
    return await link_orders.mark_order(invoice["id"], status, **fields)


def _get_order(invoice: dict):
    return link_orders.get_order(invoice["id"])


async def offline_deliver(bot, invoice: dict) -> bool:
    """入金が確認できた自販機の注文を、取り置いた在庫でお渡しする。

    DMに送れなければ False を返す(監視ループが少し間をおいて再試行する)。
    """
    payload = invoice.get("payload") or {}
    records = payload.get("records") or []
    qty = int(payload.get("qty") or len(records) or 1)
    # 実際に受け取った額(リンクは請求額より多いことがある)を優先する
    paid = int(invoice.get("paid_amount") or invoice.get("amount_jpy") or 0)
    method = invoice.get("method") or payments.PAYPAY
    product_name = payload.get("product_name") or "商品"
    machine_id = payload.get("machine_id")
    machine = load_vending().get(machine_id, {}) or {}
    product = _find_product(machine, payload.get("product_id"))

    if payload.get("released"):
        # 期限切れで在庫を戻した後の手動対応(遅れて届いた入金)。取り置き直してから渡す。
        if product is None:
            raise RuntimeError("商品が削除されているため渡せません")
        fresh = await take_stock_async(product, qty)
        if fresh is None:
            raise RuntimeError(f"在庫が足りません（{product_name} ×{qty}個 / 戻した分は他の人に売れています）")
        records = fresh
        await _mark_order(invoice, invoice.get("status", "paid"),
                          payload={**payload, "records": fresh, "released": False})

    stock_text = "\n\n".join(records)
    order_id = invoice.get("id")

    try:
        user = bot.get_user(int(invoice["user_id"])) or await bot.fetch_user(int(invoice["user_id"]))
    except (discord.HTTPException, ValueError):
        return False

    try:
        await user.send(**stock_payload(stock_text),
                        embed=purchase_dm_embed(product_name, qty, paid, method,
                                                order_id=order_id))
    except discord.HTTPException:
        return False

    # ここから先は商品がもうお客さんの手元にある状態。売上の記録・ロール付与・
    # ログ送信で失敗しても False を返さないこと。見張りが「渡せなかった」と
    # 判断して再試行し、同じ在庫をもう一度DMで送ってしまう。
    # (after_delivery は例外を外に出さず、失敗はログに残す)
    try:
        await after_delivery(
            bot, machine_id, machine,
            product or {"product_id": payload.get("product_id"), "name": product_name},
            product_name, qty, paid, user, method, stock_text,
            guild=bot.get_guild(int(invoice["guild_id"])) if invoice.get("guild_id") else None,
            role_id=payload.get("role_id"), order_id=order_id, txid=invoice.get("txid"))
    except Exception as e:
        log.exception("お渡し後の記録に失敗 (%s): %s", order_id, e)
    return True


def _claim_release(order_id: str):
    """注文の台帳の中で「この取り置きは戻す」と先に印を立てる(update_store の mutate)。

    戻せるのは、保存してある注文がいまも「終わったのに取り置きを持ったまま」の
    ときだけ(stock_leaked)。渡された控えが古くて、そのあいだに入金が確認されて
    PAID に進んでいれば、その在庫はこれから渡すものなので触らない。
    印は台帳のロックの中で立てるので、2か所から同時に戻しに来ても1回しか通らない。
    戻り値は印を立てた注文の写し(戻す records 入り)。立てなかったら None。
    """
    def mutate(store):
        stored = store["orders"].get(order_id)
        if not stored or not stock_leaked(stored):
            return None
        payload = stored.setdefault("payload", {})
        payload["released"] = True
        stored["updated_at"] = time.time()
        return dict(stored)

    return mutate


async def offline_release(bot, invoice: dict):
    """期限切れ・キャンセルになった注文の取り置き在庫を戻す。

    戻したことを注文にも記録しておく。後から入金が届いて手動で渡すことになった
    とき、同じレコードをもう一度渡すと(その間に売れていた場合)二重販売になるため、
    offline_deliver 側で在庫を取り直す判断に使う。

    順番は「印を立ててから戻す」。逆にすると、戻した後に印が書けなかった注文が
    「まだ戻していない」ように見えて、次に戻しに来たときに同じ在庫を二重に
    戻してしまう(同じアカウントが2人に渡る)。印が立ったのに在庫ファイルへ
    書けなかったときは、中身を管理者に届けて手で戻してもらう。
    """
    if not invoice or not invoice.get("id"):
        return
    claimed = await link_orders.update_store(_claim_release(invoice["id"]))
    if not claimed:
        return          # 戻し済み・持っていない・これから渡す注文(PAID 等)
    payload = claimed.get("payload") or {}
    records = payload.get("records") or []
    machine = load_vending().get(payload.get("machine_id"), {}) or {}
    product = _find_product(machine, payload.get("product_id"))
    product_name = payload.get("product_name") or (product or {}).get("name") or "商品"
    # 保留(取り置き)はDiscordのログに出さない方針なので、戻しも通知は出さない。
    # quiet は _release_log_safely に残しているが、今はどちらも内部ログだけ(互換のため保持)。
    quiet = bool(claimed.get("superseded"))
    if product is None:
        # 商品ごと消されている。戻す先が無いので、印だけ残して終える。
        log.warning("注文 %s の取り置きを戻す先の商品がありません(%s ×%d)",
                    claimed.get("id"), product_name, len(records))
        await _release_log_safely(bot, machine, claimed, product_name, len(records),
                                  "商品が削除されているため在庫には戻せません。取り置きは終了しました。",
                                  quiet=quiet)
        return
    if product.get("infinite"):
        # 無限在庫はファイルを触っていないので戻すものが無い
        await _release_log_safely(bot, machine, claimed, product_name, len(records),
                                  "無限在庫のため在庫の数は変わりません。取り置きは終了しました。",
                                  quiet=quiet)
        return
    try:
        await return_stock_async(product, records)
    except Exception as e:
        log.exception("注文 %s の取り置きを在庫に戻せませんでした", claimed.get("id"))
        head = (f"⚠️ **取り置きを在庫に戻せませんでした**（自販機「{machine.get('name') or '不明'}」 / "
                f"注文番号 `{claimed.get('id')}` / {product_name} ×{len(records)}）\n"
                f"理由: `{type(e).__name__}: {str(e)[:200]}`\n"
                "下の内容を `/shop restock` で在庫に戻してください:\n")
        if not await _dm_admins(bot, lambda: stock_payload("\n\n".join(records), prefix=head)):
            print(f"[SHOP LOG UNDELIVERED] {head}" + "\n\n".join(records), flush=True)
        return
    # 戻したことは内部ログ(標準出力)に残す。保留の通知はDiscordのログには出さない方針。
    await _release_log_safely(bot, machine, claimed, product_name, len(records), quiet=quiet)


async def _release_log_safely(bot, machine, order, product_name, count, detail=None,
                              quiet=False):
    # 取り置き(保留)は裏で処理する方針なので、戻したこともDiscordのログには出さず、
    # 追跡用の内部ログ(標準出力)だけ残す。取り置き開始の通知を出していないため、
    # 対の戻し通知も出さない。quiet は呼び出し側との互換のために残している。
    log.info("取り置きを戻しました 注文 %s %s ×%d%s",
             order.get("id"), product_name, count,
             (f"（{detail}）" if detail else ""))


# ---------- 取り置きの戻し ----------
# 在庫が動く経路は3つ(支払い画面でのお渡し・見張りの取り置き・見張りからのお渡し)。
# 取り置いた在庫は「渡す」か「戻す」かのどちらかで必ず終わらせる。


def holds_stock(order: dict) -> bool:
    """その注文が在庫を取り置いたまま持っているか(戻してもいない)。"""
    payload = (order or {}).get("payload") or {}
    return bool(payload.get("records")) and not payload.get("released")


def stock_leaked(order: dict) -> bool:
    """取り置いた在庫を、渡しも戻しもしないまま注文だけ終わっているか。

    見張りから渡した注文(DONE)は records を持ったまま終わるのが正しい(渡した
    のがその中身)。畳まれた(superseded_by)・取り消し・期限切れで records が
    残っていれば、その分だけ在庫が消えている。
    """
    if not holds_stock(order):
        return False
    status = order.get("status")
    if status in (link_orders.CANCELED, link_orders.EXPIRED):
        return True
    return status == link_orders.DONE and bool(order.get("superseded_by"))


# ---------- 見回り(落ちた拍子に取り残された注文の後始末) ----------

# 見回りの間隔(時間)。起動直後に1回、その後はこの間隔で。
SWEEP_INTERVAL_HOURS = 1
# 渡し終えてからこの秒数を過ぎても記録の印(logged)が無い注文を、流し直しの対象にする。
# 普通は渡した直後(1〜2秒)に印が立つ。進行中の購入を拾わないための余裕。
LATE_LOG_AFTER_SECONDS = 120
LATE_LOG_NOTE = "Botが途中で止まったため、遅れて流した記録です（お渡しは完了しています）"


class _Buyer:
    """Discord から取れなかった購入者の代わり(ログに ID だけ出す)。"""

    def __init__(self, user_id):
        self.id = int(user_id)
        self.mention = f"<@{self.id}>"


async def _buyer_for(bot, user_id):
    try:
        uid = int(user_id)
    except (TypeError, ValueError):
        return _Buyer(0)
    try:
        return bot.get_user(uid) or await bot.fetch_user(uid)
    except Exception:
        return _Buyer(uid)


def needs_late_record(order: dict, now: float = None) -> bool:
    """支払い画面で渡し終えたのに、売上・販売ログの印が無いまま時間が経った注文か。"""
    if order.get("kind") != "shop" or order.get("status") != link_orders.DONE:
        return False
    if order.get("settled_by") != "screen" or order.get("delivered") is not True:
        return False
    if order.get("logged") is not False:
        return False          # 印が立っている(True)か、印を使う前の古い記録(無し)
    since = float(order.get("updated_at") or order.get("paid_at") or 0)
    return (now or time.time()) - since > LATE_LOG_AFTER_SECONDS


async def late_purchase_record(bot, order: dict) -> bool:
    """渡し終えたのに記録が無い注文の、売上・購入ロール・販売ログを流し直す。"""
    payload = order.get("payload") or {}
    handed = payload.get("handed") or []
    machine_id = payload.get("machine_id")
    machine = load_vending().get(machine_id) or {}
    product = (_find_product(machine, payload.get("product_id"))
               or {"product_id": payload.get("product_id"),
                   "name": payload.get("product_name") or "商品"})
    product_name = payload.get("product_name") or product.get("name") or "商品"
    qty = int(payload.get("qty") or len(handed) or 1)
    paid = int(payload.get("paid") or order.get("paid_amount") or 0)
    method = payload.get("method") or order.get("method") or payments.PAYPAY
    user = await _buyer_for(bot, order.get("user_id"))
    sales = await asyncio.to_thread(load_shop_sales)
    sale = None
    if any(s.get("order_id") == order.get("id") for s in sales):
        sale = asyncio.sleep(0)       # 売上は書けていた。二重に数えない
    guild = None
    try:
        guild = bot.get_guild(int(order["guild_id"])) if order.get("guild_id") else None
    except (TypeError, ValueError):
        pass
    await after_delivery(bot, machine_id, machine, product, product_name, qty, paid, user,
                         method, "\n\n".join(handed), guild=guild,
                         role_id=payload.get("role_id"), order_id=order.get("id"),
                         sale=sale, log_note=LATE_LOG_NOTE)
    await _mark_logged(order.get("id"))
    return True


async def sweep_orders(bot) -> dict:
    """取り残された注文の後始末。どちらも Bot が途中で落ちたときにだけ残る。

    (a) 終わったのに取り置きを持ったままの注文 → 在庫に戻す(release_closed_order)。
        期限切れの印を付けた直後に落ちると、戻す処理だけが走らずに残る。
    (b) 渡し終えたのに売上・販売ログの印が無い注文 → 記録を流し直す。
        お渡しの印と記録のあいだで落ちると、在庫が減りお金も入っているのに
        ログが無い購入になる。
    """
    orders = await asyncio.to_thread(link_orders.list_orders)
    now = time.time()
    done = {"released": 0, "logged": 0}
    for order in orders:
        if order.get("kind") != "shop":
            continue
        try:
            if stock_leaked(order):
                await release_closed_order(bot, order)
                done["released"] += 1
            elif needs_late_record(order, now):
                if await late_purchase_record(bot, order):
                    done["logged"] += 1
        except Exception as e:
            log.exception("見回りで注文 %s を片付けられませんでした: %s", order.get("id"), e)
    return done


async def release_closed_order(bot, order: dict):
    """畳まれた・取り消された自販機の注文が在庫を取り置いたままなら戻す。

    見張りに載せた注文は在庫を取ってある。支払い画面が同じリンクを受け取って
    畳んだとき(settle_on_screen)や、買い直しで取り消したとき(cancel_superseded)、
    注文の状態は変わるが在庫は誰も戻していなかった。その分だけ「販売ログも
    売上も無いのに在庫が減る」。戻し済み・取り置き無しの注文には何もしない。
    """
    if not order or order.get("kind") != "shop" or not stock_leaked(order):
        # 見張り中・お渡し中・失敗の注文は在庫を持っていて正しい(これから渡す)。
        # 見張りから渡し終えた注文の records は渡した中身で、戻すものではない。
        return
    try:
        await offline_release(bot, order)
    except Exception as e:
        log.warning("注文 %s の取り置きを戻せませんでした: %s", order.get("id"), e)


# ---------- Cog本体 ----------

class ShopCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        os.makedirs(STOCK_DIR, exist_ok=True)
        self.sweep.start()

    def cog_unload(self):
        self.sweep.cancel()

    @tasks.loop(hours=SWEEP_INTERVAL_HOURS)
    async def sweep(self):
        """起動直後と1時間おきの見回り(sweep_orders)。失敗してもループは止めない。"""
        try:
            done = await sweep_orders(self.bot)
            if done["released"] or done["logged"]:
                log.warning("自販機の見回り: 取り置きを戻した注文 %d件 / 記録を流し直した注文 %d件",
                            done["released"], done["logged"])
        except Exception as e:
            log.exception("自販機の見回りに失敗: %s", e)

    @sweep.before_loop
    async def _before_sweep(self):
        await self.bot.wait_until_ready()
        # 在庫追加希望(廃止)のボタンが残っているパネルを片付ける。済んでいれば何もしない。
        # ここで落ちると見回りが始まらないので、失敗はログだけにする。
        try:
            fixed = await drop_request_buttons(self.bot)
            if fixed:
                log.warning("在庫追加希望ボタンを外しました(パネル %d枚)", fixed)
        except Exception as e:
            log.warning("在庫追加希望ボタンの片付けに失敗: %s", e)

    shop = app_commands.Group(name="shop", description="自販機系コマンド")
    # Telegram 自販機の設定は別グループ /tg に分ける。/shop に足し続けると Discord の
    # 1グループ25コマンドの上限を超えて、起動時に丸ごと落ちる(26個目で例外)。
    tg = app_commands.Group(name="tg", description="Telegram自販機の設定")

    def _deny_perm(self, interaction):
        return interaction.response.send_message("この自販機の操作権限がありません。", ephemeral=True)

    @shop.command(name="register", description="自販機を作成します")
    @app_commands.describe(name="自販機の名前")
    async def register(self, interaction: discord.Interaction, name: str):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        data = load_vending()
        machine_id = uuid.uuid4().hex[:8]
        password = uuid.uuid4().hex[:12]
        data[machine_id] = {
            "name": name, "owner_id": str(interaction.user.id), "password": password,
            "sell_log_channel_id": None, "private_log_channel_id": None,
            "purchase_role_id": None,
            "panel": {"title": None, "description": None, "image": None},
            "products": [],
        }
        save_vending(data)
        await interaction.response.send_message(
            f"自販機「{name}」を作成しました。\n"
            f"**自販機ID:** `{machine_id}`\n**パスワード:** `{password}`\n\n"
            f"⚠️ IDとパスワードは引き継ぎ(`/shop link`)に必要です。必ずメモしてください。",
            ephemeral=True,
        )

    @shop.command(name="panel", description="パネルを設置")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", title="パネルのタイトル", description="説明", image="画像URL")
    async def panel(self, interaction: discord.Interaction, machine_id: str,
                    title: str = None, description: str = None, image: str = None):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        if title is not None: machine["panel"]["title"] = title
        if description is not None: machine["panel"]["description"] = description
        if image is not None: machine["panel"]["image"] = image
        save_vending(data)
        self.bot.add_view(ShopPanelView(machine_id, self.bot))
        await interaction.response.send_message("自販機を設置しました。", ephemeral=True)
        await panels.put(self.bot, f"shop:{machine_id}", interaction.channel,
                         panel_embed(machine), ShopPanelView(machine_id, self.bot))

    @shop.command(name="redisplay", description="パネルを最新の内容に更新")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    async def redisplay(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        self.bot.add_view(ShopPanelView(machine_id, self.bot))
        await interaction.response.defer(ephemeral=True, thinking=True)
        # 置き直すと古いパネルが上に残って、お客さんが古いほうを押してしまう。
        # 置いてあるパネルだけを、どのチャンネルにあっても探して書き換える。
        # ここで新しく置くことはしない(設置は /shop panel から)。
        result = await refresh_panel(self.bot, machine_id, machine,
                                     guild=interaction.guild)
        await interaction.followup.send(
            {"updated": "✏️ 置いてあるパネルを最新の内容に更新しました。",
             "missing": "パネルが見つかりませんでした。"
                        "まだ設置されていないようです（`/shop panel` で設置できます）。",
             "failed": "❌ パネルを更新できませんでした。"}[result], ephemeral=True)

    @shop.command(name="logchannel", description="非公開ログの送り先")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", channel="管理者専用チャンネル")
    async def logchannel(self, interaction: discord.Interaction, machine_id: str, channel: discord.TextChannel):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        machine["private_log_channel_id"] = channel.id
        save_vending(data)
        await interaction.response.send_message(f"非公開ログを {channel.mention} に設定しました。", ephemeral=True)

    @shop.command(name="selllog", description="販売ログの送り先")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", channel="実績チャンネルなど")
    async def selllog(self, interaction: discord.Interaction, machine_id: str, channel: discord.TextChannel):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        machine["sell_log_channel_id"] = channel.id
        save_vending(data)
        await interaction.response.send_message(f"公開販売ログを {channel.mention} に設定しました。", ephemeral=True)

    @shop.command(name="role", description="購入時に付けるロール")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", role="付与するロール(省略で解除)")
    async def role(self, interaction: discord.Interaction, machine_id: str, role: discord.Role = None):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        if role is not None and interaction.guild is not None:
            me = interaction.guild.me
            if role >= me.top_role:
                return await interaction.response.send_message(
                    "そのロールはBotより上位のため付与できません。Botのロールを上に移動してください。", ephemeral=True)
        machine["purchase_role_id"] = role.id if role else None
        save_vending(data)
        if role:
            await interaction.response.send_message(
                f"購入時付与ロールを {role.mention} に設定しました。\n"
                f"※ 0円商品は付与されません。**実際に支払いがあった購入のみ**付与されます。", ephemeral=True)
        else:
            await interaction.response.send_message("購入時付与ロールを解除しました。", ephemeral=True)

    @shop.command(name="add_slot", description="商品を追加（最大25）")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", name="商品名", description="説明", price="価格(円)", emoji="絵文字(任意)")
    async def add_slot(self, interaction: discord.Interaction, machine_id: str,
                       name: str, description: str, price: int, emoji: str = None):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        if len(machine["products"]) >= MAX_SLOTS:
            return await interaction.response.send_message(f"商品は最大 {MAX_SLOTS} 個までです。", ephemeral=True)
        if price < 0:
            return await interaction.response.send_message("価格は0円以上で指定してください。", ephemeral=True)
        pid = uuid.uuid4().hex
        os.makedirs(STOCK_DIR, exist_ok=True)
        path = os.path.join(STOCK_DIR, f"{pid}.txt")
        open(path, "w", encoding="utf-8").close()
        machine["products"].append({
            "product_id": pid, "name": name, "description": description, "price": price,
            "emoji": emoji, "stock_file": path, "infinite": False, "infinite_content": None,
        })
        save_vending(data)
        await interaction.response.defer(ephemeral=True, thinking=True)
        note = await panel_note(self.bot, machine_id, machine, interaction.guild)
        await interaction.followup.send(f"商品「{name}」を追加しました。{note}",
                                        ephemeral=True)

    @shop.command(name="delete_slot", description="商品を消す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    async def delete_slot(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("削除できる商品がありません。", ephemeral=True)

        async def cb(inter, pid):
            d = load_vending()
            m = d.get(machine_id)
            prod = next((p for p in m.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.response.send_message("商品が見つかりません。", ephemeral=True)
            m["products"] = [p for p in m["products"] if p["product_id"] != pid]
            save_vending(d)
            try:
                if prod.get("stock_file") and os.path.exists(prod["stock_file"]):
                    os.remove(prod["stock_file"])
            except OSError:
                pass
            await inter.response.defer(ephemeral=True, thinking=True)
            # 消した商品がパネルに残っていると、買えないものを押させてしまう。
            note = await panel_note(self.bot, machine_id, m, inter.guild)
            await inter.followup.send(f"商品「{prod['name']}」を削除しました。{note}",
                                      ephemeral=True)

        await interaction.response.send_message("削除する商品を選択してください。",
                                                view=select_view(products, "削除する商品", cb), ephemeral=True)

    @shop.command(name="setting", description="商品の中身を変える")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    async def setting(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("変更できる商品がありません。", ephemeral=True)

        async def cb(inter, pid):
            d = load_vending()
            m = d.get(machine_id)
            prod = next((p for p in m.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.response.send_message("商品が見つかりません。", ephemeral=True)
            await inter.response.send_modal(EditProductModal(machine_id, prod))

        await interaction.response.send_message("変更する商品を選択してください。",
                                                view=select_view(products, "変更する商品", cb), ephemeral=True)

    @shop.command(name="add_bulk", description="まとめ買い値下げを足す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機")
    async def add_bulk(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message(
                "値下げを付けられる商品がありません。先に `/shop add_slot` で商品を追加してください。",
                ephemeral=True)
        if len(products) == 1:
            # 商品が1つなら選ばせずに、そのまま個数と値引き額の入力へ
            return await interaction.response.send_modal(BulkDiscountModal(machine_id, products[0]))

        async def cb(inter, pid):
            prod = _find_product(load_vending().get(machine_id), pid)
            if not prod:
                return await inter.response.send_message("商品が見つかりません。", ephemeral=True)
            await inter.response.send_modal(BulkDiscountModal(machine_id, prod))

        await interaction.response.send_message("まとめ買い値下げを付ける商品を選択してください。",
                                                view=select_view(products, "値下げを付ける商品", cb),
                                                ephemeral=True)

    @shop.command(name="delete_bulk", description="まとめ買い値下げを消す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機")
    async def delete_bulk(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = [p for p in machine.get("products", []) if bulk_tiers(p)]
        if not products:
            return await interaction.response.send_message(
                "まとめ買い値下げが付いた商品がありません。", ephemeral=True)

        async def pick_tier(inter, pid):
            prod = _find_product(load_vending().get(machine_id), pid)
            tiers = bulk_tiers(prod) if prod else []
            if not tiers:
                return await inter.response.send_message("まとめ買い値下げがありません。", ephemeral=True)
            unit = int(prod.get("price") or 0)
            choices = [(f"{n}個以上 1個あたり {off:,}円引き（1個 {unit - off:,}円）", n)
                       for n, off in tiers]

            async def remove(inter2, value):
                d = load_vending()
                m = d.get(machine_id)
                p = _find_product(m, pid)
                if not p or not remove_bulk_tier(p, int(value)):
                    return await inter2.response.send_message("その値下げはもうありません。", ephemeral=True)
                save_vending(d)
                await inter2.response.defer(ephemeral=True, thinking=True)
                # 消した値下げがパネルに残っていると、無い値段で買いに来る。
                note = await panel_note(self.bot, machine_id, m, inter2.guild)
                await inter2.followup.send(
                    f"「{p['name']}」の まとめ買い値下げ（{value}個以上）を消しました。{note}",
                    ephemeral=True)

            await inter.response.send_message(f"「{prod['name']}」の消す値下げを選択してください。",
                                              view=choice_view(choices, "消す値下げ", remove),
                                              ephemeral=True)

        if len(products) == 1:
            return await pick_tier(interaction, products[0]["product_id"])
        await interaction.response.send_message("まとめ買い値下げを消す商品を選択してください。",
                                                view=select_view(products, "値下げを消す商品", pick_tier),
                                                ephemeral=True)

    @shop.command(name="restock", description="在庫を足す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", stock_file="在庫ファイル(txt/任意)", infinite="無限在庫にする")
    async def restock(self, interaction: discord.Interaction, machine_id: str,
                      stock_file: discord.Attachment = None, infinite: bool = False):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("在庫を追加できる商品がありません。先に `/shop add_slot` で商品を追加してください。", ephemeral=True)
        if stock_file and not stock_file.filename.lower().endswith(".txt"):
            return await interaction.response.send_message("ファイルは .txt のみ対応しています。", ephemeral=True)

        file_text = None
        if stock_file:
            try:
                file_text = (await stock_file.read()).decode("utf-8", errors="replace")
            except Exception:
                return await interaction.response.send_message("ファイルを読み込めませんでした。", ephemeral=True)

        async def cb(inter, pid):
            d = load_vending()
            m = d.get(machine_id)
            prod = next((p for p in m.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.response.send_message("商品が見つかりません。", ephemeral=True)
            if file_text is not None:
                await inter.response.defer(ephemeral=True)
                if infinite:
                    prod["infinite"] = True
                    prod["infinite_content"] = file_text.strip()
                    save_vending(d)
                    return await inter.followup.send(f"「{prod['name']}」を**無限在庫**に設定しました。", ephemeral=True)
                records = parse_stock_records(file_text)
                if not records:
                    return await inter.followup.send("在庫が空です。", ephemeral=True)
                await append_stock_async(prod, records)
                save_vending(d)
                tg_note = await notify_restock(inter.client, m, prod, len(records))
                return await inter.followup.send(f"「{prod['name']}」に {len(records)}個 追加しました（在庫: {admin_stock_text(prod)}）。{tg_note}", ephemeral=True)
            # ファイルなし → このチャンネルに貼ってもらう(モーダルは4,000字で入り切らない)。
            # Bot がこのチャンネルを読めないときだけモーダルに戻す。
            me = inter.guild.me if inter.guild else None
            if me is not None and not inter.channel.permissions_for(me).view_channel:
                return await inter.response.send_modal(StockPasteModal(machine_id, pid, infinite))
            await collect_restock(inter.client, inter, machine_id, pid, infinite)

        await interaction.response.send_message("在庫を追加する商品を選択してください。",
                                                view=select_view(products, "在庫を追加する商品", cb), ephemeral=True)

    @staticmethod
    async def _send_withdraw_dm(user, machine_name, product_name, body: str) -> bool:
        """引き出した在庫の控えを、実行した本人のDMへ送る。送れたら True。

        エフェメラルは画面を閉じたりクライアントを再起動すると消えるので、引き出した
        中身が残らない。残るDMにも同じ内容を控えとして送る(長ければ .txt で添付)。"""
        head = (f"🗄 在庫の引き出し控え\n自販機: {machine_name}\n商品: {product_name}\n"
                "※ 引き出した在庫の控えです（この内容はあなたにだけ送っています）。\n")
        try:
            await user.send(**stock_payload(body, prefix=head))
            return True
        except discord.HTTPException:
            return False

    @shop.command(name="exchange", description="在庫を取り出す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", quantity="引き出す数")
    async def exchange(self, interaction: discord.Interaction, machine_id: str, quantity: int = 1):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        if quantity <= 0:
            return await interaction.response.send_message("引き出す数は1以上で指定してください。", ephemeral=True)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("引き出せる商品がありません。", ephemeral=True)

        async def cb(inter, pid):
            await inter.response.defer(ephemeral=True)
            d = load_vending()
            m = d.get(machine_id)
            prod = next((p for p in m.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.followup.send("商品が見つかりません。", ephemeral=True)
            if prod.get("infinite"):
                content = prod.get("infinite_content", "")
                await inter.followup.send(f"```\n{content}\n```", ephemeral=True)
                # 無限在庫は何度でも見られるが、引き出しの控えとしてDMにも送っておく
                await self._send_withdraw_dm(inter.user, m.get("name") or machine_id,
                                             f"{prod['name']}（無限在庫）", content)
                return
            # 読んでから書くまでは take_stock と同じロックの中で(お客さんの購入と
            # 同時に引き出しても、同じレコードが両方に出ないように)。
            taken = await asyncio.to_thread(pull_stock, prod, quantity)
            if not taken:
                return await inter.followup.send("在庫がありません。", ephemeral=True)
            # 多数の在庫は1メッセージに収まらないので、長ければ .txt で渡す(stock_payload)。
            # 渡せなかったときは必ず在庫に戻す(以前はここで送信に失敗すると、在庫だけ
            # 0 になって中身が受け取れず消えていた)。
            body = "\n\n".join(taken)
            try:
                await inter.followup.send(
                    **stock_payload(body, prefix=f"「{prod['name']}」から {len(taken)}個 引き出しました。\n"),
                    ephemeral=True)
            except discord.HTTPException as e:
                await return_stock_async(prod, taken)
                log.warning("在庫の引き出しを渡せず、在庫に戻しました (%s ×%d): %s",
                            prod.get("name"), len(taken), e)
                return await inter.followup.send(
                    "引き出した在庫をお渡しできなかったため、在庫に戻しました。"
                    "数が多い場合は数回に分けてお試しください。", ephemeral=True)
            # エフェメラルは閉じる/再起動で消えるので、残るDMにも控えを送る。
            if not await self._send_withdraw_dm(inter.user, m.get("name") or machine_id,
                                                prod["name"], body):
                await inter.followup.send(
                    "⚠️ DMに控えを送れませんでした（DMの受け取りを許可してください）。"
                    "この画面の内容を保存してください。", ephemeral=True)

        await interaction.response.send_message("引き出す商品を選択してください。",
                                                view=select_view(products, "引き出す商品", cb), ephemeral=True)

    # ---------- X垢の凍結チェック ----------
    # 先頭の id(ユーザー名)だけを使い、ログインせずにXの公開情報で「生存 / 凍結・削除」を
    # 見分ける(x_check)。パスワードは凍結判定に要らないので触らない。時間がかかるので
    # defer して、進み具合を編集で見せる。

    async def _run_x_check(self, interaction, records, where, mode: str = "frozen"):
        """records をチェックしつつ、進み具合を元の応答に出す。結果リストを返す。
        凍結/年代は同じ結果で両用(mode は表示の切り替えだけ)。"""
        async def progress(done, total, results):
            s = x_check.summarize(results)
            try:
                await interaction.edit_original_response(
                    content=(f"{where}を確認中… {done}/{total}\n"
                             f"🟢{s['active']}　🧊{s['frozen']}　❓{s['no_username']}　⚠️{s['unknown']}"))
            except discord.HTTPException:
                pass
        return await x_check.check_records(records, progress_cb=progress)

    async def _send_x_report(self, interaction, results, total_records, pulled, title,
                             mode: str = "frozen"):
        """チェック結果をまとめて出す。長ければ .txt。pulled があれば取り出した分も添付。
        mode="age" は年代(作成年)ごとにまとめ、凍結・判定不可はその下に添える。"""
        if mode == "age":
            # 年代モードは年だけ。凍結・判定不可・年不明の区分は出さない。
            summary = x_check.age_line(results, total_records)
            lines = [summary]
            by_year = {}
            for _, u, st, _, y in results:
                if st == x_check.ACTIVE and y:
                    by_year.setdefault(y, []).append(u)
            for y in sorted(by_year):
                lines += ["", f"{y}年（{len(by_year[y])}件）:"] + [f"・@{u}" for u in by_year[y]]
        else:
            summary = x_check.summary_line(results, total_records)
            lines = [summary]
            frozen = [u for _, u, st, _, _ in results if st == x_check.FROZEN]
            unknown = [(u, d) for _, u, st, d, _ in results if st == x_check.UNKNOWN]
            noname = [u for _, u, st, _, _ in results if st == x_check.NO_USERNAME]
            if frozen:
                lines += ["", f"🧊 凍結・削除(使用不可) {len(frozen)}件:"] + [f"・@{u}" for u in frozen]
            if noname:
                lines += ["", f"❓ ユーザー名を取れず {len(noname)}件（先頭がメール等）:"] + [f"・{u}" for u in noname[:30]]
            if unknown:
                lines += ["", f"⚠️ 判定不可 {len(unknown)}件（X側に問い合わせできず。時間をおいて再実行）:"]
                lines += [f"・@{u}（{d}）" for u, d in unknown[:20]]
        report = "\n".join(lines)
        files, content = [], f"**{title}**\n"
        if len(content) + len(report) > MESSAGE_LIMIT:
            files.append(discord.File(io.BytesIO(report.encode("utf-8")), filename="x_check.txt"))
            content += "結果は添付の x_check.txt をご確認ください。\n" + summary
        else:
            content += report
        if pulled:
            files.append(discord.File(io.BytesIO("\n\n".join(pulled).encode("utf-8")),
                                      filename="frozen_accounts.txt"))
            content += f"\n\n🧊 在庫から取り出した凍結在庫 {len(pulled)}件を frozen_accounts.txt に添付しました。"
        await interaction.edit_original_response(content=content[:MESSAGE_LIMIT], attachments=files)

    async def _send_clean_report(self, interaction, results, total_records, removed,
                                 cleaned, title, newer=(), max_year=None):
        """使えない垢(凍結・削除)を取り除いた結果を出す。

        removed … 取り除いたレコード。cleaned を渡すと(ファイル版)残った「使える分」も
        cleaned_accounts.txt で添付する。cleaned が None(在庫版)は取り除いた分だけ渡す。
        newer … 年代(max_year)を指定したとき、それより後に作られていて取り除いた垢。
        生きている垢なので凍結とは混ぜず、別のファイルで渡す。
        """
        removed_users = [u for _, u, st, *_ in results if st == x_check.FROZEN]
        lines = [x_check.summary_line(results, total_records), "",
                 f"取り除いた（凍結・削除）{len(removed)}件"]
        if removed_users:
            lines.append("取り除いた垢: " + "、".join(f"@{u}" for u in removed_users[:40])
                         + ("…" if len(removed_users) > 40 else ""))
        newer_file = f"since_{max_year + 1}_accounts.txt" if max_year else None
        if max_year:
            from collections import Counter
            year_of = {r[0]: r[4] for r in results}
            years = Counter(year_of.get(rec) for rec in newer)
            lines.append(f"取り除いた（{max_year + 1}年以降に作成）{len(newer)}件"
                         + ("（" + " / ".join(f"{y}年 {n}件" for y, n in sorted(years.items())) + "）"
                            if newer else ""))
            # 判定不可・作成年不明は年代が分からないので残している。混ざっていないとは
            # 言い切れないので、件数を出しておく。
            unsure = sum(1 for _, _, st, _, y in results
                         if st != x_check.FROZEN and not (st == x_check.ACTIVE and y))
            if unsure:
                lines.append(f"⚠️ 作成年を確認できなかった {unsure}件は、年代が分からないので残しています。")
        content = f"**{title}**\n" + "\n".join(lines)
        files = []
        if removed:
            files.append(discord.File(io.BytesIO("\n\n".join(removed).encode("utf-8")),
                                      filename="removed_accounts.txt"))
        if newer:
            files.append(discord.File(io.BytesIO("\n\n".join(newer).encode("utf-8")),
                                      filename=newer_file))
        if cleaned is not None:
            files.append(discord.File(io.BytesIO("\n\n".join(cleaned).encode("utf-8")),
                                      filename="cleaned_accounts.txt"))
            content += (f"\n\n✅ 使える分 {len(cleaned)}件を cleaned_accounts.txt に"
                        + (f"、取り除いた {len(removed)}件を removed_accounts.txt に" if removed else "")
                        + (f"、{max_year + 1}年以降の {len(newer)}件を {newer_file} に" if newer else "")
                        + "添付しました。")
        else:
            notes = []
            if removed:
                notes.append(f"🗑 在庫から取り除いた {len(removed)}件を removed_accounts.txt に添付しました。")
            if newer:
                notes.append(f"🗓 在庫から取り除いた {max_year + 1}年以降の {len(newer)}件を"
                             f" {newer_file} に添付しました。")
            if notes:
                content += "\n\n" + "\n".join(notes)
        await interaction.edit_original_response(content=content[:MESSAGE_LIMIT], attachments=files)

    @shop.command(name="x_check_file",
                  description="仕入れたX垢を確認(凍結/年代・ファイルか貼り付け)")
    @app_commands.describe(account_file="X垢の.txt(省略するとこのチャットに貼り付けて確認できます)",
                           mode="確認する内容")
    @app_commands.choices(mode=[app_commands.Choice(name="凍結", value="frozen"),
                                app_commands.Choice(name="年代", value="age")])
    async def x_check_file(self, interaction: discord.Interaction,
                           account_file: discord.Attachment = None,
                           mode: app_commands.Choice[str] = None):
        m = mode.value if mode else "frozen"
        kind = _X_KIND.get(m, "凍結")
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)

        if account_file is not None:
            # ファイル添付で確認
            if not account_file.filename.lower().endswith(".txt"):
                return await interaction.response.send_message("ファイルは .txt のみ対応しています。", ephemeral=True)
            try:
                text = (await account_file.read()).decode("utf-8", errors="replace")
            except Exception:
                return await interaction.response.send_message("ファイルを読み込めませんでした。", ephemeral=True)
            await interaction.response.defer(ephemeral=True)
            source = account_file.filename
            no_records = lambda: interaction.followup.send("アカウントが見つかりませんでした。", ephemeral=True)
        else:
            # ファイルなし → このチャンネルに貼り付け(手打ち)で確認
            me = interaction.guild.me if interaction.guild else None
            if me is not None and not interaction.channel.permissions_for(me).view_channel:
                return await interaction.response.send_message(
                    "このチャンネルを読めないため貼り付けを受け取れません。X垢の .txt を添付してお試しください。",
                    ephemeral=True)
            text = await collect_pasted_text(
                self.bot, interaction,
                f"確認するX垢を**このチャンネルに貼り付けてください**（{kind}チェック）。何通でも、"
                ".txt 添付でも構いません。手打ちでも大丈夫です。")
            if text is None:
                return      # やめた・集まらなかった(collect_pasted_text が案内済み)
            source = "貼り付け"
            no_records = lambda: interaction.edit_original_response(
                content="X垢を読み取れませんでした。もう一度お試しください。")

        records, headers = _drop_headers(parse_stock_records(text))
        if not records:
            return await no_records()
        where = f"{source}"
        name = source + (f"・形式の説明{headers}行は除外" if headers else "")
        results = await self._run_x_check(interaction, records, where, mode=m)
        await self._send_x_report(interaction, results, len(records), pulled=None,
                                  title=f"X垢の{kind}チェック（{name}）", mode=m)

    @shop.command(name="x_check_stock", description="在庫のX垢を確認(凍結/年代)")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", mode="確認する内容")
    @app_commands.choices(mode=[app_commands.Choice(name="凍結", value="frozen"),
                                app_commands.Choice(name="年代", value="age")])
    async def x_check_stock(self, interaction: discord.Interaction, machine_id: str,
                            mode: app_commands.Choice[str] = None):
        m = mode.value if mode else "frozen"
        kind = _X_KIND.get(m, "凍結")
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("商品がありません。", ephemeral=True)

        async def cb(inter, pid):
            await inter.response.defer(ephemeral=True)
            mch = load_vending().get(machine_id) or {}
            prod = next((p for p in mch.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.followup.send("商品が見つかりません。", ephemeral=True)
            if prod.get("infinite"):
                return await inter.followup.send("無限在庫はチェックの対象外です。", ephemeral=True)
            records = read_stock_records(prod.get("stock_file"))
            if not records:
                return await inter.followup.send("在庫がありません。", ephemeral=True)
            where = f"「{prod['name']}」の在庫"
            results = await self._run_x_check(inter, records, where, mode=m)
            await self._send_x_report(inter, results, len(records), pulled=None,
                                      title=f"在庫の{kind}チェック（{prod['name']}）", mode=m)

        await interaction.response.send_message(
            f"{kind}を確認する商品を選択してください。",
            view=select_view(products, "確認する商品", cb), ephemeral=True)

    @shop.command(name="x_clean_file",
                  description="仕入れファイルから凍結・削除された垢を取り除く（年代で新しい垢も）")
    @app_commands.describe(account_file="X垢のファイル(.txt。各行の先頭がユーザー名)",
                           max_year=_X_YEAR_HELP)
    @app_commands.rename(max_year="年代")
    async def x_clean_file(self, interaction: discord.Interaction,
                           account_file: discord.Attachment, max_year: _XYear = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)
        if not account_file.filename.lower().endswith(".txt"):
            return await interaction.response.send_message("ファイルは .txt のみ対応しています。", ephemeral=True)
        try:
            text = (await account_file.read()).decode("utf-8", errors="replace")
        except Exception:
            return await interaction.response.send_message("ファイルを読み込めませんでした。", ephemeral=True)
        # 見出し行(形式の説明)は垢ではないので、確認せず cleaned_accounts.txt にも入れない
        records, headers = _drop_headers(parse_stock_records(text))
        if not records:
            return await interaction.response.send_message("アカウントが見つかりませんでした。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        results = await self._run_x_check(interaction, records,
                                          f"ファイル「{account_file.filename}」")
        removed = x_check.removable_records(results)
        newer = x_check.newer_records(results, max_year)
        cleaned = _subtract_records(records, removed + newer)
        name = account_file.filename + (f"・形式の説明{headers}行は除外" if headers else "")
        await self._send_clean_report(interaction, results, len(records), removed, cleaned,
                                      title=f"X垢のクリーニング（{name}）",
                                      newer=newer, max_year=max_year)

    @shop.command(name="x_clean_stock",
                  description="在庫から凍結・削除された垢を取り除く（年代で新しい垢も）")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", max_year=_X_YEAR_HELP)
    @app_commands.rename(max_year="年代")
    async def x_clean_stock(self, interaction: discord.Interaction, machine_id: str,
                            max_year: _XYear = None):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        products = machine.get("products", [])
        if not products:
            return await interaction.response.send_message("商品がありません。", ephemeral=True)

        async def cb(inter, pid):
            await inter.response.defer(ephemeral=True)
            m = load_vending().get(machine_id) or {}
            prod = next((p for p in m.get("products", []) if p["product_id"] == pid), None)
            if not prod:
                return await inter.followup.send("商品が見つかりません。", ephemeral=True)
            if prod.get("infinite"):
                return await inter.followup.send("無限在庫は対象外です。", ephemeral=True)
            records = read_stock_records(prod.get("stock_file"))
            if not records:
                return await inter.followup.send("在庫がありません。", ephemeral=True)
            results = await self._run_x_check(inter, records, f"「{prod['name']}」の在庫")
            removed = x_check.removable_records(results)
            newer = x_check.newer_records(results, max_year)
            pulled = await asyncio.to_thread(remove_stock_records, prod, removed)
            pulled_newer = await asyncio.to_thread(remove_stock_records, prod, newer)
            await self._send_clean_report(inter, results, len(records), pulled, None,
                                          title=f"在庫のクリーニング（{prod['name']}）",
                                          newer=pulled_newer, max_year=max_year)

        what = (f"凍結・削除された垢と、{max_year + 1}年以降に作られた垢" if max_year
                else "凍結・削除された垢")
        await interaction.response.send_message(
            f"{what}を取り除く商品を選択してください（抜いた分はファイルで渡します）。",
            view=select_view(products, "取り除く商品", cb), ephemeral=True)

    @shop.command(name="x_format_panel", description="X垢の形式確認パネルを設置")
    async def x_format_panel(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)
        self.bot.add_view(XFormatView())
        await interaction.response.send_message("形式確認パネルを設置しました。", ephemeral=True)
        await panels.put(self.bot, "xformat", interaction.channel, xformat_embed(), XFormatView())

    @tg.command(name="products",
                description="Telegramに出す商品を選ぶ（在庫はDiscordと共有）")
    async def tg_products(self, interaction: discord.Interaction):
        uid = interaction.user.id
        data = load_vending()
        entries = []
        for mid, machine in data.items():
            if not isinstance(machine, dict) or not is_owner(uid, machine):
                continue
            for p in machine.get("products", []):
                if not isinstance(p, dict) or not p.get("product_id"):
                    continue
                if int(p.get("price") or 0) <= 0:
                    continue   # 0円商品は送金リンクで買えないので対象外
                entries.append((mid, machine.get("name") or mid, p, bool(p.get("telegram"))))
        if not entries:
            return await interaction.response.send_message(
                "管理できる商品がありません。先に Discord 側で商品を作ってください。", ephemeral=True)
        enabled = [p["name"] for _mid, _mn, p, en in entries if en]
        now = ("いまTelegramに出している商品: " + "、".join(enabled)) if enabled \
            else "いまTelegramに出している商品はありません。"
        note = ""
        if len(entries) > 25:
            note = f"\n※ 商品が多いため先頭25件だけ出しています（全{len(entries)}件）。"
        await interaction.response.send_message(
            "Telegramの自販機に並べる商品を選んでください（チェックを外すと出しません）。\n"
            + now + note,
            view=telegram_pick_view(entries), ephemeral=True)

    @tg.command(name="intro",
                description="Telegramの説明文（/startで出る案内）を編集")
    async def tg_intro(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)
        import telegram_shop
        await interaction.response.send_modal(TelegramIntroModal(telegram_shop.get_intro()))

    @tg.command(name="support",
                description="Telegramのサポート窓口（お客様ごとの専用トピック）を設定")
    @app_commands.describe(disable="サポート窓口を解除する（パネルの💬サポートも消えます）")
    async def tg_support(self, interaction: discord.Interaction, disable: bool = False):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)
        import telegram_shop
        if not telegram_shop.configured():
            return await interaction.response.send_message(
                "Telegramのボットが動いていません（TELEGRAM_BOT_TOKEN を設定してください）。",
                ephemeral=True)
        if disable:
            telegram_shop.disable_support()
            return await interaction.response.send_message(
                "Telegramのサポート窓口を解除しました。パネルの「💬 サポート」ボタンも消えます。",
                ephemeral=True)
        # コードは管理者にだけ見せる。これを知らない人は窓口を付け替えられない。
        code = telegram_shop.create_support_link_code()
        now = ("設定済み（別のグループで送ると、そちらに付け替わります）"
               if telegram_shop.support_configured() else "未設定")
        await interaction.response.send_message(
            f"**Telegramのサポート窓口を設定します**（現在: {now}）\n"
            "1. Telegramでグループを作り、グループの設定で「トピック」をオンにする。\n"
            "2. このBotをそのグループに追加して**管理者**にし、「トピックの管理」と「メッセージの削除」を許可する。\n"
            f"3. そのグループで次を送る（{telegram_shop.LINK_CODE_MINUTES}分以内・1回だけ有効）:\n"
            f"```/setsupport {code}```\n"
            "設定後、お客様がパネルの「💬 サポート」を押すと、お客様ごとにトピックができます。"
            "お客様の発言はそのトピックに届き、トピックに書いた内容はそのお客様だけに届きます。"
            "対応が終わったら、そのトピックで /close と送ってください（トピックは削除されます）。",
            ephemeral=True)

    @tg.command(name="restock_notify",
                description="Telegramの在庫追加のお知らせ（利用者全員へ）のオン/オフ")
    @app_commands.describe(state="オン / オフ")
    @app_commands.choices(state=[app_commands.Choice(name="オン", value="on"),
                                 app_commands.Choice(name="オフ", value="off")])
    async def tg_restock_notify(self, interaction: discord.Interaction,
                                state: app_commands.Choice[str]):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("この操作は管理者のみです。", ephemeral=True)
        import telegram_shop
        on = state.value == "on"
        telegram_shop.set_restock_notify(on)
        if on:
            text = ("Telegramの在庫追加のお知らせをオンにしました。Telegramに出している商品の在庫を"
                    f"足すと、このBotを使ったことのある全員（いま{telegram_shop.subscriber_count()}人）"
                    "に届きます。")
        else:
            text = ("Telegramの在庫追加のお知らせをオフにしました。"
                    "戻すときは `/tg restock_notify` でオンにしてください。")
        await interaction.response.send_message(text, ephemeral=True)

    @shop.command(name="destory", description="自販機を消す")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    async def destory(self, interaction: discord.Interaction, machine_id: str):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)

        async def confirm(inter):
            d = load_vending()
            m = d.pop(machine_id, None)
            if m:
                for p in m.get("products", []):
                    try:
                        if p.get("stock_file") and os.path.exists(p["stock_file"]):
                            os.remove(p["stock_file"])
                    except OSError:
                        pass
                save_vending(d)
            await inter.response.edit_message(content=f"自販機「{machine.get('name')}」を削除しました。", view=None)

        v = ui.View(timeout=60)
        btn = ui.Button(label="削除する", style=discord.ButtonStyle.danger)
        btn.callback = confirm
        v.add_item(btn)
        await interaction.response.send_message(
            f"自販機「{machine.get('name')}」を完全に削除します。よろしいですか？（復元不可）",
            view=v, ephemeral=True)

    @shop.command(name="link", description="自販機を引き継ぐ")
    @app_commands.describe(machine_id="自販機ID", password="パスワード")
    async def link(self, interaction: discord.Interaction, machine_id: str, password: str):
        data = load_vending()
        m = data.get(machine_id.strip())
        if not m:
            return await interaction.response.send_message("自販機が見つかりません。", ephemeral=True)
        if str(m.get("password")) != password.strip():
            return await interaction.response.send_message("パスワードが違います。", ephemeral=True)
        m["owner_id"] = str(interaction.user.id)
        save_vending(data)
        await interaction.response.send_message(f"自販機「{m.get('name')}」を引き継ぎました。", ephemeral=True)

    @shop.command(name="restock_notify", description="在庫追加の通知先")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", channel="通知先チャンネル(省略で解除)")
    async def restock_notify(self, interaction: discord.Interaction, machine_id: str,
                             channel: discord.TextChannel = None):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        machine["restock_notify_channel_id"] = channel.id if channel else None
        # 送り先を決め直したらオンに戻す(オフのまま「設定したのに来ない」にしない)。
        machine["restock_notify_enabled"] = True
        save_vending(data)
        if channel:
            await interaction.response.send_message(f"在庫追加通知を {channel.mention} に設定しました。", ephemeral=True)
        else:
            await interaction.response.send_message("在庫追加通知を解除しました。", ephemeral=True)

    @shop.command(name="restock_notify_switch", description="在庫追加の通知のオン/オフ")
    @app_commands.autocomplete(machine_id=machine_autocomplete)
    @app_commands.describe(machine_id="自販機", state="オン / オフ")
    @app_commands.choices(state=[app_commands.Choice(name="オン", value="on"),
                                 app_commands.Choice(name="オフ", value="off")])
    async def restock_notify_switch(self, interaction: discord.Interaction, machine_id: str,
                                    state: app_commands.Choice[str]):
        machine, data = get_owned_machine(interaction.user.id, machine_id)
        if not machine:
            return await self._deny_perm(interaction)
        on = state.value == "on"
        ch_id = machine.get("restock_notify_channel_id")
        if on and not ch_id:
            return await interaction.response.send_message(
                "通知先がまだありません。先に `/shop restock_notify` でチャンネルを設定してください。",
                ephemeral=True)
        machine["restock_notify_enabled"] = on
        save_vending(data)
        if on:
            text = f"在庫追加の通知をオンにしました（送り先: <#{ch_id}>）。"
        else:
            text = ("在庫追加の通知をオフにしました。送り先の設定は残しているので、"
                    "戻すときは `/shop restock_notify_switch` でオンにしてください。")
        await interaction.response.send_message(text, ephemeral=True)

    # 売上表示は /profit (代行/自販機 統合版・main.py) に移動した


async def setup(bot):
    # 既存の自販機パネルを再登録(再起動後もボタンが動くように)
    for mid in load_vending():
        try:
            bot.add_view(ShopPanelView(mid, bot))
        except Exception:
            pass
    # X垢 形式確認パネルのボタン(1種類・固定の custom_id)も再登録。
    try:
        bot.add_view(XFormatView())
    except Exception:
        pass
    # 入金が確認できたら、取り置いた在庫を渡す(期限切れなら戻す)。
    # 保留から遅れて承認された送金リンクの入金確認で動く。
    link_orders.register_handler(
        "shop",
        lambda order: offline_deliver(bot, order),
        on_expire=lambda order: offline_release(bot, order),
    )
    await bot.add_cog(ShopCog(bot))
