"""ぷにぷに代行(自動)。

にゃんこ代行(main.py)・ツムツム代行(Cogs/tsum.py)・自販機(Cogs/shop.py)と
同じ流れで動く。

    パネル → 注文する → メニュー選択 → (周回数の入力) → L5ログイン → 確認
        → 支払い → 代行 → DM

売り物は 3 つ(お客さん用パネルの「注文する」ボタンから選ぶ)。
  ・ステージ周回: 「最後に遊んだステージを指定回数だけ自動周回する」。
    ステージIDは公開されていないのでお客さんには入れさせない。「周回したい
    ステージをゲームで一度プレイ(クリアかリタイア)してから注文する」と案内し、ログイン後に垢の
    データから最後に遊んだステージを読んで、確認画面に名前つきで出す。
    違えば注文し直してもらう(選び直しや手入力は置かない)。
  ・イベントステージ進行: 今進めているイベントを、現在地から最後のステージ
    (裏ステージまで)までクリアする。入力するものは無く、ログイン後に現在地を
    読んで確認画面に出す。価格は1回いくら(ステージ数は問わない)。強敵(ボス)の
    ステージは飛ばす(別枠)。
  ・強敵取得: 強敵の妖怪を1体取得できるまで挑戦する。入力するものは無く、
    ログイン後に挑戦する強敵ステージ(最後にプレイした強敵。無ければ今のイベントの
    裏マップで次に挑む強敵)を読んで確認画面に出す。強敵ステージをクリア済みか
    どうかは問わず、取得できた時点で終える。価格は1回いくら(挑戦回数は問わない)。
    有料で妖怪を取れずに終わったら、トラブルログで人に引き継ぐ(返金か手動対応)。
  ・強敵完凸: 持っている強敵の妖怪が完凸するまで挑戦し続ける。価格は1回いくら。
価格は管理者が /puni event_price /puni boss_price /puni boss_max_price で決める。
ステージ周回は客用のメニューから外してあり、管理者パネル(0円)でだけ動かせる。

支払いは payments 層に丸ごと任せるので、受け取り先は「いつものコマンド」で
登録したアカウントそのまま(PayPayなら /paypay_login など)。

先にログインまで済ませてから支払わせるのは、ツムツム代行と同じ理由。
ログインできない・回せるステージが無い・進めるイベントが無いアカウントから
お代だけ受け取る事故を作らない。支払いが保留(PayPayの承認待ち)になっても
注文は捨てず、link_orders の見張りに渡して、承認され次第そのまま自動で流す。
そのために注文にはL5の udkey だけを預ける(メールアドレスとパスワードは保存しない)。

表示に絵文字は使わない。文字だけでも読める並びにしておく。
"""
import asyncio
import faulthandler
import io
import json
import logging
import os
import re
import signal
import threading
import time
import uuid

import discord
from discord import app_commands, ui
from discord.ext import commands, tasks

import link_orders
import panels
import payment_attempts
import payments
import puni_daiko
import puni_stages
import support
from datapath import data_path, read_json, write_json
from utils import ADMIN_USER_IDS, notify_payment_pending

log = logging.getLogger(__name__)

# 注文の種類。link_orders / payment_attempts で共通に使う。
KIND = "puni"

# ぷにぷに代行の色。ツムツム(緑)・にゃんこ(青)・自販機(赤)と見分けがつくよう紫にする。
# パネル・確認画面・完了・公開ログは PUNI_COLOR、非公開ログは少し濃い PUNI_COLOR_PRIVATE。
# 失敗(赤)・一部未完了(橙)は状態の色なので変えない。
PUNI_COLOR = 0x9b59b6
PUNI_COLOR_PRIVATE = 0x6c3483

# 保留になった支払いを見張る時間(分)。在庫を抱えないので代行と同じ既定にする。
WATCH_MINUTES = int(os.environ.get("PUNI_LINK_WATCH_MINUTES", "60"))

CONFIG_FILE = data_path("config.json")


def _config() -> dict:
    return read_json(CONFIG_FILE, {})


def _save_config(cfg: dict):
    write_json(CONFIG_FILE, cfg)


def log_channel_id():
    """公開ログの送信先。未設定ならにゃんこ代行のログ先へ相乗りする。"""
    cfg = _config()
    return cfg.get("puni_log_channel_id") or cfg.get("log_channel_id")


def private_log_channel_id():
    cfg = _config()
    return cfg.get("puni_private_log_channel_id") or cfg.get("daiko_private_log_channel_id")


def purchase_role_id(guild_id):
    """購入時に付けるロール。ぷに用が無ければ代行用を使う。"""
    cfg = _config()
    for key in ("puni_purchase_roles", "daiko_purchase_roles"):
        rid = (cfg.get(key) or {}).get(str(guild_id))
        if rid:
            return int(rid)
    return None


def set_purchase_role_id(guild_id, role_id):
    cfg = _config()
    roles = cfg.setdefault("puni_purchase_roles", {})
    if role_id:
        roles[str(guild_id)] = int(role_id)
    else:
        roles.pop(str(guild_id), None)
    _save_config(cfg)


# --- ログ ------------------------------------------------------------------

async def resolve_channel(bot, ch_id):
    if not ch_id:
        return None
    try:
        ch_id = int(ch_id)
    except (TypeError, ValueError):
        log.warning("ぷにのログ先IDが不正です: %r", ch_id)
        return None
    ch = bot.get_channel(ch_id)
    if ch is not None:
        return ch
    try:
        return await bot.fetch_channel(ch_id)
    except Exception as e:
        log.warning("ぷにのログ先を取得できません(%s): %s", ch_id, e)
        return None


async def _send_log(bot, ch_id, label: str, **kwargs) -> bool:
    ch = await resolve_channel(bot, ch_id)
    if ch is None:
        return False
    try:
        await ch.send(**kwargs)
        return True
    except discord.Forbidden:
        log.warning("%sを送れません(権限不足): %s", label, ch_id)
    except Exception as e:
        log.warning("%sの送信に失敗: %s", label, e)
    return False


async def grant_purchase_role(guild, user_id, paid_amount) -> bool:
    """購入時ロールを付ける。0円には付けない。"""
    if int(paid_amount or 0) <= 0 or guild is None:
        return False
    role_id = purchase_role_id(guild.id)
    if not role_id:
        return False
    member = guild.get_member(int(user_id))
    if member is None:
        try:
            member = await guild.fetch_member(int(user_id))
        except (discord.NotFound, discord.Forbidden, discord.HTTPException):
            member = None
    role = guild.get_role(int(role_id))
    if member is None or role is None:
        log.warning("ぷにの購入ロールを付けられません(member=%s role=%s id=%s)",
                    member is not None, role is not None, role_id)
        return False
    if role in member.roles:
        return True
    try:
        await member.add_roles(role, reason="ぷにぷに代行の購入(有料)による自動付与")
        return True
    except (discord.Forbidden, discord.HTTPException) as e:
        log.warning("ぷにの購入ロール付与に失敗: %s", e)
        return False


# --- 注文の実行 ------------------------------------------------------------

# 同じ人の二重実行を止める。ゲーム側に同時に投げると結果が混ざる。
_BUSY: set = set()
# 後追いの代行を裏で走らせると決めてから、その処理が _BUSY に入るまでの短い間の予約。
# 同じ人の注文が同じ巡回に2件並んでいても、2件目を走らせない。
_PENDING: set = set()
# 「ログインし直す」画面で入り直している最中の人(二重送信で連携が2回走らないように)。
_RELOGIN_BUSY: set = set()
# アプリ版の確認(App Store 参照)を後追いの都合で急がせた時刻。巡回のたびに叩かない。
_VERSION_KICK = {"at": 0.0}
VERSION_KICK_INTERVAL = 600.0

# DM進捗の最短更新間隔(秒)。編集しすぎるとレート制限に当たるので間を空ける。
DM_PROGRESS_INTERVAL = float(os.getenv("PUNI_DM_PROGRESS_INTERVAL", "8"))
# 代行が終わったとき、進捗DMの最後の書き換え(ボタンを外す)を待つ上限(秒)。過ぎても
# 書き換えは裏で続ける(結果の DM を先に出す)。
DM_FINISH_WAIT = float(os.getenv("PUNI_DM_FINISH_WAIT", "30"))


def _nothing_delivered(kind: str, outcome: dict) -> bool:
    """代行が何も渡せていないか。周回/進行は1周も回せていない。強敵取得・強敵完凸は撃破の
    数ではなく妖怪を取れたかで見る(撃破だけではお客さんに渡るものが無い)。"""
    if kind in puni_daiko.BOSS_KINDS:
        return not outcome.get("obtained")
    return not outcome.get("cleared")


# --- 進捗DMと停止ボタン ----------------------------------------------------

# 停止ボタンの custom_id。どの進捗DMでも同じにして、受け口(PuniStopView)を起動時に
# bot.add_view で常設する。以前は代行のたびに作るボタン(custom_id が毎回ちがう)で、
# 受け口はそのプロセスのメモリにしか無かった。再起動のあとに押すと誰も応えず、Discord に
# 「応答しませんでした」と出るだけで、止まったのかどうかも分からなかった。
# どの代行を止めるかは、押されたメッセージ(進捗DM)の ID で _STOPS から引く。
STOP_CUSTOM_ID = "puni:stop"

STOP_ACCEPTED_TEXT = "停止を受け付けました。今の周が終わり次第、そこまでの結果をお送りします。"
# お客さんに見せる文には、bot の再起動・更新などの裏側を書かない(止まった・一時停止した、まで)。
STOP_GONE_TEXT = ("この代行はもう動いていません（終わったか、途中で止まりました）。"
                  "停止ボタンを外しました。")
INTERRUPTED_TEXT = ("この代行は途中で止まりました。ここまでの結果はお送りできていません。"
                    "こちらで確認して対応します。")

# このプロセスで走っている代行の停止の合図。進捗DMのメッセージID → (合図, 依頼者のID, 取引番号)。
_STOPS: dict = {}
# このプロセスで走っている代行。取引番号 → PuniJob(見回り・健康ログ用)。
_LIVE: dict = {}

# 走っている代行の控え(1件1ファイル: <取引番号>.json)。再起動で落ちた代行は後始末が
# できず、進捗DMが「周回中…」のまま止まって見える(その場で流した0円の動作確認は台帳にも
# 載らないので、誰も気づかない)。走り出した時点で書き、終わったら消す。残っていて、
# 書いたプロセスがもう生きていなければ「途中で止まった代行」(_sweep_interrupted)。
# 1件ずつのファイルにするのは、再デプロイで新旧のプロセスが同時に書いても互いの分を
# 読み書きで潰さないため。
RUNNING_DIR = data_path("puni_running")
# プロセスの生存の印(1プロセス1ファイル: <BOOT_ID>.json に最後に生きていた時刻)。
BOOT_DIR = data_path("puni_boot")
BOOT_ID = uuid.uuid4().hex[:12]
# 生存の印を書く間隔と、これだけ更新が無ければ「そのプロセスは死んだ」とみなす秒数。
BOOT_BEAT_SECONDS = 60
BOOT_DEAD_SECONDS = float(os.getenv("PUNI_BOOT_DEAD_SECONDS", "180"))
# 進みが無いまま、これだけ経ったら「止まっている」と人に知らせる(秒)。長い休み(最大5分)・
# rc=4 の長い休み・全体停止(こちらは待っている間は数えない)より十分長くする。
STALL_SECONDS = float(os.getenv("PUNI_STALL_SECONDS", "2700"))
# ゲーム通信のスレッドが戻らないまま代行を終えたとき、その人の次の代行を止めておく上限(秒)。
# 戻らないスレッドが古い token で通信している間に入り直すと、両方がおかしくなる。
STUCK_THREAD_HOLD_SECONDS = float(os.getenv("PUNI_STUCK_THREAD_HOLD", "1800"))

# --- デプロイ・再起動をまたいで代行を続ける ---
# 代行は1周ごとに控えへ途中経過(state)を書く。プロセスが終わるときは、
#   ・デプロイなど(SIGTERM): _SUSPEND を立て、走っている代行を今の周で区切って「一時停止」
#     として控えに残し、すぐ終了する。
#   ・落ちた(OOM など、合図なし): 控えには最後に書いた途中経過が残る。
# 次のプロセスは見回り(_sweep_interrupted)で控えを見つけ、同じ取引番号・同じ進捗DMの
# まま続きから再開する(_resume_job)。結果の DM・売上・ログは、本当に終わったときに1回だけ出す。
_SUSPEND = asyncio.Event()
SUSPEND_NOTE = "一時停止しています。自動で続きから再開しますので、そのままお待ちください。"
SUSPENDED_TELL = "代行を一時停止しました。自動で続きから再開し、結果はDMでお送りします。"
# 以前の版が進捗DMに添えていた一言(bot の再起動・更新と書いていたもの)。今は出さないが、
# すでに送った進捗DMに残っている行を、再開・停止・中断で書き直すときに消すため残しておく
# (一時停止の控えは丸1日まで再開を待つので、古い版の文の DM もしばらく残る)。
_LEGACY_NOTES = (
    "（bot の再起動のあと、続きから再開しました）",
    "bot の更新のため一時停止しています。再起動が終わりしだい、自動で続きから再開します。",
    "この代行はもう動いていません（終わったか、bot の再起動などで途中で止まりました）。"
    "停止ボタンを外しました。",
    "bot の再起動などで、この代行は途中で止まりました。ここまでの結果はお送りできていません。"
    "こちらで確認して対応します。",
)
# 終了の合図(SIGTERM)を受けてから、走っている代行が今の周を終えるのを待つ上限(秒)。
# 1周のプレイ(gameStart→gameEnd)は長くて20秒ほど。
SHUTDOWN_WAIT = float(os.getenv("PUNI_SHUTDOWN_WAIT", "25"))
# 合図なしに落ちて再開した回数の上限(同じ代行で落ち続けるときに、再開と落ちるのを
# 繰り返さないため)。デプロイでの一時停止からの再開は数えない。
MAX_CRASH_RESUMES = int(os.getenv("PUNI_MAX_CRASH_RESUMES", "5"))
# 再開しようとしてサーバの都合など(拒まれた・メンテナンス・全体停止・版合わせ)で始め
# られなかったとき、次に試すまでの間(秒。失敗が続くと倍々に延ばし、上限 RESUME_RETRY_MAX)と、
# 諦めるまでの時間(最初に始められなかったときから)。回数では切らない(全体停止は最長1時間
# 続くことがあり、回数で切ると支払い済みの代行を早々に諦めてしまう)。
RESUME_RETRY_SECONDS = float(os.getenv("PUNI_RESUME_RETRY_SECONDS", "120"))
RESUME_RETRY_MAX = float(os.getenv("PUNI_RESUME_RETRY_MAX", "1800"))
RESUME_GIVE_UP_SECONDS = float(os.getenv("PUNI_RESUME_GIVE_UP_HOURS", "24")) * 3600
# 再開の手続き中(控えを自分のものにしてから、代行が _LIVE に入るまで)の取引番号。
_RESUMING: set = set()
# 走り終えて、進捗DMの最後の書き換えをしている途中の取引番号(終了のときに待つ)。
_WINDING: set = set()
# 一時停止中・再開待ちのあいだに停止ボタンが押された取引番号(再開したらすぐ止める)。
_STOP_REQUESTS: set = set()
# 終了の合図を受けた時刻(生存の印に載せる)。
_STOPPING = {"at": None}


def _running_path(tx_id: str) -> str:
    return os.path.join(RUNNING_DIR, f"{tx_id}.json")


def _write_running(tx_id: str, record: dict):
    """控えを書く。書けなくても代行は止めない。"""
    try:
        write_json(_running_path(tx_id), record)
    except Exception as e:
        log.warning("ぷにの実行中の控えを書けませんでした(%s): %s", tx_id, e)


def _drop_running(tx_id: str):
    """控えを消す(停止の申し出・再開の札も一緒に)。"""
    _STOP_REQUESTS.discard(tx_id)
    for path in (_running_path(tx_id), _stop_marker_path(tx_id), _claim_path(tx_id)):
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
        except Exception as e:
            log.warning("ぷにの実行中の控えを消せませんでした(%s): %s", path, e)


# 停止の申し出(<取引番号>.stop)。停止ボタンが押されたら、どのプロセスで受けても書く。
# 控え本体とは別のファイルにするのは、走っている代行が1周ごとに控えを書き直しても
# 申し出が消えないため。再開した代行はこれを見て、続きを回さずに止める。
def _stop_marker_path(tx_id: str) -> str:
    return os.path.join(RUNNING_DIR, f"{tx_id}.stop")


def _request_stop(tx_id: str):
    if not tx_id:
        return
    _STOP_REQUESTS.add(tx_id)
    try:
        os.makedirs(RUNNING_DIR, exist_ok=True)
        with open(_stop_marker_path(tx_id), "w", encoding="utf-8") as f:
            f.write(str(time.time()))
    except OSError as e:
        log.warning("ぷにの停止の申し出を書けませんでした(%s): %s", tx_id, e)


def _stop_requested(tx_id: str) -> bool:
    return tx_id in _STOP_REQUESTS or os.path.exists(_stop_marker_path(tx_id))


# 再開の札(<取引番号>.claim。中身は再開するプロセスの印)。控えを自分のものにする前に
# O_EXCL で作る。2つのプロセスが同時に見回っても、同じ代行を両方で再開しない。
def _claim_path(tx_id: str) -> str:
    return os.path.join(RUNNING_DIR, f"{tx_id}.claim")


def _claim(tx_id: str) -> bool:
    """再開の札を取る。取れたら True。死んだプロセスの札は捨てて取り直す。"""
    path = _claim_path(tx_id)
    for _ in range(2):
        try:
            os.makedirs(RUNNING_DIR, exist_ok=True)
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            try:
                with open(path, encoding="utf-8") as f:
                    owner = f.read().strip()
            except OSError:
                owner = ""
            if owner == BOOT_ID:
                return True
            if owner and _boot_alive(owner):
                return False              # 生きている別のプロセスが再開している
            try:
                os.remove(path)           # 札の持ち主は死んだ。捨てて取り直す
            except OSError:
                return False
            continue
        except OSError as e:
            log.warning("ぷにの再開の札を作れませんでした(%s): %s", tx_id, e)
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(BOOT_ID)
        return True
    return False


def _release_claim(tx_id: str):
    try:
        os.remove(_claim_path(tx_id))
    except OSError:
        pass


def _read_running_all() -> dict:
    """控えを全部読む。取引番号 → 中身。"""
    try:
        names = os.listdir(RUNNING_DIR)
    except FileNotFoundError:
        return {}
    except OSError as e:
        log.warning("ぷにの実行中の控えを読めませんでした: %s", e)
        return {}
    out = {}
    for name in names:
        if not name.endswith(".json"):
            continue        # 書きかけのテンポラリ(write_json)など
        rec = read_json(os.path.join(RUNNING_DIR, name), {})
        if rec:
            out[name[:-len(".json")]] = rec
    return out


def _running_record_for_message(message_id: int):
    """その進捗DMを出した代行の控え。無ければ None。"""
    for rec in _read_running_all().values():
        ids = [rec.get("message_id")] + list(rec.get("prior_message_ids") or [])
        if str(message_id) in {str(i) for i in ids if i}:
            return rec
    return None


def _beat_boot():
    """このプロセスが生きている印を書く(終了の合図を受けていれば、その時刻も載せる)。"""
    data = {"ts": time.time(), "pid": os.getpid(), "started_at": _BOOT_STARTED}
    if _STOPPING["at"]:
        data["stopping_at"] = _STOPPING["at"]
    try:
        write_json(os.path.join(BOOT_DIR, f"{BOOT_ID}.json"), data)
    except Exception as e:
        log.warning("ぷにの生存の印を書けませんでした: %s", e)


_BOOT_STARTED = time.time()


def _boot_info(boot: str) -> dict:
    if not boot:
        return {}
    return read_json(os.path.join(BOOT_DIR, f"{boot}.json"), {})


def _boot_last_seen(boot: str):
    """そのプロセスが最後に生きていた時刻。印が無ければ None。"""
    data = _boot_info(boot)
    try:
        return float(data["ts"]) if data.get("ts") else None
    except (TypeError, ValueError):
        return None


def _boot_alive(boot: str) -> bool:
    """そのプロセスが生きているか。印が BOOT_DEAD_SECONDS 以上更新されていなければ死んだ
    とみなす。終了の合図を受けたプロセスも、本当に終わる(印が途切れる)までは生きている
    扱いにする(一時停止にできなかった代行を、まだ動いているうちに横取りしない)。"""
    if boot == BOOT_ID:
        return True
    seen = _boot_last_seen(boot)
    return seen is not None and time.time() - seen < BOOT_DEAD_SECONDS


def _prune_boot_files(max_age: float = 86400.0):
    """古いプロセスの生存の印を消す(1日より前のもの)。"""
    try:
        names = os.listdir(BOOT_DIR)
    except OSError:
        return
    now = time.time()
    for name in names:
        if not name.endswith(".json") or name == f"{BOOT_ID}.json":
            continue
        seen = _boot_last_seen(name[:-len(".json")])
        if seen is None or now - seen > max_age:
            try:
                os.remove(os.path.join(BOOT_DIR, name))
            except OSError:
                pass


def _strip_notes(text: str) -> str:
    """進捗DMの本文から、こちらで添えた一言(停止・一時停止・中断。以前の版の文も)の行を除く。"""
    notes = {STOP_ACCEPTED_TEXT, SUSPEND_NOTE, STOP_GONE_TEXT, INTERRUPTED_TEXT, *_LEGACY_NOTES}
    return "\n".join(line for line in text.split("\n") if line.strip() not in notes)


class DMProgress:
    """実行中の進捗を、お客さんのDMに1通だけ出して編集し続ける。

    周回は時間がかかるので、途中経過(今どこまで進んだか)をDMで見えるようにする。
    最初の1回でメッセージを作り、以後は編集で更新。更新は間隔を空けて
    レート制限を避ける。DMが送れない/閉じている場合は何もしない(失敗は1回だけログに出す)。

    Discord への送信・編集は裏の1本の処理(_pump)だけが行い、update は最新の文を預けて
    すぐ返る。周回が Discord の通信を待つことは無い(以前は編集が詰まると周回ごと止まり、
    HTTPException 以外のエラー(接続断・タイムアウト)では周回ごと落ちた)。
    送信・編集は途中で打ち切らない(discord.py は全体のレート制限で待っている最中に
    打ち切られると、以後のすべての通信が止まったままになる)。同時に出ている通信は常に1本。
    停止ボタンつきで出したときは、そのメッセージを _STOPS に載せ、終わったら外す。
    """

    def __init__(self, user, view=None, stop_event=None, on_message=None, tx_id=""):
        self.user = user
        self.tx_id = tx_id              # 停止の申し出をファイルに残すときの取引番号
        self.msg = None
        self.view = view                # 進捗の文につけるボタン(停止)。無ければ文だけ
        self.stop_event = stop_event    # 停止ボタンで立つ合図(立ったら文にそう書き、ボタンを消す)
        self.on_message = on_message    # 初めて出せたときに呼ぶ(控えに進捗DMのIDを書く)
        self.text = ""                  # 出したい最新の文
        self.last_progress_at = time.time()   # 最後に進捗が届いた時刻(見回り用)
        self.last_dm_ok_at = None       # 最後に Discord へ出せた時刻
        self._dirty = asyncio.Event()   # まだ出していない新しい文がある
        self._closed = asyncio.Event()  # 代行が終わった(最後の書き換えをして終える)
        self._task = None
        self._fail_streak = 0
        self.note = ""                  # 文の最後に添える一言(一時停止の知らせ)

    def adopt_existing(self, msg):
        """前のプロセスが出した進捗DMをそのまま使う(再開したとき。新しく送らない)。

        前の文から一時停止などの添え書きを除いた本文を引き継ぎ、すぐ1回書き直す
        (「一時停止しています」を消して停止ボタンを付け直す。周回が1周も回らずに
        終わっても、最後の書き換えで古い添え書きとボタンが残らない)。
        """
        self.msg = msg
        self.text = _strip_notes(msg.content or "")
        self._adopt(msg)
        if self.user is not None and not self._closed.is_set():
            self._dirty.set()
            if self._task is None:
                self._task = _spawn(self._pump())

    def _stopping(self) -> bool:
        return self.stop_event is not None and self.stop_event.is_set()

    async def update(self, text: str, force: bool = False):
        """最新の文を預ける。Discord への通信は待たない(間隔を空けて裏で出す)。"""
        self.last_progress_at = time.time()
        self.text = text
        if self.user is None or self._closed.is_set():
            return
        self._dirty.set()
        if self._task is None:
            self._task = _spawn(self._pump())

    async def _pump(self):
        try:
            while True:
                if not self._closed.is_set():
                    await self._dirty.wait()
                self._dirty.clear()
                closing = self._closed.is_set()
                await self._push(closing)
                if closing:
                    return
                # 次の書き換えまで間を空ける。終わりの合図が来たらすぐ最後の書き換えへ。
                try:
                    await asyncio.wait_for(self._closed.wait(), timeout=DM_PROGRESS_INTERVAL)
                except asyncio.TimeoutError:
                    pass
        finally:
            if self.view is not None:
                # このメッセージ専用の受け口を片付ける(外しそこねたボタンが押されても、
                # 常設の受け口が「もう動いていません」と答えてボタンを外す)。
                self.view.stop()

    async def _push(self, closing: bool):
        """1回だけ送信か編集をする。失敗しても外へは出さない。"""
        text = self.text or ""
        view = self.view
        if self._stopping():
            text += "\n" + STOP_ACCEPTED_TEXT
            view = None
        if self.note:
            text += "\n" + self.note
        if closing:
            view = None
        what = "送信" if self.msg is None else "編集"
        try:
            if self.msg is None:
                if closing:
                    return      # 1度も出せていない。終わってから新しく出すことはしない
                msg = await self.user.send(text[:2000], view=view)
                self.msg = msg
                self._adopt(msg)
            else:
                await self.msg.edit(content=text[:2000], view=view)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            self._fail_streak += 1
            if self._fail_streak == 1:
                print(f"[PUNI] 進捗DMの{what}に失敗しました: {e!r}", flush=True)
            return
        if self._fail_streak:
            print(f"[PUNI] 進捗DMの{what}が戻りました（失敗{self._fail_streak}回のあと）", flush=True)
            self._fail_streak = 0
        self.last_dm_ok_at = time.time()

    def _adopt(self, msg):
        """初めて出せた進捗DMを、停止の受け口と控えに載せる。"""
        if self._closed.is_set():
            return      # 出せたときには代行が終わっていた(受け口にも控えにも載せない)
        if self.view is not None and self.stop_event is not None:
            _STOPS[msg.id] = (self.stop_event, self.user.id, self.tx_id)
        if self.on_message is not None:
            try:
                self.on_message(msg)
            except Exception as e:
                log.warning("ぷにの進捗DMの控えを更新できませんでした: %s", e)

    async def finish(self):
        """代行が終わった。進捗の文からボタンを外す(押しても何も起きないボタンを残さない)。

        最後の書き換えは DM_FINISH_WAIT 秒まで待つ。過ぎても打ち切らず、裏で続けさせる
        (結果の DM を待たせない)。
        """
        if self.msg is not None:
            _STOPS.pop(self.msg.id, None)
        self._closed.set()
        self._dirty.set()
        task = self._task
        if task is None:
            if self.view is not None:
                self.view.stop()
            return
        done, _ = await asyncio.wait({task}, timeout=DM_FINISH_WAIT)
        if not done:
            print(f"[PUNI] 進捗DMの片付けが{int(DM_FINISH_WAIT)}秒で終わりません。裏で続けます",
                  flush=True)


# 進捗DMの停止ボタンの文言(メニューごと)。
STOP_LABELS = {
    puni_daiko.KIND_FARM: "周回停止",
    puni_daiko.KIND_EVENT: "進行停止",
    puni_daiko.KIND_MAIN: "進行停止",
    puni_daiko.KIND_BOSS: "取得停止",
    puni_daiko.KIND_BOSS_MAX: "完凸停止",
}


async def _reply_ephemeral(interaction: discord.Interaction, text: str):
    """押した人にだけ見える返事。何があっても例外は外に出さない。"""
    try:
        if interaction.response.is_done():
            await interaction.followup.send(text, ephemeral=True)
        else:
            await interaction.response.send_message(text, ephemeral=True)
    except Exception as e:
        log.warning("ぷにの停止ボタンの返事に失敗: %r", e)


async def _answer_on_message(interaction: discord.Interaction, note: str):
    """押されたメッセージ(進捗DM)に note を書き足し、停止ボタンを外して応える。

    Discord はボタンに3秒以内に応えないと「応答しませんでした」と出す。ここでは
    何より先に応える(時間のかかることはしない)。書き換えに失敗したら、押した人にだけ
    見える返事で伝える。
    """
    # 前に添えた一言(一時停止の知らせ・以前の版の文など)は外してから、今の一言を書き足す。
    base = _strip_notes((interaction.message.content if interaction.message else "") or "")
    content = f"{base}\n{note}".strip()
    try:
        await interaction.response.edit_message(content=content[:2000], view=None)
        return
    except Exception as e:
        log.warning("ぷにの停止ボタンでメッセージを書き換えられませんでした: %r", e)
    await _reply_ephemeral(interaction, note)


async def _handle_stop_press(interaction: discord.Interaction):
    """停止ボタンが押された。何があっても3秒以内に答える(ファイルを数個読むだけ)。

    受け付けたときは、停止の申し出をファイルにも残す(_request_stop)。押したプロセスと
    代行を回しているプロセスが違っても、そのあと落ちて再開しても、申し出は消えない。
    """
    msg = interaction.message
    entry = _STOPS.get(msg.id) if msg is not None else None
    if entry is not None:
        stop_event, owner_id, tx_id = entry
        if interaction.user.id != owner_id:
            return await _reply_ephemeral(interaction, "この代行の依頼者ではありません。")
        stop_event.set()
        _request_stop(tx_id)
        return await _answer_on_message(interaction, STOP_ACCEPTED_TEXT)
    rec = _running_record_for_message(msg.id) if msg is not None else None
    if rec and str(rec.get("user_id")) == str(interaction.user.id) and not rec.get("dm_marked"):
        tx_id = str(rec.get("tx_id") or "")
        if tx_id in _LIVE:
            # このプロセスで走っている(進捗DMが出し直されて、古いほうが押された)。
            _LIVE[tx_id].stop_event.set()
            _request_stop(tx_id)
            return await _answer_on_message(interaction, STOP_ACCEPTED_TEXT)
        boot = str(rec.get("boot") or "")
        owner_alive = not rec.get("suspended") and boot != BOOT_ID and _boot_alive(boot)
        if owner_alive or not _not_resumable_reason(rec, not rec.get("suspended")):
            # 別のプロセスで走っている(再デプロイの新旧同時稼働中。そちらも同じ押下を
            # 受け取って止める)か、一時停止中・落ちたあとで再開を待っている。どちらでも
            # 申し出を残す(持ち主が実は死んでいても、再開したらすぐ止めて結果を送る)。
            _request_stop(tx_id)
            return await _answer_on_message(interaction, STOP_ACCEPTED_TEXT)
    # 走っている代行ではない(もう終わった・再開できずに止まった)。
    # 黙っていると「応答しませんでした」になるので、必ず答えてボタンを外す。
    return await _answer_on_message(interaction, STOP_GONE_TEXT)


class PuniStopView(ui.View):
    """進捗DMにつける停止ボタン。

    再デプロイなどで途中で落とすと、そこまでの周回の結果(DM・売上・ログ)が全部飛ぶ。
    先にこれを押しておけば、今の周(gameEnd まで)を終えてから止まり、そこまでの結果を
    普段どおり DM で受け取れる。押せるのはその代行の依頼者だけ。

    custom_id は全部の進捗DMで共通(STOP_CUSTOM_ID)。起動時に常設の受け口として
    bot.add_view しておくので、再起動のあとに古い進捗DMのボタンが押されても必ず答える
    (「もう動いていません」と伝えてボタンを外す)。代行ごとの状態は持たない。
    """

    def __init__(self, kind: str = ""):
        super().__init__(timeout=None)
        button = ui.Button(label=STOP_LABELS.get(kind, "停止"),
                           style=discord.ButtonStyle.danger, custom_id=STOP_CUSTOM_ID)
        button.callback = self._callback
        self.add_item(button)

    async def _callback(self, interaction: discord.Interaction):
        try:
            await _handle_stop_press(interaction)
        except Exception as e:
            log.exception("ぷにの停止ボタンの処理に失敗: %s", e)
            await _reply_ephemeral(interaction, "停止の受け付けに失敗しました。もう一度押してください。")


# 停止ボタンが常設の custom_id になる前に出した進捗DMのボタン(custom_id は discord.py が
# 作る32桁の16進)。受け口がもう無いので、押されたら on_interaction で拾って答える。
_LEGACY_STOP_ID = re.compile(r"[0-9a-f]{32}")


def _is_legacy_stop_button(interaction: discord.Interaction, bot_user_id: int) -> bool:
    """押されたのが、前の作りの進捗DMの停止ボタンか。

    自分(bot)が DM に出したメッセージで、押されたボタンの文言が停止ボタンのもので、
    custom_id が discord.py の自動の形のときだけ。ほかのボタンには手を出さない。
    """
    if interaction.type != discord.InteractionType.component:
        return False
    data = interaction.data or {}
    custom_id = str(data.get("custom_id") or "")
    if data.get("component_type") != discord.ComponentType.button.value:
        return False
    if custom_id == STOP_CUSTOM_ID or not _LEGACY_STOP_ID.fullmatch(custom_id):
        return False
    msg = interaction.message
    if msg is None or msg.guild is not None or msg.author.id != bot_user_id:
        return False
    labels = set(STOP_LABELS.values())
    for row in msg.components:
        for child in getattr(row, "children", []):
            if getattr(child, "custom_id", None) == custom_id:
                return getattr(child, "label", None) in labels
    return False


class Busy(Exception):
    """その人の代行がもう走っている。"""


class Full(Busy):
    """同時に回せる人数の上限まで埋まっている(順番待ち)。"""


# 同時に回す代行(人数)の上限。垢ごとの通信は _pace で全体の間隔に乗るので、多すぎると
# 1人あたりの周回が間延びするだけでなく、同じ出口(IP)からの通信量そのものが目立つ。
# 上限に達した注文は見張りに預けて順番待ちにし、空き次第自動で流す。
MAX_CONCURRENT = int(os.getenv("PUNI_MAX_CONCURRENT", "10"))


def _slots_full(user_id=None) -> bool:
    """同時実行の枠が埋まっているか(user_id が既に枠を持っているなら埋まっていない扱い)。"""
    running = set(_BUSY) | set(_PENDING)
    if user_id is not None:
        running.discard(user_id)
    return len(running) >= MAX_CONCURRENT


# 裏で走らせている処理(後追いの代行など)。参照を持っておかないと、途中で GC に
# 回収されて黙って止まることがある。
_BG_TASKS: set = set()


def _spawn(coro) -> asyncio.Task:
    task = asyncio.get_running_loop().create_task(coro)
    _BG_TASKS.add(task)

    def _done(t: asyncio.Task):
        _BG_TASKS.discard(t)
        if not t.cancelled() and t.exception() is not None:
            log.error("ぷにの裏の処理が失敗しました: %r", t.exception(), exc_info=t.exception())

    task.add_done_callback(_done)
    return task


class PuniJob:
    """1件の注文を実際に流して、DM・ログ・売上まで面倒を見る。

    その場の支払い(Interactionが生きている)と、保留から承認された後追いの
    お渡しで同じものを使う。片方だけログが出ない、を作らないため。
    kind は基本 farm。main/event はこの作り替えより前に受けた注文の後追い用に
    だけ残している(エンジン側にも進行の処理を残してある)。
    """

    def __init__(self, bot, user, udkey, user_id, kind=puni_daiko.KIND_FARM, *,
                 stage_id=0, rounds=0, count=0,
                 total_price=0, paid=0, method=payments.PAYPAY, guild=None,
                 channel=None, pay_note=None, order_id=None, account="", tx_id=None,
                 admin_free=False, runner=None, resume=None):
        self.bot = bot
        self.user = user
        self.udkey = udkey
        self.user_id = user_id          # ゲーム側のユーザーID
        # 呼び出し側が先にログインしておいたランナー(後追いのお渡し)。1回使ったら手放し、
        # 流し直すときは udkey で入り直す。
        self.runner = runner
        # 停止の合図(進捗DMの停止ボタンで立つ)。立ったら今の周を終えて止まる。
        self.stop_event = asyncio.Event()
        self._dm = None                 # 進捗DM(終わったらボタンを外す)
        self.kind = kind
        self.stage_id = int(stage_id or 0)
        self.rounds = int(rounds or 0)
        self.count = int(count or 0)
        self.total_price = int(total_price or 0)
        self.paid = int(paid or 0)
        self.method = method
        self.guild = guild
        self.channel = channel
        self.pay_note = pay_note        # 非公開ログ用(リンク・注文番号など)
        self.order_id = order_id
        self.account = account
        self.admin_free = bool(admin_free)   # 管理者の動作確認(0円・売上や公開ログに出さない)
        # 取引番号。公開ログ・非公開ログ・売上の3か所に同じものを載せて、
        # 「このログの代行はどの入金か」を後から突き合わせられるようにする。
        self.tx_id = tx_id or uuid.uuid4().hex[:16]
        self.started_at = None          # 走り出した時刻(見回り用)
        self._record = None             # 走っている間の控え(_write_running)
        self._record_progress = ""      # 控えに最後に書いた進捗の文
        self._stall_since = None        # 「止まっている」と知らせた時点の最後の進み(1回だけ知らせる)
        self._hold_seen_at = 0.0        # 全体停止中なのを最後に見た時刻(待っている間は数えない)
        # 再開(前のプロセスの控えから続ける)。控えの中身と、そこに書かれた途中経過。
        self._prior = dict(resume) if resume else None
        self.resume_state = (self._prior or {}).get("state") or None
        self.dm_message = None          # 再開のとき、そのまま使う前の進捗DM
        self.last_record = None

    def summary(self) -> str:
        return puni_daiko.summary_for(self.kind, stage_id=self.stage_id,
                                      rounds=self.rounds, count=self.count)

    # ---- 表示 ----

    def method_note(self) -> str:
        if self.paid <= 0:
            return "なし"
        return payments.method_label(self.method)

    def result_embed(self, outcome: dict) -> discord.Embed:
        label = puni_daiko.kind_label(self.kind)
        if self.kind == puni_daiko.KIND_BOSS_MAX:
            # 完凸したかが全て。取れていても完凸していなければ「途中」。
            if outcome.get("not_owned"):
                title, color = f"{label} 対象外(強敵の妖怪を持っていない)", 0xffa500
            elif outcome.get("unconfirmed"):
                title, color = f"{label} 開始せず(持っているか確認できない)", 0xffa500
            elif outcome.get("maxed") is True:
                title, color = f"{label} 完了", 0x2f9e6e
            elif outcome.get("maxed") is False:
                title, color = f"{label} 判定できず(停止)", 0xffa500
            elif outcome.get("obtained"):
                title, color = f"{label} 途中で停止", 0xffa500
            elif outcome.get("tries"):
                title, color = f"{label} 未取得(中止)", 0xffa500
            else:
                title, color = f"{label} 失敗", 0xff3333
        elif self.kind == puni_daiko.KIND_BOSS:
            # 取得できたかが全て。撃破していても取れていなければ「未取得」。
            if outcome.get("obtained"):
                title, color = f"{label} 完了", 0x2f9e6e
            elif outcome.get("tries"):
                title, color = f"{label} 未取得(中止)", 0xffa500
            else:
                title, color = f"{label} 失敗", 0xff3333
        elif not outcome.get("cleared"):
            title, color = f"{label} 失敗", 0xff3333
        elif outcome.get("warning") or outcome.get("stopped"):
            title, color = f"{label} 完了(一部未完了)", 0xffa500
        else:
            title, color = f"{label} 完了", 0x2f9e6e
        body = "\n".join(outcome.get("lines") or []) or "結果なし"
        embed = discord.Embed(title=title, description=body, color=color)
        if self.kind == puni_daiko.KIND_FARM:
            embed.add_field(name="ステージ", value=puni_stages.describe(self.stage_id),
                            inline=True)
            embed.add_field(name="周回数", value=f"{self.rounds:,}回", inline=True)
        elif self.kind in puni_daiko.BOSS_KINDS:
            sid = outcome.get("stage_id") or self.stage_id
            embed.add_field(name="強敵ステージ",
                            value=puni_stages.describe(sid) if sid else "（未確定）", inline=True)
            embed.add_field(name="挑戦回数", value=f"{int(outcome.get('tries') or 0):,}回",
                            inline=True)
            got = outcome.get("obtained")
            embed.add_field(name="取得した妖怪", value=f"ID {got}" if got else "なし",
                            inline=True)
            if self.kind == puni_daiko.KIND_BOSS_MAX:
                embed.add_field(name="取得した数",
                                value=f"{int(outcome.get('obtained_count') or 0):,}体",
                                inline=True)
        else:
            embed.add_field(name="内容", value=label, inline=True)
            embed.add_field(name="進めたステージ数",
                            value=f"{int(outcome.get('cleared') or 0):,}", inline=True)
        if outcome.get("account"):
            embed.add_field(name="アカウント", value=outcome["account"], inline=False)
        embed.add_field(name="ご利用金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        return embed

    # ---- 本体 ----

    def _make_dm_progress(self):
        """実行中の進捗をDMに流すコールバックを作る(長時間かかるため)。

        周回は「X/Y周（成功Z）」。DMは編集で更新し、レート制限を避けるため
        間隔を空ける(DMProgress側)。
        """
        view = None
        if self.user is not None:
            view = PuniStopView(self.kind)
        dm = DMProgress(self.user, view=view, stop_event=self.stop_event,
                        on_message=self._note_dm_message, tx_id=self.tx_id)
        self._dm = dm
        if self.kind == puni_daiko.KIND_FARM:
            async def on_progress(done, total, cleared):
                # 「n周」は成功した周の数(失敗した周はやり直す)。成功の数を主に出す。
                await dm.update(
                    f"🔄 **{puni_daiko.kind_label(self.kind)}**\n"
                    f"周回中… 成功 {cleared:,}/{total:,}周（{done:,}周目）")
        elif self.kind == puni_daiko.KIND_BOSS:
            async def on_progress(tries, cleared, bought):
                extra = f"・人魂購入 {bought}回" if bought else ""
                await dm.update(
                    f"**{puni_daiko.kind_label(self.kind)}**\n"
                    f"挑戦中… {tries + 1:,}回目（撃破 {cleared:,}回{extra}）。"
                    "取得できるまで続けます")
        elif self.kind == puni_daiko.KIND_BOSS_MAX:
            async def on_progress(tries, cleared, bought, count):
                extra = f"・人魂購入 {bought}回" if bought else ""
                await dm.update(
                    f"**{puni_daiko.kind_label(self.kind)}**\n"
                    f"挑戦中… {tries + 1:,}回目（取得 {count:,}体・撃破 {cleared:,}回{extra}）。"
                    "完凸するまで続けます")
        else:
            async def on_progress(cleared, target, sid):
                tgt = f"/{target:,}" if target else ""
                await dm.update(
                    f"🎯 **{puni_daiko.kind_label(self.kind)}**\n"
                    f"進行中… {cleared:,}{tgt} ステージ完了（現在地 {sid}）")
        return on_progress

    async def run(self, on_progress=None) -> dict:
        """代行だけを流して結果を返す(DM・売上・ログは finalize)。

        進捗はDMに随時流す(on_progress を渡さなければ内部でDM進捗を作る)。
        ログインできないときは PuniLoginError をそのまま投げる。
        """
        if self.user is not None and (self.user.id in _BUSY or self.user.id in _PENDING):
            raise Busy("すでに処理中です")
        if self.user is not None and _slots_full(self.user.id):
            raise Full("同時に回せる人数の上限です")
        if on_progress is None:
            on_progress = self._make_dm_progress()
        runner, self.runner = self.runner, None
        if self.user is not None:
            _BUSY.add(self.user.id)
        self._start_record()
        if _stop_requested(self.tx_id) or (self._prior or {}).get("stop_requested"):
            # 一時停止中・再開待ちの間に停止ボタンが押されていた。続きを回さずに、ここまでの
            # 結果で終える(申し出のファイルは、終わって控えを消すときに一緒に消える)。
            self.stop_event.set()
        if self._dm is not None and self.dm_message is not None:
            # 再開した旨は進捗DMに書かない(お客さんに裏側を見せない)。前の文に残っている
            # 添え書き(一時停止・以前の版の再開の知らせ)は adopt_existing で除かれる。
            self._dm.adopt_existing(self.dm_message)
        common = dict(on_progress=on_progress, runner=runner, stop_event=self.stop_event,
                      resume=self.resume_state, on_checkpoint=self._checkpoint,
                      suspend_event=_SUSPEND)
        outcome = None
        cancelled = False
        try:
            if self.kind == puni_daiko.KIND_MAIN:
                outcome = await puni_daiko.run_progress_main(
                    self.udkey, self.user_id, self.count, **common)
            elif self.kind == puni_daiko.KIND_EVENT:
                outcome = await puni_daiko.run_progress_event(
                    self.udkey, self.user_id, self.count, **common)
            elif self.kind in puni_daiko.BOSS_KINDS:
                outcome = await puni_daiko.run_hunt_boss(
                    self.udkey, self.user_id, self.stage_id,
                    until_max=self.kind == puni_daiko.KIND_BOSS_MAX, **common)
            else:
                outcome = await puni_daiko.run_farm(
                    self.udkey, self.user_id, self.stage_id, self.rounds, **common)
        except asyncio.CancelledError:
            # プロセスの終了で打ち切られた。控えは消さずに残し、次のプロセスが最後の
            # 途中経過から再開する(今の周の通信が残っているかもしれないので、一時停止の
            # 印は付けない。書いたプロセスが死んだと分かってから再開される)。
            cancelled = True
            raise
        finally:
            suspended = bool(outcome and outcome.get("suspended"))
            _WINDING.add(self.tx_id)
            try:
                if cancelled:
                    self._end_record("keep")
                elif suspended:
                    self._end_record("suspend", state=outcome.get("state"))
                else:
                    self._end_record("drop")
                if self._dm is not None and not cancelled:
                    self._dm.note = SUSPEND_NOTE if suspended else ""
                    await self._dm.finish()
            finally:
                _WINDING.discard(self.tx_id)
                self._release_busy()
        return outcome

    # ---- 走っている間の控え・見回り ----

    def _start_record(self):
        """走り出したことを控えに書く(0円の動作確認も含めて全部。進捗DMを出す前に)。

        再起動で落ちたとき、次のプロセスが「途中で止まった代行」として後始末する
        (_sweep_interrupted)。終われば _end_record で消す。
        """
        self.started_at = time.time()
        rec = dict(self._prior or {})   # 再開なら前の控え(開始時刻・進捗DMの場所・途中経過)を引き継ぐ
        rec.update({
            "tx_id": self.tx_id, "boot": BOOT_ID,
            "started_at": rec.get("started_at") or self.started_at,
            "segment_started_at": self.started_at,
            "user_id": self.user.id if self.user is not None else None,
            "kind": self.kind, "summary": self.summary(), "paid": self.paid,
            "admin_free": self.admin_free, "order_id": self.order_id,
            # 再開に要るもの(ログインし直すための udkey を含む。終われば控えごと消す)。
            "udkey": self.udkey, "puni_user_id": self.user_id,
            "stage_id": self.stage_id, "rounds": self.rounds, "count": self.count,
            "total_price": self.total_price, "method": self.method,
            "guild_id": self.guild.id if self.guild is not None else None,
            "order_channel_id": getattr(self.channel, "id", None),
            "pay_note": self.pay_note, "account": self.account,
            "state": rec.get("state") or {},
            "suspended": False,
        })
        # 再開を始められた。始められなかったときの印は片付ける。
        for key in ("next_try_at", "resume_failures", "first_failed_at", "last_resume_error"):
            rec.pop(key, None)
        self._record = rec
        _write_running(self.tx_id, self._record)
        _LIVE[self.tx_id] = self
        _RESUMING.discard(self.tx_id)

    def _checkpoint(self, state):
        """1周ごとの途中経過を控えに書く(落ちても、ここから再開する)。"""
        if self._record is None or not isinstance(state, dict):
            return
        self._record["state"] = state
        _write_running(self.tx_id, self._record)

    def _note_dm_message(self, msg):
        """進捗DMを初めて出せた。後始末で書き換えられるよう、控えに場所を足す。"""
        if self._record is None:
            return
        old_id = self._record.get("message_id")
        if old_id and str(old_id) != str(msg.id):
            # 再開で進捗DMを出し直した。古いほうの停止ボタンが押されても、この代行を引けるように。
            prior = [i for i in (self._record.get("prior_message_ids") or []) if i]
            self._record["prior_message_ids"] = (prior + [old_id])[-5:]
        self._record.update(channel_id=getattr(msg.channel, "id", None), message_id=msg.id)
        _write_running(self.tx_id, self._record)

    def _end_record(self, how: str = "drop", state=None):
        """走り終えた。how: drop=控えを消す / suspend=一時停止として残す(次のプロセスが
        すぐ再開する) / keep=そのまま残す(書いたプロセスが死んでから再開される)。"""
        _LIVE.pop(self.tx_id, None)
        if self._record is None:
            return
        self.last_record = dict(self._record)   # 最後の控え(再開した代行が落ちたときの知らせ用)
        if how == "suspend":
            if isinstance(state, dict) and state:
                self._record["state"] = state
            self._record.update(suspended=True, suspended_at=time.time())
            _write_running(self.tx_id, self._record)
            _release_claim(self.tx_id)    # 次のプロセスが再開の札を取れるように
        elif how == "drop":
            _drop_running(self.tx_id)
        self._record = None

    def _release_busy(self):
        """その人の「実行中」を外す。

        ゲーム通信のスレッドが戻らないまま終えた(puni_daiko が待つのをやめた)ときは、
        そのスレッドが終わるまで(最長 STUCK_THREAD_HOLD_SECONDS)外さない。古い token で
        通信しているスレッドがいる間に次の注文で入り直すと、両方がおかしくなる。
        """
        if self.user is None:
            return
        uid = self.user.id
        pending = puni_daiko.pending_game_calls(self.user_id) if self.user_id else []
        if not pending:
            _BUSY.discard(uid)
            return
        print(f"[PUNI] tx={self.tx_id} 戻らないゲーム通信が{len(pending)}件あるため、"
              "終わるまでこの人の次の代行を止めておきます", flush=True)

        async def later():
            try:
                done = await puni_daiko.wait_pending_game_calls(
                    self.user_id, STUCK_THREAD_HOLD_SECONDS)
                if not done:
                    print(f"[PUNI] tx={self.tx_id} 戻らないゲーム通信を"
                          f"{int(STUCK_THREAD_HOLD_SECONDS)}秒待ちましたが戻りません。"
                          "次の代行は受け付けます", flush=True)
            finally:
                _BUSY.discard(uid)

        _spawn(later())

    def last_progress_at(self) -> float:
        dm = self._dm
        if dm is not None:
            return max(dm.last_progress_at, self.started_at or 0.0)
        return self.started_at or time.time()

    def progress_text(self) -> str:
        return (self._dm.text if self._dm is not None else "") or ""

    def heartbeat(self):
        """見回り(毎分)。控えの進捗を書き足し、進みが止まっていないかを見る。

        戻り値は「止まっている」と新しく分かったときの止まっている秒数(知らせるのは1回だけ)。
        """
        text = self.progress_text()
        if self._record is not None and text != self._record_progress:
            self._record_progress = text
            self._record["progress"] = text[:500]
            _write_running(self.tx_id, self._record)
        now = time.time()
        if puni_daiko.global_hold_remaining() > 0:
            self._hold_seen_at = now      # 全体停止で待っているだけ。止まっているとは数えない
        last = max(self.last_progress_at(), self._hold_seen_at)
        idle = now - last
        if idle < STALL_SECONDS:
            self._stall_since = None
            return None
        if self._stall_since == last:
            return None                   # この止まり方はもう知らせた
        self._stall_since = last
        return idle

    async def finalize(self, outcome: dict) -> bool:
        """結果をDMし、売上・購入ロール・ログを出す。戻り値はDMできたか。"""
        embed = self.result_embed(outcome)
        try:
            await self.user.send(embed=embed)
            dm_ok = True
        except (discord.HTTPException, AttributeError):
            dm_ok = False

        # ここから先は代行そのものは終わっている。記録やログで失敗しても
        # 「渡せなかった」と判断させない(後追いの再試行で二重に走る)。
        await self._safe_async("売上の記録", self._record_sale)
        await self._safe_async("購入ロールの付与", grant_purchase_role,
                               self.guild, self.user.id if self.user else 0, self.paid)
        await self._safe_async("ログの送信", self.send_logs, outcome)
        return dm_ok

    async def execute(self, on_progress=None) -> tuple:
        """代行を流して結果をDMする。戻り値 (DMできたか, 結果)。

        アプリ版が古くて何も渡せずに止まったときは、DM・売上・ログを出さずに返す
        (版を合わせて流し直す余地がある。ここで出すと、流し直したときに DM も売上も
        二重になる)。流し直さないと決めた呼び出し側が finalize を呼ぶ。
        """
        outcome = await self.run(on_progress)
        if outcome.get("suspended"):
            # bot の更新で一時停止した。次のプロセスが続きから再開し、結果もそちらが
            # 最後にまとめて出す(ここで出すと、途中までの結果と最後の結果が二重になる)。
            return False, outcome
        if outcome.get("stale_version") and _nothing_delivered(self.kind, outcome):
            return False, outcome
        return await self.finalize(outcome), outcome

    def _record_sale(self):
        puni_daiko.record_sale(self.paid, self.user.id if self.user else 0,
                               kind=self.kind, stage_id=self.stage_id,
                               rounds=self.rounds, count=self.count,
                               method=self.method, tx_id=self.tx_id)

    async def _safe_async(self, step, fn, *args):
        try:
            result = fn(*args)
            if asyncio.iscoroutine(result):
                await result
        except Exception as e:
            log.exception("ぷにぷに代行の%sに失敗: %s", step, e)

    # ---- ログ ----

    async def send_logs(self, outcome: dict):
        """公開ログ(誰が何をいくらで買ったか)と非公開ログ(詳細つき)を送る。

        公開ログは他のお客さんの目にも入る。載せるのは注文内容・金額・
        取引番号だけにして、支払いリンクやアカウントの中身は出さない。
        """
        # 管理者の動作確認(0円)は公開ログに出さない(無料で買えたと誤読されるため)。
        pub = None if self.admin_free else log_channel_id()
        if pub:
            embed = discord.Embed(color=PUNI_COLOR)
            if self.user is not None:
                try:
                    embed.set_author(name=str(self.user),
                                     icon_url=self.user.display_avatar.url)
                except Exception:
                    embed.set_author(name=str(self.user))
            # 公開ログはシンプルに。サービス名だけ出し、ステージや周回数は伏せる。
            embed.add_field(name="内容", value=puni_daiko.kind_label(self.kind),
                            inline=False)
            embed.add_field(name="金額", value=f"¥{self.paid:,}", inline=False)
            embed.add_field(name="トランザクションID", value=self.tx_id, inline=False)
            await _send_log(self.bot, pub, "公開ぷにログ", embed=embed)

        prv = private_log_channel_id()
        if not prv:
            return
        embed = discord.Embed(title="非公開ぷにぷに代行ログ", color=PUNI_COLOR_PRIVATE,
                              timestamp=discord.utils.utcnow())
        u = self.user
        if u is not None:
            try:
                embed.set_thumbnail(url=u.display_avatar.url)
            except Exception:
                pass
            embed.add_field(
                name="購入者",
                value=(f"{u.mention}\nユーザー名: `{u}`\n"
                       f"表示名: `{getattr(u, 'display_name', u)}`\nID: `{u.id}`"),
                inline=False)
            created = getattr(u, "created_at", None)
            if created:
                embed.add_field(name="アカウント作成",
                                value=f"<t:{int(created.timestamp())}:f>", inline=True)
            joined = getattr(u, "joined_at", None)
            if joined:
                j = int(joined.timestamp())
                embed.add_field(name="サーバー参加",
                                value=f"<t:{j}:f>（<t:{j}:R>）", inline=True)
        embed.add_field(name="利用金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        embed.add_field(name="トランザクションID", value=f"`{self.tx_id}`", inline=True)
        if self.pay_note:
            embed.add_field(name="支払い情報", value=str(self.pay_note)[:1024], inline=False)
        if outcome.get("account") or self.account:
            embed.add_field(name="ぷにぷにのアカウント",
                            value=(outcome.get("account") or self.account)[:1024],
                            inline=False)
        embed.add_field(name="代行内容",
                        value=self.summary(), inline=False)
        embed.add_field(name="結果", value="\n".join(outcome.get("lines") or [])[:1024]
                        or "結果なし", inline=False)
        trace = outcome.get("trace") or []
        if trace:
            body = "\n".join(trace)
            embed.add_field(name="周回ごとの記録",
                            value=("```\n" + body[-980:] + "\n```"), inline=False)
        if self.guild is not None:
            place = self.guild.name
            if self.channel is not None:
                place += f" / {self.channel.mention}"
            embed.add_field(name="購入場所", value=place, inline=False)
        files = []
        if trace and len("\n".join(trace)) > 980:
            # 埋め込みには末尾しか入らない。全文はファイルで添える(途中の NG を追えるように)。
            try:
                files.append(discord.File(io.BytesIO("\n".join(trace).encode("utf-8")),
                                          filename=f"puni_trace_{self.tx_id}.txt"))
            except Exception as e:
                log.warning("周回ごとの記録を添付できません: %s", e)
        stage_diag = outcome.get("stage_diag")
        if stage_diag:
            # イベント進行: その垢のイベントのステージ表(ID|状態|…)と、表・裏とみなした会場。
            # 508 で弾かれたステージの欄がどうなっているかを確かめる材料。
            try:
                files.append(discord.File(io.BytesIO("\n".join(stage_diag).encode("utf-8")),
                                          filename=f"puni_stages_{self.tx_id}.txt"))
            except Exception as e:
                log.warning("ステージ表を添付できません: %s", e)
        diag = outcome.get("buy_diag")
        if diag:
            # 人魂の購入で何を投げてサーバが何を返したか(rc=100 の切り分け用)。
            # 埋め込みの欄には入らないので、ファイルで添付する。
            try:
                data = json.dumps(diag, ensure_ascii=False, indent=1,
                                  default=str).encode("utf-8")
                files.append(discord.File(
                    io.BytesIO(data), filename=f"puni_buy_{self.tx_id}.json"))
            except Exception as e:
                log.warning("人魂購入の記録を添付できません: %s", e)
        limit_diag = outcome.get("limit_diag")
        if limit_diag:
            # 強敵完凸: 取得のたびに、その妖怪の行が取得の前後でどう動いたか。どの欄が
            # 凸の数なのかを、実際の垢のデータで確かめるための材料。
            try:
                data = json.dumps(limit_diag, ensure_ascii=False, indent=1,
                                  default=str).encode("utf-8")
                files.append(discord.File(
                    io.BytesIO(data), filename=f"puni_limit_{self.tx_id}.json"))
            except Exception as e:
                log.warning("強敵完凸の記録を添付できません: %s", e)
        extra = {"files": files} if files else {}
        await _send_log(self.bot, prv, "非公開ぷにログ", embed=embed, **extra)

    async def send_trouble_log(self, reason: str):
        """「お代は受け取ったのに代行できなかった」ときのログ。"""
        if self.paid <= 0:
            return
        embed = discord.Embed(
            title="ぷにぷに代行に失敗しました(支払い済み)",
            description=("支払いは受け取れましたが、代行の処理が失敗しました。\n"
                         "手動で対応するか返金してください。"),
            color=0xff3333, timestamp=discord.utils.utcnow())
        if self.user is not None:
            embed.add_field(name="購入者", value=f"{self.user.mention}（`{self.user.id}`）",
                            inline=False)
        embed.add_field(name="受取済みの金額", value=f"{self.paid:,}円", inline=True)
        embed.add_field(name="支払い方法", value=self.method_note(), inline=True)
        embed.add_field(name="トランザクションID", value=f"`{self.tx_id}`", inline=True)
        embed.add_field(name="代行内容",
                        value=self.summary(), inline=False)
        if self.pay_note:
            embed.add_field(name="支払い情報", value=str(self.pay_note)[:1024], inline=False)
        embed.add_field(name="エラー", value=f"```{str(reason)[:500]}```", inline=False)
        embed.set_footer(text="返金または手動対応が必要です")

        for ch_id in (private_log_channel_id(), log_channel_id()):
            if ch_id and await _send_log(self.bot, ch_id, "ぷにのトラブルログ", embed=embed):
                break
        for uid in ADMIN_USER_IDS:
            try:
                admin = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                await admin.send(embed=embed)
            except Exception:
                continue


# --- 注文の下書き ----------------------------------------------------------

# 周回するステージをどう決めたか(確認画面の一言)。
HOW_NOTES = {
    "now": "注文前に最後に遊んだステージです。",
    "count": "最後に遊んだステージが読めなかったので、いちばん多くクリアしているステージを選びました。",
    "latest": "最後に遊んだステージが読めなかったので、最新のクリア済みステージを選びました。",
}
# 挑戦する強敵をどう決めたか(確認画面の一言)。
BOSS_HOW_NOTES = {
    "now": "注文前に最後にプレイした強敵ステージです。",
    "next": "今のイベントの裏マップ（強敵）で、次に挑む強敵です（クリア済みの続き）。",
    "last": "今のイベントの裏マップ（強敵）の、いちばん最後の強敵です（ここまでクリア済み）。",
}


class PuniOrder:
    """支払いが終わるまでの下書き。画面をまたいで持ち回る。

    周回(farm)は周回数だけ先に決め、ステージはログイン後に垢のデータから決める
    (puni_daiko.PuniRunner.pick_farm_stage)。イベント進行(event)は入力が無く、
    ログイン後に「今のイベントの現在地」を読んで、そこから最後まで進める。
    admin_free=True は管理者の動作確認(0円・売上/公開ログに出さない)。
    """

    def __init__(self, bot, user, kind=puni_daiko.KIND_FARM, *, stage_id=0, rounds=0,
                 count=0, admin_free=False):
        self.bot = bot
        self.user = user
        self.kind = kind
        self.stage_id = int(stage_id or 0)
        self.rounds = int(rounds or 0)
        self.count = int(count or 0)
        self.admin_free = bool(admin_free)
        self.total_price = 0 if admin_free else puni_daiko.price_for(
            kind, rounds=self.rounds, count=self.count)
        self.udkey = ""
        self.user_id = None             # ゲーム側のユーザーID
        self.account = ""
        self.method = payments.PAYPAY
        self._done = False              # 二重実行・二重払いの防止
        # ログイン後に分かるもの(保存しない)。
        self.states = {}                # stageId → state
        self.stage_how = None           # HOW_NOTES のキー(周回)
        self.event_no = None            # 進めるイベントの番号(イベント進行)
        self.deck_id = None             # 戦うデッキ(ゲームで選択中のデッキ番号)
        # 強敵完凸: この強敵で取れる妖怪のID(分かっていれば)と、それを持っているか。
        self.boss_youkai = None
        self.boss_owned = None          # True / False / None(分からない)

    def deck_line(self) -> str:
        """確認画面の「戦うデッキ」の一言。特性・スキルはこのデッキで決まる。"""
        deck = f"デッキ{self.deck_id}" if self.deck_id else "ゲームで選択中のデッキ"
        return (f"戦うデッキ: **{deck}**（ゲームで選択中のデッキ。Yポイントアップなどの"
                "特性・スキルはそのまま反映されます）")

    def summary(self) -> str:
        return puni_daiko.summary_for(self.kind, stage_id=self.stage_id,
                                      rounds=self.rounds, count=self.count)

    def payload(self) -> dict:
        """後追いで代行し直すのに要るもの。

        メールアドレスとパスワードは入れない。入れるのは udkey だけで、
        これは渡し終わった時点で消す(_scrub_token)。
        """
        return {"kind": self.kind, "stage_id": self.stage_id, "rounds": self.rounds,
                "count": self.count, "udkey": self.udkey, "puni_user_id": self.user_id,
                "total_price": int(self.total_price), "account": self.account,
                "admin_free": self.admin_free}

    def price_line(self) -> str:
        if self.admin_free:
            return "管理者の動作確認のため、お支払いはありません（売上にも入りません）。"
        if self.total_price > 0:
            if self.kind == puni_daiko.KIND_FARM:
                return (f"お支払い金額: {self.total_price:,}円"
                        f"（1周 {puni_daiko.get_price():,}円 × {self.rounds:,}周）")
            return f"お支払い金額: {self.total_price:,}円"
        return "お支払いはありません。"

    def confirm_embed(self) -> discord.Embed:
        """ログイン前の確認(内容と金額)。"""
        if self.kind == puni_daiko.KIND_BOSS_MAX:
            lines = ["ご注文内容", "・強敵完凸（強敵の妖怪が完凸するまで挑戦し続ける）", "",
                     self.price_line(), "",
                     "ログイン後に、挑戦する**強敵ステージ**を読み取り、次の画面でお見せします。",
                     "（最後にプレイした強敵ステージ。無ければ、今のイベントの裏マップで次に挑む強敵）",
                     "強敵の妖怪を取得しても止めず、完凸するまで自動で挑戦を繰り返します。",
                     "完凸かどうかは、取得のたびにゲームの妖怪のデータを見て判定します。",
                     "（人魂が足りなくなったときは、ワイマネーで自動購入して続けます）", "",
                     "下のボタンからログインしてください。",
                     "ログイン情報は保存しません。"]
        elif self.kind == puni_daiko.KIND_BOSS:
            lines = ["ご注文内容", "・強敵取得（強敵の妖怪を取得できるまで挑戦）", "",
                     self.price_line(), "",
                     "ログイン後に、挑戦する**強敵ステージ**を読み取り、次の画面でお見せします。",
                     "（最後にプレイした強敵ステージ。無ければ、今のイベントの裏マップで次に挑む強敵）",
                     "強敵ステージをクリア済みかどうかは問いません。強敵の妖怪が手に入るまで"
                     "自動で挑戦を繰り返し、取得できた時点で終了します。",
                     "（人魂が足りなくなったときは、ワイマネーで自動購入して続けます）", "",
                     "下のボタンからログインしてください。",
                     "ログイン情報は保存しません。"]
        elif self.kind == puni_daiko.KIND_EVENT:
            lines = ["ご注文内容", "・イベントステージ進行（現在地から最後まで）", "",
                     self.price_line(), "",
                     "ログイン後に、今進めているイベントの**現在地**を読み取り、"
                     "次の画面でお見せします。",
                     "そこから最後のステージ（裏ステージを含む）まで、順にクリアして進めます。",
                     "（人魂が足りなくなったときは、ワイマネーで自動購入して続けます）", "",
                     "下のボタンからログインしてください。",
                     "ログイン情報は保存しません。"]
        else:
            lines = ["ご注文内容", f"・ステージ周回 {self.rounds:,}周", "",
                     self.price_line(), "",
                     "周回するステージは、ログイン後に**最後に遊んだステージ**を自動で選び、"
                     "次の画面でお見せします。",
                     "（周回したいステージをゲームで一度プレイ（クリアかリタイア）してから"
                     "進んでください）", "",
                     "下のボタンからログインしてください。",
                     "ログイン情報は保存しません。"]
        return discord.Embed(title="ご注文内容", description="\n".join(lines),
                             color=PUNI_COLOR)

    def stage_embed(self) -> discord.Embed:
        """ログイン後の確認(どのステージを何周・いくら / どこから進めるか / どの強敵か)。"""
        if self.kind in puni_daiko.BOSS_KINDS:
            state = self.states.get(self.stage_id)
            cleared = ("クリア済み" if state == 1 else
                       "開放済み・未クリア" if state == 2 else "")
            until = ("強敵の妖怪が完凸するまで挑戦を繰り返し、完凸した時点で終了します。"
                     if self.kind == puni_daiko.KIND_BOSS_MAX else
                     "強敵の妖怪を取得できるまで挑戦を繰り返し、取得した時点で終了します。")
            owned = None
            if self.kind == puni_daiko.KIND_BOSS_MAX and self.boss_owned:
                # ここまで来たら持っていると確かめてある(確かめられなければ前で断っている)。
                owned = f"この強敵の妖怪（ID {self.boss_youkai}）を持っていることを確認しました。"
            lines = [self.account, "",
                     f"挑戦する強敵: **{puni_stages.describe(self.stage_id)}**"
                     + (f"　{cleared}" if cleared else ""),
                     BOSS_HOW_NOTES.get(self.stage_how, ""),
                     until,
                     owned,
                     self.deck_line(), "",
                     self.price_line(), "",
                     "この強敵でよければ、下のボタンから進んでください。",
                     "違う強敵に挑戦したいときは、ゲームでその強敵ステージを一度プレイ"
                     "（クリアかリタイア）してから、注文し直してください。"]
            return discord.Embed(title="挑戦する強敵の確認",
                                 description="\n".join(l for l in lines if l is not None),
                                 color=PUNI_COLOR)
        if self.kind == puni_daiko.KIND_EVENT:
            lines = [self.account, "",
                     f"進めるイベント: **イベント{self.event_no}**",
                     f"現在地: **{puni_stages.describe(self.stage_id)}**",
                     "ここから最後のステージ（裏ステージを含む）まで進めます。",
                     self.deck_line(), "",
                     self.price_line(), "",
                     "よければ、下のボタンから進んでください。"]
            return discord.Embed(title="進めるイベントの確認",
                                 description="\n".join(lines), color=PUNI_COLOR)
        state = self.states.get(self.stage_id)
        cleared = "クリア済み" if state == 1 else ("開放済み・未クリア" if state == 2 else "")
        lines = [self.account, "",
                 f"周回するステージ: **{puni_stages.describe(self.stage_id)}**"
                 + (f"　{cleared}" if cleared else ""),
                 HOW_NOTES.get(self.stage_how, ""),
                 f"周回数: {self.rounds:,}周",
                 self.deck_line(), "",
                 self.price_line(), "",
                 "このステージでよければ、下のボタンから進んでください。",
                 "違うステージを周回したいときは、ゲームでそのステージを一度プレイ"
                 "（クリアかリタイア）してから、注文し直してください。"]
        return discord.Embed(title="周回するステージの確認",
                             description="\n".join(l for l in lines if l is not None),
                             color=PUNI_COLOR)


class PuniOrderModal(ui.Modal, title="ステージ周回のご注文"):
    """周回数だけ聞く。ステージはログイン後に自動で決める。"""

    rounds = ui.TextInput(label="周回数", placeholder="例: 100", required=True,
                          max_length=6)

    def __init__(self, bot, admin_free: bool = False):
        super().__init__(timeout=600)
        self.bot = bot
        self.admin_free = admin_free
        unit = puni_daiko.get_price()
        self.rounds.label = f"周回数（1〜{puni_daiko.get_max_rounds():,} / 1周{unit:,}円）"[:45]

    async def on_submit(self, interaction: discord.Interaction):
        if self.admin_free and interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        rounds_raw = self.rounds.value.strip().replace(",", "").replace("，", "")
        rounds_raw = rounds_raw.translate(str.maketrans("０１２３４５６７８９", "0123456789"))
        if not rounds_raw.isdigit() or int(rounds_raw) <= 0:
            return await interaction.response.send_message(
                "周回数は1以上の半角数字で入力してください。", ephemeral=True)
        rounds = int(rounds_raw)
        cap = puni_daiko.get_max_rounds()
        if rounds > cap:
            return await interaction.response.send_message(
                f"周回数は{cap:,}回までで指定してください。", ephemeral=True)
        order = PuniOrder(self.bot, interaction.user, puni_daiko.KIND_FARM,
                          rounds=rounds, admin_free=self.admin_free)
        await interaction.response.send_message(
            embed=order.confirm_embed(), view=OrderView(order), ephemeral=True)


class OrderView(ui.View):
    """注文内容の確認画面。ログインボタンから先へ進む。"""

    def __init__(self, order: PuniOrder):
        super().__init__(timeout=600)
        self.order = order

    @ui.button(label="ログインして進む", style=discord.ButtonStyle.success)
    async def login(self, interaction: discord.Interaction, button: ui.Button):
        if self.order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        await interaction.response.send_modal(PuniLoginModal(self.order))


NO_STAGE_TEXT = ("周回できるステージが見つかりませんでした。\n"
                 "周回したいステージをゲームで一度プレイ（クリアかリタイア）してから、"
                 "もう一度お試しください。\n"
                 "お代はいただいていません。")
NO_EVENT_TEXT = ("進めるイベントが見つかりませんでした。\n"
                 "イベントのステージをゲームで一度開いて（1ステージ目に入って）から、"
                 "もう一度お試しください。\n"
                 "お代はいただいていません。")
ALL_CLEARED_TEXT = ("イベント{event_no}は、このアカウントではすでに最後までクリア済みです"
                    "（進めるステージがありません）。\n"
                    "裏マップなど、まだ進めていないマップが残っている場合は、ゲームでそのマップを"
                    "一度開いて（1ステージ目に入って）から、もう一度お試しください。\n"
                    "お代はいただいていません。")
NO_BOSS_TEXT = ("挑戦できる強敵ステージが見つかりませんでした。\n"
                "今のイベントの裏マップ（強敵）のステージを、ゲームで一度プレイ"
                "（クリアかリタイア）してから、もう一度お試しください。\n"
                "お代はいただいていません。")
BOSS_LOCKED_TEXT = ("強敵ステージ {stage} は、このアカウントではまだ開放されていません"
                    "（裏マップ(強敵)が未解放・ロック中）。\n"
                    "ゲームで裏マップ(強敵)を開放して、強敵ステージを一度プレイしてから、"
                    "もう一度お試しください。\n"
                    "お代はいただいていません。")
SERVER_DOWN_TEXT = ("ゲームのサーバに接続できませんでした（サーバ側の応答: {detail}）。\n"
                    "メールアドレス・パスワードの問題ではありません。\n"
                    "サーバが混み合っているか、一時的にこちらからの接続を受け付けて"
                    "いない状態です。10分ほど時間をおいてから、もう一度お試しください。\n"
                    "お代はいただいていません。")
STALE_LOGIN_TEXT = ("ゲームの更新に合わせている途中です（{detail}）。\n"
                    "メールアドレス・パスワードの問題ではありません。\n"
                    "数分ほど時間をおいてから、もう一度お試しください。\n"
                    "お代はいただいていません。")
# お代は受け取ったのに、その場では代行を始められなかったとき(見張りに預けたとき)の案内。
HANDED_OVER_TEXT = ("**お代は受け取っています。**追加のお支払いは不要です。\n"
                    "準備ができ次第こちらで自動的に代行を開始し、結果をDMでお知らせします。")


class PuniLoginModal(ui.Modal):
    """L5(レベルファイブ)のログイン情報。ここで受け取るだけで保存しない。"""

    email = ui.TextInput(label="メールアドレス",
                         placeholder="example@example.com", required=True, max_length=200)
    password = ui.TextInput(label="パスワード", style=discord.TextStyle.short,
                            required=True, max_length=200)

    def __init__(self, order: PuniOrder):
        super().__init__(title="ぷにぷにのログイン", timeout=300)
        self.order = order

    async def on_submit(self, interaction: discord.Interaction):
        order = self.order
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        if (interaction.user.id in _BUSY or interaction.user.id in _PENDING
                or interaction.user.id in _RELOGIN_BUSY):
            # 「ログインし直す」で同じ垢へ入り直している最中に画面からも入ると、連携が2回走る。
            return await interaction.response.send_message(
                "すでに処理中です。終わってからもう一度お試しください。", ephemeral=True)

        _BUSY.add(interaction.user.id)
        await interaction.response.send_message("ログインしています。", ephemeral=True)
        try:
            runner = await puni_daiko.login_with_email(
                self.email.value, self.password.value)
            order.udkey = runner.udkey
            order.user_id = runner.user_id
            order.account = runner.account_line()
            order.states = runner.client.stage_states()
            order.deck_id = runner.client.active_deck_id
            # 受け取ってから「回せません」「進められません」にならないよう、
            # お代の前に、どこを回す/どこから進めるかを決める。
            if order.kind == puni_daiko.KIND_EVENT:
                event_no = runner.current_event()
                start = (runner.event_resume_point(event_no)
                         if event_no is not None else None)
                if start is None:
                    return await _fail(interaction, NO_EVENT_TEXT)
                if runner.event_remaining(event_no) <= 0:
                    # 表の上では全部クリア済み。進めるものが無いのにお代は取らない。
                    # (未開放 state=0 のステージが残っているだけの垢は断らない。表に載っていない
                    # 続き(強敵の先の通常ステージなど)が進められることがあるため。)
                    return await _fail(interaction,
                                       ALL_CLEARED_TEXT.format(event_no=event_no))
                order.event_no = event_no
                order.stage_id = int(start)      # 現在地(進め始めるステージ)
            elif order.kind in puni_daiko.BOSS_KINDS:
                target = runner.boss_target()
                if not target.get("stage_id"):
                    return await _fail(interaction, NO_BOSS_TEXT)
                if target.get("locked"):
                    # 表でロック(0)か、裏マップ(強敵)を一度も開いていない(表に強敵が無い)。
                    # 入れないステージにお代は取らない。走ってからも rc=5 で止まるが、
                    # ここで断るのが本筋(お代の前)。
                    return await _fail(interaction, BOSS_LOCKED_TEXT.format(
                        stage=puni_stages.describe(target["stage_id"])))
                order.event_no = target.get("event_no")
                order.stage_id = int(target["stage_id"])
                order.stage_how = target.get("how")
                if order.kind == puni_daiko.KIND_BOSS_MAX:
                    # 強敵完凸は持っている妖怪を完凸させるメニュー。ログインのこの時点で
                    # 持っていると確かめられたときだけ進める。取れる妖怪を覚えていない・
                    # 持ち物が読めない・持っていない、のどれでも挑戦の前(お代の前)に断る。
                    block, order.boss_youkai, _ = runner.boss_max_block(order.stage_id)
                    if block:
                        return await _fail(interaction, block)
                    order.boss_owned = True
            else:
                pick = runner.pick_farm_stage()
                if not pick.get("stage_id"):
                    return await _fail(interaction, NO_STAGE_TEXT)
                order.stage_id = int(pick["stage_id"])
                order.stage_how = pick.get("how")
        except puni_daiko.PuniServerError as e:
            # サーバに繋がらない/拒まれた。メール・パスワードの話ではないので、
            # 「確認してください」とは言わない(合っているのに入れ直させることになる)。
            return await _fail(interaction, SERVER_DOWN_TEXT.format(detail=str(e)[:200]))
        except puni_daiko.PuniStaleVersionError as e:
            # アプリ版が古くて弾かれた。これもメール・パスワードの話ではない。版を合わせに
            # 行き(裏で)、少し待ってからやり直してもらう。
            _spawn(_auto_update_version(interaction.client))
            return await _fail(interaction, STALE_LOGIN_TEXT.format(detail=str(e)[:200]))
        except puni_daiko.PuniLoginError as e:
            return await _fail(
                interaction,
                f"ログインに失敗しました。\n```{str(e)[:300]}```\n"
                "メールアドレスとパスワードをご確認のうえ、もう一度お試しください。")
        except Exception as e:
            return await _fail(
                interaction,
                f"ログインに失敗しました: {type(e).__name__}: {str(e)[:200]}\n"
                "時間をおいてもう一度お試しください。")
        finally:
            _BUSY.discard(interaction.user.id)

        try:
            await interaction.edit_original_response(
                content=None, embed=order.stage_embed(), view=StageConfirmView(order))
        except discord.HTTPException:
            try:
                await interaction.followup.send(
                    embed=order.stage_embed(), view=StageConfirmView(order), ephemeral=True)
            except discord.HTTPException:
                pass


async def _fail(interaction: discord.Interaction, text: str):
    try:
        await interaction.edit_original_response(content=text, attachments=[],
                                                 embed=None, view=None)
    except discord.HTTPException:
        pass


class StageConfirmView(ui.View):
    """ログイン後の確認画面。よければ支払い(0円なら実行)へ。

    ステージの選び直しや ID の手入力は置かない。周回するステージは「注文前に
    最後に遊んだステージ」で決まりで、違うなら注文し直してもらう。選択肢を
    並べると、押す前に迷わせるだけだった。
    """

    def __init__(self, order: PuniOrder):
        super().__init__(timeout=600)
        self.order = order
        if order.total_price <= 0:
            label = "無料で実行する（管理者）"
        else:
            label = "お支払いへ進む"
        go = ui.Button(label=label, style=discord.ButtonStyle.success)
        go.callback = self._go
        self.add_item(go)

    async def interaction_check(self, interaction: discord.Interaction) -> bool:
        if self.order.user is not None and interaction.user.id != self.order.user.id:
            await interaction.response.send_message("この注文は他の方のものです。",
                                                    ephemeral=True)
            return False
        return True

    async def _go(self, interaction: discord.Interaction):
        if self.order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        await _to_payment(interaction, self.order)


async def _edit_screen(interaction: discord.Interaction, **kwargs):
    """確認画面(ボタン押下)の続きとして、同じメッセージを書き換える。"""
    if not interaction.response.is_done():
        await interaction.response.edit_message(**kwargs)
    else:
        await interaction.edit_original_response(**kwargs)


async def _to_payment(interaction: discord.Interaction, order: PuniOrder):
    """ステージが決まった。0円ならそのまま実行、有料なら支払い方法を選ばせる。"""
    if order.total_price <= 0:
        # 0円の道(管理者の動作確認)は押した人が管理者かここでも確かめる。
        if order.admin_free and interaction.user.id not in ADMIN_USER_IDS:
            return await _edit_screen(interaction, content="権限がありません。",
                                      embed=None, view=None)
        order._done = True
        await _edit_screen(interaction,
                           content="代行を実行しています。少々お待ちください。",
                           embed=None, view=None)
        return await run_now(interaction, order, paid=0,
                             method=payments.FREE, pay_note=None)

    if not payments.available_methods():
        return await _edit_screen(
            interaction,
            content="現在ご利用いただける支払い方法がありません。\n" + support.contact_line(),
            embed=None, view=None)

    note = [order.account, "", "ご注文内容", f"・{order.summary()}"]
    embed = payments.picker_embed(
        order.total_price, title="お支払い方法の選択", note="\n".join(note))
    await _edit_screen(interaction, content=None, embed=embed,
                       view=payments.MethodPicker(_make_method_picker(order)))


def _make_method_picker(order: PuniOrder):
    async def on_pick(interaction: discord.Interaction, method_id: str):
        if order._done:
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        order.method = method_id
        return await interaction.response.send_modal(PuniPaymentModal(order, method_id))

    return on_pick


class PuniPaymentModal(ui.Modal):
    """リンク方式(PayPay / Kyash)の支払い入力。"""

    def __init__(self, order: PuniOrder, method: str):
        m = payments.method(method)
        super().__init__(title=f"お支払い（{m.label}）"[:45])
        self.order = order
        self.method = method
        self.link = ui.TextInput(
            label=f"{m.label}リンク（{order.total_price:,}円）"[:45],
            placeholder=m.placeholder, required=True)
        self.add_item(self.link)
        self.link_pw = None
        if method == payments.PAYPAY:
            self.link_pw = ui.TextInput(label="リンクのパスワード（なければ空欄）",
                                        required=False)
            self.add_item(self.link_pw)

    async def on_submit(self, interaction: discord.Interaction):
        """支払いの受け取りから代行まで。試行の記録は必ず開いて必ず閉じる。"""
        order = self.order
        if order._done or getattr(order, "_paying", False):
            # 支払い方法の選択を2回押して画面を2つ開き、両方から送った等。受け取りは
            # 1回きりなので、先に進んでいるほうに任せる。
            return await interaction.response.send_message("既に処理を開始しています。",
                                                           ephemeral=True)
        order._paying = True
        attempt = await payment_attempts.record_async(
            KIND, interaction.user.id, amount=int(order.total_price), method=self.method,
            link=self.link.value.strip(), summary=order.summary(),
            guild_id=interaction.guild.id if interaction.guild else None,
            channel_id=interaction.channel.id if interaction.channel else None,
            payload=order.payload())
        hold = None
        try:
            # 同じリンクを見張り(または別の画面)が持っていないか先に確かめる。
            # ここを通さずに受け取ると、入金1回で代行が2回走る。
            hold = await payments.hold_link_for(
                interaction, KIND, self.link.value.strip(), attempt)
            if hold is None:
                return
            await self._submit(interaction, attempt)
        finally:
            order._paying = False
            await payment_attempts.finish_async(attempt)
            await link_orders.release_link(hold)

    async def _submit(self, interaction: discord.Interaction, attempt: str):
        order = self.order
        await interaction.response.defer(ephemeral=True, thinking=True)
        passcode = (self.link_pw.value.strip() or None) if self.link_pw else None

        async def notify_pending(deadline: float):
            await notify_payment_pending(
                interaction, deadline, amount=order.total_price,
                title="ぷにぷに代行のお支払いが保留中です",
                detail=f"承認され次第、自動で代行（{order.summary()}）を開始します。",
                footer="承認が遅れても、確認でき次第そのまま自動で代行します",
                ephemeral_hint="DMを確認して、「承認する」を押してください。承認され次第、代行を開始します。",
                app_name=payments.method_label(self.method))

        state = {}
        try:
            paid = await payments.receive_link_payment(
                self.method, self.link.value.strip(), passcode=passcode,
                min_amount=order.total_price, on_pending=notify_pending,
                client=interaction.client, state=state)
        except payments.PaymentNotRegistered as e:
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await interaction.followup.send(str(e), ephemeral=True)
        except payments.PaymentError as e:
            # 決着しなかった。リンクがまだ生きている(保留・承認待ち・通信不良)なら
            # 注文を捨てずに見張りへ渡す。ここで捨てると、あとから承認されたお金
            # だけがこちらに入って代行が走らない事故になる。
            if getattr(e, "watchable", False) and await self._watch_pending(interaction, e):
                await payment_attempts.resolve_async(attempt, payment_attempts.WATCHING, str(e))
                return
            if getattr(e, "accepted", False):
                job = self._job(interaction, paid=int(order.total_price), pay_note=None)
                await job.send_trouble_log(
                    "受け取りのリクエストは送信済みですが、見張りに載せられませんでした。"
                    f"{getattr(e, 'watch_note', '') or e} "
                    "入金されていれば、手動で代行するか返金してください。")
                await payment_attempts.resolve_async(
                    attempt, payment_attempts.DROPPED,
                    f"受け取り送信済みだが見張りに載せられず: {getattr(e, 'watch_note', '') or e}")
                return await interaction.followup.send(
                    str(e) if isinstance(e, payments.PaymentUnsure) else
                    ("受け取りのリクエストは送信済みですが、処理を完了できませんでした。\n"
                     "**お代をいただいている可能性があります。もう一度支払わないでください。**\n"
                     "こちらで確認して対応します。\n" + support.contact_line()),
                    ephemeral=True)
            if isinstance(e, payments.PaymentAuthError):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
                return await interaction.followup.send(str(e), ephemeral=True)
            if isinstance(e, payments.PaymentPending):
                await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, "承認されませんでした")
                return await interaction.followup.send(
                    "支払いがまだ承認されていません。PayPayアプリで承認してから、もう一度お試しください。",
                    ephemeral=True)
            await payment_attempts.resolve_async(attempt, payment_attempts.REJECTED, str(e))
            return await interaction.followup.send(
                f"支払いを確認できませんでした。\n```{e}```\n"
                "**お代はいただいていません。** もう一度お試しいただくか、\n"
                + support.contact_line(), ephemeral=True)

        await payment_attempts.resolve_async(attempt, payment_attempts.DELIVERED, f"{paid:,}円")
        # このリンクのお金はここで受け取った。同じリンクを持っている見張りが
        # あれば畳む(畳まないと、見張りが同じ入金でもう一度代行を走らせる)。
        try:
            for closed in await link_orders.record_screen_receipt(
                    KIND, interaction.user.id, self.link.value.strip(), paid=paid,
                    method=self.method, summary=order.summary(),
                    guild_id=interaction.guild.id if interaction.guild else None,
                    channel_id=interaction.channel.id if interaction.channel else None):
                log.info("同じリンクの見張りを畳みました: %s", closed.get("id"))
        except Exception as e:
            log.warning("ぷにの受け取り記録に失敗: %s", e)
        # 買い直しで置き去りになった見張りを畳む。
        try:
            for closed in await link_orders.cancel_superseded(
                    interaction.user.id, KIND, int(order.total_price)):
                log.info("ぷにの注文を畳みました: %s", closed.get("id"))
        except Exception as e:
            log.warning("ぷにの見張り整理に失敗: %s", e)

        try:
            await interaction.followup.send(
                f"{paid:,}円を受け取りました。代行を開始します。", ephemeral=True)
        except discord.HTTPException:
            pass
        await run_now(interaction, order, paid=paid, method=self.method,
                      pay_note=self.link.value.strip()[:200],
                      link=self.link.value.strip(), passcode=passcode)

    def _job(self, interaction, *, paid: int, pay_note) -> PuniJob:
        order = self.order
        return PuniJob(interaction.client, interaction.user, order.udkey, order.user_id,
                       order.kind, stage_id=order.stage_id, rounds=order.rounds,
                       count=order.count, total_price=order.total_price,
                       paid=paid, method=self.method, guild=interaction.guild,
                       channel=interaction.channel, pay_note=pay_note,
                       account=order.account, admin_free=order.admin_free)

    async def _watch_pending(self, interaction: discord.Interaction, error) -> bool:
        """決着しなかった支払いを見張りに引き継ぐ。引き継げたら True。"""
        order = self.order
        if self.method != payments.PAYPAY:
            error.watch_note = "PayPay以外は後追いの見張りに対応していません。"
            return False
        accepted = bool(getattr(error, "accepted", False))
        try:
            watched = await link_orders.create_order(
                KIND, interaction.user.id, self.link.value.strip(),
                amount_jpy=int(order.total_price), payload=order.payload(),
                method=self.method, minutes=WATCH_MINUTES,
                passcode=(self.link_pw.value.strip() or None) if self.link_pw else None,
                accepted=accepted, summary=order.summary(),
                guild_id=interaction.guild.id if interaction.guild else None,
                channel_id=interaction.channel.id if interaction.channel else None)
        except Exception as e:
            log.warning("ぷにの見張り登録に失敗: %s", e)
            error.watch_note = f"見張りへの登録に失敗しました: {str(e)[:150]}"
            return False
        if not watched:
            error.watch_note = "見張りへの登録に失敗しました。"
            return False

        order._done = True
        if accepted:
            text = ("PayPayアプリに「◯◯さんへの送金が保留になっています」と出ています。\n"
                    "**「承認する」を押してください。**\n"
                    "※ **「キャンセル」を押すと送金が失敗してお金が戻り、代行は始まりません。**\n"
                    "**承認が確認でき次第、自動で代行してDMでお知らせします**。")
        else:
            text = ("まだ承認が確認できていません。PayPayアプリに保留の案内が出ていれば"
                    "**「承認する」**を押してください。\n"
                    "※ **「キャンセル」を押すと送金が失敗します。**\n"
                    "**承認され次第、自動で代行してDMでお知らせします**。\n"
                    "支払い直す必要はありません。")
        try:
            await interaction.user.send(f"{text}\n注文番号: `{watched['id']}`")
            dm_note = ""
        except discord.HTTPException:
            dm_note = support.DM_CLOSED_NOTE
        try:
            await interaction.followup.send(f"{text}\n注文番号: `{watched['id']}`{dm_note}",
                                            ephemeral=True)
        except discord.HTTPException:
            pass
        return True


async def _notify_version_update(bot, before: str, after: str):
    """アプリバージョンを自動更新したことを管理者に知らせる。"""
    embed = discord.Embed(
        title="ぷにぷにのバージョンを自動更新しました",
        description=(f"ぷにぷにの更新を検知したので、代行で使うバージョンを切り替えました。\n\n"
                     f"**{before}** → **{after}**\n\n"
                     "次の代行から新しいバージョンで動きます。再デプロイは不要です。"),
        color=PUNI_COLOR)
    for uid in ADMIN_USER_IDS:
        try:
            user = bot.get_user(uid) or await bot.fetch_user(uid)
            await user.send(embed=embed)
        except Exception:
            continue


async def _auto_update_version(bot) -> dict:
    """App Storeの最新版を見て、必要なら切り替える。更新したら管理者へ知らせる。"""
    result = await asyncio.to_thread(puni_daiko.check_and_update_app_version)
    if result.get("updated"):
        await _notify_version_update(bot, result.get("before"), result.get("latest"))
    return result


async def _run_with_version_retry(bot, job: PuniJob, run_once, kind: str) -> tuple:
    """代行を流し、アプリ版が古くて弾かれたら最新版に合わせて1度だけ流し直す。

    ログインで弾かれた(PuniStaleVersionError)ときも、周回の途中で弾かれた(結果の
    stale_version)ときも同じ。合わせても弾かれるなら、周回の結果はそのまま
    (DM・売上・ログを出して)返し、ログインの失敗はそのまま投げる(呼び出し側が
    見張りに預けるか人に引き継ぐ)。
    """
    updated = False
    try:
        dm_ok, outcome = await run_once()
    except puni_daiko.PuniStaleVersionError:
        res = await _auto_update_version(bot)
        if not res.get("updated"):
            raise
        updated = True
        dm_ok, outcome = await run_once()
    if outcome.get("stale_version") and _nothing_delivered(kind, outcome):
        if not updated:
            res = await _auto_update_version(bot)
            if res.get("updated"):
                dm_ok, outcome = await run_once()
        if outcome.get("stale_version") and _nothing_delivered(kind, outcome):
            # 合わせても弾かれる(または新しい版が見つからない)。結果はここで伝える。
            dm_ok = await job.finalize(outcome)
    return dm_ok, outcome


async def run_now(interaction: discord.Interaction, order: PuniOrder, *,
                  paid: int, method: str, pay_note, link: str = None, passcode: str = None):
    """支払いが済んだ(または0円の)注文をその場で流す。

    その場で始められなかった(サーバに拒まれた・その人の別の代行が走っている・
    アプリ版が古い)有料の注文は、見張り(link_orders)に「受け取り済み」で預けて、
    次の巡回から自動で流し直す。お代を受け取った注文を「もう一度お試しください」で
    終わらせない(お客さんに二重に払わせる原因になる)。
    """
    order._done = True
    job = PuniJob(interaction.client, interaction.user, order.udkey, order.user_id,
                  order.kind, stage_id=order.stage_id, rounds=order.rounds,
                  count=order.count, total_price=order.total_price, paid=paid,
                  method=method, guild=interaction.guild, channel=interaction.channel,
                  pay_note=pay_note, account=order.account, admin_free=order.admin_free)
    guild_id = interaction.guild.id if interaction.guild else None
    channel_id = interaction.channel.id if interaction.channel else None

    # 進捗は job.execute が内部でDMに流す(長時間かかるため)。画面側は開始案内だけ。
    try:
        await interaction.edit_original_response(
            content="代行を実行しています。進捗はDMでお知らせします。少々お待ちください。",
            attachments=[], embed=None, view=None)
    except discord.HTTPException:
        pass

    # お代を受け取った注文は、走らせる前に見張りの台帳にも残す(状態は「お渡し済み」・
    # 走り出した印つき)。再デプロイなどで途中で落ちても、起動時の点検
    # (_report_interrupted_jobs)が拾って人に知らせる。その場で始められなかったときは
    # この記録を「受け取り済み」に戻して、見張りに流し直してもらう。
    record = None
    if paid > 0 and link:
        try:
            record = await link_orders.create_settled_order(
                KIND, interaction.user.id, link, paid=int(paid),
                payload={**order.payload(), "run_started_at": time.time()},
                method=method, passcode=passcode, summary=order.summary(),
                guild_id=guild_id, channel_id=channel_id, note="画面から実行中",
                status=link_orders.DONE)
            # 走っている代行の控えにも注文番号を載せる(再起動で落ちたときの後始末が、
            # この注文に「知らせ済み」の印を付けて二重に知らせないため)。
            job.order_id = record.get("id")
        except Exception as e:
            log.warning("ぷにの注文を台帳に残せませんでした: %s", e)

    async def close_record(status: str, note: str = "", finished: bool = False,
                           keep_mark: bool = False) -> bool:
        """台帳の記録を閉じる。書けたら True。

        finished=True: 終わった時刻を残し udkey を手放す。keep_mark=True: 途中で落ちた
        かもしれないので走り出した印を残す(手で流し直したときに offline_deliver が止める)。
        それ以外: ゲームに何も投げていないので印を戻す。
        """
        if record is None:
            return False
        payload = dict(record.get("payload") or {})
        if finished:
            payload.update(udkey="", finished_at=time.time())
        elif not keep_mark:
            payload.pop("run_started_at", None)
        try:
            updated = await link_orders.mark_order(record["id"], status, note=str(note)[:300],
                                                   payload=payload)
        except Exception as e:
            log.warning("ぷにの台帳を更新できませんでした(%s): %s", record.get("id"), e)
            return False
        return updated is not None

    async def run_once():
        return await job.execute()

    async def hand_over(reason: str) -> bool:
        """お代は受け取ったがその場で流せなかった注文を、見張りに預ける。預けられたら True。"""
        nonlocal record
        if paid <= 0 or not link:
            return False
        if record is not None:
            if not await close_record(link_orders.PAID, note=reason):
                # 台帳に書けなかった(見張りは拾えない)。預けたと言わず、人に引き継ぐ側へ。
                log.warning("ぷにの注文を見張りに預けられませんでした(%s)", record.get("id"))
                return False
        else:
            try:
                record = await link_orders.create_settled_order(
                    KIND, interaction.user.id, link, paid=int(paid), payload=order.payload(),
                    method=method, passcode=passcode, summary=order.summary(),
                    guild_id=guild_id, channel_id=channel_id, note=reason)
            except Exception as e:
                log.warning("ぷにの注文を見張りに預けられませんでした: %s", e)
                return False
        log.info("ぷにの注文を見張りに預けました(%s): %s", record.get("id"), reason)
        text = (f"代行をすぐには始められませんでした（{reason[:120]}）。\n{HANDED_OVER_TEXT}\n"
                f"注文番号: `{record.get('id')}`")
        try:
            await interaction.user.send(text)
        except discord.HTTPException:
            pass
        await _tell(interaction, text)
        return True

    async def give_up(title: str, log_reason: str, *, started: bool = False):
        """人に引き継ぐ(トラブルログ)。本人には画面、駄目なら DM で伝える。

        started=True は「ログインは通っていて、何周か回った後かもしれない」失敗。台帳の
        走り出した印を残し、手で流し直したときに済んだ分を二重に回さないようにする。
        """
        await close_record(link_orders.FAILED, note=log_reason, keep_mark=started)
        await job.send_trouble_log(log_reason)
        embed = support.trouble_embed(
            support.NEEDS_SUPPORT, title,
            support.PAID_AND_STUCK if paid > 0 else "時間をおいてもう一度お試しください。",
            amount=paid or None, summary=order.summary(),
            order_id=record.get("id") if record else None)
        if not await _tell_embed(interaction, embed):
            await _dm_stuck(interaction.user, summary=order.summary(), paid=paid,
                            order_id=record.get("id") if record else None)

    try:
        dm_ok, outcome = await _run_with_version_retry(
            interaction.client, job, run_once, order.kind)
    except Busy as e:
        full = isinstance(e, Full)
        if await hand_over(f"同時に回せる人数の上限({MAX_CONCURRENT}人)のため順番待ち" if full
                           else "別の代行を実行中のため"):
            return
        if paid > 0:
            # お代は受け取っているのに預けられなかった。人に引き継ぐ。
            return await give_up("代行を始められませんでした",
                                 "別の代行の実行中(または混雑)で始められず、見張りにも預けられませんでした")
        return await _tell(interaction,
                           "ただいま混み合っています。しばらくしてからもう一度お試しください。" if full
                           else "すでに処理中です。終わってからもう一度お試しください。")
    except puni_daiko.PuniServerError as e:
        # サーバの都合。お代を受け取っていれば見張りに預けて自動で流し直す。
        if await hand_over(f"ゲームのサーバに接続できないため: {str(e)[:100]}"):
            return
        if paid <= 0:
            return await _tell(interaction, SERVER_DOWN_TEXT.format(detail=str(e)[:200]))
        return await give_up("ゲームのサーバに接続できませんでした",
                             f"ゲームのサーバに接続できませんでした: {e}")
    except puni_daiko.PuniStaleVersionError as e:
        # 版を合わせても弾かれる(新しい版が見つからない)。人が /puni_version set で
        # 合わせれば、見張りがそのまま流し直す。
        if await hand_over("ゲームの更新に合わせている途中のため"):
            await job.send_trouble_log(
                "アプリのバージョンが古く、自動更新でも合わせられませんでした。"
                "/puni_version set で合わせれば、見張りが自動で流し直します。")
            return
        if paid <= 0:
            return await _tell(interaction, STALE_LOGIN_TEXT.format(detail=str(e)[:200]))
        return await give_up("代行の処理に失敗しました",
                             f"アプリのバージョンが古く、更新しても代行できませんでした: {e}")
    except puni_daiko.PuniLoginError as e:
        # ログイン段階の失敗(周回中の login は各所で握っている)。ゲームには何も投げていない。
        return await give_up("ぷにぷににログインできませんでした",
                             f"ぷにぷににログインできませんでした: {e}")
    except Exception as e:
        # ログイン中の想定外は _open_with_retry が PuniServerError に変えるので、ここに来るのは
        # ログイン後(周回の途中など)。何周か回っている可能性があるので、台帳の印は残す。
        log.exception("ぷにぷに代行の実行に失敗: %s", e)
        return await give_up("代行の処理に失敗しました", f"想定外のエラー: {type(e).__name__}: {e}",
                             started=True)

    if outcome.get("suspended"):
        # bot の更新で一時停止した。次のプロセスが控えから続きを再開し、終わったときに
        # 結果の DM と台帳の記録の片付けをする(_run_resumed)。ここでは何も閉じない。
        await _tell(interaction, SUSPENDED_TELL)
        return

    # お代を受け取っているのに何も渡せていない(1周も回せなかった・強敵の妖怪を取れなかった・
    # 版を合わせても弾かれた)ときは、そのまま終わらせない。トラブルログで人に引き継ぐ
    # (返金か手動対応)。
    undelivered = _nothing_delivered(order.kind, outcome)
    if paid > 0 and undelivered:
        await job.send_trouble_log(_undelivered_reason(order.kind, outcome))
    await close_record(link_orders.DONE, finished=True)

    if dm_ok:
        await _tell(interaction,
                    "代行を完了できませんでした。結果はDMをご確認ください。こちらで確認して対応します。"
                    if undelivered else "代行が完了しました。結果はDMをご確認ください。")
        return
    # DM が送れない。画面(長い代行のあとは期限切れで書けないことが多い)に出し、それも
    # 駄目なら買った場所で一言だけ(中身は出さない)。
    if not await _tell_embed(interaction, job.result_embed(outcome)):
        await _nudge_channel(interaction.channel, interaction.user)


def _boss_unobtained_reason(outcome: dict) -> str:
    """有料の強敵取得が妖怪を取れずに終わったときの、トラブルログ用の説明。"""
    tries = int(outcome.get("tries") or 0)
    why = outcome.get("stopped") or "理由不明"
    return (f"強敵の妖怪を取得できないまま終わりました（{tries:,}回挑戦）: {why}。"
            "返金するか、手動で対応してください。")


def _undelivered_reason(kind: str, outcome: dict) -> str:
    """有料の注文が何も渡せずに終わったときの、トラブルログ用の説明。"""
    if outcome.get("stale_version"):
        return ("アプリのバージョンが古く、更新しても代行できませんでした。"
                "手動でバージョンを合わせるか返金してください。")
    if kind in puni_daiko.BOSS_KINDS:
        return _boss_unobtained_reason(outcome)
    why = outcome.get("stopped") or "理由不明"
    return f"代行が1つも進まずに終わりました: {why}。返金するか、手動で対応してください。"


async def _dm_stuck(user, *, summary: str, paid: int, order_id: str = None) -> bool:
    """こちらで調べないと直せない止まり方を、本人の DM にだけ伝える(生のエラーは出さない)。"""
    if user is None:
        return False
    embed = support.trouble_embed(
        support.NEEDS_SUPPORT, "代行の処理を完了できませんでした",
        support.PAID_AND_STUCK if paid > 0 else "時間をおいてもう一度お試しください。",
        amount=paid or None, summary=summary, order_id=order_id)
    try:
        await user.send(embed=embed)
        return True
    except (discord.HTTPException, AttributeError):
        return False


async def _kick_version_update(bot) -> dict:
    """アプリ版の確認を急がせる。ただし短い間に何度も App Store を見に行かない。"""
    now = time.time()
    if now - _VERSION_KICK["at"] < VERSION_KICK_INTERVAL:
        return {"updated": False, "skipped": True}
    _VERSION_KICK["at"] = now
    return await _auto_update_version(bot)


async def _nudge_channel(channel, user):
    """DM も画面も使えないとき、買った場所で一言だけ声をかける(中身は出さない)。"""
    if channel is None or user is None:
        return
    try:
        await channel.send(
            f"{user.mention} ぷにぷに代行が終わりましたが、DMをお送りできませんでした。\n"
            "DMを開放していただくか、" + support.contact_line())
    except discord.HTTPException:
        pass


async def _tell(interaction: discord.Interaction, text: str) -> bool:
    try:
        await interaction.edit_original_response(content=text, attachments=[],
                                                 embed=None, view=None)
        return True
    except discord.HTTPException:
        try:
            await interaction.followup.send(text, ephemeral=True)
            return True
        except discord.HTTPException:
            return False


async def _tell_embed(interaction: discord.Interaction, embed: discord.Embed) -> bool:
    try:
        await interaction.edit_original_response(content=None, attachments=[],
                                                 embed=embed, view=None)
        return True
    except discord.HTTPException:
        try:
            await interaction.followup.send(embed=embed, ephemeral=True)
            return True
        except discord.HTTPException:
            return False


# --- パネル(常設) ----------------------------------------------------------

def panel_embed() -> discord.Embed:
    event_price = puni_daiko.get_event_price()
    boss_price = puni_daiko.get_boss_price()
    boss_max_price = puni_daiko.get_boss_max_price()
    # 各メニューの説明と注意点は別のチャンネルにまとめて書く。パネルは商品と値段だけ。
    return discord.Embed(
        title="ぷにぷに代行メニュー",
        description=("下のボタンからメニューを選んでご注文ください。\n\n"
                     f"**イベントステージ進行** - {event_price:,}円\n"
                     f"**強敵取得** - {boss_price:,}円\n"
                     f"**強敵完凸** - {boss_max_price:,}円"),
        color=PUNI_COLOR)


def admin_panel_embed() -> discord.Embed:
    """管理者用パネル。客用と同じメニューを0円で流せる(動作確認用)。"""
    return discord.Embed(
        title="ぷにぷに 管理者パネル",
        description="管理者専用。**全メニュー0円**で動作確認できます。",
        color=PUNI_COLOR_PRIVATE)


async def _start_event_order(interaction: discord.Interaction, admin_free: bool):
    """イベント進行の注文を始める。入力するものが無いので、確認画面から。"""
    order = PuniOrder(interaction.client, interaction.user, puni_daiko.KIND_EVENT,
                      admin_free=admin_free)
    await interaction.response.send_message(
        embed=order.confirm_embed(), view=OrderView(order), ephemeral=True)


class PuniMenuSelect(ui.Select):
    """メニュー選択(ツムツムと同じ形)。押した本人にしか見えない画面から選ばせる。"""

    def __init__(self, admin_free: bool = False):
        event_price = puni_daiko.get_event_price()
        boss_price = puni_daiko.get_boss_price()
        boss_max_price = puni_daiko.get_boss_max_price()
        options = []
        if admin_free:
            # ステージ周回は客用のメニューから外した。動作確認のためだけに管理者パネルに残す。
            options.append(discord.SelectOption(
                value=puni_daiko.KIND_FARM, label="ステージ周回（0円・管理者のみ）"))
        options += [
            discord.SelectOption(
                value=puni_daiko.KIND_EVENT,
                label=("イベントステージ進行（0円）" if admin_free
                       else f"イベントステージ進行 - {event_price:,}円")[:100]),
            discord.SelectOption(
                value=puni_daiko.KIND_BOSS,
                label=("強敵取得（0円）" if admin_free
                       else f"強敵取得 - {boss_price:,}円")[:100]),
            discord.SelectOption(
                value=puni_daiko.KIND_BOSS_MAX,
                label=("強敵完凸（0円）" if admin_free
                       else f"強敵完凸 - {boss_max_price:,}円")[:100]),
        ]
        super().__init__(placeholder="メニューを選択", options=options,
                         min_values=1, max_values=1)
        self.admin_free = admin_free

    async def callback(self, interaction: discord.Interaction):
        kind = self.values[0]
        if self.admin_free and interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.edit_message(
                content="権限がありません。", embed=None, view=None)
        if kind == puni_daiko.KIND_FARM:
            if not self.admin_free:
                # 客用のメニューには出していない(管理者パネルの選択肢にしか無い)。
                return await interaction.response.edit_message(
                    content="そのメニューは終了しました。", embed=None, view=None)
            # 周回数の入力はモーダルで受ける。選択メッセージはそのまま残す
            # (モーダルを閉じてもメニューを開き直せるよう)。
            return await interaction.response.send_modal(
                PuniOrderModal(interaction.client, admin_free=self.admin_free))
        if kind in (puni_daiko.KIND_EVENT, *puni_daiko.BOSS_KINDS):
            # 入力するものが無いメニュー。そのまま確認画面へ。
            order = PuniOrder(interaction.client, interaction.user, kind,
                              admin_free=self.admin_free)
            return await interaction.response.edit_message(
                content=None, embed=order.confirm_embed(), view=OrderView(order))
        # 未知の値(将来の追加分に備えて)。
        await interaction.response.edit_message(
            content="そのメニューはまだ選べません。", embed=None, view=None)


class PuniMenuSelectView(ui.View):
    """注文ボタンから開くメニュー選択の入れ物。ephemeral 前提。"""

    def __init__(self, admin_free: bool = False):
        super().__init__(timeout=300)
        self.add_item(PuniMenuSelect(admin_free=admin_free))


class PuniPanelView(ui.View):
    """常設(客用)パネル。注文ボタン1つ → メニュー選択。"""

    def __init__(self, bot=None):
        super().__init__(timeout=None)
        self.bot = bot

    @ui.button(label="注文する", style=discord.ButtonStyle.success,
               custom_id="puni:order")
    @panels.guard
    async def order(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_message(
            "ご希望のメニューを選択してください。",
            view=PuniMenuSelectView(admin_free=False), ephemeral=True)


class PuniAdminPanelView(ui.View):
    """管理者用パネル。客用と同じメニューを0円で使える(にゃんこ/ツムと同方式)。

    押してもモーダルの on_submit / 0円の道で管理者かどうかを必ず確認する。
    """

    def __init__(self, bot=None):
        super().__init__(timeout=None)
        self.bot = bot

    @ui.button(label="動作確認する（全メニュー0円）", style=discord.ButtonStyle.secondary,
               custom_id="puni:admin:free")
    @panels.guard
    async def free_order(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message(
                "これは管理者が動作確認するためのパネルです。"
                "ご注文は通常のパネルからお願いします。", ephemeral=True)
        await interaction.response.send_message(
            "動作確認するメニューを選択してください（0円で流します）。",
            view=PuniMenuSelectView(admin_free=True), ephemeral=True)


# --- 入金確認後の後追い実行 ------------------------------------------------

RELOGIN_PROMPT = ("お預かりしたログイン情報が使えなくなっていました"
                  "（有効期限切れ・パスワード変更など）。")


def _get_order(order: dict):
    return link_orders.get_order(order["id"])


async def _mark_order(order: dict, status: str, **fields):
    return await link_orders.mark_order(order["id"], status, **fields)


async def _clear_run_mark(order: dict):
    """「走り出した」印を戻す。ゲームに何も投げていないと分かったときだけ。"""
    payload = dict(order.get("payload") or {})
    if not payload.pop("run_started_at", None):
        return
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "paid", payload=payload)
    except Exception as e:
        log.warning("ぷにの実行印を戻せませんでした(%s): %s", order.get("id"), e)


async def _report_blocked_rerun(bot, order: dict):
    """二重実行を止めたことを管理者に知らせる(同じ注文につき1回だけ)。"""
    payload = dict(order.get("payload") or {})
    if payload.get("rerun_reported"):
        return
    payload["rerun_reported"] = True
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "paid", payload=payload)
    except Exception:
        pass
    embed = discord.Embed(
        title="ぷにぷに代行の二重実行を止めました",
        description=("一度始めた代行が、終わったと記録される前に中断していました。"
                     "二重に周回しないよう自動での流し直しを止めています。\n"
                     "ゲーム側に反映されているかを確認して、必要なら手で流し直すか"
                     "返金してください。"),
        color=0xff3333, timestamp=discord.utils.utcnow())
    embed.add_field(name="注文番号", value=f"`{order.get('id')}`", inline=True)
    embed.add_field(name="金額",
                    value=f"{int(order.get('paid_amount') or order.get('amount_jpy') or 0):,}円",
                    inline=True)
    embed.add_field(name="購入者", value=f"<@{order.get('user_id')}>", inline=True)
    embed.add_field(name="内容", value=str(order.get("summary") or "")[:1024], inline=False)
    for ch_id in (private_log_channel_id(), log_channel_id()):
        if ch_id and await _send_log(bot, ch_id, "ぷにの二重実行ログ", embed=embed):
            break
    for uid in ADMIN_USER_IDS:
        try:
            admin = bot.get_user(uid) or await bot.fetch_user(uid)
            await admin.send(embed=embed)
        except Exception:
            continue


async def _scrub_token(order: dict):
    """渡し終わった注文から udkey を落とす。もう使う予定が無いものを持ち続けない。"""
    payload = dict(order.get("payload") or {})
    if not payload.get("udkey"):
        return
    payload["udkey"] = ""
    current = _get_order(order) or order
    try:
        await _mark_order(order, current.get("status") or "done", payload=payload)
    except Exception as e:
        log.warning("ぷにの注文から udkey を消せませんでした(%s): %s", order.get("id"), e)


async def offline_deliver(bot, order: dict, runner=None) -> bool:
    """入金が確認できた注文を、後追いで代行する。

    ここで済ませるのはログインまで(数十秒)。周回そのものは何時間もかかるので、
    見張りの巡回(他の商品のお渡しも同じ巡回で流れる)を塞がないよう裏で走らせ
    (_run_offline_job)、走り出した時点で True(お渡し済み扱い)を返す。裏の代行が
    途中で駄目になったときは、その処理が注文を「受け取り済み」に戻して次の巡回で
    流し直すか、本人にログインし直してもらうか、トラブルログで人に引き継ぐ。

    None を返すのは「まだ始められない」とき(その人の別の代行が走っている・サーバに
    拒まれた直後・版を合わせ中)。ゲームには何も投げていないので、見張りは失敗に数えず
    次の巡回でまた見る(理由は注文のメモに残す)。False は「この注文は流せない」
    (購入者が読めない等)で、見張りが失敗に数える。ログインできないときは
    NeedsCustomerInput にして、本人にログインし直してもらう。

    runner を渡せば(入れ直しの画面で今ログインしたばかりのとき)、入り直さずにそれで流す。
    """
    payload = order.get("payload") or {}
    udkey = payload.get("udkey") or ""
    puni_user_id = payload.get("puni_user_id")
    kind = payload.get("kind") or puni_daiko.KIND_FARM
    stage_id = payload.get("stage_id")
    rounds = int(payload.get("rounds") or 0)
    count = int(payload.get("count") or 0)
    paid = int(order.get("paid_amount") or order.get("amount_jpy") or 0)
    method = order.get("method") or payments.PAYPAY

    try:
        user = bot.get_user(int(order["user_id"])) or await bot.fetch_user(int(order["user_id"]))
    except (discord.HTTPException, KeyError, TypeError, ValueError):
        return False
    if kind == puni_daiko.KIND_FARM:
        if not stage_id or rounds <= 0:
            raise RuntimeError("注文の内容が読めませんでした（ステージ/周回数が空です）")
    elif kind == puni_daiko.KIND_MAIN and count <= 0:
        # イベント進行は count=0 が「最後まで」なので、空でも読める。
        raise RuntimeError("注文の内容が読めませんでした（進めるステージ数が空です）")
    if not udkey:
        # 渡し終わった後にもう一度呼ばれた等。黙って通すと二重代行になる。
        await _ask_relogin(bot, order)
        raise link_orders.NeedsCustomerInput(
            "udkey がありません", prompt=RELOGIN_PROMPT)

    async def defer(note: str):
        """まだ始められない。理由をメモに残して None(失敗に数えない)を返す。"""
        try:
            await _mark_order(order, order.get("status") or "paid", note=str(note)[:300])
        except Exception as e:
            log.warning("ぷにの注文のメモを書けませんでした(%s): %s", order.get("id"), e)
        return None

    if _SUSPEND.is_set():
        # bot の終了中(デプロイなど)。ここで始めても一時停止になるだけなので、注文は
        # 受け取り済みのまま残し、次のプロセスの見張りに流してもらう。
        return await defer("bot の再起動中のため、再起動後に流します")
    if user.id in _BUSY or user.id in _PENDING:
        # その人の別の代行(裏で走っているものを含む)が終わってから。ゲームには何も
        # 投げていない。走り出した印より先に見る(印は「落ちた」の判定で、実行中とは別)。
        return await defer("その人の別の代行が終わるのを待っています")
    if _slots_full(user.id):
        return await defer(f"同時に回せる人数の上限({MAX_CONCURRENT}人)のため順番待ちです")
    if payload.get("run_started_at"):
        # 一度始めた注文が、終わったと記録される前に落ちた(再デプロイ等)。
        await _report_blocked_rerun(bot, order)
        raise RuntimeError(
            "この注文は一度代行を始めています。二重に回さないよう止めました。"
            "ゲーム側に反映されているかを確認してください。")

    # ログインだけ先に済ませる。ここで駄目なら、走り出した印を付けずに引き下がれる。
    if runner is None:
        try:
            runner = await puni_daiko.login_with_udkey(udkey, puni_user_id)
        except puni_daiko.PuniServerError as e:
            # サーバに繋がらない/拒まれた。本人に入れ直してもらう話ではないので、
            # 注文はそのまま残して次の巡回で流し直す(全体停止の間は接続せずに返る)。
            log.warning("ぷにの後追いでサーバに拒まれました(%s): %s", order.get("id"), e)
            return await defer(f"サーバに拒まれました: {str(e)[:200]}")
        except puni_daiko.PuniStaleVersionError as e:
            # アプリ版が古い。版を合わせてから次の巡回で流し直す。
            log.warning("ぷにの後追いがアプリ版で弾かれました(%s): %s", order.get("id"), e)
            await _kick_version_update(bot)
            return await defer(f"アプリ版が古く弾かれました。版を合わせて流し直します: {str(e)[:150]}")
        except puni_daiko.PuniLoginError as e:
            if order.get("source") != "link":
                await _ask_relogin(bot, order)
            raise link_orders.NeedsCustomerInput(str(e)[:300], prompt=RELOGIN_PROMPT)

    # 走り出したことを先に残す。ここを後回しにすると、上の判定が効かない。
    payload = {**payload, "run_started_at": time.time()}
    order = (await _mark_order(order, order.get("status") or "paid", payload=payload)
             or {**order, "payload": payload})
    # 裏の処理が _BUSY に入るまでのあいだ、この人の代行を予約しておく(同じ巡回に並んだ
    # 同じ人の2件目を走らせない)。
    _PENDING.add(user.id)

    guild = bot.get_guild(int(order["guild_id"])) if order.get("guild_id") else None
    channel = bot.get_channel(int(order["channel_id"])) if order.get("channel_id") else None
    note = [f"注文番号: `{order['id']}`"] if order.get("id") else []
    if order.get("link"):
        note.append(f"{payments.method_label(method)}リンク: {str(order['link'])[:200]}")

    job = PuniJob(bot, user, udkey, puni_user_id, kind,
                  stage_id=stage_id or 0, rounds=rounds, count=count,
                  total_price=int(payload.get("total_price") or paid), paid=paid,
                  method=method, guild=guild, channel=channel,
                  pay_note="\n".join(note) or None, order_id=order.get("id"),
                  account=payload.get("account", ""),
                  admin_free=bool(payload.get("admin_free")), runner=runner)
    _spawn(_run_offline_job(bot, order, job, user, channel, kind, paid))
    return True


async def _run_offline_job(bot, order: dict, job: PuniJob, user, channel, kind: str, paid: int):
    """後追いの代行の本体(裏で走る)。終わり方に応じて注文の状態を整える。

    見張りは offline_deliver が True を返した時点で注文を「お渡し済み」にしている。
    ここで流し直しが要ると分かったら「受け取り済み」に戻す(走り出した印も戻す)。
    """
    oid = order.get("id")

    async def back_to_paid(note: str, **fields):
        await _clear_run_mark(order)
        try:
            await _mark_order(order, link_orders.PAID, note=str(note)[:300], **fields)
        except Exception as e:
            log.warning("ぷにの注文を戻せませんでした(%s): %s", oid, e)

    # 見張りは offline_deliver が返った直後に「お渡し済み」を書く。ここがそれより先に
    # 「受け取り済み」へ戻す(別の代行が走っていた等、すぐ分かる失敗)と、後から来た
    # 「お渡し済み」に上書きされて注文が流れなくなる。先に書かせてから始める。
    try:
        await asyncio.sleep(1.0)
    finally:
        # ここから先は job.run が _BUSY に入れる(その間に await は無い)。予約を解く。
        _PENDING.discard(user.id)
    try:
        dm_ok, outcome = await job.execute()
    except Busy:
        await back_to_paid("別の代行の実行中だったため、次の巡回で流し直します")
        return
    except puni_daiko.PuniServerError as e:
        log.warning("ぷにの後追いでサーバに拒まれました(%s): %s", oid, e)
        await back_to_paid(f"サーバに拒まれました: {str(e)[:200]}")
        return
    except puni_daiko.PuniStaleVersionError as e:
        await back_to_paid(f"アプリ版が古く弾かれました。版を合わせて流し直します: {str(e)[:150]}")
        await _auto_update_version(bot)
        return
    except puni_daiko.PuniLoginError as e:
        await back_to_paid(str(e)[:300], awaiting_code=True)
        await _ask_relogin(bot, order)
        return
    except Exception as e:
        log.exception("ぷにの後追いの代行に失敗(%s): %s", oid, e)
        await job.send_trouble_log(f"想定外のエラー: {type(e).__name__}: {e}")
        try:
            await _mark_order(order, link_orders.FAILED,
                              note=f"想定外のエラー: {type(e).__name__}: {str(e)[:200]}")
        except Exception as e2:
            log.warning("ぷにの注文を失敗にできませんでした(%s): %s", oid, e2)
        # 本人にも伝える(進捗の文が「周回中…」のまま止まって見えるのを放置しない)。
        await _dm_stuck(user, summary=job.summary(), paid=paid, order_id=oid)
        return

    if outcome.get("suspended"):
        # bot の更新で一時停止した。次のプロセスが控えから続きを再開し、終わったときに
        # 注文を閉じる(_run_resumed)。走り出した印は残したまま(二重に流させない)。
        return
    if outcome.get("stale_version") and _nothing_delivered(kind, outcome):
        # アプリ版が古くて何も渡せなかった(DM・売上・ログはまだ出していない)。最新版に
        # 合わせてから、次の巡回でそのまま流し直す(お代は受け取り済みなので注文は手放さない)。
        await back_to_paid("アプリ版が古く弾かれました。版を合わせて流し直します")
        await _auto_update_version(bot)
        return
    if paid > 0 and _nothing_delivered(kind, outcome):
        await job.send_trouble_log(_undelivered_reason(kind, outcome))

    # ここまで来たら代行は終わっている。預かった udkey は用済みなので手放し、
    # 終わった時刻を残す(再起動で途中で止まった注文と見分けるため)。
    current = _get_order(order) or order
    final_payload = {**(current.get("payload") or order.get("payload") or {}),
                     "udkey": "", "finished_at": time.time()}
    try:
        await _mark_order(order, link_orders.DONE, note="", payload=final_payload)
    except Exception as e:
        log.warning("ぷにの注文を完了にできませんでした(%s): %s", oid, e)
    if not dm_ok:
        await _nudge_channel(channel, user)


async def _report_interrupted_jobs(bot):
    """起動時に、裏で走っていた代行が再起動で途中で止まった注文を探して人に知らせる。

    見張りは走り出した時点で注文を「お渡し済み」にしているので、途中で落ちると
    誰にも気づかれない。走り出した印があり・終わった記録が無く・udkey が残っている
    (終わっていれば手放している)注文がそれ。二重に回さないよう自動では流し直さない。
    走っている代行の控え(RUNNING_DIR)に載っている注文は、_sweep_interrupted が
    進捗DMの後始末と一緒に知らせるので、ここでは飛ばす(同じ注文を2回知らせない。
    再デプロイで古いプロセスがまだ回している注文を「止まった」と言わない)。
    """
    await bot.wait_until_ready()
    try:
        orders = link_orders.list_orders(link_orders.DONE)
    except Exception as e:
        log.warning("ぷにの注文一覧を読めませんでした: %s", e)
        return
    owned = {str(rec.get("order_id")) for rec in _read_running_all().values()
             if rec.get("order_id")}
    for order in orders:
        if order.get("kind") != KIND or str(order.get("id")) in owned:
            continue
        payload = order.get("payload") or {}
        if (not payload.get("run_started_at") or payload.get("finished_at")
                or not payload.get("udkey") or payload.get("rerun_reported")):
            continue
        try:
            await _report_blocked_rerun(bot, order)
        except Exception as e:
            log.warning("ぷにの中断した注文の報告に失敗(%s): %s", order.get("id"), e)


async def _sweep_interrupted(bot):
    """走っている代行の控えを見回り、回しているプロセスがいないものを続きから再開する。

    控えが「回しているプロセスがいない」のは、
      ・一時停止(suspended): デプロイなどで今の周で区切って止めた。すぐ再開してよい。
      ・書いたプロセスが死んだ(生存の印が BOOT_DEAD_SECONDS 途切れた): 落ちた(OOM など)、
        または終了の合図のあと今の周で区切れないままプロセスが終わった。最後に書いた
        途中経過から再開する(落ちた周の分は数えていないので、その分もう1周まわる)。
    再開できないもの(再開に要るものが控えに無い・落ちて再開した回数が多すぎる・
    ログインできなくなった)は、進捗DMを「途中で止まりました」に直してボタンを外し、
    本人と管理者に知らせて控えを消す(_notify_interrupted)。
    書いたプロセスが生きている間は触らない(再デプロイで新旧のプロセスが同時に動いている
    間に、古いほうがまだ回している代行を横取りしない)。終了の合図を受けたプロセスは
    何も再開しない(次のプロセスに任せる)。控えは1件ずつ読み直してから扱う(見回りの
    途中で Discord との通信を待っている間に、ほかで書き換わっていることがある)。
    """
    if _SUSPEND.is_set():
        return
    for tx_id in list(_read_running_all()):
        if _SUSPEND.is_set():
            return
        if tx_id in _LIVE or tx_id in _RESUMING:
            continue
        rec = read_json(_running_path(tx_id), {})
        if not rec:
            continue
        boot = str(rec.get("boot") or "")
        suspended = bool(rec.get("suspended"))
        if boot == BOOT_ID and not suspended:
            _drop_running(tx_id)          # このプロセスの終わった代行の消し忘れ
            continue
        if not suspended and _boot_alive(boot):
            continue
        try:
            if float(rec.get("next_try_at") or 0) > time.time():
                continue                  # 少し前に再開できなかった。間を空ける
        except (TypeError, ValueError):
            pass
        crash = not suspended
        why = _not_resumable_reason(rec, crash)
        if why is None:
            try:
                await _resume_job(bot, tx_id, rec, crash)
            except Exception as e:
                log.warning("ぷにの代行を再開できませんでした(%s): %s", tx_id, e)
                _RESUMING.discard(tx_id)
                _PENDING.discard(int(rec.get("user_id") or 0))
                await _retry_resume_later(bot, tx_id, rec, f"{type(e).__name__}: {e}",
                                          stop=_stop_requested(tx_id))
            continue
        if not _claim(tx_id):
            continue                      # ほかのプロセスが扱っている
        print(f"[PUNI] 途中で止まった代行を再開できません tx={tx_id} boot={boot} "
              f"user={rec.get('user_id')} 理由={why} "
              f"progress={str(rec.get('progress') or '')[:80]!r}", flush=True)
        await _notify_interrupted(bot, tx_id, rec, why)
    _prune_boot_files()


def _not_resumable_reason(rec: dict, crash: bool):
    """再開できない理由。再開できるなら None。"""
    kind = rec.get("kind") or puni_daiko.KIND_FARM
    if not (rec.get("udkey") and rec.get("puni_user_id") and rec.get("user_id")):
        return "再開に要る情報が控えにありません"
    if kind == puni_daiko.KIND_FARM and not (rec.get("stage_id") and rec.get("rounds")):
        return "周回するステージ・周回数が控えにありません"
    if crash and int(rec.get("crash_resumes") or 0) >= MAX_CRASH_RESUMES:
        return f"同じ代行で{MAX_CRASH_RESUMES}回続けて bot が落ちました"
    if rec.get("dm_marked"):
        return "すでに「途中で止まりました」と知らせています"
    return None


def _other_job_running_for(user_id, tx_id: str) -> bool:
    """同じ人の別の代行が、どこかのプロセスで走っているか(同じ垢を2つ同時に動かさない)。"""
    for other_tx, rec in _read_running_all().items():
        if other_tx == tx_id or str(rec.get("user_id")) != str(user_id):
            continue
        if not rec.get("suspended") and _boot_alive(str(rec.get("boot") or "")):
            return True
    return False


async def _resume_job(bot, tx_id: str, rec: dict, crash: bool) -> bool:
    """控えから代行を再開する(裏で走らせる)。始めたら True、順番待ちなら False。

    先に再開の札(O_EXCL のファイル)を取り、控えを読み直して、見回りで見たときから
    変わっていないことを確かめてから自分のものにする(2つのプロセスが同じ代行を
    両方で再開しない)。
    """
    uid = int(rec["user_id"])
    if uid in _BUSY or uid in _PENDING or _slots_full(uid):
        return False                      # その人の別の代行が走っている・枠が埋まっている
    if _other_job_running_for(uid, tx_id):
        return False
    if not _claim(tx_id):
        return False                      # ほかのプロセスが再開している
    fresh = read_json(_running_path(tx_id), {})
    same = all(str(fresh.get(k)) == str(rec.get(k)) for k in ("boot", "suspended", "resumes"))
    if not fresh or not same or fresh.get("dm_marked"):
        _release_claim(tx_id)
        return False
    rec = fresh
    _RESUMING.add(tx_id)
    try:
        user = bot.get_user(uid) or await bot.fetch_user(uid)
        guild = bot.get_guild(int(rec["guild_id"])) if rec.get("guild_id") else None
        channel = None
        if rec.get("order_channel_id"):
            channel = bot.get_channel(int(rec["order_channel_id"]))
        dm_message = await _fetch_progress_message(user, rec)
    except BaseException:
        _RESUMING.discard(tx_id)
        _release_claim(tx_id)
        raise
    # 控えを自分のものにする。ここから代行が _LIVE に入るまでは _RESUMING で見回りから外す。
    rec = {**rec, "boot": BOOT_ID, "suspended": False,
           "resumes": int(rec.get("resumes") or 0) + 1,
           "crash_resumes": int(rec.get("crash_resumes") or 0) + (1 if crash else 0)}
    rec.pop("next_try_at", None)
    _write_running(tx_id, rec)
    _PENDING.add(uid)
    job = PuniJob(bot, user, rec["udkey"], rec["puni_user_id"],
                  rec.get("kind") or puni_daiko.KIND_FARM,
                  stage_id=rec.get("stage_id") or 0, rounds=rec.get("rounds") or 0,
                  count=rec.get("count") or 0, total_price=rec.get("total_price") or 0,
                  paid=rec.get("paid") or 0, method=rec.get("method") or payments.PAYPAY,
                  guild=guild, channel=channel, pay_note=rec.get("pay_note"),
                  order_id=rec.get("order_id"), account=rec.get("account") or "",
                  tx_id=tx_id, admin_free=bool(rec.get("admin_free")), resume=rec)
    job.dm_message = dm_message
    if _stop_requested(tx_id) or rec.get("stop_requested"):
        job.stop_event.set()              # 一時停止中・再開待ちの間に停止ボタンが押されていた
    print(f"[PUNI] 代行を再開します tx={tx_id} user={uid} kind={job.kind} "
          f"{'落ちたあと' if crash else '一時停止のあと'} 途中経過={rec.get('state') or {}}",
          flush=True)
    _spawn(_run_resumed(bot, job, rec))
    return True


async def _fetch_progress_message(user, rec: dict):
    """前のプロセスが出した進捗DM。読めなければ None(新しく出し直す)。"""
    if not rec.get("message_id"):
        return None
    try:
        channel = user.dm_channel or await user.create_dm()
        return await channel.fetch_message(int(rec["message_id"]))
    except Exception as e:
        log.warning("ぷにの前の進捗DMを読めませんでした(%s): %s", rec.get("message_id"), e)
        return None


async def _retry_resume_later(bot, tx_id: str, rec: dict, reason: str, stop: bool = False):
    """再開を始められなかった(サーバの都合・メンテナンス・全体停止・版合わせなど)。
    控えを一時停止に戻し、間を空けて再び試す。間は失敗が続くと倍々に延ばし(上限
    RESUME_RETRY_MAX)、全体停止中はその残りより長く空ける。最初に始められなかった
    ときから RESUME_GIVE_UP_SECONDS 経っても始められなければ諦めて人に知らせる。"""
    now = time.time()
    try:
        first = float(rec.get("first_failed_at") or now)
    except (TypeError, ValueError):
        first = now
    fails = int(rec.get("resume_failures") or 0) + 1
    rec = {**rec, "suspended": True, "resume_failures": fails, "first_failed_at": first,
           "last_resume_error": str(reason)[:300]}
    if now - first >= RESUME_GIVE_UP_SECONDS:
        await _notify_interrupted(
            bot, tx_id, rec,
            f"{int(RESUME_GIVE_UP_SECONDS // 3600)}時間試しても再開できませんでした"
            f"（{fails}回目・{str(reason)[:120]}）")
        return
    wait = min(RESUME_RETRY_SECONDS * (2 ** min(fails - 1, 10)), RESUME_RETRY_MAX)
    wait = max(wait, puni_daiko.global_hold_remaining() + 5.0)
    rec["next_try_at"] = now + wait
    _write_running(tx_id, rec)
    if stop:
        # 試した代行で停止ボタンが押されていた(控えを消したときに申し出も消えている)。
        _request_stop(tx_id)
    _release_claim(tx_id)
    print(f"[PUNI] 代行の再開を{int(wait)}秒後に試し直します tx={tx_id} ({fails}回目): "
          f"{str(reason)[:200]}", flush=True)


async def _run_resumed(bot, job: PuniJob, rec: dict):
    """再開した代行の本体(裏で走る)。終わったら結果を出し、台帳の注文を閉じる。"""
    tx_id = job.tx_id
    uid = job.user.id
    # ここから先は job.run が _BUSY に入れる(その間に await は無い)。予約を解く。
    _PENDING.discard(uid)
    try:
        dm_ok, outcome = await job.execute()
    except Busy:
        _RESUMING.discard(tx_id)
        await _retry_resume_later(bot, tx_id, rec, "別の代行の実行中",
                                  stop=job.stop_event.is_set())
        return
    except (puni_daiko.PuniUdkeyError, puni_daiko.PuniAccountError) as e:
        # 預かった udkey ではもう入れない・垢が違う。待っても直らない。人に引き継ぐ。
        await _notify_interrupted(bot, tx_id, rec,
                                  f"再開しようとしましたがログインできませんでした（{str(e)[:150]}）")
        return
    except puni_daiko.PuniLoginError as e:
        # サーバに拒まれた・メンテナンス・版が古いなど(ゲームには何も投げていない)。
        # 途中経過はそのまま、間を空けて試し直す。
        await _retry_resume_later(bot, tx_id, rec, str(e), stop=job.stop_event.is_set())
        if isinstance(e, puni_daiko.PuniStaleVersionError):
            await _kick_version_update(bot)
        return
    except Exception as e:
        log.exception("ぷにの再開した代行に失敗(%s): %s", tx_id, e)
        latest = {**rec, **(job.last_record or {})}
        await _notify_interrupted(bot, tx_id, latest,
                                  f"再開した代行が想定外のエラーで止まりました（{type(e).__name__}: {e}）")
        return
    finally:
        _RESUMING.discard(tx_id)
    if outcome.get("suspended"):
        return                            # また一時停止した。次のプロセスが続ける
    if outcome.get("stale_version") and _nothing_delivered(job.kind, outcome):
        # 版が古くて何も渡せなかった(結果はまだ出していない)。先に控えを戻してから、
        # 版を合わせる(合わせている途中で落ちても、控えは残る)。
        latest = {**rec, **(job.last_record or {})}
        await _retry_resume_later(bot, tx_id, latest, "アプリ版が古く弾かれました",
                                  stop=job.stop_event.is_set())
        await _auto_update_version(bot)
        return
    if job.paid > 0 and _nothing_delivered(job.kind, outcome):
        await job.send_trouble_log(_undelivered_reason(job.kind, outcome))
    if job.order_id:
        try:
            await _finish_order(str(job.order_id))
        except Exception as e:
            log.warning("ぷにの注文を完了にできませんでした(%s): %s", job.order_id, e)
    if not dm_ok and job.channel is not None:
        await _nudge_channel(job.channel, job.user)


async def _finish_order(order_id: str):
    """台帳の注文を「お渡し済み・終わった」にする(預かった udkey を手放す)。"""
    order = link_orders.get_order(order_id)
    if not order:
        return
    payload = {**(order.get("payload") or {}), "udkey": "", "finished_at": time.time()}
    await link_orders.mark_order(order_id, link_orders.DONE, note="", payload=payload)


def _state_line(rec: dict) -> str:
    """控えの途中経過を、お客さん向けの短い一文にする(無ければ空)。"""
    st = rec.get("state") or {}
    kind = rec.get("kind") or puni_daiko.KIND_FARM
    try:
        if kind == puni_daiko.KIND_FARM and rec.get("rounds"):
            return f"ここまで {int(st.get('cleared') or 0):,}/{int(rec['rounds']):,}周 回しました"
        if kind == puni_daiko.KIND_BOSS_MAX:
            got = int((st.get("limit") or {}).get("count") or 0)
            return (f"ここまで {int(st.get('tries') or 0):,}回 挑戦しました"
                    + (f"（取得 {got:,}体）" if got else ""))
        if kind == puni_daiko.KIND_BOSS:
            return f"ここまで {int(st.get('tries') or 0):,}回 挑戦しました"
        if st.get("cleared") is not None:
            return f"ここまで {int(st.get('cleared') or 0):,}ステージ 進めました"
    except (TypeError, ValueError):
        pass
    return ""


async def _notify_interrupted(bot, tx_id: str, rec: dict, why: str):
    """再開できない代行の後始末。進捗DMを「途中で止まりました」に直してボタンを外し、
    本人と管理者に知らせ、台帳の注文に「知らせ済み」の印を付けて控えを消す。"""
    boot = str(rec.get("boot") or "")
    progress = str(rec.get("progress") or "")
    if not rec.get("dm_marked"):
        try:
            progress = await _mark_interrupted_dm(bot, rec) or progress
        except Exception as e:
            log.warning("ぷにの中断した進捗DMを直せませんでした(%s): %s", tx_id, e)
        # 以下がどこで失敗しても、本人への連絡を2回しない。
        rec = {**rec, "dm_marked": True}
        _write_running(tx_id, rec)
    try:
        await _report_interrupted_progress(bot, rec, progress, _boot_last_seen(boot), why)
    except Exception as e:
        log.warning("ぷにの中断の報告に失敗(%s): %s", tx_id, e)
    if rec.get("order_id"):
        try:
            await _mark_rerun_reported(str(rec["order_id"]))
        except Exception as e:
            log.warning("ぷにの注文に報告済みの印を付けられませんでした(%s): %s",
                        rec.get("order_id"), e)
    _drop_running(tx_id)


async def _graceful_shutdown(bot):
    """終了の合図(SIGTERM。デプロイ・再起動)を受けた。

    走っている代行を今の周で区切って一時停止にし(_SUSPEND)、控えに残す。次のプロセスが
    続きから再開する。bot そのものは閉じない(プラットフォームが SIGKILL で止めるまで
    これまでどおり動かす)。ここで閉じると、ほかの機能(にゃんこの引き継ぎコードの発行
    など)の処理をその場で切ってしまう。SHUTDOWN_WAIT 秒で区切れなかった代行は、最後に
    書いた途中経過から、このプロセスが本当に終わって生存の印が途切れてから再開される。
    この間に新しく始まる代行も、ログインせずにすぐ一時停止になる(次のプロセスが回す)。
    """
    if _STOPPING["at"]:
        return
    _STOPPING["at"] = time.time()
    _SUSPEND.set()
    _beat_boot()                          # 終了の途中であることを生存の印に載せる
    print(f"[PUNI] 終了の合図を受けました。走っている代行{len(_LIVE)}件を今の周で区切って"
          "一時停止します", flush=True)
    deadline = time.monotonic() + SHUTDOWN_WAIT
    while (_LIVE or _RESUMING or _WINDING) and time.monotonic() < deadline:
        await asyncio.sleep(0.5)
    if _LIVE:
        print(f"[PUNI] {len(_LIVE)}件は{int(SHUTDOWN_WAIT)}秒で区切れませんでした。"
              "このプロセスが終わったあと、最後の途中経過から次のプロセスが再開します",
              flush=True)
    else:
        print("[PUNI] 走っている代行は全部一時停止しました。次のプロセスが続きから再開します",
              flush=True)


def _install_shutdown_handler(bot):
    """SIGTERM で _graceful_shutdown を走らせる(1回だけ)。

    これまでは SIGTERM を受けても何もせず(コンテナの PID 1 の python は既定では
    SIGTERM で終わらない)、猶予のあと SIGKILL で落とされていた。走っている代行はその場で
    消え、進捗DMが「周回中…」のまま残っていた。ここでは代行を一時停止にするだけで、
    プロセスの終わり方(猶予のあと SIGKILL)は変えない。
    """
    if _STOPPING.get("installed"):
        return
    try:
        loop = asyncio.get_running_loop()
        loop.add_signal_handler(signal.SIGTERM, lambda: _spawn(_graceful_shutdown(bot)))
        _STOPPING["installed"] = True
    except (NotImplementedError, RuntimeError, ValueError) as e:
        log.warning("ぷに: SIGTERM の受け口を付けられませんでした: %s", e)


async def _mark_rerun_reported(order_id: str):
    """台帳の注文に「中断を知らせ済み」の印を付ける(_report_interrupted_jobs が重ねない)。"""
    order = link_orders.get_order(order_id)
    if not order:
        return
    payload = dict(order.get("payload") or {})
    if payload.get("rerun_reported"):
        return
    payload["rerun_reported"] = True
    await link_orders.mark_order(order_id, order.get("status") or link_orders.DONE,
                                 payload=payload)


async def _mark_interrupted_dm(bot, rec: dict) -> str:
    """止まった代行の進捗DMに「途中で止まりました」を書き足してボタンを外し、本人に一言
    DM する。戻り値は書き換える前の進捗の文(読めなければ空)。"""
    user_id = int(rec.get("user_id") or 0)
    if not user_id:
        return ""
    user = bot.get_user(user_id) or await bot.fetch_user(user_id)
    progress = ""
    if rec.get("message_id"):
        try:
            channel = user.dm_channel or await user.create_dm()
            msg = await channel.fetch_message(int(rec["message_id"]))
            progress = msg.content or ""
            # 前に添えた一言(「一時停止しています…自動で再開します」や以前の版の文)は外す。
            # 残すと、止まったのに「再開します」とも読めてしまう。
            content = f"{_strip_notes(progress)}\n{INTERRUPTED_TEXT}".strip()[:2000]
            if content != progress.strip():
                await msg.edit(content=content, view=None)
        except discord.HTTPException as e:
            log.warning("ぷにの中断した進捗DMを書き換えられませんでした(%s): %s",
                        rec.get("message_id"), e)
    summary = f"（{rec['summary']}）" if rec.get("summary") else ""
    done = _state_line(rec)
    done = f"{done}。" if done else ""
    try:
        await user.send(f"ご依頼の代行{summary}は、途中で止まりました。{done}"
                        "こちらで確認して対応します。")
    except discord.HTTPException:
        pass
    return progress


async def _report_interrupted_progress(bot, rec: dict, progress: str, last_seen=None,
                                      why: str = ""):
    """再開できずに止まった代行を人に知らせる(非公開ログ、無ければ管理者の DM)。"""
    embed = discord.Embed(
        title="ぷにぷに代行が途中で止まりました（再開できません）",
        description=("bot の再起動などで止まった代行を、続きから再開できませんでした。"
                     "結果の DM・売上・ログは出ていません。進捗DMは「途中で止まりました」に"
                     "直し、停止ボタンを外して本人に知らせました。"
                     "ゲーム側に反映されているかを確認して、必要なら手で流し直すか返金して"
                     "ください。"),
        color=0xff3333, timestamp=discord.utils.utcnow())
    if why:
        embed.add_field(name="再開できない理由", value=str(why)[:1024], inline=False)
    state = rec.get("state") or {}
    if state:
        embed.add_field(name="控えの途中経過", value=", ".join(
            f"{k}={v}" for k, v in state.items() if not isinstance(v, dict))[:1024] or "-",
            inline=False)
    if rec.get("user_id"):
        embed.add_field(name="依頼者", value=f"<@{rec['user_id']}>", inline=True)
    embed.add_field(name="金額", value=("0円（動作確認）" if rec.get("admin_free")
                                      else f"{int(rec.get('paid') or 0):,}円"), inline=True)
    if rec.get("order_id"):
        embed.add_field(name="注文番号", value=f"`{rec['order_id']}`", inline=True)
    if rec.get("summary"):
        embed.add_field(name="内容", value=str(rec["summary"])[:1024], inline=False)
    if progress:
        embed.add_field(name="止まった時点の進捗", value=progress[:1024], inline=False)
    if rec.get("started_at"):
        embed.add_field(name="開始", value=f"<t:{int(rec['started_at'])}:f>", inline=True)
    if last_seen:
        # そのプロセスが最後に生きていた時刻(1分おきに記録)。落ちた時刻の目安。
        embed.add_field(name="プロセスが最後に生きていた時刻",
                        value=f"<t:{int(last_seen)}:f>", inline=True)
    embed.add_field(name="取引番号", value=f"`{rec.get('tx_id') or '-'}`", inline=True)
    await _notify_private(bot, embed, "ぷにの中断ログ")


async def _notify_private(bot, embed: discord.Embed, label: str):
    """管理者向けの知らせ。非公開ログへ、無ければ管理者の DM へ(公開ログには出さない)。"""
    ch_id = private_log_channel_id()
    if ch_id and await _send_log(bot, ch_id, label, embed=embed):
        return
    for uid in ADMIN_USER_IDS:
        try:
            admin = bot.get_user(uid) or await bot.fetch_user(uid)
            await admin.send(embed=embed)
        except Exception:
            continue


async def _report_stall(bot, job: "PuniJob", idle: float):
    """代行の進みが長く止まっている(プロセスは生きている)ことを知らせる。

    まず標準出力に全スレッドの状態を出す(Discord への通信そのものが詰まっていても
    ログには残る)。代行は止めない(打ち切ると結果の DM・記録が出なくなる)。
    """
    print(f"[PUNI] 代行の進みが{int(idle // 60)}分止まっています tx={job.tx_id} "
          f"user={job.user.id if job.user else None} kind={job.kind} "
          f"progress={job.progress_text()[:80]!r} "
          f"pending_game_calls={len(puni_daiko.pending_game_calls(job.user_id)) if job.user_id else 0}",
          flush=True)
    try:
        faulthandler.dump_traceback(all_threads=True)
    except Exception:
        pass
    embed = discord.Embed(
        title="ぷにぷに代行の進みが止まっています",
        description=(f"走っている代行の進みが **{int(idle // 60)}分** 止まっています"
                     "（bot は動いています）。停止ボタンを押しても今の周が終わらないと止まり"
                     "ません。ゲームの通信が戻らない場合は自動で中止されます。"
                     "様子はサーバのログ（[PUNI] で始まる行）を見てください。"),
        color=0xffa500, timestamp=discord.utils.utcnow())
    if job.user is not None:
        embed.add_field(name="依頼者", value=f"<@{job.user.id}>", inline=True)
    embed.add_field(name="内容", value=job.summary()[:1024], inline=False)
    if job.progress_text():
        embed.add_field(name="最後の進捗", value=job.progress_text()[:1024], inline=False)
    embed.add_field(name="取引番号", value=f"`{job.tx_id}`", inline=True)
    await _notify_private(bot, embed, "ぷにの停滞ログ")


def _rss_mb():
    """このプロセスの使っているメモリ(MB)。読めなければ None。"""
    try:
        with open("/proc/self/status", encoding="ascii") as f:
            for line in f:
                if line.startswith("VmRSS:"):
                    return int(line.split()[1]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return None


async def offline_release(bot, order: dict):
    """期限切れ・キャンセルの注文の後始末。預かった udkey を手放す。"""
    await _scrub_token(order)


async def _ask_relogin(bot, order: dict) -> bool:
    """ログインし直してもらうお願いをDMで送る(udkeyが無くなった注文の保険)。"""
    embed = support.trouble_embed(
        support.NEEDS_CODE, "ぷにぷににログインし直してください",
        (RELOGIN_PROMPT + "\n下のボタンからもう一度ログインしてください。"
         "そのまま代行を続けます。\n\n"
         + support.PAID_NO_DEADLINE + "\n" + support.contact_short()),
        order_id=order.get("id"),
        amount=int(order.get("paid_amount") or order.get("amount_jpy") or 0),
        summary=order.get("summary") or "")
    view = PuniReloginView(order["id"])
    try:
        bot.add_view(view)
    except Exception:
        pass
    return await support.send_private(bot, order, embed, view)


class PuniReloginModal(ui.Modal, title="ぷにぷにのログインのやり直し"):
    email = ui.TextInput(label="メールアドレス", required=True, max_length=200)
    password = ui.TextInput(label="パスワード", required=True, max_length=200)

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.order_id = order_id

    async def on_submit(self, interaction: discord.Interaction):
        uid = interaction.user.id
        if uid in _BUSY or uid in _PENDING or uid in _RELOGIN_BUSY:
            # 別の代行が走っている最中に同じ垢へ入り直すと、走っているほうの token がずれる。
            # 二重送信(連携が2回走って端末が2つ湧く)もここで止める。
            return await interaction.response.send_message(
                "すでに処理中です。終わってからもう一度「ログインし直す」を押してください。",
                ephemeral=True)
        # 最初の await より先に予約する(await の間に同じ人の2件目が上の判定を通ってしまう)。
        _RELOGIN_BUSY.add(uid)
        try:
            await interaction.response.send_message("ログインしています。", ephemeral=True)
            order = link_orders.get_order(self.order_id)
            if not order:
                return await _tell(interaction, "この注文が見つかりませんでした。")
            if str(order.get("user_id")) != str(interaction.user.id):
                return await _tell(interaction, "この注文の購入者ではありません。")
            if order.get("status") == link_orders.DONE:
                return await _tell(interaction, "この注文はお渡し済みです。")
            if order.get("status") != link_orders.PAID or not order.get("awaiting_code"):
                # 入れ直しを待っている注文だけ受ける。失敗(FAILED)や、途中で落ちた印が残る注文を
                # ここから流し直すと、済んだ分をもう一度回す(二重代行)ことになる。人が見る。
                return await _tell_embed(interaction, support.trouble_embed(
                    support.NEEDS_SUPPORT, "この注文はログインし直しを待っている状態ではありません",
                    support.PAID_AND_STUCK, order_id=self.order_id,
                    summary=order.get("summary") or ""))

            payload = dict(order.get("payload") or {})
            try:
                runner = await puni_daiko.login_with_email(
                    self.email.value, self.password.value, user_id=payload.get("puni_user_id"))
            except puni_daiko.PuniServerError as e:
                return await _tell(interaction, SERVER_DOWN_TEXT.format(detail=str(e)[:200]))
            except puni_daiko.PuniStaleVersionError as e:
                await _kick_version_update(interaction.client)
                return await _tell(interaction, STALE_LOGIN_TEXT.format(detail=str(e)[:200])
                                   .replace("お代はいただいていません。",
                                            "お代は受け取り済みです。追加のお支払いは不要です。"))
            except puni_daiko.PuniAccountError as e:
                return await _tell(
                    interaction,
                    f"ログインはできましたが、この注文のゲームアカウントが見つかりませんでした"
                    f"（{str(e)[:120]}）。\n注文したときと同じアカウントで、もう一度お試しください。")
            except Exception as e:
                return await _tell(
                    interaction,
                    f"ログインに失敗しました: {type(e).__name__}: {str(e)[:200]}\n"
                    "もう一度お試しください。")

            payload["udkey"] = runner.udkey
            payload["puni_user_id"] = runner.user_id
            # 入れ直し待ちの印(awaiting_code)はまだ消さない。消すと、次の巡回が同じ注文を
            # 同時に流そうとする(裏で走らせる前に、同じ垢へもう一度ログインしてしまう)。
            order = await _mark_order(order, link_orders.PAID, payload=payload,
                                      deliver_attempts=0, last_attempt_at=0) or order
            try:
                # 今ログインしたばかりのランナーでそのまま流す(入り直さない)。
                ok = await offline_deliver(interaction.client, order, runner=runner)
            except link_orders.NeedsCustomerInput as e:
                await _mark_order(order, link_orders.PAID, awaiting_code=True, note=str(e)[:300])
                return await _tell(interaction, f"{e.prompt}\n\nもう一度お試しください。")
            except Exception as e:
                log.exception("ぷにのやり直しに失敗 (%s)", self.order_id)
                await _mark_order(order, link_orders.PAID, note=str(e)[:300])
                return await _tell_embed(interaction, support.trouble_embed(
                    support.NEEDS_SUPPORT, "処理を完了できませんでした",
                    support.PAID_AND_STUCK, order_id=self.order_id))

            if ok:
                await _mark_order(order, link_orders.DONE, awaiting_code=False, note="")
                return await _tell(interaction, "受け付けました。結果をDMでお送りします。")
            if ok is None:
                # まだ始められない(サーバに拒まれた直後など)。見張りに任せる。
                await _mark_order(order, link_orders.PAID, awaiting_code=False)
                return await _tell(interaction,
                                   "ログインはできましたが、いまは代行を始められませんでした"
                                   "（サーバの都合か、別の処理の実行中です）。\n"
                                   f"{HANDED_OVER_TEXT}\n注文番号: `{self.order_id}`")
            await _mark_order(order, link_orders.PAID, awaiting_code=False)
            await _tell_embed(interaction, support.trouble_embed(
                support.NEEDS_SUPPORT, "処理を始められませんでした",
                support.PAID_AND_STUCK, order_id=self.order_id))
        finally:
            _RELOGIN_BUSY.discard(uid)


class PuniReloginView(ui.View):
    """ログインし直し用の常設ボタン(見張りが注文ごとに出す)。"""

    ask_title = "ぷにぷににログインし直してください"
    ask_howto = ("下のボタンから**メールアドレスとパスワード**を"
                 "もう一度入力してください。そのまま代行を続けます。")

    def __init__(self, order_id: str):
        super().__init__(timeout=None)
        self.order_id = order_id
        button = ui.Button(label="ログインし直す", style=discord.ButtonStyle.primary,
                           custom_id=f"puni:relogin:{order_id}")
        button.callback = self._callback
        self.add_item(button)

    async def _callback(self, interaction: discord.Interaction):
        await interaction.response.send_modal(PuniReloginModal(self.order_id))


# --- 管理コマンド ----------------------------------------------------------

class PuniCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._watch_ticks = 0
        self._sweeping = False
        self.version_watch.start()
        self.running_watch.start()

    async def cog_load(self):
        print(f"[PUNI] 起動 boot={BOOT_ID} pid={os.getpid()}", flush=True)
        # デプロイ・再起動の合図(SIGTERM)で、走っている代行を一時停止にしてから終える。
        _install_shutdown_handler(self.bot)
        # 再起動で途中で止まった後追いの代行があれば、人に知らせる(自動では流し直さない)。
        _spawn(_report_interrupted_jobs(self.bot))

    # ---- 走っている代行の見回り ----
    # 毎分: 生存の印を書く・走っている代行の控えに進捗を書き足し、進みが止まっていないかを
    # 見る・一時停止した/前のプロセスで途中で止まった代行を続きから再開する。10分ごと(走って
    # いる代行があるときだけ): メモリ・スレッド数などを標準出力に残す(落ちた原因を後から
    # 追えるように。OOM で落ちると何も残らない)。

    @tasks.loop(seconds=BOOT_BEAT_SECONDS)
    async def running_watch(self):
        self._watch_ticks += 1
        _beat_boot()
        for job in list(_LIVE.values()):
            try:
                if not job.stop_event.is_set() and _stop_requested(job.tx_id):
                    job.stop_event.set()      # 別のプロセスで押された停止の申し出
                idle = job.heartbeat()
                if idle:
                    _spawn(_report_stall(self.bot, job, idle))
            except Exception as e:
                log.warning("ぷにの見回りに失敗(%s): %s", getattr(job, "tx_id", "?"), e)
        if not self._sweeping and not _SUSPEND.is_set():
            # 再開・後始末は Discord との通信で長くかかることがある。見回り(生存の印)を
            # 止めないよう裏で流す(止めると、別のプロセスからこちらが死んだように見える)。
            _spawn(self._sweep_once())
        if _LIVE and self._watch_ticks % 10 == 0:
            now = time.time()
            jobs = " ".join(f"{j.tx_id}:{int(now - j.last_progress_at())}s"
                            for j in list(_LIVE.values()))
            print(f"[PUNI] health boot={BOOT_ID} rss={_rss_mb()}MB "
                  f"threads={threading.active_count()} jobs={len(_LIVE)} {jobs}", flush=True)

    @running_watch.before_loop
    async def _before_running_watch(self):
        await self.bot.wait_until_ready()

    @running_watch.error
    async def _running_watch_error(self, error):
        log.warning("ぷにの見回りが止まりました: %r", error)

    async def _sweep_once(self):
        self._sweeping = True
        try:
            await _sweep_interrupted(self.bot)
        except Exception as e:
            log.warning("ぷにの途中で止まった代行の後始末に失敗: %s", e)
        finally:
            self._sweeping = False

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        # 前の作り(custom_id が毎回ちがう)の停止ボタンは受け口がもう無い。押されたら
        # ここで答える(黙っていると Discord に「応答しませんでした」と出る)。
        try:
            if self.bot.user is None or not _is_legacy_stop_button(interaction, self.bot.user.id):
                return
            if not interaction.response.is_done():
                await _answer_on_message(interaction, STOP_GONE_TEXT)
        except Exception as e:
            log.warning("ぷにの古い停止ボタンの処理に失敗: %r", e)

    def cog_unload(self):
        self.version_watch.cancel()
        self.running_watch.cancel()

    puni = app_commands.Group(name="puni", description="ぷにぷに代行の管理コマンド")
    version = app_commands.Group(name="puni_version",
                                 description="ぷにぷにのゲームバージョン管理")

    # ---- ゲームバージョンの自動追従 ----
    # ぷにぷにが更新されると古いバージョンでは弾かれ、代行が丸ごと止まる。
    # ツムツム代行と同じで、App Storeを定期的に見て自動で切り替える。

    @tasks.loop(hours=puni_daiko.VERSION_CHECK_INTERVAL_HOURS)
    async def version_watch(self):
        try:
            await _auto_update_version(self.bot)
        except Exception as e:
            log.warning("ぷにのバージョン確認に失敗: %s", e)

    @version_watch.before_loop
    async def _before_version_watch(self):
        await self.bot.wait_until_ready()

    def _deny(self, interaction: discord.Interaction):
        return interaction.response.send_message("権限がありません。", ephemeral=True)

    # ---- パネル ----

    @puni.command(name="panel", description="ぷにぷに代行パネルを設置")
    async def panel(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.send_message("ぷにぷに代行パネルを設置しました。",
                                                ephemeral=True)
        await panels.put(self.bot, "puni:panel", interaction.channel,
                         panel_embed(), PuniPanelView(self.bot))

    @puni.command(name="test_panel", description="動作確認パネルを設置（全メニュー0円）")
    async def test_panel(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.send_message("動作確認パネルを設置しました。",
                                                ephemeral=True)
        await panels.put(self.bot, "puni:adminpanel", interaction.channel,
                         admin_panel_embed(), PuniAdminPanelView(self.bot))

    @puni.command(name="redisplay", description="パネルを最新の内容に更新")
    async def redisplay(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        results = {
            "代行パネル": await panels.refresh(
                self.bot, "puni:panel", panel_embed(), PuniPanelView(self.bot),
                guild=interaction.guild),
            "動作確認パネル": await panels.refresh(
                self.bot, "puni:adminpanel", admin_panel_embed(),
                PuniAdminPanelView(self.bot), guild=interaction.guild),
        }
        labels = {"updated": "更新しました", "missing": "置いていないので何もしません",
                  "failed": "更新できませんでした"}
        await interaction.followup.send(
            "\n".join(f"{k}: {labels.get(v, v)}" for k, v in results.items()),
            ephemeral=True)

    # ---- 価格・上限 ----

    @puni.command(name="event_price", description="イベントステージ進行の価格を決める")
    @app_commands.describe(price="イベント進行1回の価格（円）。省略すると現在の価格を表示します")
    async def event_price(self, interaction: discord.Interaction, price: int = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if price is None:
            return await interaction.response.send_message(
                f"イベントステージ進行は現在 **{puni_daiko.get_event_price():,}円** です"
                "（現在地から最後まで）。\n"
                "変更するには `/puni event_price price:金額` を実行してください。",
                ephemeral=True)
        if price < 0:
            return await interaction.response.send_message(
                "価格は0以上で指定してください。", ephemeral=True)
        puni_daiko.set_event_price(int(price))
        await interaction.response.send_message(
            f"イベントステージ進行の価格を **{int(price):,}円** にしました。\n"
            "パネルの表示は `/puni redisplay` で更新できます。", ephemeral=True)

    @puni.command(name="boss_price", description="強敵取得の価格を決める")
    @app_commands.describe(price="強敵取得1件の価格（円）。省略すると現在の価格を表示します")
    async def boss_price(self, interaction: discord.Interaction, price: int = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if price is None:
            return await interaction.response.send_message(
                f"強敵取得は現在 **{puni_daiko.get_boss_price():,}円** です"
                "（取得できるまで挑戦）。\n"
                "変更するには `/puni boss_price price:金額` を実行してください。",
                ephemeral=True)
        if price < 0:
            return await interaction.response.send_message(
                "価格は0以上で指定してください。", ephemeral=True)
        puni_daiko.set_boss_price(int(price))
        await interaction.response.send_message(
            f"強敵取得の価格を **{int(price):,}円** にしました。\n"
            "パネルの表示は `/puni redisplay` で更新できます。", ephemeral=True)

    @puni.command(name="boss_max_price", description="強敵完凸の価格を決める")
    @app_commands.describe(price="強敵完凸1件の価格（円）。省略すると現在の価格を表示します")
    async def boss_max_price(self, interaction: discord.Interaction, price: int = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if price is None:
            return await interaction.response.send_message(
                f"強敵完凸は現在 **{puni_daiko.get_boss_max_price():,}円** です"
                "（完凸するまで挑戦）。\n"
                "変更するには `/puni boss_max_price price:金額` を実行してください。",
                ephemeral=True)
        if price < 0:
            return await interaction.response.send_message(
                "価格は0以上で指定してください。", ephemeral=True)
        puni_daiko.set_boss_max_price(int(price))
        await interaction.response.send_message(
            f"強敵完凸の価格を **{int(price):,}円** にしました。\n"
            "パネルの表示は `/puni redisplay` で更新できます。", ephemeral=True)

    # ---- ログ・ロール ----

    @puni.command(name="selllog", description="完了ログの送り先")
    @app_commands.describe(channel="ログを送信するチャンネル(省略時は今のチャンネル)")
    async def selllog(self, interaction: discord.Interaction,
                      channel: discord.TextChannel = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        target = channel or interaction.channel
        cfg = _config()
        cfg["puni_log_channel_id"] = target.id
        _save_config(cfg)
        await interaction.response.send_message(
            f"ぷにの公開ログを {target.mention} に設定しました。", ephemeral=True)

    @puni.command(name="logchannel", description="非公開ログの送り先")
    @app_commands.describe(channel="管理者専用チャンネル(省略時は今のチャンネル)")
    async def logchannel(self, interaction: discord.Interaction,
                         channel: discord.TextChannel = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        target = channel or interaction.channel
        cfg = _config()
        cfg["puni_private_log_channel_id"] = target.id
        _save_config(cfg)
        await interaction.response.send_message(
            f"ぷにの非公開ログを {target.mention} に設定しました。\n"
            "購入者のIDや支払いリンクが送られます。管理者だけが見られるチャンネルにしてください。",
            ephemeral=True)

    @puni.command(name="role", description="購入時に付けるロール")
    @app_commands.describe(role="付与するロール(省略で解除)")
    async def role(self, interaction: discord.Interaction, role: discord.Role = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if interaction.guild is None:
            return await interaction.response.send_message("サーバー内で実行してください。",
                                                           ephemeral=True)
        set_purchase_role_id(interaction.guild.id, role.id if role else None)
        await interaction.response.send_message(
            f"購入時ロールを {role.mention} に設定しました。" if role else
            "購入時ロールの設定を解除しました（以降はにゃんこ代行の設定を使います）。",
            ephemeral=True)

    # ---- 状態 ----

    @puni.command(name="status", description="設定と売上を見る")
    async def status(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        sales = puni_daiko.load_sales()
        today = time.time() - 86400
        embed = discord.Embed(title="ぷにぷに代行の状態", color=0x00aaff)
        embed.add_field(name="イベントステージ進行",
                        value=f"{puni_daiko.get_event_price():,}円", inline=True)
        embed.add_field(name="強敵取得",
                        value=f"{puni_daiko.get_boss_price():,}円", inline=True)
        embed.add_field(name="強敵完凸",
                        value=f"{puni_daiko.get_boss_max_price():,}円", inline=True)
        embed.add_field(name="アプリバージョン",
                        value=f"`{puni_daiko.get_app_version()}`", inline=True)
        embed.add_field(
            name="人魂の自動購入",
            value=("ON（ワイマネーで補充）" if puni_daiko.AUTO_BUY_HITODAMA else "OFF"),
            inline=True)
        embed.add_field(name="合計売上",
                        value=f"{sum(int(s.get('amount', 0)) for s in sales):,}円"
                              f"（{len(sales)}件）", inline=True)
        embed.add_field(name="直近24時間",
                        value=f"{sum(int(s.get('amount', 0)) for s in sales if float(s.get('ts', 0)) >= today):,}円",
                        inline=True)
        embed.add_field(name="公開ログ",
                        value=f"<#{log_channel_id()}>" if log_channel_id() else "未設定",
                        inline=True)
        embed.add_field(name="非公開ログ",
                        value=f"<#{private_log_channel_id()}>" if private_log_channel_id() else "未設定",
                        inline=True)
        methods = payments.available_methods()
        embed.add_field(name="使える支払い方法",
                        value=" / ".join(m.label for m in methods) or "なし", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

    # ---- バージョン管理 ----

    @version.command(name="show", description="いまのバージョンを見る")
    async def version_show(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        latest = await asyncio.to_thread(puni_daiko.fetch_latest_app_version)
        current = puni_daiko.get_app_version()
        st = puni_daiko.get_version_check_state()
        embed = discord.Embed(title="ぷにぷにのゲームバージョン", color=0x00aaff)
        embed.add_field(name="使用中", value=f"`{current}`", inline=True)
        if latest:
            state = "一致" if latest == current else "最新と不一致"
            embed.add_field(name="App Storeの最新版",
                            value=f"`{latest}`（{state}）", inline=True)
            if puni_daiko.is_newer_version(latest, current):
                embed.add_field(name="対応",
                                value="`/puni_version auto` で今すぐ更新できます。",
                                inline=False)
        else:
            embed.add_field(name="App Storeの最新版", value="取得できませんでした", inline=True)
        hours = puni_daiko.VERSION_CHECK_INTERVAL_HOURS
        interval = f"{int(hours)}時間ごと" if hours == int(hours) else f"{hours}時間ごと"
        auto = f"自動チェック: {interval}"
        last = st.get("last_checked_at")
        auto += (f"\n最終チェック: <t:{int(last)}:R>" if last
                 else "\n最終チェック: まだ実行されていません")
        if st.get("last_updated_at"):
            auto += (f"\n最終更新: `{st.get('last_updated_from')}` → "
                     f"`{st.get('last_updated_to')}`（<t:{int(st['last_updated_at'])}:R>）")
        embed.add_field(name="自動更新", value=auto, inline=False)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @version.command(name="auto", description="いますぐ最新に合わせる")
    async def version_auto(self, interaction: discord.Interaction):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        await interaction.response.defer(ephemeral=True, thinking=True)
        result = await _auto_update_version(self.bot)
        if result.get("latest") is None:
            return await interaction.followup.send(
                "App Storeの最新版を取得できませんでした。時間をおいてお試しください。\n"
                "うまく取れないときは `/puni_version set` で直接指定できます。",
                ephemeral=True)
        if result.get("updated"):
            text = f"アプリのバージョンを `{result['before']}` → `{result['latest']}` に更新しました。"
        else:
            text = f"すでに最新です（`{result['current']}`）。"
        await interaction.followup.send(text, ephemeral=True)

    @version.command(name="set", description="アプリのバージョンを手で決める")
    @app_commands.describe(version="例: 4.170.0（省略すると現在の値を表示します）")
    async def version_set(self, interaction: discord.Interaction, version: str = None):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await self._deny(interaction)
        if version is None:
            return await interaction.response.send_message(
                f"現在のアプリバージョンは `{puni_daiko.get_app_version()}` です。\n"
                "自動更新が入っているので普段は触らなくて大丈夫。App Storeとずれて"
                "止まったときだけ `/puni_version set version:番号` で合わせてください。",
                ephemeral=True)
        version = version.strip()
        if not re.fullmatch(r"\d+(\.\d+){1,3}", version):
            return await interaction.response.send_message(
                "バージョンは `4.170.0` のように数字とドットで入力してください。", ephemeral=True)
        puni_daiko.set_app_version(version)
        await interaction.response.send_message(
            f"アプリバージョンを `{version}` にしました。次の代行から反映されます。",
            ephemeral=True)


async def setup(bot):
    # 再起動後もパネルのボタンが効くように登録し直す。
    bot.add_view(PuniPanelView(bot))
    bot.add_view(PuniAdminPanelView(bot))
    # 進捗DMの停止ボタンの常設の受け口。再起動のあとに押されても必ず答える。
    bot.add_view(PuniStopView())
    # 保留から遅れて承認された送金リンクの入金が確認できたら、後追いで代行する。
    link_orders.register_handler(
        KIND, lambda order: offline_deliver(bot, order),
        on_expire=lambda order: offline_release(bot, order),
        retry_view=PuniReloginView)
    await bot.add_cog(PuniCog(bot))
