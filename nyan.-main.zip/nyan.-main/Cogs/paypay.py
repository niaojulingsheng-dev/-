import asyncio
import json
import logging
import os
import random

import discord
from discord import ui
from discord.ext import commands, tasks
from discord import app_commands

from datetime import datetime, timedelta, timezone

from utils import is_allowed, ADMIN_USER_IDS
from paypay_mobile.app_version import get_app_version, version_source
import history_view
import usage_report
import reconcile
from paypay_async import (
    start_login,
    complete_login,
    device_login,
    owner_device_uuid,
    run_owner_op,
    receive_payment,
    diagnose_link,
    signout_owner,
    refresh_tokens,
    recover_session,
    relogin as paypay_relogin,
    keep_alive,
    owner_login_info,
    token_status,
    money_priority,
    set_money_priority,
    MONEY_FIRST,
    MONEY_LITE_FIRST,
    PRIORITY_LABELS,
    read_journal,
    classify_status,
    RECEIVED,
    GONE,
    PENDING,
    NotRegisteredError,
    ReceiveUnsure,
    PendingTimeout,
    TokenExpiredError,
    RefreshFailedError,
    RefreshUnsafeError,
    ReloginUnavailableError,
    ReloginFailedError,
    PayPayLoginError,
    PayPayError,
    PayPayNetWorkError,
    REFRESH_INTERVAL_HOURS,
    KEEP_ALIVE_DAY_MINUTES,
    KEEP_ALIVE_NIGHT_MINUTES,
    KEEP_ALIVE_NIGHT_HOURS,
)

log = logging.getLogger(__name__)


def _is_admin(interaction) -> bool:
    return interaction.user.id in ADMIN_USER_IDS


# payload の中で人が読める文言が入っていそうなキー
_TEXT_KEYS = {"title", "body", "message", "description", "text", "subtitle",
              "displaymessage", "errormessage", "heading", "caption"}


def _payload_detail(payload: dict, limit: int = 250) -> str:
    """PayPayが返した payload から、人が読める文言をできるだけ拾う。

    「Specific Error with half sheet（S9999）」のように、汎用コードだけ返して
    本当の理由はアプリ側のハーフシートに載せてくることがある。その文言は
    payload に入っているので、拾えるものは拾い、無ければ payload をそのまま出す。
    """
    if not isinstance(payload, dict) or not payload:
        return ""

    texts = []

    def walk(node, depth=0):
        if depth > 4 or len(texts) >= 5:
            return
        if isinstance(node, dict):
            for k, v in node.items():
                if isinstance(v, str):
                    if v.strip() and k.lower() in _TEXT_KEYS and v.strip() not in texts:
                        texts.append(v.strip())
                else:
                    walk(v, depth + 1)
        elif isinstance(node, list):
            for v in node[:5]:
                walk(v, depth + 1)

    walk(payload)
    if texts:
        return " / ".join(texts)[:limit]
    try:
        return json.dumps(payload, ensure_ascii=False)[:limit]
    except (TypeError, ValueError):
        return str(payload)[:limit]


# PayPayが返す固有コードのうち、そのままでは何をすればいいか分からないもの。
_BACKEND_HINTS = {
    # 「Request logout because of Refresh Token is revoke.（S1003）」と一緒に返る。
    # PayPayは1アカウント1端末なので、スマホのアプリでこのアカウントにログインすると
    # 先に入っていたBot側が問答無用で切られる。こちらの更新の仕方は関係ない。
    "01182102": (
        "PayPayがこのセッションをログアウトさせました。スマホのPayPayアプリで"
        "この受取用アカウントにログインすると（出金のときなど）、PayPayは1アカウント"
        "1端末なので必ずBot側が切られます。心当たりがあればそれが原因です。"
        "出金は /paypay_status の「送金リンクを作る」から別アカウントへ移すと、"
        "このアカウントにアプリでログインせずに済みます。"
    ),
    # 「It was received unexpected error from the remote server.[]（S5000）」と
    # 一緒に返る。受取口が自分で送ったリンクを受け取ろうとしたときに、この形で
    # 断られることを実機で確認した。別のアカウントから送ったリンクでも同じ
    # コードが出るなら、自分のリンクかどうかは無関係ということになる。
    "42007001": (
        "受け取りが成立しない組み合わせのときに返るコードです。"
        "**受取口が自分で送ったリンクを受け取ろうとした**ときに、この形"
        "（S5000 / 42007001）で断られることを確認しています。"
        "別のアカウントから送ったリンクで試して、同じコードが出るかを"
        "確かめてください。出るなら原因は別にあります。"
    ),
    "P2P_BLOCK_FOR_MAYBE_EMULATOR": (
        "PayPayがこのクライアントを実機ではないと判定し、送金系の操作をブロックしています。"
        "アカウントの制限ではありません。送金リンクの作成はPayPayアプリから行ってください。\n"
        "**受け取りにも及ぶことがあります。**その場合は受け取りが通らず、送金は送り主へ"
        "差し戻されます（送り主のアプリでは「送金（譲渡）失敗」）。効くのは "
        "`PAYPAY_PROXY` に日本の住宅/モバイル回線のプロキシを入れることです。"
    ),
}


def _find_key(node, key: str, depth: int = 0):
    """入れ子になった応答から特定のキーの値を探す。"""
    if depth > 5:
        return None
    if isinstance(node, dict):
        if isinstance(node.get(key), str):
            return node[key]
        for v in node.values():
            found = _find_key(v, key, depth + 1)
            if found:
                return found
    elif isinstance(node, list):
        for v in node[:5]:
            found = _find_key(v, key, depth + 1)
            if found:
                return found
    return None


def _paypay_err(e) -> str:
    """PayPayError などから読みやすいエラー文言を取り出す。"""
    arg = e.args[0] if getattr(e, "args", None) else str(e)
    if isinstance(arg, dict):
        payload = arg.get("payload") or {}
        header = arg.get("header") or {}
        rest = {k: v for k, v in arg.items() if k != "header" and v not in (None, {}, [], "")}
        code = header.get("resultCode")
        msg = payload.get("message") if isinstance(payload.get("message"), str) else None
        msg = msg or header.get("resultMessage") or code
        base = f"{msg}（{code}）" if msg and code and msg != code else str(msg or code or arg)[:400]

        # 理由は payload だけでなく応答の別の場所に入っていることもある
        detail = _payload_detail(payload) or _payload_detail(rest) or _raw_rest(arg)
        out = f"{base}\n{detail}"[:400] if detail and detail not in base else base

        hint = _BACKEND_HINTS.get(_find_key(arg, "backendResultCode") or "")
        return f"{out}\n\n※ {hint}" if hint else out
    return str(arg)[:400]


def _raw_rest(raw: dict, limit: int = 250) -> str:
    """文言が拾えなかったときに、header以外の中身をそのまま出す。

    PayPayが理由を独自の構造で返してきても、何が返ってきたのかは分かるようにする。
    中身が空(本当に理由を返していない)なら空文字。
    """
    rest = {k: v for k, v in raw.items() if k != "header" and v not in (None, {}, [], "")}
    if not rest:
        return ""
    try:
        return json.dumps(rest, ensure_ascii=False)[:limit]
    except (TypeError, ValueError):
        return str(rest)[:limit]


# ログイン開始済み(OTLリンク待ち)の PayPay オブジェクトを保持する。
# user_id -> {"pp":PayPay, "phone":str, "password":str}
PENDING_LOGINS = {}


class LoginUrlModal(ui.Modal, title="PayPayログインURL入力"):
    url_input = ui.TextInput(
        label="ログイン用URL",
        placeholder="SMSで届いた https://www.paypay.ne.jp/portal/oauth2/l?id=... を貼り付け",
        style=discord.TextStyle.long,
        required=True,
    )

    def __init__(self, session: dict, cog=None):
        super().__init__(timeout=600)
        self.session = session
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        s = self.session
        try:
            await complete_login(
                s["pp"], self.url_input.value.strip(),
                interaction.user.id, s["phone"], s["password"],
            )
        except (PayPayLoginError, PayPayError, PayPayNetWorkError):
            embed = discord.Embed(
                title="PayPay認証エラー",
                description="ログインURLが正しくないか、有効期限が切れています。\n`/paypay登録` からやり直してください。",
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)

        PENDING_LOGINS.pop(str(interaction.user.id), None)
        if self.cog is not None:
            # 再ログインできたので通知状態を戻す
            self.cog._on_healthy()
        embed = discord.Embed(
            title="PayPay登録完了",
            description=(
                "PayPayアカウントの登録が完了しました。\n"
                "このアカウントで代行時の支払いを自動受取します。\n"
                f"セッションは{REFRESH_INTERVAL_HOURS}時間ごとに自動更新されます。"
            ),
            color=discord.Color.green(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


class LoginUrlView(ui.View):
    def __init__(self, cog=None):
        super().__init__(timeout=600)
        self.cog = cog

    @ui.button(label="ログインURLを入力", style=discord.ButtonStyle.primary, emoji="🔑")
    async def enter_url(self, interaction: discord.Interaction, button: ui.Button):
        session = PENDING_LOGINS.get(str(interaction.user.id))
        if not session:
            return await interaction.response.send_message(
                "認証セッションの有効期限が切れました。もう一度 `/paypay登録` を実行してください。",
                ephemeral=True,
            )
        await interaction.response.send_modal(LoginUrlModal(session, self.cog))


# 失効したまま放置されないよう、再ログインするまで一定間隔で通知し直す。
EXPIRY_RENOTIFY_HOURS = 6
# トークン更新がこの回数続けて失敗したら、まだ切れていなくても警告する。
REFRESH_FAIL_WARN = 2
# 定期処理をきっかり同じ時刻に走らせると機械的で目立つため、毎回この範囲で
# ずらしてから実行する(実行間隔の平均は変わらない)。
REFRESH_JITTER_SECONDS = 1800     # トークン更新: 1日1回 ±30分

JST = timezone(timedelta(hours=9))

# セッション履歴の表示。失効はPayPay側の判断で理由が返ってこないので、
# 「切れる直前に何をしていたか」を並べて見られるようにする。
_JOURNAL_LABELS = {
    "login": "🔑 ログイン",
    "relogin": "🔑 自動で入り直し（SMS認証なし）",
    "relogin_denied": "❌ 自動ログインを断られた",
    "relogin_unavailable": "❌ 自動で入り直せず（SMS認証が必要）",
    "refresh_ok": "🔄 更新",
    "refresh_salvaged": "🔄 更新（応答が読めず一部だけ回収）",
    "refresh_failed": "⚠️ 更新失敗（トークンは温存）",
    "refresh_unknown": "⚠️ 更新の結果不明（以後このトークンは使わない）",
    "access_token_dead": "❌ アクセストークンが無効",
    "revoked": "❌ 失効（再ログインが必要）",
}
JOURNAL_SHOW = 6


def _journal_lines() -> str:
    """直近の出来事を新しい順に整形する。"""
    lines = []
    for entry in reversed(read_journal()[-JOURNAL_SHOW:]):
        label = _JOURNAL_LABELS.get(entry.get("event"), entry.get("event", "?"))
        at = entry.get("at")
        when = f"<t:{int(at)}:R>" if at else "?"
        tokens = ""
        if entry.get("token"):
            tokens = f" `{entry['token']}`"
            if entry.get("new_token"):
                tokens += f" → `{entry['new_token']}`"
        lines.append(f"{when} {label}{tokens}")
    return "\n".join(lines)


def _keep_alive_delay() -> float:
    """次の生存確認までの秒数。時間帯に応じて幅を持たせる。

    このアカウントはアプリから触られていないので、Botのリクエストがそのまま
    「その人の使い方」になる。きっかり等間隔で24時間叩き続けるのをやめ、
    日中は数十分おき・深夜は数時間おきと、実際に開く人に近い間隔にする。
    """
    lo, hi = (KEEP_ALIVE_NIGHT_MINUTES
              if datetime.now(JST).hour in KEEP_ALIVE_NIGHT_HOURS
              else KEEP_ALIVE_DAY_MINUTES)
    return random.uniform(lo, hi) * 60


class ReloginView(ui.View):
    """失効通知DMに付ける「再ログインを開始」ボタン。

    まず保存済みの端末UUIDでの入り直しを試すので、たいていはボタン1回で終わる
    (PayPayは一度使った端末を覚えていて、その端末からならSMS認証が要らない)。
    それが通らないときだけ、従来どおりSMSのURLを貼り付けてもらう。
    Bot再起動後に古いDMのボタンを押しても動くよう、永続Viewにしてある。
    """

    def __init__(self, cog=None):
        super().__init__(timeout=None)
        self.cog = cog

    @ui.button(label="再ログインを開始", style=discord.ButtonStyle.primary, emoji="🔑",
               custom_id="paypay:relogin")
    async def relogin(self, interaction: discord.Interaction, button: ui.Button):
        if interaction.user.id not in ADMIN_USER_IDS:
            return await interaction.response.send_message(
                "この操作は管理者のみ実行できます。", ephemeral=True)

        phone, password = owner_login_info()
        if not phone or not password:
            return await interaction.response.send_message(
                "保存された電話番号・パスワードがありません。`/paypay` から登録してください。",
                ephemeral=True)

        await interaction.response.defer(ephemeral=True)

        # まずはSMS無しで入り直せないか試す(人が押したときは待ち時間を無視する)
        try:
            await paypay_relogin(force=True)
        except (ReloginUnavailableError, NotRegisteredError):
            pass                      # 端末を忘れられている → SMS認証へ
        except ReloginFailedError as e:
            return await interaction.followup.send(
                "PayPayとの通信に失敗しました。少し時間をおいてからもう一度押してください。\n"
                f"```{str(e)[:300]}```", ephemeral=True)
        except Exception as e:
            log.exception("PayPay relogin error: %s", e)
        else:
            if self.cog is not None:
                self.cog._on_healthy()
            return await interaction.followup.send(
                "✅ SMS認証なしで再ログインできました。自動受取はそのまま続きます。",
                ephemeral=True)

        try:
            pp = await start_login(phone, password)
        except PayPayLoginError as e:
            return await interaction.followup.send(
                "ログインを開始できませんでした。パスワードが変更されている可能性があります。\n"
                f"`/paypay` からやり直してください。\n```{_paypay_err(e)}```", ephemeral=True)
        except (PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                "PayPayとの通信に失敗しました。少し時間をおいてからもう一度押してください。\n"
                f"```{_paypay_err(e)}```", ephemeral=True)

        PENDING_LOGINS[str(interaction.user.id)] = {"pp": pp, "phone": phone, "password": password}
        embed = discord.Embed(
            title="SMSを送信しました",
            description=(
                f"`{phone[:3]}****{phone[-4:]}` にログイン用リンクを送りました。\n"
                "届いたURLを下のボタンから貼り付ければ再登録は完了です。"
            ),
            color=discord.Color.blurple(),
        )
        await interaction.followup.send(embed=embed, view=LoginUrlView(self.cog), ephemeral=True)


class PaypayCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # 再起動前に送ったDMのボタンも押せるように永続Viewを登録しておく
        bot.add_view(ReloginView(self))
        # 失効通知を送った時刻(再ログイン成功でリセット)。0 は未通知。
        self._expiry_notified_at = 0.0
        # トークン更新の連続失敗回数と、その警告を送ったかどうか
        self._refresh_failures = 0
        self._trouble_notified = False
        # 最後に生存確認できた時刻
        self._last_alive = 0.0
        # 失効を確認済みかどうか(再ログインでリセット)。生きていない状態で
        # 「最終生存確認 ◯分前」だけを出すと、直っていると勘違いするため。
        self._expired = False
        # 「急ぎではないが再ログインが要る」通知を送ったかどうか
        self._relogin_notified = False
        self.auto_refresh.start()
        self.keep_alive_loop.start()

    def cog_unload(self):
        self.auto_refresh.cancel()
        self.keep_alive_loop.cancel()

    # ---- 生存確認(切れたことに早く気付く / 放置による失効を防ぐ) ----

    @tasks.loop(minutes=KEEP_ALIVE_DAY_MINUTES[0])
    async def keep_alive_loop(self):
        """PayPayアプリを開いたのと同じリクエストを投げて、セッションを維持する。

        トークンは消費しないので、切れていたら次の周回で気付ける。間隔は毎回
        引き直す(日中は数十分・深夜は数時間)ので、等間隔の機械的な足跡が残らない。
        """
        self.keep_alive_loop.change_interval(seconds=_keep_alive_delay())
        try:
            ok = await keep_alive()
        except NotRegisteredError:
            return
        except PayPayLoginError:
            # アクセストークンが無効。トークン更新 → 端末UUIDでの再ログインの順に
            # 自動復帰を試す。どちらもできないときだけ人を呼ぶ。
            try:
                result = await recover_session()
            except NotRegisteredError:
                return
            except TokenExpiredError as e:
                log.warning("PayPay session expired: %s", _paypay_err(e))
                await self._notify_expired(_paypay_err(e))
                return
            except RefreshFailedError as e:
                # 一時的な失敗(通信断など)。次の周回でまた試す。
                log.warning("PayPay keep-alive recovery failed (will retry): %s", e)
                return
            except Exception as e:
                log.exception("PayPay keep-alive recovery error: %s", e)
                return
            self._on_healthy()
            log.info("PayPay session revived (%s)", result.get("how"))
            return
        except Exception as e:
            log.exception("PayPay keep-alive error: %s", e)
            return

        if ok:
            self._last_alive = datetime.now(timezone.utc).timestamp()
            self._on_healthy()

    @keep_alive_loop.before_loop
    async def _before_keep_alive(self):
        await self.bot.wait_until_ready()

    # ---- トークン自動更新(セッションが数日で切れるのを防ぐ) ----

    @tasks.loop(hours=REFRESH_INTERVAL_HOURS)
    async def auto_refresh(self):
        """1日1回トークンを回して、放置によるリフレッシュトークンの失効を防ぐ。

        更新は「回すほど安全」ではなく1回ごとに失効の危険があるので、これ以上は
        増やさない。失効したときと、更新が連続で失敗しているとき(まだ切れては
        いないが危険な状態)に管理者へDMする。
        """
        await asyncio.sleep(random.uniform(0, REFRESH_JITTER_SECONDS))
        try:
            result = await refresh_tokens()
        except NotRegisteredError:
            return
        except TokenExpiredError as e:
            # 失効。保存済みの端末UUIDで入り直せれば人手は要らない。
            if await self._try_auto_relogin():
                log.info("PayPay session restored by device relogin")
                return
            log.warning("PayPay token expired: %s", _paypay_err(e))
            await self._notify_expired(_paypay_err(e))
            return
        except RefreshUnsafeError as e:
            # 前回の更新の結果が分からず、リフレッシュトークンをもう使えない。
            # 受取はアクセストークンで続けられるが延命はできないので、ここで
            # 端末UUIDから入り直しておく(取れれば新しいトークン一式が手に入る)。
            if await self._try_auto_relogin():
                log.info("PayPay session renewed by device relogin (refresh token unusable)")
                return
            log.warning("PayPay refresh token unusable: %s", e)
            await self._notify_relogin_recommended(str(e))
            return
        except RefreshFailedError as e:
            # 一時的な通信エラー。次回(REFRESH_INTERVAL_HOURS後)に再試行する。
            # ただし連続で失敗しているなら、失効する前に知らせる。
            self._refresh_failures += 1
            log.warning("PayPay token refresh failed (will retry): %s", e)
            if self._refresh_failures >= REFRESH_FAIL_WARN:
                await self._notify_refresh_trouble(str(e))
            return
        except Exception as e:
            log.exception("PayPay auto refresh error: %s", e)
            return
        if result.get("refreshed"):
            self._on_healthy()
            log.info("PayPay token refreshed")

    @auto_refresh.before_loop
    async def _before_auto_refresh(self):
        await self.bot.wait_until_ready()

    async def _try_auto_relogin(self) -> bool:
        """保存済みの端末UUIDでこっそり入り直す。戻せたら True。

        PayPayは1アカウント1端末なので、スマホのアプリで受取用アカウントに入られると
        Bot側は必ず切られる。覚えられている端末から入り直せばSMS認証は要らないので、
        人を呼ぶ前にここで戻す。
        """
        try:
            await paypay_relogin()
        except NotRegisteredError:
            return False
        except ReloginUnavailableError as e:
            # 端末を忘れられた / パスワードが変わった等。ここから先は人手が要る。
            log.warning("PayPay device relogin unavailable: %s", _paypay_err(e))
            return False
        except RefreshFailedError as e:
            # 一時的な失敗(通信断など)。まだ失効と決まったわけではない。
            log.warning("PayPay device relogin failed (will retry): %s", e)
            return False
        except Exception as e:
            log.exception("PayPay device relogin error: %s", e)
            return False
        self._on_healthy()
        return True

    def _on_healthy(self):
        """セッションが生きていることを確認できたときに通知状態を戻す。"""
        self._refresh_failures = 0
        self._trouble_notified = False
        self._expiry_notified_at = 0.0
        self._expired = False
        self._relogin_notified = False

    async def _dm_admins(self, embed: discord.Embed, view: ui.View = None):
        for uid in ADMIN_USER_IDS:
            try:
                user = self.bot.get_user(uid) or await self.bot.fetch_user(uid)
                if view is not None:
                    await user.send(embed=embed, view=view)
                else:
                    await user.send(embed=embed)
            except Exception:
                continue

    async def _notify_expired(self, detail: str = ""):
        """PayPayセッションが失効したことを管理者にDMで知らせる。

        再ログインされるまで EXPIRY_RENOTIFY_HOURS ごとに送り直す
        (1通見逃すと丸一日受取が止まるため)。
        """
        self._expired = True
        now = datetime.now(timezone.utc).timestamp()
        if self._expiry_notified_at and now - self._expiry_notified_at < EXPIRY_RENOTIFY_HOURS * 3600:
            return
        self._expiry_notified_at = now
        embed = discord.Embed(
            title="⚠️ PayPayのログインが切れました",
            description=(
                "トークンの更新も、保存済みの端末での入り直しもできませんでした。\n"
                "SMS認証からの再ログインが必要です。\n\n"
                "下の **再ログインを開始** を押すと、登録済みの電話番号にSMSが届きます。\n"
                "届いたURLを貼り付けるだけで復旧できます。\n\n"
                "**このままだと代行の自動受取ができません。**\n\n"
                "※ 直前にスマホのPayPayアプリでこのアカウントにログインしませんでしたか？"
                "PayPayは1アカウント1端末なので、その時点でBot側は必ず切られます。"
                "出金は `/paypay_status` の「送金リンクを作る」を使えば、アプリで"
                "ログインせずに別アカウントへ移せます。"
            ),
            color=0xff3333,
        )
        if detail:
            embed.add_field(name="PayPayの応答", value=f"```{detail[:300]}```", inline=False)
        embed.set_footer(text=f"再登録されるまで{EXPIRY_RENOTIFY_HOURS}時間ごとに通知します")
        await self._dm_admins(embed, view=ReloginView(self))

    async def _notify_relogin_recommended(self, detail: str = ""):
        """まだ受け取れるが、延命ができなくなったことを知らせる(1回だけ)。

        失効DMと違って急ぎではない。再ログインは回数を重ねるほどPayPay側の
        制限に近づくので、「今すぐ」ではなく「都合のいいときに」と伝える。
        """
        if self._relogin_notified:
            return
        self._relogin_notified = True
        embed = discord.Embed(
            title="🔑 PayPayの再ログインをおすすめします（急ぎではありません）",
            description=(
                "トークンの更新結果が確認できなかったため、安全のためこのリフレッシュ"
                "トークンの使用を止めました。保存済みの端末での入り直しも通りませんでした。\n"
                "**受け取りは今まで通りできます**が、セッションの延命ができないので、"
                "いずれ切れます。\n\n"
                "手が空いたときに下のボタンから再ログインしてください。"
            ),
            color=0xffaa00,
        )
        if detail:
            embed.add_field(name="理由", value=f"```{detail[:300]}```", inline=False)
        await self._dm_admins(embed, view=ReloginView(self))

    async def _notify_refresh_trouble(self, detail: str = ""):
        """トークン更新が連続で失敗していることを、失効する前に知らせる(1回だけ)。"""
        if self._trouble_notified:
            return
        self._trouble_notified = True
        embed = discord.Embed(
            title="⚠️ PayPayのトークン更新に連続で失敗しています",
            description=(
                f"{self._refresh_failures}回続けて更新できていません。まだログインは生きていますが、"
                "このまま失敗し続けるとセッションが切れます。\n"
                "`/paypay_refresh` を実行して復帰するか確認してください。"
            ),
            color=0xffaa00,
        )
        if detail:
            embed.add_field(name="エラー", value=f"```{detail[:300]}```", inline=False)
        await self._dm_admins(embed)

    @app_commands.command(name="paypay", description="PayPayを登録")
    @is_allowed()
    @app_commands.describe(phone="電話番号", password="パスワード")
    async def paypay_register(self, interaction: discord.Interaction, phone: str, password: str):
        await interaction.response.defer(ephemeral=True)

        # 同じ番号を登録し直すだけなら、前と同じ端末を名乗ればSMS認証は要らない。
        # 毎回新しい端末を名乗るとPayPay側の登録端末が増え、先に入っていた
        # セッションが切られる原因にもなるので、使い回せるなら使い回す。
        device_uuid = owner_device_uuid(phone)
        if device_uuid:
            try:
                await device_login(phone, password, device_uuid, user_id=interaction.user.id)
            except (ReloginUnavailableError, ReloginFailedError):
                pass                  # 端末を忘れられている等 → SMS認証へ
            except Exception as e:
                log.warning("PayPay device login failed, falling back to SMS: %s", e)
            else:
                self._on_healthy()
                embed = discord.Embed(
                    title="PayPay登録完了",
                    description=(
                        "前回と同じ端末として登録し直したので、SMS認証は不要でした。\n"
                        f"セッションは{REFRESH_INTERVAL_HOURS}時間ごとに自動更新されます。"
                    ),
                    color=discord.Color.green(),
                )
                return await interaction.followup.send(embed=embed, ephemeral=True)

        try:
            pp = await start_login(phone, password)
        except PayPayLoginError as e:
            embed = discord.Embed(
                title="PayPayログインエラー",
                description=(
                    "電話番号・パスワードが正しいか確認してください。\n"
                    "（正しいのに出る場合は、下のPayPay側の応答を確認してください）\n"
                    f"```{_paypay_err(e)}```"
                ),
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)
        except PayPayNetWorkError:
            embed = discord.Embed(
                title="PayPay接続エラー",
                description="PayPayに接続できませんでした。\nBotのサーバーが日本国内にあるか確認してください。",
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)
        except Exception as e:
            embed = discord.Embed(
                title="PayPayログイン処理エラー",
                description=f"ログイン処理中にエラーが発生しました。\n```{str(e)[:500]}```",
                color=0xff3333,
            )
            return await interaction.followup.send(embed=embed, ephemeral=True)

        PENDING_LOGINS[str(interaction.user.id)] = {"pp": pp, "phone": phone, "password": password}

        embed = discord.Embed(
            title="SMS認証",
            description=(
                "電話番号宛にログイン用のURLを送信しました。\n"
                "SMSに届いたURLを下のボタンから貼り付けてください。"
            ),
            color=discord.Color.blue(),
        )
        await interaction.followup.send(embed=embed, view=LoginUrlView(self), ephemeral=True)

    # ---- PayPay操作系(登録済みの共有アカウントで操作) ----

    async def _guard(self, interaction):
        if not _is_admin(interaction):
            await interaction.response.send_message("権限がありません。", ephemeral=True)
            return False
        return True

    async def status_embed(self) -> discord.Embed:
        """セッション状態と残高をまとめたEmbedを作る。残高が取れなくても状態は出す。"""
        st = token_status()
        e = discord.Embed(title="PayPayの状態", color=discord.Color.blue())
        phone = st.get("phone") or ""
        if phone:
            e.add_field(name="アカウント", value=f"`{phone[:3]}****{phone[-4:]}`", inline=False)

        bal = None
        try:
            bal = await run_owner_op(lambda pp: pp.get_balance())
        except TokenExpiredError as ex:
            # 失効していると残高だけでなく受取も止まる。ここで気付いたときも
            # 再ログイン導線(DM)を出しておく(定期処理の次の周回を待たない)。
            e.color = 0xff3333
            e.add_field(
                name="残高",
                value=("取得できませんでした\n**PayPayのログインが切れています。"
                       "`/paypay` で再ログインしてください。**\n"
                       f"```{_paypay_err(ex)[:200]}```"),
                inline=False)
            await self._notify_expired(_paypay_err(ex))
        except (NotRegisteredError, PayPayLoginError, PayPayError, PayPayNetWorkError) as ex:
            e.add_field(name="残高", value=f"取得できませんでした\n```{_paypay_err(ex)[:200]}```", inline=False)
        if bal is not None:
            money = f"\nマネー {bal.money:,}円" if bal.money is not None else ""
            e.add_field(
                name="残高",
                value=(f"**{bal.all_balance:,}円**（利用可能 {bal.useable_balance:,}円）\n"
                       f"マネーライト {bal.money_light:,}円{money}\nポイント {bal.points:,}pt"),
                inline=False)
            # マネーの財布が無い = 本人確認が未完了。マネーで送られた送金は
            # 受け取れず、PayPayが送金ごと失敗させて送り主へ差し戻す。
            # 送る側は本人確認が要らないので、送金だけ通って受け取りが落ちる。
            if bal.money is None:
                e.color = 0xff3333
                e.add_field(
                    name="⚠️ PayPayマネーの受け取り",
                    value=("**できません（本人確認が未完了）**\n"
                           "マネーで送られた送金は受け取れず、送り主へ差し戻されます"
                           "（送り主のアプリでは「送金（譲渡）失敗」）。\n"
                           "PayPayアプリで本人確認を済ませると受け取れるようになります。"),
                    inline=False)

        for label, ts in (("最終ログイン", st.get("logged_in_at")), ("最終トークン更新", st.get("refreshed_at"))):
            e.add_field(name=label,
                        value=(f"<t:{int(ts)}:f>（<t:{int(ts)}:R>）" if ts else "記録なし（旧データ）"),
                        inline=False)
        if st.get("refresh_unsafe"):
            rt_state = "**使用停止中（結果不明のため / 再ログイン推奨）**"
        elif st.get("has_refresh_token"):
            rt_state = "あり"
        else:
            rt_state = "**なし（再ログイン推奨）**"
        e.add_field(name="リフレッシュトークン", value=rt_state, inline=True)
        if st.get("relogin_denied_at"):
            relogin_state = (f"**断られました**（<t:{int(st['relogin_denied_at'])}:R>）\n"
                             "パスワードが変わっていないか確認してください")
        elif st.get("can_relogin"):
            relogin_state = "可（切られてもSMS認証なしで戻ります）"
        else:
            relogin_state = "**不可（切れるとSMS認証が必要）**"
        e.add_field(name="自動再ログイン", value=relogin_state, inline=True)
        e.add_field(name="自動更新", value=f"{REFRESH_INTERVAL_HOURS}時間ごと（1日1回）", inline=True)
        e.add_field(name="生存確認",
                    value=(f"{KEEP_ALIVE_DAY_MINUTES[0]}〜{KEEP_ALIVE_DAY_MINUTES[1]}分ごと"
                           f"（深夜は{KEEP_ALIVE_NIGHT_MINUTES[0] // 60}〜"
                           f"{KEEP_ALIVE_NIGHT_MINUTES[1] // 60}時間ごと）"), inline=True)
        e.add_field(name="名乗るアプリ版", value=f"{get_app_version()}（{version_source()}）", inline=True)
        # 受け取りが弾かれると売上がまるごと止まる(送金は送り主へ差し戻される)。
        # 直結はその最有力の原因なので、ただの情報ではなく警告として出す。
        e.add_field(name="送金・受け取りの経路",
                    value=("プロキシ経由" if st.get("proxied")
                           else "⚠️ **直結（このサーバーのIP）**\n"
                                "PayPayに実機でないと判定されやすく、受け取りごと"
                                "弾かれることがあります。`PAYPAY_PROXY` の設定を"
                                "検討してください。"), inline=True)
        if self._expired:
            e.add_field(name="セッション", value="**失効（再ログインが必要）**", inline=True)
        elif self._last_alive:
            e.add_field(name="最終生存確認", value=f"<t:{int(self._last_alive)}:R>", inline=True)
        if self._refresh_failures:
            e.add_field(name="⚠️ 連続更新失敗", value=f"{self._refresh_failures}回", inline=True)

        e.add_field(name="送金で先に使う財布", value=await _priority_text(), inline=False)

        history = _journal_lines()
        if history:
            e.add_field(name="セッションの履歴", value=history, inline=False)
        return e

    @app_commands.command(
        name="paypay_status",
        description="PayPayの残高・履歴・操作")
    async def paypay_status(self, interaction: discord.Interaction):
        if not await self._guard(interaction): return
        if not token_status().get("registered"):
            return await interaction.response.send_message(
                "PayPayアカウントは未登録です。`/paypay` で登録してください。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        await interaction.followup.send(embed=await self.status_embed(),
                                        view=SessionActionView(self), ephemeral=True)


async def _priority_text() -> str:
    """送金で先に使う財布の表示。分からないときは分からないと書く。

    PayPayに取得APIが無いので、応答から読めたときだけ「今の設定」と言い切り、
    こちらの控えしか無いときはそう断る。スマホのアプリから変えられていても
    こちらには届かないので、控えを「今の設定」と見せると嘘になる。
    """
    try:
        state = await money_priority()
    except Exception:
        return "確認できませんでした"
    value = state.get("value")
    if not value:
        return ("**未確認**\n"
                "下の「送金の優先種別」から設定すると、それ以降は表示されます。")
    label = PRIORITY_LABELS.get(value, value)
    if state.get("source") == "paypay":
        return f"**{label}**"
    when = f"（<t:{int(state['at'])}:R> に設定）" if state.get("at") else ""
    return (f"**{label}**{when}\n"
            "※ Botが設定した値です。PayPayアプリ側で変えられていると一致しません。")


class PriorityView(ui.View):
    """送金で先に使う財布を切り替える。

    受け取りは選べないので、ここには出さない。受け取った額がどちらの財布に
    入るかは送り主が決める(送金リンクがその内訳をそのまま運んでくる)。
    """

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def _apply(self, interaction: discord.Interaction, paypay_money: bool):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            state = await set_money_priority(paypay_money)
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"変更できませんでした。\n```{_paypay_err(e)}```", ephemeral=True)
        label = PRIORITY_LABELS.get(state["value"], state["value"])
        await interaction.followup.send(
            f"✅ 送金で先に使う財布を **{label}** にしました。\n"
            "口座ぜんたいの設定なので、以降の送金すべてに効きます。",
            ephemeral=True)

    @ui.button(label="マネーから先に出す", style=discord.ButtonStyle.primary)
    async def money_first(self, interaction: discord.Interaction, button: ui.Button):
        await self._apply(interaction, True)

    @ui.button(label="マネーライトから先に出す", style=discord.ButtonStyle.primary)
    async def light_first(self, interaction: discord.Interaction, button: ui.Button):
        await self._apply(interaction, False)


class WithdrawModal(ui.Modal, title="送金リンクを作る"):
    """受取用アカウントから送金リンクを作って、残高を外に出すための入力。

    出金のたびにスマホのアプリでこのアカウントにログインしていると、そのたびに
    Botのセッションが切られる(PayPayは1アカウント1端末)。リンクで別アカウントへ
    移してからそちらで出金すれば、受取用アカウントにアプリで触る必要がなくなる。
    """

    amount_input = ui.TextInput(
        label="金額（空欄なら利用可能残高の全額）",
        placeholder="例: 10000",
        required=False,
    )
    passcode_input = ui.TextInput(
        label="受け取りパスコード（任意・数字4桁）",
        placeholder="付けておくと、リンクが漏れても受け取られない",
        required=False,
        max_length=4,
    )

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        passcode = self.passcode_input.value.strip() or None
        raw = self.amount_input.value.strip().replace(",", "").replace("円", "")

        if raw:
            if not raw.isdigit():
                return await interaction.followup.send("金額は数字で入れてください。", ephemeral=True)
            amount = int(raw)
        else:
            try:
                bal = await run_owner_op(lambda pp: pp.get_balance())
            except (NotRegisteredError, PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
                return await interaction.followup.send(
                    f"残高を取得できませんでした。\n```{_paypay_err(e)}```", ephemeral=True)
            amount = bal.useable_balance

        if amount <= 0:
            return await interaction.followup.send("出せる残高がありません。", ephemeral=True)

        try:
            link = await run_owner_op(lambda pp: pp.create_link(amount, passcode=passcode))
        except (NotRegisteredError, PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"リンクを作れませんでした。\n```{_paypay_err(e)}```", ephemeral=True)

        embed = discord.Embed(
            title="送金リンクを作りました",
            description=(
                f"**{amount:,}円**\n{link.link}\n\n"
                "このリンクを、**受け取り用の別アカウント**（スマホのアプリでログインしている方）で"
                "受け取ってから、そちらで銀行へ出金してください。\n\n"
                "⚠️ 受取用アカウントのほうをアプリでログインすると、その時点でBotのセッションが"
                "切れて再ログインが必要になります。"
            ),
            color=discord.Color.green(),
        )
        if passcode:
            embed.add_field(name="パスコード", value=f"`{passcode}`", inline=True)
        embed.set_footer(text="受け取られるまでは「送金を取り消す」で戻せます")
        await interaction.followup.send(embed=embed, ephemeral=True)


# 取引種別を、PayPayアプリで見るのと同じ言い方にする。
_KIND_LABELS = {
    "RECEIVE": "受け取り",
    "SEND": "送金",
    "TOPUP": "チャージ",
    "CASHBACK": "還元",
    "MERCHANT": "支払い",
    "PAYMENT": "支払い",
    "REFUND": "返金",
    "WITHDRAW": "出金",
}


def _kind_label(entry: dict) -> str:
    """取引種別の見出し。知らない種別はそのまま出す(黙って隠さない)。"""
    order_type = entry.get("type") or ""
    for key, label in _KIND_LABELS.items():
        if key in order_type:
            return label
    return order_type or "取引"


def _direction(entry: dict) -> str:
    """入り・出・自分の入り・失敗。向きは金額に付いた符号(amountPrefix)で決まる。

    種別名では決まらない。PayPayは受け取りの履歴にも orderType="P2PSEND" を
    付けるので、名前で見ると入金が全部「送金」に化ける。
    """
    kind = reconcile.classify(entry)
    if kind == "outgoing":
        return history_view.OUT
    if kind == "self":
        return history_view.SELF
    if kind == "dead":
        return history_view.FAIL
    return history_view.IN


def history_embed(entries: list, balance=None) -> discord.Embed:
    """PayPayアプリの取引履歴に近い形で並べる（並べ方は history_view と共通）。"""
    return history_view.render(entries, title="取引履歴", balance=balance,
                               direction=_direction, kind_label=_kind_label)


# 利用レポートの内訳。
#   種別に含まれる語 → (出の見出し, 入りの見出し, 向きの決め打ち)
#
# 向きは金額の符号がいちばん強い。ここの決め打ちは符号が読めないときの
# 受け皿で、None のものは符号でしか決まらない。
# P2P を決め打ちしてはいけない。PayPayは送金1件を送る側にも受け取る側にも
# 同じ種別(P2PSEND)で返すので、種別名からは向きが分からない。
_REPORT_RULES = (
    ("CASHBACK", "PayPayポイント利用", "PayPayポイント獲得額", usage_report.IN),
    ("AUTO_CHARGE", "チャージ取消", "チャージ額", usage_report.IN),
    ("TOPUP", "チャージ取消", "チャージ額", usage_report.IN),
    ("REFUND", "返金取消", "返金額", usage_report.IN),
    ("WITHDRAW", "銀行口座への出金額", "銀行口座からの入金額", usage_report.OUT),
    ("BANK", "銀行口座への出金額", "銀行口座からの入金額", usage_report.OUT),
    ("MERCHANT", "支払い額", "支払いの返金", usage_report.OUT),
    ("PAYMENT", "支払い額", "支払いの返金", usage_report.OUT),
    # ACQUIRING は加盟店での決済。買い物・アプリの課金がこれになる。
    ("ACQUIRING", "支払い額", "支払いの返金", usage_report.OUT),
    # ここから下は向きを決め打ちしない(符号でしか決まらない)
    ("P2P", "送金（譲渡）した額", "受け取り額", None),
    ("SEND", "送金（譲渡）した額", "受け取り額", None),
    ("RECEIVE", "送金（譲渡）した額", "受け取り額", None),
)


def _report_direction(entry: dict):
    """入りか出かを決める。決められなければ None。

    符号 → 向きの決まる種別 → 諦める、の順。決められないものを入金に
    寄せると、自分が払った額が「その他の入金」に並んで合計が狂う。
    """
    signed = reconcile.sign_direction(entry)
    if signed == "outgoing":
        return usage_report.OUT
    if signed == "incoming":
        return usage_report.IN
    order_type = (entry.get("type") or "").upper()
    if not order_type:
        return None
    for key, _out, _in, fixed in _REPORT_RULES:
        if key in order_type:
            return fixed          # 決め打ちの無い種別(P2Pなど)は None のまま
    return None


def _report_bucket(entry: dict):
    """1件を (向き, 見出し) に振り分ける。

    失敗・取り消しは数えない。向きが決まらないものは「不明」へ回す。
    知らない種別も落とさず「その他」に入れる(落とすと合計が合わなくなる)。
    """
    if reconcile.looks_dead(entry):
        return None, ""
    order_type = (entry.get("type") or "").upper()
    way = _report_direction(entry)
    if way is None:
        # 何が読めていないのかが分かるように、ゲーム側の種別をそのまま出す。
        return usage_report.UNKNOWN, order_type or "種別が読めない取引"
    for key, out_label, in_label, _fixed in _REPORT_RULES:
        if key in order_type:
            return way, out_label if way == usage_report.OUT else in_label
    side = "出金" if way == usage_report.OUT else "入金"
    return way, f"その他の{side}（{order_type}）" if order_type else f"その他の{side}"


def report_view(entries: list, fetched: int = 0) -> usage_report.ReportView:
    oldest = min((e.get("ts") or 0) for e in entries) if entries else 0
    return usage_report.ReportView(entries, bucket=_report_bucket,
                                   title="PayPay 利用レポート",
                                   fetched=fetched, oldest_ts=oldest)


# レポート用に取る履歴の件数。一覧の20件では月の合計に足りない。
# 返しきれなければ取れたところまでで集計し、その旨をレポートに書く。
REPORT_HISTORY_SIZE = int(os.environ.get("PAYPAY_REPORT_HISTORY_SIZE", "200"))


class HistoryView(ui.View):
    """取引履歴に添えるボタン。月ごとの合計はここから開く。"""

    def __init__(self):
        super().__init__(timeout=300)

    @ui.button(label="利用レポート（月ごとの入出金）",
               style=discord.ButtonStyle.primary, emoji="📊")
    async def report(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。",
                                                           ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            raw = await run_owner_op(
                lambda pp: pp.get_history(size=REPORT_HISTORY_SIZE))
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。",
                ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"利用レポートを作れませんでした。\n```{_paypay_err(e)}```",
                ephemeral=True)

        items = ((raw or {}).get("payload") or {}).get("paymentInfoList") or []
        entries = [reconcile.normalize_entry(x) for x in items
                   if isinstance(x, dict)]
        if not entries:
            return await interaction.followup.send(
                "集計できる取引がありませんでした。", ephemeral=True)
        view = report_view(entries, fetched=len(entries))
        await interaction.followup.send(embed=view.embed(), view=view,
                                        ephemeral=True)


class ChargeLinkModal(ui.Modal, title="請求リンクを作る"):
    """相手に払ってもらうためのリンク(PayPayの「送ってもらう」)を作る。"""

    amount_input = ui.TextInput(
        label="請求金額（空欄なら相手が金額を入れる）",
        placeholder="例: 1000",
        required=False,
    )

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        raw = self.amount_input.value.strip().replace(",", "").replace("円", "")
        amount = None
        if raw:
            if not raw.isdigit() or int(raw) <= 0:
                return await interaction.followup.send(
                    "請求金額は1円以上の数字で入れてください。", ephemeral=True)
            amount = int(raw)

        try:
            code = await run_owner_op(lambda pp: pp.create_p2pcode(amount))
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"請求リンクを作れませんでした。\n```{_paypay_err(e)}```", ephemeral=True)

        embed = discord.Embed(
            title="請求リンクを作りました",
            description=(f"**{amount:,}円**\n" if amount else "**金額は相手が入力します**\n")
                        + f"{code.p2pcode}\n\nこのリンクを相手に渡すと、受取用アカウントへ支払えます。",
            color=discord.Color.blue(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


class ReceiveLinkModal(ui.Modal, title="受け取りリンクから受け取る"):
    """送られてきたリンクを受取用アカウントで受け取る。

    受け取りは投げた時点でお金が動く。応答が読めなかっただけの場合に
    「失敗」と言い切ると、入金済みなのに気付けなくなるので分けて扱う。
    """

    link_input = ui.TextInput(
        label="PayPayリンク",
        placeholder="https://pay.paypay.ne.jp/...",
        required=True,
    )
    password_input = ui.TextInput(
        label="リンクパスワード（任意）",
        required=False,
        max_length=8,
    )

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        link = self.link_input.value.strip()
        passcode = self.password_input.value.strip() or None
        try:
            amount = await receive_payment(url=link, passcode=passcode)
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except ReceiveUnsure as e:
            return await interaction.followup.send(
                "受け取りの結果を確認できませんでした。**入金されている可能性があります**。\n"
                "もう一度受け取る前に、残高と履歴を確認してください。\n"
                f"```{str(e)[:200]}```", ephemeral=True)
        except PayPayLoginError:
            return await interaction.followup.send(
                "PayPayのログインが切れています。`/paypay` で再ログインしてください。", ephemeral=True)
        except PendingTimeout:
            # 弾かれてリンクが開いたまま。ここで生の理由は拾えないので、
            # 同じことをその場で再現できる診断へ案内する。
            return await interaction.followup.send(
                "受け取りが通らず、保留のまま待ち時間が終わりました。\n"
                "**このあとPayPayが送金を失敗させて送り主へ戻すことがあります。**\n"
                "「受け取りを診断」で同じリンクを試すと、PayPayが返した理由が"
                "そのまま出ます。", ephemeral=True)
        except (PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"受け取れませんでした。\n```{_paypay_err(e)}```", ephemeral=True)
        await interaction.followup.send(f"✅ **{amount:,}円** を受け取りました。", ephemeral=True)


def diagnosis_embed(report: dict) -> discord.Embed:
    """受け取り診断の結果を、そのまま読める形で出す。

    ここでは何も伏せない。原因が分からないまま「受け取れませんでした」だけを
    見せられている状態を終わらせるための画面なので、PayPayが返した文言・
    コード・リンクの中身・受取口の状態を全部並べる。
    """
    stage = report.get("stage")
    ok = stage == "received"
    embed = discord.Embed(
        title="✅ 受け取れました" if ok else "受け取りの診断",
        color=discord.Color.green() if ok else 0xff3333)

    if report.get("self_link"):
        # ここを見落とすと、断られたコードを本来の原因だと読み違える。
        # 何より先に出す。
        embed.description = (
            "⚠️ **これは受取口が自分で送ったリンクです。**\n"
            "PayPayは自分の送金を自分で受け取れないので、この結果からは"
            "本来の原因が分かりません。\n"
            "**別のアカウントから送ったリンクで試してください。**")

    if report.get("amount") is not None:
        embed.add_field(
            name="リンクの中身",
            value=(f"**{report['amount']:,}円**\n"
                   f"マネー {report.get('link_emoney', 0):,}円 / "
                   f"マネーライト {report.get('link_light', 0):,}円\n"
                   f"送り主 {report.get('sender') or '不明'}"
                   + ("（**受取口と同じ**）" if report.get("self_link") else "")
                   + f"\n状態 `{report.get('status')}`"
                   + ("\nパスワードあり" if report.get("has_password") else "")),
            inline=False)

    wallet = report.get("wallet")
    wallet_text = {True: "マネーの財布あり（本人確認済み）",
                   False: "**マネーの財布なし（本人確認が未完了）**",
                   None: "読み取れませんでした"}[wallet if wallet in (True, False) else None]
    embed.add_field(
        name="受取口",
        value=(f"残高 {report['balance']:,}円\n" if report.get("balance") is not None
               else f"残高を取れませんでした: `{report.get('balance_error', '')[:80]}`\n")
              + wallet_text
              + ("\n経路: プロキシ経由" if report.get("proxied") else "\n経路: 直結"),
        inline=False)

    # PayPayが返す状態は2か所ある。判定に使っているのは orderStatus だけなので、
    # もう一方(message.data.status)と生の中身も並べて、承認待ちのような状態が
    # 本当にあるのかを目で確かめられるようにする。
    raw_lines = [f"message.data.status = `{report.get('message_status')}`"]
    for name in ("pending_info", "message_data"):
        if report.get(name):
            raw_lines.append(f"`{str(report[name])[:300]}`")
    if report.get("message_status") is not None or len(raw_lines) > 1:
        embed.add_field(name="リンクの生の状態", value="\n".join(raw_lines)[:1024],
                        inline=False)

    stages = {"link_check": "リンクの情報を取れませんでした",
              "status": "受け取れる状態ではありませんでした（投げていません）",
              "receive": "**受け取りのPOSTが弾かれました**",
              "received": "受け取りのPOSTは通りました"}
    embed.add_field(name="どこで止まったか",
                    value=stages.get(stage, f"`{stage}`"), inline=False)

    if report.get("error") is not None:
        embed.add_field(name="PayPayの応答",
                        value=f"```{_paypay_err(report['error'])[:1000]}```", inline=False)
    if report.get("after") is not None:
        # 振り分けは paypay_async に一本化する。ここで同じ表を書き直すと、
        # 受け取り後の SUCCESS を「まだ開いています」と出しかねない
        # (受け取れているのに保留に見える)。
        after_note = {
            RECEIVED: "受け取れています（このリンクはもう開いていません）",
            GONE: "差し戻されています（送り主に戻りました）",
            PENDING: "まだ開いています（保留＝送金者の承認待ち）",
        }.get(classify_status(report["after"]),
              "**この状態は知らない値です。** そのまま伝えてください")
        embed.add_field(name="投げた後のリンクの状態",
                        value=f"`{report['after']}`\n{after_note}", inline=False)
    embed.set_footer(text="この内容をそのまま伝えれば原因を特定できます")
    return embed


class DiagnoseLinkModal(ui.Modal, title="受け取りを診断する"):
    """受け取りが通らない原因を、その場で1回だけ試して確かめる。

    保留の待ちも投げ直しもしない。PayPayが何と言って断ったのかを、
    コードごとそのまま出す。少額のリンクで試すためのもの。
    """

    link_input = ui.TextInput(
        label="PayPayリンク（少額で試してください）",
        placeholder="https://pay.paypay.ne.jp/...",
        required=True,
    )
    password_input = ui.TextInput(label="リンクパスワード（任意）", required=False,
                                  max_length=8)

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        try:
            report = await diagnose_link(self.link_input.value.strip(),
                                         passcode=self.password_input.value.strip() or None)
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except Exception as e:
            return await interaction.followup.send(
                f"診断そのものが失敗しました。\n```{_paypay_err(e)}```", ephemeral=True)
        await interaction.followup.send(embed=diagnosis_embed(report), ephemeral=True)


class CancelLinkModal(ui.Modal, title="送金を取り消す"):
    """まだ受け取られていない送金リンクを取り消して、残高を戻すための入力。

    金額を間違えた・相手が受け取らない、といったときに使う。
    受け取られた後は取り消せない(PayPay側の仕様)。
    """

    link_input = ui.TextInput(
        label="送金リンク",
        placeholder="https://pay.paypay.ne.jp/...",
        required=True,
    )

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        url = self.link_input.value.strip()
        if not url:
            return await interaction.followup.send("リンクを入れてください。", ephemeral=True)
        if "/" in url and "pay.paypay.ne.jp" not in url:
            return await interaction.followup.send(
                "PayPayの送金リンクを貼ってください。", ephemeral=True)

        def cancel(pp):
            # 先に状態を見てから取り消す。金額を控えておくと、取り消したものが
            # いくらだったのかを結果に出せる(リンクだけでは分からない)。
            info = pp.link_check(url)
            pp.link_cancel(url, link_info=info.raw)
            return info

        try:
            info = await run_owner_op(cancel)
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                "取り消せませんでした。\n"
                "（すでに受け取られている・辞退やキャンセル済み・このアカウントが作った"
                "リンクではない、のいずれかだと取り消せません）\n"
                f"```{_paypay_err(e)}```", ephemeral=True)

        embed = discord.Embed(
            title="送金を取り消しました",
            description=(f"**{int(info.amount):,}円** を残高に戻しました。\n`{url}`"),
            color=discord.Color.orange(),
        )
        await interaction.followup.send(embed=embed, ephemeral=True)


class SessionActionView(ui.View):
    """状態表示に付ける操作ボタン。

    たまにしか使わない操作(送金リンク・取り消し・トークンの手動更新・サインアウト)は、
    専用コマンドを増やさずここに置く。サインアウトは戻せないので、もう一段確認を挟む。
    """

    def __init__(self, cog: "PaypayCog"):
        super().__init__(timeout=300)
        self.cog = cog

    # --- 1段目: お金の出し入れ ---

    @ui.button(label="送金リンクを作る", style=discord.ButtonStyle.success, emoji="💸", row=0)
    async def withdraw(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(WithdrawModal(self.cog))

    @ui.button(label="請求リンクを作る", style=discord.ButtonStyle.success, emoji="🧾", row=0)
    async def charge_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(ChargeLinkModal(self.cog))

    @ui.button(label="受け取る", style=discord.ButtonStyle.success, emoji="📥", row=0)
    async def receive_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(ReceiveLinkModal(self.cog))

    @ui.button(label="送金を取り消す", style=discord.ButtonStyle.secondary, emoji="↩️", row=0)
    async def cancel_link(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(CancelLinkModal(self.cog))

    # --- 3段目: 口座の設定 ---

    @ui.button(label="送金の優先種別", style=discord.ButtonStyle.secondary, emoji="⚖️", row=2)
    async def priority(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        embed = discord.Embed(
            title="送金で先に使う財布",
            description=("**送るとき**にどちらの財布から先に出るかの設定です。\n"
                         "先の財布が尽きると、足りない分はもう一方が混ざります。"),
            color=discord.Color.blue())
        embed.add_field(name="いまの設定", value=await _priority_text(), inline=False)
        embed.add_field(
            name="受け取りについて",
            value=("受け取りには**この設定は効きません**。受け取った額がマネーに"
                   "入るかマネーライトに入るかは、**送り主がどちらから送ったか**で"
                   "決まります（受け取る側では選べません）。"),
            inline=False)
        await interaction.followup.send(embed=embed, view=PriorityView(self.cog),
                                        ephemeral=True)

    # --- 2段目: 確認・メンテナンス ---

    @ui.button(label="受け取りを診断", style=discord.ButtonStyle.danger, emoji="🩺", row=1)
    async def diagnose(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.send_modal(DiagnoseLinkModal(self.cog))

    @ui.button(label="取引履歴", style=discord.ButtonStyle.primary, emoji="📜", row=1)
    async def history(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            raw = await run_owner_op(lambda pp: pp.get_history(size=20))
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"取引履歴を取得できませんでした。\n```{_paypay_err(e)}```", ephemeral=True)

        items = ((raw or {}).get("payload") or {}).get("paymentInfoList") or []
        entries = [reconcile.normalize_entry(x) for x in items if isinstance(x, dict)]
        balance = None
        try:
            bal = await run_owner_op(lambda pp: pp.get_balance())
            balance = bal.all_balance
        except Exception:
            pass    # 残高が取れなくても履歴は出す
        await interaction.followup.send(embed=history_embed(entries, balance),
                                        view=HistoryView(), ephemeral=True)

    @ui.button(label="アカウント情報", style=discord.ButtonStyle.primary, emoji="👤", row=1)
    async def profile(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            prof = await run_owner_op(lambda pp: pp.get_profile())
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (PayPayLoginError, PayPayError, PayPayNetWorkError) as e:
            return await interaction.followup.send(
                f"取得できませんでした。\n```{_paypay_err(e)}```", ephemeral=True)
        embed = discord.Embed(title="受取用アカウント", color=discord.Color.blurple())
        embed.add_field(name="表示名", value=prof.name or "—", inline=True)
        embed.add_field(name="ユーザーID", value=f"`{prof.external_user_id}`", inline=False)
        if prof.icon:
            embed.set_thumbnail(url=prof.icon)
        await interaction.followup.send(embed=embed, ephemeral=True)

    @ui.button(label="トークン更新", style=discord.ButtonStyle.secondary, emoji="🔄", row=1)
    async def refresh(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        try:
            result = await refresh_tokens(force=True)
        except NotRegisteredError:
            return await interaction.followup.send(
                "PayPayアカウントが未登録です。`/paypay` で登録してください。", ephemeral=True)
        except (TokenExpiredError, RefreshUnsafeError) as e:
            # 更新では戻せない。保存済みの端末で入り直せればここで復旧できる。
            if await self.cog._try_auto_relogin():
                return await interaction.followup.send(
                    "✅ トークンを更新できなかったので、保存済みの端末で入り直しました。"
                    "（SMS認証は不要でした）", ephemeral=True)
            if isinstance(e, TokenExpiredError):
                return await interaction.followup.send(
                    "❌ セッションが失効しています。`/paypay` で再ログインしてください。\n"
                    f"```{_paypay_err(e)}```", ephemeral=True)
            return await interaction.followup.send(
                "⚠️ 前回の更新の結果が確認できていないため、このリフレッシュトークンは使いません。\n"
                "（使い回すとセッションごと失効するため）\n"
                "**受け取りは今まで通りできます。** 都合のいいときに `/paypay` で再ログインしてください。\n"
                f"```{str(e)[:300]}```", ephemeral=True)
        except RefreshFailedError as e:
            return await interaction.followup.send(
                f"⚠️ 一時的に更新できませんでした（再ログインは不要です）。\n```{str(e)[:300]}```", ephemeral=True)
        self.cog._on_healthy()
        ts = int(result.get("refreshed_at") or 0)
        await interaction.followup.send(
            f"✅ トークンを更新しました。（<t:{ts}:f>）" if ts else "✅ トークンを更新しました。", ephemeral=True)

    @ui.button(label="サインアウト", style=discord.ButtonStyle.danger, emoji="🚪", row=1)
    async def signout(self, interaction: discord.Interaction, button: ui.Button):
        if not _is_admin(interaction):
            return await interaction.response.send_message("権限がありません。", ephemeral=True)

        async def confirm(inter: discord.Interaction):
            removed = signout_owner()
            await inter.response.edit_message(
                content=("PayPayアカウントをサインアウトしました。`/paypay` で登録し直せます。"
                         if removed else "登録済みのPayPayアカウントはありません。"),
                view=None)

        view = ui.View(timeout=60)
        btn = ui.Button(label="サインアウトする", style=discord.ButtonStyle.danger)
        btn.callback = confirm
        view.add_item(btn)
        await interaction.response.send_message(
            "PayPayの認証情報を削除します。よろしいですか？\n（削除すると、再登録するまで自動受取が止まります）",
            view=view, ephemeral=True)


async def setup(bot):
    await bot.add_cog(PaypayCog(bot))
