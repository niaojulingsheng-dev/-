"""PKCE の code verifier / code challenge を生成する最小実装。

外部PyPIパッケージ `pkce` を同梱したもの(標準ライブラリのみに依存)。
デプロイ先が pip 依存を確実に入れられなくても import が通るように、
リポジトリに取り込んでいる。_core.py が自身のディレクトリを sys.path 先頭へ
挿入するため、`import pkce` はこのモジュールが優先的に解決される。
"""

import secrets
import hashlib
import base64
from typing import Tuple


def generate_code_verifier(length: int = 128) -> str:
    if not 43 <= length <= 128:
        raise ValueError('Parameter `length` must verify `43 <= length <= 128`.')
    return secrets.token_urlsafe(96)[:length]


def generate_pkce_pair(code_verifier_length: int = 128) -> Tuple[str, str]:
    if not 43 <= code_verifier_length <= 128:
        raise ValueError(
            'Parameter `code_verifier_length` must verify '
            '`43 <= code_verifier_length <= 128`.'
        )
    code_verifier = generate_code_verifier(code_verifier_length)
    code_challenge = get_code_challenge(code_verifier)
    return code_verifier, code_challenge


def get_code_challenge(code_verifier: str) -> str:
    if not 43 <= len(code_verifier) <= 128:
        raise ValueError(
            'Parameter `code_verifier` must verify '
            '`43 <= len(code_verifier) <= 128`.'
        )
    hashed = hashlib.sha256(code_verifier.encode('ascii')).digest()
    encoded = base64.urlsafe_b64encode(hashed)
    return encoded.decode('ascii')[:-1]
