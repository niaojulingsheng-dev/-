"""お客さんが支払いを試みた事実を、結果によらず必ず残す台帳。

入金だけが残って注文が消えると、それは「誰のものか分からないお金」になる。
突合に出た紐づかない入金は、どれも送り主の表示名しか分からず、Discordの
誰なのかを追えなかった。

そこで受け取りを試みる前に「誰が・何を・いくらで買おうとしたか」を書く。
成功した注文は売上に残るので、ここが効くのは失敗したときだけ。

記録は必ず閉じる(finish)。閉じられないまま残った試行は処理の途中で落ちた
ということなので、それ自体が手がかりになる。
"""
import asyncio
import os
import threading
import time
import uuid

from datapath import data_path, read_json, write_json

ATTEMPT_FILE = data_path("payment_attempts.json")

# 残しておく日数。売上と違って調査用なので、短くてよい。
KEEP_DAYS = int(os.environ.get("PAYMENT_ATTEMPT_KEEP_DAYS", "30"))

# 台帳の読み書きは「読んで・足して・書く」なので、同時に走ると片方の追記が
# 消える。支払い画面はこの書き込みをスレッドに逃がして(イベントループを
# 止めないため)呼ぶので、プロセス内で必ず直列にする。
_lock = threading.Lock()

# このプロセスで決着を書き込んだ控え番号。finish() は決着済みなら何もしないが、
# それを知るために毎回ファイルを読み直していた(支払いのたびに台帳を丸ごと
# 読む無駄)。覚えている番号はファイルを見ずに返す。
_settled_ids = set()
_SETTLED_REMEMBER = 2000


def _remember_settled(attempt_id: str):
    if len(_settled_ids) >= _SETTLED_REMEMBER:
        _settled_ids.clear()
    _settled_ids.add(attempt_id)

STARTED = "started"        # 受け取りを試み始めた(まだ決着していない)
DELIVERED = "delivered"    # お渡しまで完了した
WATCHING = "watching"      # 見張りへ引き継いだ(link_orders 側で追える)
DROPPED = "dropped"        # 決着せず終わった。入金があれば身元はここで分かる
REJECTED = "rejected"      # そもそも受け取れなかった(金額不足・無効なリンク等)

# 突合で「持ち主を探す」対象にする状態。delivered は売上側で拾えるので入れず、
# watching は link_orders 側で拾えるので入れない(同じ入金を二重に数えない)。
ORPHAN_STATUSES = (STARTED, DROPPED)


def _load() -> list:
    return read_json(ATTEMPT_FILE, [])


def _save(data: list):
    write_json(ATTEMPT_FILE, data)


def record(kind: str, user_id, *, amount: int, method: str, link: str = "",
           summary: str = "", guild_id=None, channel_id=None, payload: dict = None) -> str:
    """支払いを試みる前に1件書く。戻り値は finish/resolve に渡す控え番号。

    payload には、あとから注文をやり直すのに要るもの(代行なら引き継ぎコードと
    選択内容、自販機なら商品と個数)をそのまま入れる。入金だけ確認できた注文を
    人手を介さず届け直すのに使う。渡し終わったら消す(_clear_payload)。

    ここで失敗しても支払いは止めない(記録のために売上を落とすほうが損)。
    """
    attempt_id = f"PA-{uuid.uuid4().hex[:8].upper()}"
    try:
        with _lock:
            data = _load()
            data.append({
                "id": attempt_id,
                "ts": time.time(),
                "kind": kind,
                "user_id": str(user_id),
                "amount": int(amount or 0),
                "method": method,
                "link": (link or "")[:200],
                "summary": (summary or "")[:200],
                "guild_id": str(guild_id) if guild_id else None,
                "channel_id": str(channel_id) if channel_id else None,
                "payload": payload or {},
                "status": STARTED,
                "note": "",
            })
            _save(data)
    except Exception as e:
        print(f"[ATTEMPT RECORD ERROR] {e}", flush=True)
    return attempt_id


async def record_async(*args, **kwargs) -> str:
    """record() をスレッドで。支払い画面から呼ぶ用(イベントループを止めない)。"""
    return await asyncio.to_thread(record, *args, **kwargs)


# 決着した試行から payload を消す状態。payload には引き継ぎコードとPINが
# 入るので、届け直しに使う見込みが無くなった時点で持たない。
_PAYLOAD_DONE = (DELIVERED, WATCHING, REJECTED)


def _drop_payload_files(payload: dict):
    """payload が抱えていたファイル(預かったセーブ)を消す。

    payload を空にするだけだと、ディスク上のセーブが置き去りになる。
    支払いのたびに1つ増えるので、決着した時点で片付ける。
    """
    path = (payload or {}).get("save_file")
    if not path:
        return
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError as e:
        print(f"[ATTEMPT FILE CLEANUP] {path}: {e}", flush=True)


def resolve(attempt_id: str, status: str, note: str = ""):
    """試行の結末を書き込む。"""
    if not attempt_id:
        return
    try:
        with _lock:
            data = _load()
            for item in data:
                if item.get("id") == attempt_id:
                    item["status"] = status
                    item["note"] = (note or "")[:300]
                    item["resolved_at"] = time.time()
                    if status in _PAYLOAD_DONE:
                        # 渡し終わった / 見張りへ移した / 入金が無い のいずれか。
                        # 引き継ぎコードを持ち続ける理由が無いので落とす。見張りへ
                        # 移した分は注文側が別に退避を持っている。
                        _drop_payload_files(item.get("payload"))
                        item["payload"] = {}
                    break
            else:
                return
            _save(data)
            # 書き込めたときだけ覚える。書けなかった試行は finish() に
            # もう一度ファイルを見てもらう(started のまま残っていれば畳める)。
            _remember_settled(attempt_id)
    except Exception as e:
        print(f"[ATTEMPT RESOLVE ERROR] {e}", flush=True)


async def resolve_async(attempt_id: str, status: str, note: str = ""):
    """resolve() をスレッドで。支払い画面から呼ぶ用。"""
    await asyncio.to_thread(resolve, attempt_id, status, note)


def finish(attempt_id: str, note: str = "決着しないまま終了しました"):
    """まだ決着していなければ dropped にする。

    支払い画面の出口はいくつもあり、1つ書き漏らすとそこだけ記録が
    started のまま残る。呼び出し側の finally から必ず通して、
    「気付かないうちに消えた注文」を作らない。

    このプロセスで決着を書き込み済みの番号は、ファイルを読まずに返す
    (支払いが通ったあとの finally で、台帳を丸ごと読み直すだけだった)。
    """
    if not attempt_id or attempt_id in _settled_ids:
        return
    try:
        with _lock:
            data = _load()
            for item in data:
                if item.get("id") == attempt_id and item.get("status") == STARTED:
                    item["status"] = DROPPED
                    item["note"] = note[:300]
                    item["resolved_at"] = time.time()
                    _save(data)
                    break
            _remember_settled(attempt_id)
    except Exception as e:
        print(f"[ATTEMPT FINISH ERROR] {e}", flush=True)


async def finish_async(attempt_id: str, note: str = "決着しないまま終了しました"):
    """finish() をスレッドで。支払い画面の finally から呼ぶ用。"""
    if not attempt_id or attempt_id in _settled_ids:
        return
    await asyncio.to_thread(finish, attempt_id, note)


def all_attempts() -> list:
    """台帳の全件。速度・分割の判定(risk)がここから読む。"""
    return _load()


def orphans(max_age_seconds: float = None) -> list:
    """入金の持ち主を探す対象になる試行(渡せていないもの)。"""
    limit = time.time() - max_age_seconds if max_age_seconds else 0
    return [a for a in _load()
            if a.get("status") in ORPHAN_STATUSES and float(a.get("ts") or 0) >= limit]


def purge_old(days: int = KEEP_DAYS) -> int:
    limit = time.time() - days * 86400
    with _lock:
        data = _load()
        kept, gone = [], []
        for item in data:
            (kept if float(item.get("ts") or 0) >= limit else gone).append(item)
        if gone:
            for item in gone:
                _drop_payload_files(item.get("payload"))
            _save(kept)
    return len(gone)
