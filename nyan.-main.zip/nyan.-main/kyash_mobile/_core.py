"""Kyash のスマホアプリ向けAPIを叩く最小クライアント。

paypay_mobile と同じ考え方で、外部PyPIパッケージに頼らずリポジトリへ同梱する
(デプロイ先が pip 依存を確実に入れられなくても import が通るように)。
requests だけで動き、HTMLの解析も正規表現で済ませている。

対応している操作:
  - ログイン(メールアドレス + パスワード / SMSのワンタイムコード)
  - プロフィール・ウォレット(残高)・取引履歴の取得
  - 送金リンクの確認 / 受け取り / キャンセル
  - 送金リンク・請求リンクの作成

Kyash の応答は {"code":200,"result":{"data":{...}}} という形で、失敗時は
{"code":4xx,"error":{"message":"..."}} が返る。code が 200 以外なら例外にし、
認証切れ(401)だけは KyashLoginError にして呼び出し側で再ログインできるようにする。
"""
import re
import time
from typing import NamedTuple
from uuid import uuid4

import requests

# paypay_mobile も同名の app_version を持つので、必ずこのパッケージのものを使う
# (向こうは sys.path に自分のディレクトリを差し込むため、トップレベル名で
#  取り合いになる)。
from .app_version import get_app_version

API_BASE = "https://api.kyash.me"
LINK_BASE = "https://kyash.me/payments/"
REQUEST_TIMEOUT = 20

# 名乗る端末。実際に通ることが分かっている Kyasher(taka-4602/Kyasher) と同じ組み合わせ
# にしておく。ここだけ自分で盛っても得は無く、弾かれたときに切り分けが難しくなる。
# アプリのバージョンだけは App Store に追従する(古いクライアントは弾かれ得るため)。
DEVICE_INFO = "iPhone 8, Version:16.7.5"
USER_AGENT = "Kyash/2 CFNetwork/1240.0.4 Darwin/20.6.0"

# リンクのページ(HTML)から必要な情報を取り出す。Kyashは受け取り用の内部UUIDを
# アプリ起動用のスキームに埋め込んでいるので、そこから拾う。
_CLAIM_RE = re.compile(r"kyash://claim/([0-9A-Za-z\-]{8,})")
_REQUEST_RE = re.compile(r"kyash://request/u/([0-9A-Za-z\-]{8,})")
_AMOUNT_RE = re.compile(r'class="amountText[^"]*"[^>]*>\s*[¥￥]?\s*([\d,]+)')

_PAGE_HEADERS = {
    "User-Agent": ("Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) "
                   "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1"),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "ja-JP,ja;q=0.9",
}


class KyashError(Exception):
    pass


class KyashLoginError(Exception):
    pass


class KyashNetWorkError(Exception):
    pass


def error_message(err, limit: int = 300) -> str:
    """例外やAPI応答から、人が読める文言をできるだけ取り出す。"""
    raw = err.args[0] if isinstance(err, Exception) and err.args else err
    if isinstance(raw, dict):
        detail = raw.get("error")
        if isinstance(detail, dict):
            msg = detail.get("message") or detail.get("code")
            if msg:
                return str(msg)[:limit]
        message = raw.get("message")
        if message:
            return str(message)[:limit]
    return str(raw)[:limit]


class Profile(NamedTuple):
    username: str
    icon: str
    last_name: str
    first_name: str
    phone: str
    is_kyc: bool
    raw: dict


class Wallet(NamedTuple):
    uuid: str
    all_balance: int
    money: int
    value: int
    point: int
    raw: dict


class LinkInfo(NamedTuple):
    amount: int
    uuid: str
    public_id: str
    sender_name: str
    is_send_link: bool   # True=送金リンク(受け取れる) / False=請求リンク
    raw: dict


class CreatedLink(NamedTuple):
    link: str
    raw: dict


class Kyash:
    def __init__(self, email: str = None, password: str = None, client_uuid: str = None,
                 installation_uuid: str = None, access_token: str = None,
                 refresh_token: str = None, proxy: dict = None, timeout: int = REQUEST_TIMEOUT):
        if not (email and password) and not access_token:
            raise KyashLoginError("メールアドレスとパスワード、またはアクセストークンを指定してください")

        self.email = email
        self.password = password
        self.proxy = proxy
        self.timeout = timeout
        self.access_token = access_token
        self.refresh_token = refresh_token
        # 端末を識別するUUID。一度ログインした組み合わせを使い回すと、次回以降は
        # SMSのワンタイムコード無しでログインできる(=Bot単体で復帰できる)。
        self.client_uuid = client_uuid or str(uuid4()).upper()
        self.installation_uuid = installation_uuid or str(uuid4()).upper()
        self.session = requests.Session()

    # ---- 低レベル ----

    def _headers(self) -> dict:
        headers = {
            "Host": "api.kyash.me",
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Accept-Language": "ja-jp",
            "Accept-Encoding": "gzip, deflate, br",
            "User-Agent": USER_AGENT,
            "X-Kyash-Client-Id": self.client_uuid,
            "X-Kyash-Installation-Id": self.installation_uuid,
            "X-Kyash-Client-Version": get_app_version(),
            "X-Kyash-Device-Info": DEVICE_INFO,
            "X-Kyash-Device-Language": "ja",
            "X-Kyash-Os": "iOS",
            "X-Kyash-Date": str(round(time.time())),
            "Connection": "keep-alive",
        }
        if self.access_token:
            headers["X-Auth"] = self.access_token
        return headers

    def _call(self, method: str, path: str, *, body: dict = None, params: dict = None,
              auth: bool = True) -> dict:
        if auth and not self.access_token:
            raise KyashLoginError("まずはログインしてください")
        try:
            res = self.session.request(
                method, f"{API_BASE}{path}", headers=self._headers(),
                json=body, params=params, proxies=self.proxy, timeout=self.timeout,
            )
        except requests.exceptions.RequestException as e:
            raise KyashNetWorkError(e)

        try:
            data = res.json()
        except ValueError:
            raise KyashError(f"Kyashから解釈できない応答が返りました（HTTP {res.status_code}）")

        code = data.get("code", res.status_code)
        if code == 200:
            return data
        if code in (401, 403) or res.status_code in (401, 403):
            raise KyashLoginError(data)
        raise KyashError(data)

    @staticmethod
    def _data(res: dict) -> dict:
        return ((res.get("result") or {}).get("data")) or {}

    def _set_tokens(self, data: dict):
        self.access_token = data.get("token") or self.access_token
        self.refresh_token = data.get("refreshToken") or self.refresh_token

    # ---- ログイン ----

    def login_start(self) -> bool:
        """メールアドレスとパスワードでログインを開始する。

        戻り値 True  … トークンを取得できた(登録済み端末なのでワンタイムコード不要)
        戻り値 False … Kyashがワンタイムコードを送った。login_verify() に渡すこと。
        """
        res = self._call("POST", "/v2/login", auth=False,
                         body={"email": self.email, "password": self.password})
        data = self._data(res)
        if data.get("token"):
            self._set_tokens(data)
            return True
        return False

    def login_verify(self, otp: str) -> dict:
        """SMS(またはメール)で届いたワンタイムコードでログインを完了する。"""
        res = self._call("POST", "/v2/login/mobile/verify", auth=False,
                         body={"verificationCode": str(otp).strip(), "email": self.email})
        data = self._data(res)
        if not data.get("token"):
            raise KyashLoginError(res)
        self._set_tokens(data)
        return res

    # ---- 参照系 ----

    def get_profile(self) -> Profile:
        res = self._call("GET", "/v1/me")
        d = self._data(res)
        return Profile(
            username=d.get("userName") or "",
            icon=d.get("imageUrl") or "",
            last_name=d.get("lastNameReal") or "",
            first_name=d.get("firstNameReal") or "",
            phone=d.get("phoneNumber") or "",
            is_kyc=bool(d.get("kyc")),
            raw=res,
        )

    def alive(self) -> None:
        """アクセストークンがまだ有効かどうかだけを確かめる(生存確認)。"""
        self._call("GET", "/v1/me")

    def get_wallet(self) -> Wallet:
        res = self._call("GET", "/v1/me/primary_wallet")
        d = self._data(res)
        balance = d.get("balance") or {}
        breakdown = balance.get("amountBreakdown") or {}
        point = d.get("pointBalance") or {}
        return Wallet(
            uuid=d.get("uuid") or "",
            all_balance=int(balance.get("amount") or 0),
            money=int(breakdown.get("kyashMoney") or 0),
            value=int(breakdown.get("kyashValue") or 0),
            point=int(point.get("availableAmount") or 0),
            raw=res,
        )

    def get_history(self, wallet_uuid: str = None, limit: int = 10) -> list:
        if not wallet_uuid:
            wallet_uuid = self.get_wallet().uuid
        res = self._call("GET", f"/v1/me/wallets/{wallet_uuid}/timeline", params={"limit": limit})
        return self._data(res).get("timelines") or []

    # ---- リンク ----

    @staticmethod
    def _normalize_link(url: str) -> str:
        """貼られた文字列をリンクのページURLに直す。

        フルURL・スキーム無し(kyash.me/payments/...)・アプリ用スキーム・IDだけ、
        のどれで来ても開けるようにする(お客さんは色々な貼り方をするため)。
        """
        url = (url or "").strip()
        if not url:
            raise KyashError("リンクが空です")
        if url.startswith("kyash://"):
            return LINK_BASE + url.rstrip("/").rsplit("/", 1)[-1]
        if "kyash.me" in url:
            return url if url.startswith("http") else "https://" + url.lstrip("/")
        return LINK_BASE + url.rstrip("/").rsplit("/", 1)[-1]

    def _fetch_link_page(self, url: str) -> str:
        try:
            res = requests.get(self._normalize_link(url), headers=_PAGE_HEADERS,
                               proxies=self.proxy, timeout=self.timeout)
        except requests.exceptions.RequestException as e:
            raise KyashNetWorkError(e)
        if res.status_code == 404:
            raise KyashError("リンクが見つかりません。URLを確認してください")
        return res.text

    def link_check(self, url: str) -> LinkInfo:
        """送金リンクの中身(金額・受け取り用UUID)を確認する。

        金額と受け取り用UUIDはリンクのページから読む。実際に動いている実装
        (taka-4602/Kyasher)でも、通っているのはこのページ経由の経路だけで、
        /v1/links/{uuid} を引く経路は不具合で一度も実行されていない。
        そのため詳細の取得は「取れたら足す」だけの扱いにして、失敗しても
        受け取り自体は止めない(本当にトークンが切れていれば、続く受け取りの
        リクエストが 401 を返すので、そこで気付ける)。

        受け取り済み・キャンセル済みのリンクはページから受け取りボタンが消えるため、
        UUIDを拾えない = 処理済みとして扱う。
        """
        page = self._fetch_link_page(url)

        is_send_link = True
        matched = _CLAIM_RE.search(page)
        if not matched:
            matched = _REQUEST_RE.search(page)
            is_send_link = False
        if not matched:
            raise KyashError("受け取り済み・キャンセル済み、または送金リンクではありません")
        link_uuid = matched.group(1)

        amount = 0
        amount_matched = _AMOUNT_RE.search(page)
        if amount_matched:
            amount = int(amount_matched.group(1).replace(",", ""))

        public_id, sender_name, raw = "", "", {}
        try:
            raw = self._call("GET", f"/v1/links/{link_uuid}")
            detail = self._data(raw)
            target = detail.get("target") or {}
            public_id = target.get("publicId") or ""
            sender_name = target.get("userName") or ""
            amount = int(detail.get("amount") or amount)
        except (KyashLoginError, KyashError, KyashNetWorkError, TypeError, ValueError):
            pass

        return LinkInfo(amount=amount, uuid=link_uuid, public_id=public_id,
                        sender_name=sender_name, is_send_link=is_send_link, raw=raw)

    def link_receive(self, url: str = None, link_uuid: str = None) -> dict:
        """送金リンクを受け取る(自分のKyash残高に入る)。"""
        if not link_uuid:
            if not url:
                raise KyashError("受け取るリンクが指定されていません")
            info = self.link_check(url)
            if not info.is_send_link:
                raise KyashError("これは請求リンクです。送金リンクを送ってください")
            link_uuid = info.uuid
        return self._call("PUT", f"/v1/links/{link_uuid}/receive")

    def link_cancel(self, url: str = None, link_uuid: str = None) -> dict:
        if not link_uuid:
            if not url:
                raise KyashError("キャンセルするリンクが指定されていません")
            link_uuid = self.link_check(url).uuid
        return self._call("DELETE", f"/v1/links/{link_uuid}")

    def create_link(self, amount: int, message: str = "", is_claim: bool = False) -> CreatedLink:
        """送金リンク(is_claim=False)または請求リンク(is_claim=True)を作る。"""
        body = {
            "uuidClient": str(uuid4()).upper(),
            "amount": int(amount),
            "repeatable": bool(is_claim),
            "action": 2 if is_claim else 1,
            "message": {"text": message or "", "uuidClient": str(uuid4()).upper()},
            "service": "share",
        }
        res = self._call("POST", "/v1/me/links", body=body)
        return CreatedLink(link=self._data(res).get("link") or "", raw=res)
