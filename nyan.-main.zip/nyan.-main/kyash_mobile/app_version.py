"""名乗るKyashアプリのバージョンを決める。

PayPay と同じく、古いクライアントを名乗ると弾かれることがあるので
App Store の最新バージョンに追従する。取得結果は24時間キャッシュし、
取得できないときは FALLBACK_VERSION を使う(ネットワークが不調でも動く)。
環境変数 KYASH_APP_VERSION を入れておけば、それが最優先される。
"""
import json
import os
import re
import threading
import time

import requests

# App Store から取得できなかったときに名乗るバージョン。
# 追従できているかは /kyash_status で確認できる。
FALLBACK_VERSION = "12.12.0"

LOOKUP_URL = "https://itunes.apple.com/lookup?id=1084264883&country=jp"
CACHE_TTL = 24 * 3600      # 取得に成功したら1日は再取得しない
RETRY_AFTER = 600          # 失敗したら10分は再試行しない(操作のたびに外に出ない)
_VERSION_RE = re.compile(r"^\d+(\.\d+){1,3}$")

_lock = threading.Lock()
_state = {"version": None, "next_check": 0.0, "source": "fallback"}


def _cache_file() -> str:
    try:
        from datapath import data_path
        return data_path("kyash_app_version.json")
    except Exception:
        return os.path.join(os.path.dirname(os.path.abspath(__file__)), "app_version.json")


def _load_cache():
    try:
        with open(_cache_file(), "r", encoding="utf-8") as f:
            data = json.load(f)
        v = data.get("version")
        if isinstance(v, str) and _VERSION_RE.match(v):
            return v, float(data.get("fetched_at") or 0)
    except (OSError, ValueError, TypeError):
        pass
    return None, 0.0


def _save_cache(version: str, fetched_at: float):
    try:
        with open(_cache_file(), "w", encoding="utf-8") as f:
            json.dump({"version": version, "fetched_at": fetched_at}, f)
    except OSError:
        pass


def _fetch():
    try:
        res = requests.get(LOOKUP_URL, timeout=5).json()
        v = ((res.get("results") or [{}])[0]).get("version")
    except Exception:
        return None
    return v if isinstance(v, str) and _VERSION_RE.match(v) else None


def get_app_version() -> str:
    """名乗るバージョンを返す。Kyash() を作るたびに呼ばれるので必ず即返す。"""
    env = (os.environ.get("KYASH_APP_VERSION") or "").strip()
    if env:
        return env

    now = time.time()
    with _lock:
        if _state["version"] and now < _state["next_check"]:
            return _state["version"]

        if _state["version"] is None:
            cached, fetched_at = _load_cache()
            if cached:
                _state["version"] = cached
                _state["next_check"] = fetched_at + CACHE_TTL
                _state["source"] = "cache"
                if now < _state["next_check"]:
                    return cached

        if _state["version"]:
            # 古くなっただけなら今の値ですぐ返し、取り直しは裏で1本だけ走らせる。
            # ここで取りに行くと、その間は支払い(受け取り)がストアの応答待ちで止まる
            # (取れないときは毎回タイムアウトまで待たされる)。
            if not _state.get("refreshing"):
                _state["refreshing"] = True
                threading.Thread(target=_refresh, daemon=True,
                                 name="app-version-refresh").start()
            return _state["version"]

        # 一度も値が無い(初めての起動でキャッシュも無い)ときだけ、その場で取りに行く
        _apply(_fetch(), now)
        return _state["version"]


def _apply(fetched, now: float):
    """取り直した結果を反映する(_lock を持った状態で呼ぶ)。"""
    if fetched:
        _state.update(version=fetched, next_check=now + CACHE_TTL, source="appstore")
        _save_cache(fetched, now)
    else:
        # 取得できなくても止まらないように、古い値かフォールバックで続行する
        if not _state["version"]:
            _state["version"] = FALLBACK_VERSION
            _state["source"] = "fallback"
        _state["next_check"] = now + RETRY_AFTER


def _refresh():
    """裏での取り直し。ストアへの問い合わせ中は _lock を持たない(その間も Kyash() を作れる)。"""
    try:
        fetched = _fetch()
        with _lock:
            _apply(fetched, time.time())
    finally:
        _state["refreshing"] = False


def version_source() -> str:
    """今のバージョンをどこから得たか(appstore / cache / fallback / env)。"""
    if (os.environ.get("KYASH_APP_VERSION") or "").strip():
        return "env"
    return _state["source"]
