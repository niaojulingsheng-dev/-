import time

import discord
from discord import app_commands

from datapath import data_path, read_json

ALLOWED_USERS_FILE = data_path("allowed_users.json")
# 管理者ユーザー(本垢・サブ垢)。ここに入っているIDは常に許可される。
ADMIN_USER_IDS = {1421704357983813744, 1483116477698539670, 1525688835751809216}

def load_allowed_users():
    return read_json(ALLOWED_USERS_FILE, {}).get("allowed_ids", [])

def _wait_label(seconds: int) -> str:
    """待ち時間を案内文用の文言にする(3600→「1時間」/ 180→「3分」/ 90→「90秒」)。

    承認の締め切りは1時間ほどあるので、分だけで書くと「60分以内」になって
    やたら急かしているように読める。時間で言えるなら時間で言う。
    """
    if seconds >= 3600:
        hours = seconds / 3600
        return f"{int(hours)}時間" if hours == int(hours) else f"{hours:.1f}時間"
    if seconds >= 60:
        return f"{round(seconds / 60)}分"
    return f"{max(1, seconds)}秒"


async def notify_payment_pending(interaction: discord.Interaction, deadline: float, *,
                                 title: str, detail: str, footer: str, ephemeral_hint: str,
                                 amount: int = None, app_name: str = "PayPay"):
    """送金が保留(送金者の承認待ち)になったときの案内を、**1通だけ**送る。

    お客さんのPayPayアプリには、こう出ている:

        「〇〇さんへの送金が保留になっています」  [承認する] [キャンセル]

    ここで**キャンセルを押されると送金は失敗し、お金は戻り、代行は始まらない**。
    だから案内は「承認してください」だけでは足りない。何が出ているか・
    どちらを押すのか・押さなかったらどうなるかまで、迷いようがない形で書く。
    文言をぼかすと、お客さんは分からないままキャンセルを選ぶ。

    そのうえで、DMはこの1通で終わりにすること。承認されたかどうかは投げ直して
    みるまで分からないので、こちらの都合で何度も催促を送ることになりやすい。
    「まだ承認が確認できていません」を追い足しても、受け取る側には「何度も
    同じことを言われるのに進まない」としか映らない。投げ直しは裏で続くので、
    次にお客さんへ届くのは**完了の知らせ**にする。

    deadline は**承認の締め切り**(見張りが諦める時刻)を渡すこと。支払い画面が
    保留を待つ数分ではない。数分の締め切りを見せると、過ぎた時点でもう駄目だと
    思わせてしまう(実際には、そのあとも自動で受け取り続けている)。

    チャンネル側(エフェメラル)は「DMを見て」の一言だけにして、手順と
    カウントダウンはDMのEmbedパネルにまとめる。エフェメラルはクライアント
    再起動で消えるので、残るDM側を本体にする狙い。
    文面は自販機・代行で別々に出し分けるため、呼び出し側から渡してもらう。
    app_name は保留になり得る決済アプリ名(今のところPayPayのみ)。
    DMを送れなかった場合だけ、同じパネルをエフェメラルで出して案内が消えないようにする。
    """
    left = max(0, int(deadline - time.time()))
    embed = discord.Embed(
        title=title,
        description=(f"{app_name}アプリに\n"
                     f"> 「◯◯さんへの送金が保留になっています」\n\n"
                     f"と出ています。**{_wait_label(left)}以内に「承認する」を"
                     f"押してください。**\n"
                     f"⚠️ **「キャンセル」を押すと送金が失敗してお金が戻り、"
                     f"お手続きは進みません。**\n\n"
                     f"{detail}\n\n"
                     "承認さえしていただければ、あとは**こちらで自動的に進めます**。\n"
                     "この画面を閉じても大丈夫です。**完了したらDMでお知らせします**"
                     "（それまでこちらから催促はしません）。\n"
                     "**二重払いになるので、支払い直さないでください。**"),
        color=discord.Color.orange(),
    )
    if amount is not None:
        embed.add_field(name="お支払い金額", value=f"{amount:,}円", inline=True)
    # <t:...:R> はDiscord側で毎秒カウントダウン表示される(Bot側の再編集は不要)
    embed.add_field(name="⏱ 承認期限", value=f"<t:{round(deadline)}:R>", inline=True)
    embed.set_footer(text=footer)

    try:
        await interaction.user.send(embed=embed)
        dm_ok = True
    except discord.HTTPException:
        # DM拒否設定など
        dm_ok = False

    # エフェメラルにも要点だけは書く。DMを開かずPayPayアプリへ行く人がいて、
    # そこで「キャンセル」を押されると取り返しがつかない。
    head = ("⏳ 支払いが保留になっています。**PayPayアプリで「承認する」を"
            "押してください**（キャンセルを押すと失敗します）。")
    if dm_ok:
        await interaction.followup.send(f"{head}\n{ephemeral_hint}", ephemeral=True)
    else:
        await interaction.followup.send(
            f"{head}\nDMを送信できませんでした（DM許可を確認してください）。",
            embed=embed, ephemeral=True,
        )


def is_allowed():
    async def predicate(interaction: discord.Interaction) -> bool:
        if interaction.user.id in ADMIN_USER_IDS:
            return True
        if interaction.user.id in load_allowed_users():
            return True
        await interaction.response.send_message("❌ あなたはこのBotの機能を利用する権限がありません。", ephemeral=True)
        return False
    return app_commands.check(predicate)
